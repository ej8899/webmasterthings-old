	<center>
	<p>&nbsp;
	<p>&nbsp;
	<p>&nbsp;
	<p>&nbsp;
	<center><a href="http://www.internetunderground.com/scripts/">phpBannerExchange</a> version <? echo "$script_version"; ?><br>
	Administered by: <a href="mailto:<? echo "$owner_email"; ?>"><? echo "$owner_name" ?></a>
	</center>