
<?
/////////////////////////////////////////////////
//              phpBannerExchange              //
//              A Free Script by:              //
//                                             //
// darkrose - darkrose@internetunderground.com //
//       lazurus - lazurus@rustedgate.com      //
//                                             //
// Updates and future versons can be found at: //
// http://www.internetunderground.com/scripts/ //
//                                             //
// This script is covered under the GNU GPL.   //
//                                             //
// If you modify this script, please make your //
// code available to us! We are not programmers//
// by trade, so there's bound to be bugs and   //
// inefficient code, but we're trying!         //
/////////////////////////////////////////////////

include("config.php");
?>
<html><head><title><? echo "$exchange_name"; ?> - Terms and Conditions</title><LINK REL=stylesheet HREF="style.css" TYPE="text/css">
</head>
<body>
<br><br>
    <center>
<table width="80%" cellpadding="0" cellspacing="1" border="0" bgcolor="#333333" class="windowbg"><tr><td>
    <center><TABLE width="100%"><TR><TD BGCOLOR="#222222"><CENTER><h3>Member Agreement</h3></CENTER></TD></TR></TABLE></center>
    <table width="100%" cellpadding="5" cellspacing="1" border="0" bgcolor="#000000"><tr><td>
All members of <? echo "$exchange_name"; ?> are required to agree to the following Terms and Conditions. Anyone determined by <? echo "$exchange_name"; ?> administrators to have violated these terms and conditions is subject to being banned from <? echo "$exchange_name"; ?> without any obligation by <? echo "$site_name"; ?> to redeem any earned credits.<br><br>
Members agree to include the full unmodified HTML code provided by us for displaying banner ads on their web site, in as many or few pages as they wish.  We reserves the right to verify the correctness of its HTML code through any means.<br><br>
<b>Members acknowledge that <? echo "$exchange_name"; ?> is a free service. At any time, this free service can be revoked for any reason the adminstrators see fit.</b><br><br>
A member may not artificially inflate traffic counts to his/her site using a device, program, or other means. A member may not insert more than one exchange HTML code on any page. A member may not include the banner exchange HTML code on any pages that automatically reload or go to another page without interaction from the user (i.e., client pull or server push) or on a page which is inaccessible to the general surfing population including but not limited to pop-up windows and hidden frames. A member may not place his/her banner exchange HTML code on pages that are unrelated to the site being advertised. Anyone found in violation of these policies will be banned from <? echo "$exchange_name"; ?> and will forfeit any credits pending on his/her account.<br><br>
Members acknowledge and agree that their web site information (name, URL, traffic counts, etc.) may be utilized by <? echo "$site_name"; ?>. Possible uses include (but are not limited to) lists of the busiest sites, lists of member sites, etc. <br><br>
All members agree to utilize the services of this banner exchange program at their own risk.  <? echo "$exchange_name"; ?>, its administrators, <? echo "$site_name"; ?> and it's partners cannot be held liable for any damage or loss of information that may occur from the use of the services of this banner exchange program.<br><br> 
Although we will make a reasonable effort to provide a high standard of quality for our services, we make no guarantees of any kind regarding the dependability, accuracy, or timeliness of the services. <br><br>
Anyone found in deliberate violation of these terms and conditions is subject to being banned from <? echo "$exchange_name"; ?> and forfeit any credits pending on his/her account.<br><br>
You agree to defend, indemnify and hold <? echo "$exchange_name"; ?> and its sponsors (<? echo "$site_name"; ?>) harmless from and against any and all claims, losses, liability costs and expenses (including but not limited to attorneys' fees) arising from your violation of this Agreement or any third-party's rights, including but not limited to infringement of any copyright, violation of any proprietary right and invasion of any privacy rights. This obligation will survive any termination of this Agreement. <br><br>
<center><a href="signup.php"><b>I agree</b></center></td></tr></table>