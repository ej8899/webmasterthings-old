<?php

/*
  ===========================

  Search Engine friendly URLs for boastMachine v3.0+
  Released : Sunday, January 09th 2005 ( 01/09/2005 )
  http://boastology.com

  Coded by Kailash Nadh
  Email   : kailash@bnsoft.net
  Website : www.kailashnadh.name
			www.bnsoft.net
			www.boastology.com

  boastMachine is a free software and is licensed under GPL (General public license)

  Install instructions for this mod can be found within the zip of this script.

  ===========================
*/

	include_once dirname(__FILE__)."/config.php";
	include_once dirname(__FILE__)."/$bmc_dir/main.php";

	$per_page=$bmc_vars['p_page'];
		// Number of entries per page;

	$path="archive";
		// Name for 'VIRTUAL' the archive directory. If you change this, you should do the same in the .htaccess file
		// eg: archive, posts, lists...
		// your html files will appear as http://site.com/bmachine/archive/my-first-post-1.html


	// ========================= Code begins here =======================

	if(isset($_SERVER['REQUEST_URI'])) {
		$req=$_SERVER['REQUEST_URI'];
	} else {
		$req=null;
	}

	$req=explode("/",$req);
	$req=$req[count($req)-1];
	$req=str_replace(".html","",$req);
	$req=str_replace(".htm","",$req);
	$req=explode("-",$req);

	if($req[0] == "bmc_page") {
		$page=$req[1];
	} else {
		$id=$req[count($req)-2];
		$blog=$req[count($req)-1];
	}


	if(isset($id) && is_numeric($id) && isset($blog) && is_numeric($blog)) {
		$blog_info=$db->query("SELECT blog_file FROM ".MY_PRF."blogs WHERE id='{$blog}' AND frozen='0'", false);
		if(!empty($blog_info['blog_file'])) {
			$_GET['id']=$id;
			include_once dirname(__FILE__)."/".$blog_info['blog_file'];
			exit;
		}
	}


	if(!isset($page) || $page < 0 || !is_numeric($page)) { $page=1; }
	$start=($page*$per_page)-$per_page;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title><?php echo $lang['archive']; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<style type="text/css">
	<!--
	body, br, p, html {
		font-family: verdana;
		font-size: 10px;
		background: #F7F7F7;
	}

	a {
		color: #cc3333;
		font-size: 12px;
		font-weight: bold;
	}
	//-->
	</style>

</head>
<body>

<?php
	$sql=$db->query("SELECT title,id,date,blog FROM ".MY_PRF."posts WHERE status != '0' ORDER BY date DESC LIMIT $start,$per_page");
	$total=$db->row_count("SELECT id FROM ".MY_PRF."posts WHERE status != '0'"); // Total number of entries

	$item=null;
	$f_name=null;
	for($n=0;$n<count($sql);$n++) {
		$item=$sql[$n];
		$f_name=bmc_SE_friendly_url($item['title']);
		echo "<a href=\"".$bmc_vars['c_url']."/{$path}/{$f_name}-{$item['id']}-{$item['blog']}.html\" title=\"{$item['title']}\">{$item['title']}</a><br />".bmcDate($item['date'])."<br /><br />\n";
	}

?>
<br /><br /><br />
<?php

	for($n=1;$n<($total/$per_page);$n++) {
		echo "<a href=\"".$bmc_vars['c_url']."/{$path}/bmc_page-{$n}.html\" title=\"bmc_page-{$n}.html\">Page {$n}</a>&nbsp;,&nbsp;";
	}

?>
</body>
</html>