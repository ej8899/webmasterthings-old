Search Engine friendly URLs mod for boastMachine v3.0+

Coded by Kailash Nadh
mail@kailashnadh.name

http://boastology.com
http://kailashnadh.name

=========================================================

This simple mod will make your boastMachine even more search friendly :)
Your posts's permalinks like 
	http://site.com/blog/?id=26
will change to
	http://site.com/blog/archive/my-post-title-26.html

that is 100% search engine friendly!

=========================================================

INSTALLATION
============

This package consists of 2 files, .htaccess and archive.php

1 )
First, you need to open archive.php and IF NECESSARY, change the virtual directory name from 'archive'
to something else. If you do so, you need to open the .htaccess and CHANGE
	RewriteRule ^archive/ archive.php [L]
to
	RewriteRule ^your_custom_name/ archive.php [L] 

2 )
Now open ./bmc/functions.php in your blog directory
Goto the last line and just above ?> , enter this code

/********* SE FRIENDLY CODE BEGINS **********/

	function bmc_SE_friendly_url($s) {
		$abc = "1234567890abcdefghijklmnopqrstuvwxyz";
		$s = strtolower($s);
		$r = "";
		for($i=0;$i<strlen($s);$i++)
			{
			if (strpos($abc,$s[$i])!==false)
				$r .= $s[$i];
			if (($s[$i]==' ')&&($r[strlen($r)-1]!=' '))
				$r .= ' ';
			}		
		$r = trim($r);
		return str_replace(' ','-',$r);
	}

/********* SE FRIENDLY CODE ENDS **********/

3 )
Upload archive.php and .htaccess to your boastMachine directory, i.e /blog or whatever it is
(This needs to be in your blog's parent directory)

Thats it ! Now you can goto yoursite.com/blog/archive to see all your posts listed in orders with SE friendly URLS


