<div id="error_msg">
<div class="bold_red">
<?php echo $title; ?>
</div> <br /><br />

<?php echo $desc; ?>
</div>