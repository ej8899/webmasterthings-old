

</div> <!-- end content //-->

</div> <!-- end main //-->

<div id="footer">
Powered by <a href="http://boastology.com" title="boastMachine :: powering the best blogs!">boastMachine <?php echo BMC_VERSION; ?></a>

<script type="text/javascript">
<!--
	// LOG THE REFERER !
	document.write("<img src=\"<?php echo $bmc_vars['c_urls']."/".BMC_DIR."/reflog.php?i=".$_SERVER['HTTP_REFERER']; ?>\" height=\"1\" width=\"1\" />");
//-->
</script>

</div> <!-- end footer //-->

</div> <!-- end wrap //-->
</body></html>