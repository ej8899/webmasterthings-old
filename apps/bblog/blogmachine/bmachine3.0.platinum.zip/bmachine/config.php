<?php

	$bmc_dir="bmc";

	// The name of the 'bmc' directory.
	// Only need to be changed if you rename the directory

?>