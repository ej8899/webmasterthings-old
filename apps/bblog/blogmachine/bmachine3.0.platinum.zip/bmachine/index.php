<?php

	// Static loader for blog 'My first blog' (Blog created Created on September 18, 2004, 7:41 pm
	$blog_id=1;
	include dirname(__FILE__)."/bmc/start.php";

?>