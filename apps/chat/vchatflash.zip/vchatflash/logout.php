<?
header("Expires: ".gmdate("D, d M Y H:i:s")."GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
?>

<?
$nickname = str_replace ("\n"," ", $nickname);
$nickname = str_replace ("<", " ", $nickname);
$nickname = str_replace (">", " ", $nickname);
$nickname = stripslashes ($nickname);
?>

&login=
<?
$date = date( "H:i");
$chat_file = "login.txt";
$chat_lenght = 10;
$max_single_msg_lenght = 50000;
$max_file_size = $chat_lenght * $max_single_msg_lenght;
$file_size= filesize($chat_file);
if ($file_size > $max_file_size) {
$lines = file($chat_file);
$a = count($lines);
$u = $a - $chat_lenght;
for($i = $a; $i >= $u ;$i--){
$msg_old =  $lines[$i] . $msg_old;
}
$deleted = unlink($chat_file);
$fp = fopen($chat_file, "a+");
$fw = fwrite($fp, $msg_old);
fclose($fp);
}

if ($nickname != ""){
$fp = fopen($chat_file, "a+");
$fw = fwrite($fp, "$date - $nickname exits\n");
fclose($fp);}
$lines = file($chat_file);
$a = count($lines);
$u = $a - $chat_lenght;
for($i = $a; $i >= $u ;$i--){
echo $lines[$i];
}
?>