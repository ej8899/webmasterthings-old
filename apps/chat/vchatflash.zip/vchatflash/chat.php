<?
header("Expires: ".gmdate("D, d M Y H:i:s")."GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
?>
<?

/*        Modified By CgiXp Team : http://www.cgixp.vze.com */
/*        Original script by Nicola Delbono <key5@key5.com>        */
?>

<?
$nickname = str_replace ("\n"," ", $nickname);
$nickname = str_replace ("<", " ", $nickname);
$nickname = str_replace (">", " ", $nickname);
$nickname = stripslashes ($nickname);
?>

&output=
<?
$chat_file = "chat.txt";
$chat_lenght = 40;
$max_single_msg_lenght = 100000;
$max_file_size = $chat_lenght * $max_single_msg_lenght;
$file_size= filesize($chat_file);
if ($file_size > $max_file_size) {
$lines = file($chat_file);
$a = count($lines);
$u = $a - $chat_lenght;
for($i = $a; $i >= $u ;$i--){
$msg_old =  $lines[$i] . $msg_old;
}
$deleted = unlink($chat_file);
$fp = fopen($chat_file, "a+");
$fw = fwrite($fp, $msg_old);
fclose($fp);
}
$msg = str_replace ("\n"," ", $message);

$msg = stripslashes ($msg);
if ($msg != ""){
$fp = fopen($chat_file, "a+");
$fw = fwrite($fp, "$nickname : $msg\n");
fclose($fp);}
$lines = file($chat_file);
$a = count($lines);
$u = $a - $chat_lenght;
for($i = $a; $i >= $u ;$i--){
echo $lines[$i];
}

?>