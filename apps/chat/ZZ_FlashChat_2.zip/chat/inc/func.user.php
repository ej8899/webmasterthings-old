<?
# -- USER-MANAGEMENT----------------------------------------------------------------------------------

$sql = 'DELETE FROM '. $userdat ." WHERE status<0"; 	# -- delete all kicked users and users that are still listed after chat was closed last time
mysql_query($sql, $db);

$sql = 'SELECT * FROM '.$userdat.' WHERE user!=\'admin\' ';				# -- Get all user data
$result = mysql_query($sql, $db);
$user_num = mysql_num_rows($result);
if ($result) {
	while ($row = mysql_fetch_array($result, MYSQL_NUM)) { 
		$user_data[] = $row;  
	}  # END WHILE
}	# END IF RESULT


$timenow = time();														# -- Create Timelimit with UNIX Timestamp
$timelimit = $timenow - ($mindelete * 60); 								# -- timelimit = 'mindelete' minutes (e.g. 5 min) without message until you get kicked

# -- USER-SECURITY-FUNCTION ----------------------------------------------------------------------------------																	
# -- If somehow a user did not logout he will be deleted, when he is in the chat for 5 minutes without sending a message

if($user_num > 0) { 													# -- if an user is in the chat
	$mes = array();
	for($i=0; $i <= ($user_num-1); $i++) { 									# -- go through array of every user logged in
		
		$logintime = strtotime($user_data[$i][1]);
		if($logintime < $timelimit) {												# -- if user is in chat for over 'mindelete' minutes;
					
			$sql = 'SELECT max(ID) FROM '.$msgdat." WHERE user='".$user_data[$i][2]."'";
			$result = mysql_query($sql, $db);
			$row = mysql_fetch_array($result, MYSQL_NUM);
	
			$sql = 'SELECT time FROM '.$msgdat." WHERE ID='".$row[0]."'";			# -- select posting-time of the last message of this user
			$result = mysql_query($sql, $db);
			$row = mysql_fetch_array($result, MYSQL_NUM);				
				
			if($row[0]!=0){ 
				$last_msg_time = strtotime($row[0]);								# -- check the posting-time of the user's last message
			} else {
				$last_msg_time = 0;													# -- if there is no last message, last message time is set to 0
			}
			
			if($last_msg_time < $timelimit) {										# -- if last message time is under timelimit: kick user !
				$sql = 'UPDATE ' . $userdat . ' SET status=\'-3\' WHERE user=\''.$user_data[$i][2].'\'';
				$result = mysql_query($sql, $db);
				$mes[] = $user_data[$i][2];
			}	
		} # END if user is in for over 5 min
	}# END for
} else { # END if user_num > 0
	if($killmessages) {
		$sql = 'DELETE FROM '. $msgdat; 										# -- delete all remaining messages if there is no user left in the chat
		mysql_query($sql, $db);
	}
}
?>