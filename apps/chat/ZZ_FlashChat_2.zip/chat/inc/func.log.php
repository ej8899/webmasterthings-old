<?
		$handle = opendir ('./');												#
		
		while (false !== ($entry = readdir ($handle))) { #-- Read all files untill false
		if (!is_dir($entry)) {         					#-- Alle Files listen
			if(strtolower(strrchr($entry, '.')) == '.htm') {
				$end = strtolower(strrchr($entry, '+'));
				$end = ereg_replace('.htm', '', $end);
				$index[0][] = $entry;
				$index[1][] = $end;
			} # 
		} # is dir
		$data = fopen('./log/log.htm',"a");
		$send = "<b>$username</b> <font size=-2>| $ip <b>|</b> [$date] |</font> - <b>$message </b><br>\n";
		fputs($data, $send);
		fclose($data);
?>