<?
function disapear() {												# inchat messages like 'loading admin ...
																	# will disapear earlier than chat-messages
	global $minremain;
	$timenow = time();
	$time = (($timenow - ($minremain * 60))+20);
	$time = date("Y-m-d H:i:s", $time);
	return $time;
}

if($message != '') { 												# -- if message is send and not empty

	$message = strip_tags($message, '<b> <br> <i>');				# -- strip 'bad' tags
	$sql = 'SELECT max(ID) FROM '.$msgdat;							# -- Create Unique ID for Database
	$result = mysql_query($sql, $db);
	$row = mysql_fetch_array($result, MYSQL_NUM);

		if($row[0] != 0 && $row[0] < 8000) {							# if message id (i.e. a message) exists
			$msg_id = $row[0]+1;
		} else {														# if NO message id (i.e. no message) exists
		$msg_id = 1;												#
	}																# -- END: Create Unique ID for Database
	
	$user=array();
	$sql = 'SELECT * FROM '.$userdat;								# -- Get all current users
	$result = mysql_query($sql, $db);
	if ($result) {
		while ($row = mysql_fetch_array($result, MYSQL_NUM)) { 
					$user[] = $row;  
		}  # END WHILE
	}

	$date = strftime("%Y-%m-%d %H:%M:%S");
##------------------------------------------------------------------ Command-Line
if(substr($message,0,1) == '/') {
	$message = substr($message,1,strlen($message)); # erstes zeichen = '/' entfernen
	$command = explode(':', $message);
	
	if(strtolower($command[0]) == 'admin') {
		$pass = md5((chop($command[1])).(chop($command[2])));#
		$message = 'loading Admin ...';
		$target = $user_id;
		$date = disapear();
		echo '&admin=YES';
		echo '&pass='.$pass;
	} elseif(strtolower($command[0])  == 'help') {
		$message = 'loading help ...';
		$target = $user_id;
		$date = disapear();
		echo '&help=YES';
	} else {
		$re_ids = array();
		$match = 0;
		for($i=0; $i <= (count($command)-1); $i++) {
			for($j=0; $j <= (count($user)-1); $j++) {
				if($command[$i] == $user[$j][2]) {
					$re_ids[] = $user[$j][0];
				}
			}
		}
		if((count($re_ids)) == (count($command)-1) && count($command)-1 != 0){
			$message = array_pop($command);
			$command = implode(', ', array_unique($command));
			$message = $username.' <i>whispers to</i> '.$command.' : '.$message;
			$re_ids = array_unique($re_ids);
			$target = (implode('|', $re_ids)).'|'.$user_id;
		} else {
			array_pop($command);
			$command = '/'.(implode(':', $command)).':';
			$message = '<b>ERROR:</b> Unknown command or Unknown user: " '.$command.' "';
			$target = $user_id;
			$date = disapear();
		}	
	}
##------------------------------------------------------------------ Normal-Messages
} else {
	$message = $username.' : '.$message;
	$target = 'all';
}	

## Bad words filter ###############################################################
if($badwords) {
	$badwords = explode(',', $badwords);
	for($i=0; $i <= (count($badwords)-1); $i++) {
			$add = '';
		for($j=1; $j <= strlen($badwords[$i]); $j++){
			$add .= '*';
		}
		$replace = substr($badwords[$i],0,1).$add;
		$message = eregi_replace($badwords[$i], $replace, $message);
	}
}
###################################################################################	
	
	$sql = 'INSERT INTO ' . $msgdat . " (ID, time, user, msgtext, target) VALUES ('".$msg_id."', '". $date ."', '". $username ."', '" . $message . "', '".$target."' )";
	$result = mysql_query($sql, $db);										# -- END: Connect Database and fullfill SQL action


	if ($log_data == '1') { 												# -- CHAT-DATA-LOG-FUNCTION (if logging is on)
		## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
		include('inc/inc.log.php'); # Read Log-Function
		## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""															#
	}																		# -- END: CHAT-DATA-LOG-FUNCTION (if logging is on)
} # END if message != 0
?>