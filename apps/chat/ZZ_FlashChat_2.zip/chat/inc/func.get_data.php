<?
$data=array();
$user=array();
																		
$sql = 'SELECT * FROM '.$userdat.' WHERE user !=\'admin\' ORDER BY user';	# -- read userlist
$result = mysql_query($sql, $db);				
if ($result) {
	while ($row = mysql_fetch_array($result, MYSQL_NUM)) { 
		$user[] = $row;  
	}  # END WHILE
}	# END IF RESULT

$userstat = 0;
if($user) { 
	$userlist = array();
	for($i=0; $i <= (count($user)-1); $i++) {
		if ($user[$i][4] != 0) { 										# if username != 0 --> banned, kicked, etc. = not online
			if($user[$i][0] == $user_id) {
				$userstat = $user[$i][4];
			}
		} else {
			$userlist[] = $user[$i][2];
		}
	}
	$usercount = count($userlist);
}

if($chatspeed_percent) {												# -- adjust CHAT SPEED --------
	$chatspeed = $chatspeed + round($chatspeed/100 * ((count($userlist)-1) * $chatspeed_percent));
}

$sql = 'SELECT max(ID) FROM '.$msgdat;
$result = mysql_query($sql, $db);
$id_max = mysql_fetch_array($result, MYSQL_NUM);

$sql = 'SELECT * FROM '.$msgdat.' ORDER BY ID';
$result = mysql_query($sql, $db);
if ($result) {
	while ($row = mysql_fetch_array($result, MYSQL_NUM)) { 
		$data[] = $row;  
	}  # END WHILE
}	# END IF RESULT	
		
		
$timenow = time();														# -- Create Timelimit with UNIX Timestamp
$timelimit = $timenow - ($minremain * 60);								# -- END: Create Timelimit with UNIX Timestamp

if($data && $userstat == 0) {
	$output = '';																# -- If Data exists, create Output
	while (list ($key, $val) = each ($data)) { 									# -- Get every chat-message from MySQL
		if(strtotime($val[1]) >= $timelimit) {										# -- If message is inside the timelimit, create formated Output
			if($val[4] == 'all' || ereg($user_id, $val[4])) {
				if(ereg(':', $val[3]) && substr($val[3],0,9) != '<b>ERROR:') {
					$count = strpos($val[3], ':');
					$first = substr($val[3],0,$count);
					$second = substr($val[3],($count+1),strlen($val[3]));
					$output .= $fdata01.$first.$fdata02.$second.$fdata03.'<br>';
				} else {
					$output .= '<font color="'.$msg_color.'">'.$val[3].'</font><br>';
				}
			}
		} else {																	# -- If message is NOT inside the timelimit, delete it
			$sql = 'DELETE FROM ' . $msgdat . ' WHERE ID=\'' . $val[0] .'\'';	
			mysql_query($sql, $db);
		} # end strtotime														#	
	} # end while																#-- END: Get every chat-message from MySQL


	if($loc != 'main') { # if data is send to flash-file						#-- If get_data-function is called from flash, create output
		$userlist = implode(':', $userlist);
		echo '&output='. (urlencode($output));
		echo '&usercount='.(urlencode($usercount));
		echo '&userlist='.(urlencode($userlist));
		echo '&id_max='.$id_max[0];
		echo "&chatspeed=$chatspeed";
		echo "&userstat=$userstat";
		echo '&loading=NO';
	}																			#-- END: If get_data-function is called from flash, create output
} else { # end if data															# -- END: If Data exists, create Output
	echo "&userstat=$userstat";
	echo '&loading=NO';
}
?>