<?
$handle = opendir ('./');												#
$data = fopen('./log/log.htm',"a");
$send = "<b>$username</b> <font size=-2>| $ip <b>|</b> [$date] |</font> - <b>$message </b><br>\n";
fputs($data, $send);
fclose($data);
?>
