<?
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

if ($server && $user && $password) {
	if(@mysql_connect($server,$user,$password)) {
		$db = mysql_connect($server,$user,$password);
		$dat = mysql_select_db($datab);
																	# -- Get USER-MANAGEMENT function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./func.user.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

if($mes) {
																	# -- Create Message 'was kicked due to inactivity !'
$message = '<i>[<b>'.(implode(', ', $mes)).'</b> was kicked due to inactivity !]</i>';
$username = '[Chat]';
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./func.add_data.php'); # Include MySQL - Add Data Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
}
@mysql_close($db);
	 }
}
?>