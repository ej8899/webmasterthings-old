<?
if ($server && $user && $password) {									# -- Connect Database and get User-Data
	if(@mysql_connect($server,$user,$password)) {						#
		$db = mysql_connect($server,$user,$password);
		$dat = mysql_select_db($datab);
		
		## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
		include('./inc/func.user.php'); # Get User-Management-Function
		## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""		

# -- Check User-Data -------------------------------------------------------------------------------------
if($username) { 													# -- Check if chosen username was sent from flash
	$loginstat = 'go';
	
	if ($user_data) { 													#-- Check if an user online in chat (if there are other users online fullfill check)
		while (list ($key, $val) = each ($user_data)) { 					#-- one row of mysql-dataif 
				if($username == $val[2]) {								#-- Check if username is already chosen by another user
					$loginstat = 'inuse'; # Username in Use
				} 
				if($REMOTE_ADDR == $val[3]) {							#-- check if IP is already online in chat
					if($val[4] > 0) { 										# -- check if User is banned
						$loginstat = $val[4]; # = user is banned
					} else {
						$sql = 'DELETE FROM '. $userdat ." WHERE ip='". $REMOTE_ADDR ."'";
						$result = mysql_query($sql, $db);
						$loginstat = 'loggedin'; # IP already logged in
					}
				} # END Remote Addr	
		} # END while
	}	# END if data
	
	if($badwords) { 													# -- Badwords Filter
		$badwords = explode(',', $badwords);							#
	} else {
		$badwords = array();
	}
	$badwords[] = 'admin';
	$badwords[] = '/help';
	$badwords[] = '/user';
	$badwords[] = ':';
	
	for($i=0; $i <= (count($badwords)-1); $i++) {
		if(ereg($badwords[$i], strtolower($username))) {
			$loginstat = 'notallowed'; # Username not allowed
			$notallowed = "Change '$badwords[$i]' !";
		}																#
	}																	# -- End Badwords Filter
} # END if username

# -- END: Check User-Data -------------------------------------------------------------------------------------

	
if ($loginstat == 'go' || $loginstat == '1' || $loginstat == 'loggedin') {							#-- If userdata is ok, insert user-data into table and login 															
	$logintime = strftime("%Y-%m-%d %H:%M:%S");
	$id = md5($logintime.$REMOTE_ADDR);
	$sql = 'INSERT INTO '. $userdat ." (ID, logintime, user, IP, status) VALUES ('". $id ."', '". $logintime ."', '". $username ."', '". $REMOTE_ADDR ."', '0' )";	
	$result = mysql_query($sql, $db);
} # END if loginstat

	@mysql_close($db);													#-- END: Connect Database and get User-Data
	} # END IF CONNECT	
} # END IF SERVER + USER + PASSWORD
echo "&loading=NO";														#-- send user-info to flash
echo "&user_id=$id";
echo "&notallowed=$notallowed";
echo "&loginstat=$loginstat";
?>