<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
	<title>FlashChat - ERROR</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link href="inc/styles.css" rel="stylesheet" type="text/css">
	<SCRIPT LANGUAGE="JavaScript"><!--
	
	var width = window.screen.availWidth;
	x = width/2 - 325;
	var height = window.screen.availHeight;
	y = height/2 - 250;
	//--></SCRIPT>
	</head>
	<body bgcolor="#CC3300" scroll=no body onLoad="window.moveTo(x,y);resizeTo(650,500)">
	<table width="100%" height="90%" border="0" cellpadding="0" cellspacing="0">
	  <tr>
		<td align="center">
		<? echo $error ?>
		  </td>
	  </tr>
	</table>
	</body>
	</html>