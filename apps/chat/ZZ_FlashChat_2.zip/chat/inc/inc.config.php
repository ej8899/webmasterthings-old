<?
##############################################################################################
##								  - ZZ:FlashChat 2 -										##
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~##
## CONFIGURATION_FILE									  			script: |zehnet.de|  	##
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~##
##																							##
##   ZZ:FlashChat Version 2 																##
##   *PHP-based ChatScript with Flash-Interface*											##
##																							##
##   Copyright (c) 2002 # Nicolas Zeh <mail@zehnet.de>										##
##   																						##
##   This File is part of the distribution of ZZ:FlashChat 2. 								##
##   This License inlcudes all the other files of the distribution.							##
##   ZZ:FlashChat 2 is free software; you can redistribute it and/or modify					##
##   it under the terms of the GNU General Public License as published by					##
##   the Free Software Foundation; either version 2 of the License, or						##
##   (at your option) any later version.													##
##   																						##
##   This program is distributed in the hope that it will be useful,						##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of							##
##   MERCHANTABILITY. 																		##
##																							##
##   See the GNU General Public License for more details.									##
##   You should have received a copy of the GNU General Public License						##
##   along with this program [gpl.html]														##		
##   																						##
##------------------------------------------------------------------------------------------##
##							scripts at: | download.zehnet.de |								##
##------------------------------------------------------------------------------------------##
##																							##
##																							##
##																							##
## Pleas read this carefully !!																##
## The MAIN-Section contains variables that HAVE to be changed !							##
## The SUB-Section contains variables that CAN be changed !									##
##																							##
##																							##
##																							##
##------------------------------------------------------------------------------------------##
## MAIN: [Variables essential for the functionality of the program]							##
##------------------------------------------------------------------------------------------##
##																							##
## Servername for MySQL (is normaly localhost)												##
$server = 'localhost';																		##
## Your MySQL Username:																		##
$user = '';																					##
## Your MySQL Password:																		##
$password = '';																				##
## Your MySQL Database Where you want to store the FlashChat Tables							##
$datab = '';																				##
																							##
##------------------------------------------------------------------------------------------##
## SUB: [cosmetic Variables: not essential, but worth to play with ]						##
##------------------------------------------------------------------------------------------##
##																							##
## Name of the Message and user table in MySQL-Database.									##
## If you change the names here you have to rename them in MySQL							##
## If you have installed / will install the Tables via PHPMyAdmin with 'install.sql' 		##
## don't change anything.																	##
$msgdat = 'zz_messages';																	##
$userdat = 'zz_user';																		##
##																							##
##------------------------------------------------------------------------------------------##
##																							##
## ++++++ LOG-DATA-FUNCTION																	##
## If you want to log who writes and what is said in the chat, you can turn on				##
## LOG-function.																			##
## - ATTENTION -: If you enable the LOG-DATA-FUNCTION, 										##
## be sure that you chmod the directory 'log' to 777.										##
$log_data='0'; # if is set to '1' = logging enabled ; '0' = logging disabled				##
##																							##
##------------------------------------------------------------------------------------------##
##																							##
## ++++++ TIME UNTIL DELETE																	##
## $minremain describes the time in minutes that chat messages stay on screen				##
## until they are deleted.																	##
$minremain = '10'; # = minute(s) chatmessages should remain visible;						##
##																							##
## $mindelete describes the minutes a user can stay online in the chat without writing		##
## a message until he will be kicked														##
$mindelete = '5'; # = minutes until you get kicked when you are not talking					##
##																							##
## $killmessages defines wether 															##
## all messages should be deleted when nobody is in the chat [1] 							##
## or stay visible until they will be deleted by timelimit	[0]								##
## Uncomment it to activate it																##																					##
$killmessages = '0';																		##
##																							##
##------------------------------------------------------------------------------------------##
##																							##
## ++++++ COLOR OF CHAT-OUTPUT																##
## These three variables define the Output-Format of the chat-messages.						##
## The Output-Field in Flash supports HTML. 												##
## Only the following HTML-Tags are supported by Flash:										##
## [ <A> <B> <FONT COLOR> <FONT FACE> <FONT SIZE> <I> <P> <U> ] 							##
##																							##
## The variables are in the following order to the output:									##
## Output in HTML:																			##
# '<font color="#6699CC" face="Arial"><b>'*username*'</b></font>: '*message*'<br>';			##
## Output in Variables:																		##
## ' $fdata01 '*username*' $fdata02 '*message*' $fdata03 <br>';								##
## a '<br>'-tag for linebreak is already added at the end !!								## 
##																							##
$fdata01 = '<b><font color="#CCCC99" face="Arial">';										##
$fdata02 = '</font></b>';																	##
$fdata03 = '';																				##
##																							##
## Color of the InChat-Messages like 'loading Admin ...', 'loading Help ...', etc.			##
$msg_color = '#FFCC00';																		##
##																							##
##																							##
##------------------------------------------------------------------------------------------##
##																							##
## ++++++ HELP MENU																			##
##																							##
## Content of the HelpMenu of FlashChat:													##
$help_msg = '<b>Help:</b><br>
-----------------------------------------------------------------------------------------------------------------------------<br>
<b>[1] the title bar:</b><br>
----------------------------------------------<br>
Clicking on the QuestionMark on the left side of the title bar brings up the help. <br>(I assume you know that !).<br>
Moving over the cross in the corner of the rigth side brings up the LogoutDialog. Clicking on it will log you out of the chat.<br>
Clicking on User Online brings up a menu showing all users that are currently in the chat.<br>
By clicking on a username, you can send a private message to this user. (You can also send private messages to a couple of users)<br><br>
<b>[2] privat messages (whispering):</b><br>
----------------------------------------------<br>
A private message means that only you and the chatusers you specified can read the message have written.<br><br>
<b>[3] command line:</b><br>
----------------------------------------------<br>
You can also use the message input field as command line !??<br>
This means that you can call certain functions out of the inputfield.<br>
Every command begins with the sign \'/\':
a) You can call help by typing: <br>
<font face="Courier New, Courier, mono">/help</font><br><br>
b) You can send private messages by typing: <br>
<font face="Courier New, Courier, mono">/[targetuser01]:[targetuser02]:[etc]:[Your message to them]</font><br><br>
c) You can call th admin section by typing:<br>
<font face="Courier New, Courier, mono">/admin:[YourAdminName]:[YourAdminPassword]</font><br><br>
Everything in the [ ]-brackets is just a placeholder !<br>
-----------------------------------------------------------------------------------------------------------------------------
';																							##
##																							##
##------------------------------------------------------------------------------------------##
##																							##
## ++++++ CHATSPEED																			##
## the chatspeed defines how often the chat client calls the chat data on th server			##
## the speed ranges from 1 (fastest) to ~ ((indefinite) highest)							##
## reason for a fast speed is a better chat environment										##
## reason for a slower speed is to spare the server 										## 
## further information see readme.htm														##
$chatspeed = '5';																			##
##																							##
#$chatspeed_percent = '10'; 																##
##   defines how chat should slow down with one person more in the chat 					##
##   (5 means that the chat is 5% slower when another user comes in)						##
##   if there are 11 people chatting the chat speed is at 50% !								##
##   Uncomment it to use this function !!!													##
##																							##
##------------------------------------------------------------------------------------------##
##																							##
## ++++++ BAD WORDS FILTER																	##
## Below there is a list of comma-seperated bad words.										##
## You need to add your own list to it.														##
## But beware: IT'S CASE SENSITIVE															##
## That means that you can specifiy if a bad word matches only if it stands at the 			##
## beginning, in the middle or at the end of a word depending on a whitespace before or		##
## after the bad word !																		##
## e.g. ...,sex ,... matches sex but not sexy because of the whitespace at the end			##
## e.g. ...,fuck,... matches even a word like asfucker because whitespaces are not defined	##													
##																							##
$badwords = 'fuck,bitch,cunt,penis,shit';													##
##																							##
##------------------------------------------------------------------------------------------##
## CONFIGURATION END									  									##					
##############################################################################################
?>