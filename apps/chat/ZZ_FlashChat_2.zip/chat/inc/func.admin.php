<?
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

$sql = 'SELECT * FROM '.$userdat.' WHERE user=\'admin\'';

if ($server && $user && $password) {									#-- Connect Database and get User-Data
	if(@mysql_connect($server,$user,$password)) {						#
		$db = mysql_connect($server,$user,$password);
		$dat = mysql_select_db($datab);
		
		$result = mysql_query($sql, $db);
		$row = mysql_fetch_array($result, MYSQL_NUM);
		$cadminname =	chop($row[0]);
		$cadminpass= chop($row[3]);
		$check = md5($cadminname.$cadminpass);#
	}
}

if($pass) { # if password was sent
$pass = chop($pass);
if($check == $pass) { # if login is valid

echo '&adminlog=YES';

if($com == 'shkb') { # get user data - kick & bann ---------------------------------------------------------------
	
	$sql = 'SELECT * FROM '.$userdat.' WHERE user !=\'admin\' and status=\'0\'';
	$result = mysql_query($sql, $db);
	$user = array();
	if ($result) {
		while ($row = mysql_fetch_array($result, MYSQL_NUM)) { 
					$user[] = $row[2];  
		}  # END WHILE
	}
	$userlist = implode(':',$user);
	echo '&chat_userlist='.$userlist;

	
} elseif($com == 'kb') { # command - kick & bann ---------------------------------------------------------------
		$show='';
		$message=array();
		while(list($key, $var) = each($HTTP_POST_VARS)) {
			 if(substr($key,0,2) == 'zz') {
			 	$key = substr($key,2,strlen($key));
			 	if($var == '-2') {
					$sql = 'UPDATE ' . $userdat . ' SET status=\'-2\' WHERE user=\''.$key.'\'';
					$result = mysql_query($sql, $db);
					$show .= "- $key was kicked !<br>";
					
					$message[] = "<i>[<b>$key</b> was kicked !]</i>";
				} elseif($var > 0) {				
					$timenow = time();														# -- Create Timelimit with UNIX Timestamp
					$banntime = ($timenow - ($mindelete * 60))+($var * 60); # change logintime so user is deleted when bann is over
					$banntime = date("Y-m-d H:i:s", $banntime);
					
					$sql = 'UPDATE ' . $userdat . ' SET status=\''.$var.'\', logintime=\''.$banntime.'\' WHERE user=\''.$key.'\'';
					$result = mysql_query($sql, $db);
					$show .= "- $key was banned for $var minutes !<br>";
					
					$message[] = "<i>[<b>$key</b> was banned for <b>$var</b> minutes !]</i>";
				}
			}
		} # end while
		if($message[0]) {
					$message = implode('<br>', $message);
					$username = '[admin]';
					## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
					include('.././inc/func.add_data.php'); # Include MySQL - Add Data Function
					## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
		}
		echo "&show=<b>$show</b>";
	
} elseif($com == 'cc') { # command close chat ---------------------------------------------------------------
		if($chat == 'close') {
				$timenow = time();														# -- Create Timelimit with UNIX Timestamp
				$logintime = ($timenow - ($mindelete * 60))+30; # change logintime so user is deleted when bann is over
				$logintime = date("Y-m-d H:i:s", $logintime);
				$sql = 'UPDATE ' . $userdat . ' SET status=\'-1\', logintime=\''.$logintime.'\' WHERE user!=\'admin\'';
				mysql_query($sql, $db);
				$sql = 'UPDATE ' . $userdat . ' SET status=\'closed\' WHERE user=\'admin\'';
				mysql_query($sql, $db);
				echo '&show=The chat has been closed !';
		}
		if($chat == 'open') {
				$sql = 'UPDATE ' . $userdat . ' SET status=\'0\' WHERE user=\'admin\'';
				mysql_query($sql, $db);
				$sql = 'DELETE FROM ' . $userdat . ' WHERE user!=\'admin\'';
				mysql_query($sql, $db);
				echo '&show=The chat has been opened !';
		}
		echo '&loading=NO';

} elseif($com == 'al') { # command alter login  ---------------------------------------------------------------
			$newpassword = chop($newpassword);
			$retypedpassword = chop($retypedpassword);
			$adminname = chop($adminname);
			$oldpassword = chop($oldpassword);
			$newadminname = chop($newadminname);
		switch(TRUE) {
					case ($adminname == ''):
						$error = 'AdminName was not filled out !';
					break;
					case ($oldpassword == ''):
						$error = 'OldPassword was not filled out !';
					break;
					case ($newadminname == ''):
						$error = 'New AdminName was not filled out !';
					break;
					case ($newpassword == ''):
						$error = 'New AdminPassword was not filled out !';
					break;
					case ($retypedpassword == ''):
						$error = 'Retyped AdminPassword was not filled out !';
					break;
					}
		if(!$error) {
			$sql = 'SELECT ID, IP FROM '.$userdat.' WHERE user =\'admin\'';
			$result = mysql_query($sql, $db);
			$row = mysql_fetch_array($result, MYSQL_NUM);
			switch(TRUE) {
					case ($newpassword != $retypedpassword):
						$error = 'New and Retyped Passwords don\'t match !';
					break;
					case ($oldpassword != $row[1]):
						$error = 'Old AdminPassword is wrong !';
					break;
					case ($adminname != $row[0]):
						$error = 'Old AdminName is wrong !';
					break;
					default:
						$sql = 'UPDATE ' . $userdat . ' SET id=\''.$newadminname.'\', ip=\''.$newpassword.'\' WHERE user=\'admin\'';
						mysql_query($sql, $db);
						echo '&logupdate=update';
						#$error = 'LoginData was updated !';
			}
		}
		echo '&error='.$error;
	}  # end if command
	  
	} 
}
@mysql_close($db);
echo '&loading=NO';
?>	