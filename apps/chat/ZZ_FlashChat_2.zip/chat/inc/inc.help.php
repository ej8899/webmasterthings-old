<?
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
$help_msg = preg_replace('/\n/','',$help_msg); 				# -- Cutting off newlines				
echo "&help_msg=$help_msg";									# -- Send help data to Flash
echo "&helploading=NO";
?>