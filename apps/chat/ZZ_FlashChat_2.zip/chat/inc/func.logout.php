<?
		$sql = 'SELECT * FROM '.$userdat." WHERE ID='". $user_id ."'";
		$del_sql = 'DELETE FROM '. $userdat ." WHERE ID='". $user_id ."'";
			
		$result = mysql_query($sql, $db);
		$data = mysql_fetch_array($result, MYSQL_ASSOC);
		
if($data['status'] < 3) {
		$delete = mysql_query($del_sql, $db);												#-- END: Connect Database and fullfill SQL-Action

		if($data) {														#-- If Data returned, create 'left the room' message
			$logouttime = strftime("%H:%M:%S");
			$message = "<i>[left the room at $logouttime]</i>";
			$username = $data['user'];
			$logintime = substr($data['logintime'],11,19);
			## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
			include('./inc/func.add_data.php'); # Include MySQL - Add Data Function
			## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
		}
		echo "&username=".(urlencode($username));
		echo "&logintime=$logintime";
		echo "&logouttime=$logouttime";
		echo "&loading=NO";												#-- If Data returned, create 'left the room' message
} else {
		echo "&adminaction=YES";
}
?>