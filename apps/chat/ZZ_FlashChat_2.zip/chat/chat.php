<?
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

# -- LOGIN ----------------------------------------------------------------------------------
if($com=='login') {
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/func.login.php'); # Include MySQL - Login Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
} else {

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if($user_id) {														# -- IF user_id is send

if ($server && $user && $password) {									# -- Database Connection
	if(@mysql_connect($server,$user,$password)) {						#
		$db = mysql_connect($server,$user,$password);
		$dat = mysql_select_db($datab);
		
		$sql = 'SELECT * FROM '.$userdat." WHERE ID='".$user_id."'";
		$result = mysql_query($sql, $db);
		$data = mysql_fetch_array($result, MYSQL_ASSOC);
		
		if($data) {													# -- IF user_id is valid															

# -- OPEN FROM MAINPAGE ------------------------------------------------------------------------
if($com=='open') { 

$logintime = $data['logintime'];
$username = $data['user'];
$ip = $data['IP'];
$message = "<i>[entered the room at $logintime]</i>";
$loc = 'main'; # send identification 'main' to get datafunction

## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/func.add_data.php'); # Include MySQL - Add Data Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/func.get_data.php'); # Include MySQL - Get Data Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
} 

# -- GET DATA --------------------------------------------------------------------------------
if($com=='getdata') { 
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/func.get_data.php'); # Include MySQL - Get Data Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
} 

# -- ADD DATA --------------------------------------------------------------------------------
if($com=='add') {
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/func.add_data.php'); # Include MySQL - Add Data Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
} 

# -- LOGOUT ----------------------------------------------------------------------------------
if($com=='logout') {
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/func.logout.php'); # Include MySQL - Logout Function
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
}

# -- ERRORS ----------------------------------------------------------------------------------
	} else {
				$error = '
				Data is not valid !<br>Your are logged out of FlashChat.<br>
				<a href="index.php">[ log-in again ]</a>
				';
				## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
				include('./inc/tmpl.error.php'); # read ERROR-Template
				## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
	} # END IF data 
	
	
		@mysql_close($db);
		} # END IF connection
	} # END IF $server && $user && $password

} else {# END CHECK username + ip echo "Log-In required !";
			$error = '
			Log-In required !<br>You have to log-in to FlashChat.<br>
			<a href="index.php">[ log-in ]</a>
			';
			## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
			include('./inc/tmpl.error.php'); # read ERROR-Template
			## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
} # END IF user_id
} # END if com=login
?>