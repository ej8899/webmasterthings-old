<?
if($user_id) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>FlashChat - Log-out</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="inc/styles.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE="JavaScript"><!--

var width = window.screen.availWidth;
x = width/2 - 325;
var height = window.screen.availHeight;
y = height/2 - 250;
//--></SCRIPT>
</head>

<body onLoad="window.moveTo(x,y)">
<table width="100%" height="90%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"> 
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" name="chat" width="600" height="450" id="chat">
        <param name="movie" value="logout.swf?user_id=<? echo $user_id ?>">
        <param name="quality" value="high">
		<param name="menu" value="false">
        <param name="wmode" value="transparent">
        <param name="LOOP" value="false">
        <param name="SCALE" value="exactfit">
        <embed src="logout.swf?user_id=<? echo $user_id ?>" width="600" height="450" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="chat" scale="exactfit" swliveconnect="true"></embed></object>
  </tr>
</table>
</body>
</html>
<? } # END IF user_id?>