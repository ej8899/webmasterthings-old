<?
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

$com = 'open';
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('chat.php');  # 
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

$username = urlencode($username);

if (!$error) {
echo <<< CHAT_PAGE
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>ZZ:FlashChat 2</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="inc/styles.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function geturl(url) {
	action = 'in';
	if(url) {
		window.location.href=url;
	}
}

function openadmin(linkadd) {
	admin = window.open(linkadd,'admin','resizable=yes,scrollbars=yes,width=675,height=300');
}

function logout(action) {
	if(action == 'out') {
		window.open('logout.php?user_id=$user_id','logout','resizable=yes,scrollbars=no,width=650,height=500');
	} 		
}
//-->
</script>
</head>

<body onLoad="action='out'" onUnload="logout(action)">
<table width="100%" height="90%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"> 
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" name="chat" width="600" height="450" id="chat">
        <param name="movie" value="chat.swf?username=$username&user_id=$user_id">
        <param name="quality" value="high">
		<param name="menu" value="false">
		<param name="wmode" value="transparent">
		<param name="LOOP" value="false">
		<param name="SCALE" value="exactfit">
        <embed src="chat.swf?username=$username&user_id=$user_id" width="600" height="450" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="chat" scale="exactfit"></embed></object></tr>
</table>
<!-- ZZ:FlashChat by http://download.zehnet.de -->
</body>
</html>
CHAT_PAGE;
} ?>