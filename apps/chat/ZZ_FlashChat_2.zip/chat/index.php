<?
header("Expires: ".gmdate("D, d M Y H:i:s")."GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

if ($server && $user && $password) {
	if(@mysql_connect($server,$user,$password)) {
		$db = mysql_connect($server,$user,$password);
		$dat = mysql_select_db($datab);
		
		$sql = "SELECT status FROM $userdat WHERE user='admin'";
		$result = mysql_query($sql, $db);
		$row = mysql_fetch_array($result, MYSQL_NUM);
		
		if ($row[0] == '0') { 											# -- if chat is open					
			
			## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
			include('./inc/func.user.php'); # Get User-Management-Function
			## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
	
			$sql = 'SELECT * FROM '.$userdat.' WHERE user!=\'admin\' and status=\'0\'';    # -- get user currently online
			$result = mysql_query($sql, $db);
			$number = mysql_num_rows($result);
			
			$number = "There are $number persons in the chat at the moment:";
			$link = '<a href="#" onClick="openchat();">[ open ZZ:FlashChat ]</a>';
		
		} else { #- if chat is closed
			$number = 'The chat is closed at the moment !';
		}
	@mysql_close($db);
	} # END IF CONNECT
} # END IF SERVER + USER + PASSWORD
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>ZZ:FlashChat - Start</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="inc/styles.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE="JavaScript"><!--
function openchat() {
  window.open('login.php','chat','resizable=yes,scrollbars=no,width=650,height=500');
}
//--></SCRIPT>
</head>

<body scroll=no>
<table width="100%" height="90%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center">
	<strong><? echo $number ?></strong><br>
      <br>
	  <? echo $link ?>
      </td>
  </tr>
</table>
</body>
</html>