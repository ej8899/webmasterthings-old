<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>ZZ:FlashChat - Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="inc/styles.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE="JavaScript"><!--

var width = window.screen.availWidth;
x = width/2 - 325;
var height = window.screen.availHeight;
y = height/2 - 250;
//--></SCRIPT>
</head>

<body onLoad="window.moveTo(x,y)">
<table width="100%" height="90%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"> 
<?
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""
include('./inc/inc.config.php'); # Read Configuration-Data
## """"" INCLUDE """"""""""""""""""""""""""""""""""""""""""""

if ($server && $user && $password) {									#-- Connect Database and get User-Data
	if(@mysql_connect($server,$user,$password)) {						#
		$db = mysql_connect($server,$user,$password);
		$dat = mysql_select_db($datab);
		$sql = "SELECT * FROM $userdat WHERE user='admin'";
		$result = mysql_query($sql, $db);
		$row = mysql_fetch_array($result, MYSQL_NUM);

if ($row[4] == '0') {													# -- if chat is open
?>
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" name="chat" width="600" height="450" id="chat">
        <param name="movie" value="login.swf">
        <param name="quality" value="high">
		<param name="menu" value="false">
		<param name="wmode" value="transparent">
		<param name="LOOP" value="false">
		<param name="SCALE" value="exactfit">
        <embed src="login.swf" width="600" height="450" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="chat" scale="exactfit"></embed></object>
<?
} else {
?>

<b><h2>The chat is closed !</h2></b>

<?
		}	# end if != closed
	} # end if connect
} # end if password
?>
</td></tr></table>
</body>
</html>