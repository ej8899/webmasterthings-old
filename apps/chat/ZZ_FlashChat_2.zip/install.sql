# ---------------------------------------------------------
#                    - ZZ:FlashChat 2 -
# ---------------------------------------------------------
# ~~~~~~~~~~~~~~~~~~~ FULL Installation ~~~~~~~~~~~~~~~~~~~
#
# MySQL DatabaseTables - Installation
#
# ~~~~~~~~~~~~~~~~~~~ UPDATE Instalation ~~~~~~~~~~~~~~~~~~
#
# Uncomment the following two lines 
# if your installation should update ZZ:FlashChat 1.xxx
#
# DROP TABLE zz_messages;
# DROP TABLE zz_user;

CREATE TABLE zz_messages (
  ID int(5) NOT NULL default '0',
  time datetime default NULL,
  user varchar(18) NOT NULL default '',
  msgtext text NOT NULL,
  target text NOT NULL,
  PRIMARY KEY  (ID),
  UNIQUE KEY ID (ID),
  KEY ID_2 (ID)
) TYPE=MyISAM;


CREATE TABLE zz_user (
  ID varchar(200) NOT NULL default '',
  logintime datetime default NULL,
  user varchar(18) NOT NULL default '',
  IP varchar(150) NOT NULL default '',
  status varchar(10) NOT NULL default '',
  PRIMARY KEY  (ID),
  UNIQUE KEY ID (ID),
  KEY ID_2 (ID)
) TYPE=MyISAM;

INSERT INTO zz_user (ID, logintime, user, IP, status) VALUES ('zzname', '0000-00-00 00:00:00', 'admin', 'zzpass', '0');