//////////////////////// ONE COLUM PATCH 2002_02_10 //////////////////////////

Overwrite existing files in admin and include of admin/configuration.php and
include/main.cats.php.  Then run column_one.sql with PHPMyAdmin.

You then need to go to your configruation through the admin area and select
to use one column for the main categories listing.

///////////////////////////////////////////////////////////////////////////////////////