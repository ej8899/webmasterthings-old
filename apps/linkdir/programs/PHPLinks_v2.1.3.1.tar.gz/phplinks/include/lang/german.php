<?

//        *******************************************************************
//        include/about.php
//        *******************************************************************

        $about_1 = "Infos/AGB/Impressum ";
        $about_2 = "Dieser Bereich wird z. Zt. �berarbeitet";
        $about_3 = "";
        $about_4 = "";
        $about_5 = "";
        $about_6 = "";
        $about_7 = "";
        $about_8 = "";
        $about_9 = "";

//        *******************************************************************
//        include/hinzuf�gen.php
//        *******************************************************************

        $add_1 = "Webseite eintragen";
        $add_2 = "Eintragung vollst�ndig.";
        $add_3 = "Webseiten Name:";
        $add_4 = "Webseiten URL: ";
        $add_5 = "Beschreibung: ";
        $add_6 = "Kategorie:";
        $add_7 = "Nutzername: ";
        $add_8 = "Passwort Erinnerung: ";
        $add_9 = "Ihre E-Mail: ";
        $add_10 = "Bitte verwenden Sie diesen Code wenn Sie einen Link zu uns setzen m�chten:";
        $add_11 = "Ihr Link zu uns erh�ht Ihre Position bei den Partnerseiten";
        $add_12 = "Verwenden Sie diesen Code f�r Ihre Webseite Ihre Besuchen k�nnen hiermit Ihre Seite bewerten oder einen ";
        $add_13 = "Kommentar eintragen ";
        $add_14 = "Ihre Website wird nun redaktionell gepr�ft Sie erhalten eine Nachricht per E-Mail. Vielen Dank f�r Ihren Eintrag!";
        $add_15 = "Eintrags-Fehler ";
        $add_16 = "Webseiten Name: ";
        $add_17 = "Webseiten Name muss zwischen ";
        $add_18 = " und ";
        $add_19 = " Zeichen lang sein";
        $add_20 = "Webseiten URL: ";
        $add_21 = "Webseiten URL muss g�ltig sein";
        $add_22 = "Ihre Webseite ist bereits im Verzeichnis eingetragen. M�chten Sie ihren ";
        $add_23 = "Eintrag bearbeiten?";
        $add_24 = "Ihre Webseiten URL ist bereits zur Bearbeitung vorgemerkt. Bitte haben Sie noch etwas Geduld, Sie erhalten eine Mailnachricht wenn Ihrer Seite eingetragen wurde. ";
        $add_25 = "Beschreibung: ";
        $add_26 = "Beschreibung muss zwischen ";
        $add_28 = " Zeichen lang sein";
        $add_29 = "Kategorie: ";
        $add_30 = "Nutzername: ";
        $add_31 = "Nutzername muss zwischen ";
        $add_33 = " Zeichen lang sein";
        $add_34 = "Passwort: ";
        $add_35 = "Passwort muss zwischen ";
        $add_37 = " Zeichen lang sein";
        $add_38 = "Passwort-Wiederholung: ";
        $add_39 = "Passw�rter m�ssen m�ssen �berein stimmen";
        $add_40 = "Passwort Erinnerung: ";
        $add_41 = "Passwort Erinnerung muss zwischen ";
        $add_42 = " Zeichen lang sein";
        $add_43 = "E-Mail: ";
        $add_44 = "Ihre E-Mail muss in der Form 'user@domain.com' angegeben werden";
        $add_45 = " Webseite anmelden ";
		$add_46 = "Land:";
//        *******************************************************************
// include/common.php
//        *******************************************************************

        $common_1 = "oder";
        $common_2 = "und";
        $common_3 = "Satz";

//        *******************************************************************
//        include/email_addition.php
//        *******************************************************************

        $email_addition_1 = "Website Eintrag ";
        $email_addition_2 = "Eine neue Website wurde eingetragen zur Bearbeitung: ";
        $email_addition_3 = "Website Name: ";
        $email_addition_4 = "Website URL: ";
        $email_addition_5 = "Zum Bearbeiten dieser Website hier klicken: ";
        $email_addition_6 = "Danke";

//        *******************************************************************
//        include/email_confirmation.php
//        *******************************************************************

        $email_confirmation_1 = "Eintrag wurde hinzugef�gt bei  ";
        $email_confirmation_2 = "Ihr Webseitenvorschlag wurde in das Verzeichnis von ";
        $email_confirmation_3 = "aufgenommen. Seitenname: ";
        $email_confirmation_4 = "Webseiten URL: ";
        $email_confirmation_5 = "Bitte verwenden Sie diesen Code wenn Sie einen Link zu Immos24 zu setzen m�chten:";
        $email_confirmation_6 = "Ein Link zu Immos24 erh�ht Ihre Position bei unseren Topsite-Eintr�gen !";
        $email_confirmation_7 = "Mit freundlichen Gr�ssen";
$email_confirmation_8 = "Support http://www.Immos24.de";
//        *******************************************************************
//        include/email_deletion.php
//        *******************************************************************

        $email_deletion_1 = "Ihr Eintrag wurde Abgelehnt ";
        $email_deletion_2 = "Bitte haben Sie Verst�ndnis das wir hierf�r keinen Grund angeben  ";
        $email_deletion_3 = "Webseiten Name: ";
        $email_deletion_4 = "Webseiten URL: ";
        $email_deletion_5 = "Support Immos24";

//        *******************************************************************
//        include/functions.php
//        *******************************************************************

        $functions_1 = "Seite: ";
        $functions_2 = " Start";
        $functions_3 = "Ende ";
        $functions_4 = " Anzeigen ";
        $functions_5 = " von ";
        $functions_6 = " Webseiten";
        //$functions_7 = "Was ist ";
        $functions_8 = "Neue Eintr�ge";
        $functions_9 = "Topreferer";
        $functions_10 = "H�ufig besuchte Seiten";
        $functions_11 = "Webmasterbereich";
        $functions_12 = "Webseiten Bewertung";
        $functions_13 = "Hinzugef�gt: ";
        $functions_14 = "Letzte Bearbeitung: ";
        $functions_15 = "Kategorie: ";
        $functions_16 = "Refers: ";
        $functions_17 = "Klicks: ";
        $functions_18 = "Leider keine Eintr�ge in diesem Bereich.";
        $functions_19 = "Eintr�ge gefunden: ";
        $functions_20 = "Leider ergab Ihre Suche keine Treffer.";
        $functions_21 = "Kategorien gefunden: ";

//        *******************************************************************
//        include/lost.php
//        *******************************************************************

        $lost_1 = "Passwort anfordern ";
        $lost_2 = "Passwort wie angefordert...";
        $lost_3 = "Sie haben Ihre Zugangsdaten erneut angefordert";
        $lost_4 = "diese erhalten Sie mit dieser Mail. ";
        $lost_5 = "Bitte bewahren Sie diese vor dem Zugriff";
        $lost_6 = "Fremder gesch�tzt auf. ";
        $lost_7 = "Ihr Username lautet: ";
        $lost_8 = "Ihre Passwort Erinnerung lautet: ";
        $lost_9 = "Mit diesem Link k�nnen Sie ihren Eintrag bearbeiten:  ";
        $lost_10 = "Mit freundlichen Gr�ssen Support Immos24";
        $lost_11 = "Ihre Zugangsdaten wurden an ";
        $lost_12 = " geschickt";
        $lost_13 = "Kein Nutzer mit dieser Mailadresse  ";
        $lost_14 = "  vorhanden Bitte versuchen Sie es noch einmal : ";
        $lost_15 = "Bitte geben Sie Ihre E-Mail-Adresse an, Sie erhalten Ihre Zugangsdaten anschliessend zugesandt: ";
        $lost_16 = " Anfordern ";

//        *******************************************************************
//        include/owner.php
//        *******************************************************************

        $owner_1 = "Eintrags Information:";
        $owner_2 = "Um bei den Topreferern gelistet zu werden, verwenden Sie bitte diesen Code zum Verweis auf ";
        $owner_3 = "Verwenden Sie bitte diesen Code um Ihren Besuchern zu erm�glichen Ihre Webseite zu bewerten:";
        $owner_4 = "Unsere Webseite bewerten";
        $owner_5 = "Klicken Sie hier um Ihre Eintrag zu bearbeiten ";
        $owner_6 = " Bitte Webseiten ID eingeben : ";
        $owner_7 = " Webmaster-Info erhalten";

// *******************************************************************
//  include/update.php
// *******************************************************************

	$update_1 = "Um einen Eintrag zu bearbeiten, m�ssen Sie sich einloggen. ";
	//$update_1 .= "";
	$update_2 = "Wenn Sie Ihren Nutzernamen oder Ihr Passwort vergessen haben, klicken Sie bitte ";
	$update_3 = "hier";
	$update_4 = " um Ihre Zugangsdaten erneut zu erhalten.";
	$update_5 = "Eintrag aktualisieren/bearbeiten";
	$update_6 = "Ihr Nutzername und Passwort stimmen nicht �berein.";  
	$update_7 = "Ihr Seiteneintrag wurde aktualisiert. ";
	$update_8 = " gehts weiter....";
	$update_9 = "Fehler.";
	$update_10 = "Eintrag bearbeiten: ";
	$update_11 = "Webseiten Name: ";
	$update_12 = "Webseiten Name muss ";
	$update_13 = "zwischen ";
	$update_14 = " und ";
	$update_15 = " Zeichen lang sein.";
	$update_16 = "Webseiten URL muss g�ltig sein.";
	$update_17 = "Beschreibung muss ";
	$update_18 = "Webseiten URL: ";
	$update_19 = "Beschreibung: ";
	$update_20 = "Kategorie: ";
	$update_21 = "Bundesland: ";
	$update_22 = "Bitte w�hlen Sie ihr Land";
	$update_23 = "Nutzername: ";
	$update_24 = "Nutzername muss  ";
	$update_25 = "Passwort:";
	$update_26 = "(falls ge�ndert werden soll)";
	$update_28 = "Passwort muss ";
	$update_29 = "Passwort wiederholen: ";
	$update_30 = "Ihre Passw�rter m�ssen �berein stimmen.";
	$update_31 = "Passwort Erinnerung: ";
	$update_32 = "Passwort Erinnerung muss ";
	$update_33 = "Ihre E-Mail Adresse muss in dieser Form 'user@domain.com' angegeben werden.";
	$update_34 = " Eintrag aktualisieren ";
	$update_35 = "Login: ";
	$update_36 = "Nutzername: ";
	$update_37 = "Passwort: ";
	$update_38 = " Login ";
	$update_39 = "E-Mail: ";
//        *******************************************************************
//        include/related.php
//        *******************************************************************
        $related_1 = "Verwandte Kategorien";
//        *******************************************************************
//        include/results.php
//        *******************************************************************

        $results_1 = "aus der Suche gel�scht ";
        $results_2 = "Sie suchten nach : ";
        $results_3 = "Suchzeit : ";
        $results_4 = " Sekunden ";
        $results_5 = "Oft verwendete Suchbegriffe : ";
        $results_6 = "Versuchen Sie Ihre Suche bei anderen Suchmaschinen :";
        $results_7 = "Es wurde kein Suchbegriff eingegeben.";

//        *******************************************************************
//        include/review.php
//        *******************************************************************

        $review_1 = "Webseiten Bewertung";
        $review_2 = "Webseite:";
        $review_3 = "Durchschnittliche Webseiten Bewertung: ";
        $review_4 = "Von: ";
        $review_5 = " bei ";
        $review_6 = " Punkt ";
        $review_7 = " Strich ";
        $review_8 = " unterstreichen  ";
        $review_9 = "F�r diesen Eintrag sind noch keine Bewertungen vorhanden...";
        $review_10 = "Klicken Sie hier um eine Bewertung durchzuf�hren.";

//        *******************************************************************
//        include/review_add.php
//        *******************************************************************

        $review_add_1 = "Bewertung komplett.";
        $review_add_2 = "Titel: ";
        $review_add_3 = "Bewertet von: ";
        $review_add_4 = "Bewertung: ";
        $review_add_5 = "Webseiten Bewertung: ";
        $review_add_6 = "Bewerter E-Mail: ";
        $review_add_7 = "Webseiten Bewertung Eintrags-Fehler.";
        $review_add_8 = "Titel: ";
        $review_add_9 = " Titel muss  zwischen ";
        $review_add_10 = " und ";
        $review_add_11 = " Zeichen lang sein";
        $review_add_12 = "Ihr Name: ";
        $review_add_13 = "Ihr Name muss  zwischen ";
        $review_add_14 = "Ihre E-Mail muss in dieser Form user@domain.com angegeben werden.";
        $review_add_15 = "Ihre E-Mail: ";
        $review_add_16 = "Ihre Webseiten URL: ";
        $review_add_17 = "Webseiten Bewertung: ";
        $review_add_18 = "Webseiten Bewertung muss zwischen ";
        $review_add_19 = "Webseiten Bewertung: ";
        $review_add_20 = "Schlecht";
        $review_add_21 = "Gut";
        $review_add_22 = " Jetzt bewerten!";

//        *******************************************************************
//        admin/menu.php
//        *******************************************************************
$menu_1 = "Haupt";
$menu_2 = "Startseite";
$menu_3 = "Ihre phpLinks";
$menu_4 = "Editieren Funktionen";
$menu_5 = "Website-Konfiguration";
$menu_6 = "Voreinstellungen";
$menu_7 = "Kategorien";
$menu_8 = "Verwandte Kategorien";
$menu_9 = "Links bearbeiten";
$menu_10 = "Links eintragen ";
$menu_11 = "Links pr�fen";
$menu_12 = "Reviews";
$menu_13 = "Z�hler-Reset";
$menu_14 = "Setup Funktionen";
$menu_15 = "Installation / Upgrade";
$menu_16 = "Wichtige Links:";
$menu_17 = "phpLinks.org";
$menu_18 = "phpLinks Support";
//$menu_19 = "PHP.net";
//$menu_20 = "meineSQL.com";
//$menu_22 = "Apache.org";
$menu_23 = "Andere:";
$menu_24 = "Lizenzbedingungen";
$menu_25 = "changelog";
$menu_26 = "readme";

?>
