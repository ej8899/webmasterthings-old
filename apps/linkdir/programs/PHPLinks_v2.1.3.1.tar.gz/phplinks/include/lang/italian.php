<?

// *******************************************************************
//  include/lang/italian.php
// *******************************************************************

// Translation by: Settimo Tudor Eugen C.
// Sito: www.tuoweb.it
// Shop: www.tuoweb.it/shop/
// webmaster@topitalia.net

// *******************************************************************
//  include/about.php
// *******************************************************************
	
	$about_1 = "Informazioni ";

	$about_2 = "PHPLinks � una risosa gratuita in PHP. ";
	$about_2 .= "Consente di gestire in modo automatico i link degli utenti nel proprio sito.  ";
	$about_2 .= "Si possono anche oganizzare per categoie senza alcun limite.";
	$about_2 .= "Ricerca avanzata per categoia e molto altro. ";
	$about_2 .= "Installazione Facile. Opzioni Server Richieste:";

	$about_3 = "Server con suppoto PHP3 o supperioe. ";
	$about_3 .= "La Versione PHP Consigliata comunque il PHP4.";

	$about_4 = "<br>Versione Italiana configurata da: www.tuoweb.it";
	
	$about_5 = "<br>Autor Translate Italian Language PHPLinks: Settimo Tudor Eugen C.";
	
	$about_6 = "PHPLinks 2.x ha molte opzioni:";
	$about_6 .= "Ricerca per categoia, ricerca avanzata,";
	$about_6 .= "classifica dei siti pi� visitati e molto altro.";

	$about_7 = "Hai problemi per installare questo script? ";
	
	$about_8 = "Visita il forum di discussione";
	
	$about_9 = "Scarica anche tu PHPLinks";


// *******************************************************************
//  include/add.php
// *******************************************************************

	$add_1 = "Aggiungi Sito";

	$add_2 = "Conferma Aggiunta sito.";

	$add_3 = "Titolo del sito: ";

	$add_4 = "URL del sito: ";

	$add_5 = "Descrizione: ";

	$add_6 = "Categoia: ";

	$add_7 = "Nome Utente: ";

	$add_8 = "password: ";

	$add_9 = "Email: ";

	$add_10 = "La preghiamo di usare il seguente codice nel suo sito: ";

	$add_11 = "Inserendo questo link possiamo garantirLe una maggioe visibilit� del suo link!";

	$add_12 = "Usate questo codice, se volete farVi votare dai vostri utenti ";
	$add_12 .= "Vota per ";

	$add_13 = "Vota  ";

	$add_14 = "Il suo sito � stato inserito nel database.  Grazie. ";
	$add_14 .= "Se il sito risulta pubblicabile il nostro staff lo inserir� al pi� presto!";

	$add_15 = "Errore Aggiunta Sito";

	$add_16 = "Titolo del sito: ";

	$add_17 = "Titolo del sito deve essere fra ";

	$add_18 = " e ";

	$add_19 = " caratteri in lunghezza";

	$add_20 = "L'indirizzo del sito: ";

	$add_21 = "L'indirizzo del sito deve essere valido";

	$add_22 = "L'indirizzo del sito � gi� presente nel database. Pertanto ti conviene ";

	$add_23 = "aggiornare soltanto il tuo sito inserendo nome utente e password.";

	$add_24 = "L'indirizzo del sito � gi� sotto la visione dle nostro staff, la preghiamo ";
	$add_24 .= "di attendere con pazienza il controllo da parte dello staff.";

	$add_25 = "Descrizione: ";

	$add_26 = "Descrizione deve essere fra ";

	$add_28 = " caratteri in lunghezza";

	$add_29 = "Categoria: ";

	$add_30 = "Nome Utente: ";

	$add_31 = "Nome Utente deve essere fra ";

	$add_33 = " caratteri in lunghezza";

	$add_34 = "password: ";

	$add_35 = "password deve essere fra ";

	$add_37 = " caratteri in lunghezza";

	$add_38 = "inserisci nuovamente la password: ";

	$add_39 = "La sua password deve corispondere alla prima";

	$add_40 = "password : ";

	$add_41 = "la password  deve essere fra ";

	$add_42 = " caratteri in lunghezza";

	$add_43 = "Email: ";

	$add_44 = "L'Email deve essere nella foma 'utente@dominio.com'";

	$add_45 = " Aggiunta del sito ";

	$add_46 = "Paese: ";

	$add_47 = "la preghiamo di scegliere";

	$add_48 = "la preghiamo di scegliere il Paese";

// *******************************************************************
//  include/common.php
// *******************************************************************

	$common_1 = "o";

	$common_2 = "e";

	$common_3 = "Frase";


// *******************************************************************
//  include/email_addition.php
// *******************************************************************
	
	$email_addition_1 = "sito aggiunto in ";

	$email_addition_2 = "Un nuovo sito � stato aggiunto nella lista delle validazioni: ";

	$email_addition_3 = "Titolo del sito: ";

	$email_addition_4 = "L'indirizzo del sito: ";

	$email_addition_5 = "Per validare questo  sito, deve entrare in: ";

	$email_addition_6 = "Grazie";


// *******************************************************************
//  include/email_confirmation.php
// *******************************************************************

	$email_confirmation_1 = "aggiunta del sito a";

	$email_confirmation_2 = "Il suo sito � stato aggiunto a ";

	$email_confirmation_3 = "Titolo del sito: ";

	$email_confirmation_4 = "L'indirizzo del sito: ";

	$email_confirmation_5 = "la preghiamo di usi questo codice to link to us:";

	$email_confirmation_6 = "Linkati per aver successo. ";
	$email_confirmation_6 .= "Sezione Consigliata!";

	$email_confirmation_7 = "Grazie";


// *******************************************************************
//  include/email_deletion.php
// *******************************************************************

	$email_deletion_1 = "Sito espulso da ";

	$email_deletion_2 = "Spicente, Il suo sito has deleted from ";

	$email_deletion_3 = "Titolo del sito: ";

	$email_deletion_4 = "L'indirizzo del sito: ";

	$email_deletion_5 = "Ringraziamenti";


// *******************************************************************
//  include/functions.php
// *******************************************************************

	$functions_1 = "Pagina: ";

	$functions_2 = " Inizio";

	$functions_3 = "Fine ";

	$functions_4 = " Guardando ";

	$functions_5 = " il ";

	$functions_6 = " sito";

	$functions_7 = "Che cosa c'�";

	$functions_8 = "Nuovo";

	$functions_9 = "Consigliato";

	$functions_10 = "Popolare";

	$functions_11 = "Proprietario";

	$functions_12 = "Valutazione del Sito";

	$functions_13 = "Aggiunto: ";

	$functions_14 = "Ultimo Aggiornamento: ";

	$functions_15 = "Categoria: ";

	$functions_16 = "Click in entrata: ";

	$functions_17 = "Click in uscita: ";

	$functions_18 = "Spicente, non ci sono siti in questa sezione.";

	$functions_19 = "sito trovato: ";

	$functions_20 = "Spicente, nessun sito trovato in base alla chiave inserita.";

	$functions_21 = "Categorie Disponibili: ";

// *******************************************************************
//  include/line.cat.php
// *******************************************************************

	$line_cat_1 = "Top";

// *******************************************************************
//  include/lost.php
// *******************************************************************

	$lost_1 = "Richiesta password";

	$lost_2 = "password richiesta...";

	$lost_3 = "Per il suo account � richiesta la sua email ";
	$lost_3 .= "";

	$lost_4 = "infomazioni riguardanti il sito disponibili al";

	$lost_5 = ".  Non � posta spazatura  SPAM.  Questa email";

	$lost_6 = "� stata inviata per richiesta di:";

	$lost_7 = "Il suo Nome Utente is: ";

	$lost_8 = "Il suo password Hint is: ";

	$lost_9 = "Stai ora entrando in ";

	$lost_10 = "Grazie";

	$lost_11 = "E' stata inviata un email a";

	$lost_12 = " contenente il nome utente e le informazioni per la sua password";

	$lost_13 = "Non riesco a trovare l'account ";

	$lost_14 = "  la preghiamo di riprovarci: ";

	$lost_15 = "Inserisca la sua Email : ";

	$lost_16 = " Invia";


// *******************************************************************
//  include/owner.php
// *******************************************************************

	$owner_1 = "Informazioni per l'autore del sito:";

	$owner_2 = "Per essere presente nell'archivio di votazione ,<br />usi questo codice ";
	$owner_2 .= "che li consente di aumentare la visibilit� del suo sito. <br>Votazione Semplificata";

	$owner_3 = "Usi questo codice per far votare il suo sito<br /> ";
	$owner_3 .= "Codice Votazione Avanzata del sito:";

	$owner_4 = "Vota Questo Sito!!";

	$owner_5 = "clicca qui per aggiornare la lista dei siti";

	$owner_6 = " la preghiamo di inserire L'ID del suo sito: ";

	$owner_7 = " Ottenere informazioni sul proprietario ";


// *******************************************************************
//  include/related.php
// *******************************************************************

	$related_1 = "Categorie appartenenti alla prima";


// *******************************************************************
//  include/results.php
// *******************************************************************

	$results_1 = "rimosso dal campo";

	$results_2 = "Lei sta cercando: ";

	$results_3 = "Tempo impiegato per la ricerca: ";

	$results_4 = " secondi";

	$results_5 = "Le chiavi di ricerca pi� richieste: ";

	$results_6 = "Provi a fare la sua ricerca in un altro motore di ricerca:";

	$results_7 = "Non ha inserito alcuna frase per la ricerca.";


// *******************************************************************
//  include/review.php
// *******************************************************************
	
	$review_1 = "Valutazione del Sito";

	$review_2 = "Sito:";

	$review_3 = " Valutazione Del Sito
: ";

	$review_4 = "Da: ";

	$review_5 = " a ";

	$review_6 = " Puntato ";

	$review_7 = " Barratto ";

	$review_8 = " Sottolineamento ";

	$review_9 = "Spicente, non ci sono valutazioni per questo sito...";

	$review_10 = "clicca qui per aggiungere valutazione al sito.";


// *******************************************************************
//  include/review_add.php
// *******************************************************************

	$review_add_1 = "Valutazione del sito confermata.";

	$review_add_2 = "Titolo del suo sito: ";

	$review_add_3 = "Autore Valutazione: ";

	$review_add_4 = "Valutazione: ";

	$review_add_5 = "Voto al Sito ";

	$review_add_6 = "Email: ";

	$review_add_7 = "Valutazione del Sito -  Errore Inserimento.";

	$review_add_8 = "Titolo : ";

	$review_add_9 = "Il Titolo deve essere fra ";

	$review_add_10 = " e ";

	$review_add_11 = " caratteri in lunghezza";

	$review_add_12 = "Il suo Nome: ";

	$review_add_13 = "Il suo Nome deve essere fra ";

	$review_add_14 = "La sua email deve essere nella fomra user@domain.com.";

	$review_add_15 = "La sua email: ";

	$review_add_16 = "L'indirizzo del suo sito: ";

	$review_add_17 = "Voto del sito: ";

	$review_add_18 = "Il voto del Sito deve essere fra ";

	$review_add_19 = "Voto Del Sito
: ";

	$review_add_20 = "Sito Scarso";

	$review_add_21 = "Ottimo Sito";

	$review_add_22 = " Aggiungi valutazione al sito";

	$review_add_23 = "Aggiungi la tua valutazione  per il sito:";


// *******************************************************************
//  include/update.php
// *******************************************************************

	$update_1 = "Per Aggiornare,Votare o alterare il sito devi avere l' Accesso.  ";
	$update_1 .= "Se non hai accesso il sito ti registra.";

	$update_2 = "Nome Utente o password, la preghiamo di ";

	$update_3 = "clicca qui";

	$update_4 = "per avere via email informazioni riguardanti la tua password.";

	$update_5 = "Informazioni sugli aggiornamenti del sito";

	$update_6 = "Spiacente, Il suo Nome Utente o password non sono giusti.  ";
	$update_6 .= "";

	$update_7 = "Il suo sito � stato aggiornato . ";

	$update_8 = " per continuare.";

	$update_9 = "C'� un errore.";

	$update_10 = "Modifica Lista: ";

	$update_11 = "Titolo del sito: ";

	$update_12 = "Titolo del sito deve essere ";

	$update_13 = "fra ";

	$update_14 = " e ";

	$update_15 = " caratteri in lunghezza.";

	$update_16 = "L'indirizzo del sito deve essere valido.";

	$update_17 = "Descrizione deve essere ";

	$update_18 = "sitoURL: ";

	$update_19 = "Descrizione: ";

	$update_20 = ": ";

	$update_21 = "Paese: ";

	$update_22 = "la preghiamo di scegliere il Paese";

	$update_23 = "Nome Utente: ";

	$update_24 = "Nome Utente deve essere ";

	$update_25 = "password:";

	$update_26 = "(solo se modificato)";

	$update_28 = "password deve essere ";

	$update_29 = "password Again: ";

	$update_30 = "La sua password deve corispondere alla prima.";

	$update_31 = "Suggerimento password: ";

	$update_32 = "la password suggerita deve essere ";

	$update_33 = "L'Email  deve essere nella forma 'nomeutente@dominio.it'.";

	$update_34 = " Elenco Delle Valutazioni ";

	$update_35 = "Accesso: ";

	$update_36 = "Nome Utente: ";

	$update_37 = "password: ";

	$update_38 = " Accesso ";

	$update_39 = "Email: ";


// *******************************************************************
//  admin/menu.php
// *******************************************************************

	$menu_1 = "Principale";

	$menu_2 = "Pagina Principale";

	$menu_3 = "Il Tuo TuoWebPHP Links";

	$menu_4 = "Aggiorna Funzioni";

	$menu_5 = "Configurazione";

	$menu_6 = "Specificazioni del sito";

	$menu_7 = "Aggiorna Categorie";

	$menu_8 = "Categoria Appropriata";

	$menu_9 = "Vota Questo Sito";

	$menu_10 = "Aggiungi un nuovo sito";

	$menu_11 = "Verifica Link";

	$menu_12 = "Aggiornamento del Sito";

	$menu_13 = "Resetta Conteggio";

	$menu_14 = "Settaggio Funzioni";

	$menu_15 = "Installazione / Aggiornamento";

	$menu_16 = "Link Importanti:";

	$menu_17 = "TuoWeb Links";

	$menu_18 = "PHPLinks Supporto";

	$menu_19 = "PHP.net";

	$menu_20 = "MySQL.com";

	$menu_22 = "Apache.org";

	$menu_23 = "Altro:";

	$menu_24 = "licenza";

	$menu_25 = "Aggiorna log";

	$menu_26 = "leggimi";

?>

