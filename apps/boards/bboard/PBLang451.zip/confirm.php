<?php
/***************************************************************************
 *                            confirm.php  - PBLang
 *                            -------------------
 *              see the file copyright.txt in the docs-folder
***************************************************************************/


error_reporting  (E_ERROR | E_WARNING | E_PARSE);
//error_reporting  (E_ALL);
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");  

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include($dbpath."/settings.php");
include_once("functions.php");
include_once("ffunctions.php");
include($temppath."/pb/language/lang_".$language.".php");

$username=$HTTP_COOKIE_VARS[$cookieid];
$permit=CheckLoginStatus($username,"0","1");

if ($loggedin=="1") {
     writeheader($newestm,0,0,0,$username,"1",$VConfirmation);
     ErrorMessage($AlreadyLoggedIn,$username);
     exit;
} else {
     if ($allowreg!="1") {
          writeheader($newestm,0,0,0,$username,"0",$VConfirmation);
          ErrorMessage($NoNewUsers,$username);
          exit;
     //Here begins the action!
     } else {
          $regcode=$HTTP_GET_VARS['code'];
          $user=$HTTP_GET_VARS['user'];
          writeheader($newestm,0,0,0,$username,"0",$VConfirmation);
          $filename=$dbpath."/members/pending/".$regcode;
          if (!file_exists($filename)){
               ErrorMessage($VWrongConfirmationCode,$username);
               exit;
          } else {
               include($filename);
               if ($username==$user){
                    copy($filename,$dbpath."/members/".$user);
                    @unlink ($filename);

                    $filename = $dbpath."/mems";
                    $fd = fopen ($filename, "r");
                    $n = fread ($fd, filesize ($filename));
                    fclose ($fd);
                    $n++;
                    $fp = fopen($dbpath."/mems", "w");
                    fputs($fp, $n);
                    fclose($fp);

                    $zero="0";
                    $fp = fopen($dbpath."/pm/".$user, "w");
                    fputs($fp, $zero);
                    fclose($fp);
                    $fp = fopen($dbpath."/pm/".$user."_tot", "w");
                    fputs($fp, $zero);
                    fclose($fp);

                    $fp = fopen($dbpath."/settings/newestm", "w");
                    fputs($fp, $user);
                    fclose($fp);

                    $fp = fopen($dbpath."/memss/".$user, "w");
                    fputs($fp, $zero);
                    fclose($fp);

                    regdone($user,0,$userlang);
               } else {
                    writeheader($newestm,0,0,0,$username,"0",$VConfirmation);
                    ErrorMessage($VConfirmationError,$username);
               }
          }
     }
}
writefooter($newestm);


ob_end_flush();
?>
