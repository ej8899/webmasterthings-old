<?php
/***************************************************************************
*                            delpost.php
*                            -------------------
*
*              see the file copyright.txt in the docs-folder
*   last updated 28 Dec 2002
***************************************************************************/


error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
                                                  // always modified
header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include_once("functions.php");
include_once("ffunctions.php");
include_once("scan.php");
include($dbpath."/settings.php");

$username=$HTTP_COOKIE_VARS[$cookieid];
$permit=CheckLoginStatus($username,"1","0");
if ($permit=="1") {
	$language=SetLanguage($username);
	include("$temppath/$template/language/lang_$language.php");
	$cat=$HTTP_GET_VARS['cat'];
	$fid=$HTTP_GET_VARS['fid'];
	$pid=$HTTP_GET_VARS['pid'];
	$type=$HTTP_GET_VARS['t'];
	$reply=$HTTP_GET_VARS['r'];
	$auto=$HTTP_GET_VARS['auto'];
	$cdreply=0;   //count down reply in cats only if a reply is deleted!
	$cdtopic=0;   //count down topics in cats only if a topic is deleted!
	if (($type==2 || $type==3) && $reply>=1) {          //if it's a reply...
		$filename = $dbpath."/posts/".$cat."_".$fid."_".$pid."_r_".$reply;
		$delreply="1";
	} else {
		$filename = $dbpath."/posts/".$cat."_".$fid."_".$pid;
		$delreply="0";
	}
	if (!file_exists($filename)){
		ErrorMessage($NoSuchFile." - ".$filename,$username);
		exit;
	}
	include($filename);
	if ($delreply=="1"){
		$pauth=$rauthor;
	}else{
		$pauth=$pauthor;
	}
	//determine how many replies exist in this topic
	include($dbpath."/posts/".$cat."_".$fid."_".$pid);
	$replies=$preplies;
	if ($pauth!=$username && $admin!="1") {      // Only author or Admin may delete a message (and moderator?)
		ErrorMessage($DeletePostNotAllowed,$username);
		exit;
	} elseif (!$type && $replies && $admin!="1") {         //if it's the first post of a thread with replies, it shouldn't be deleted unless you are admin
		ErrorMessage($DeletePostNotAllowed,$username);
		exit;
	//now the checks are done, the deletion can start:
	} else {
		if ($type==2 || $type==3)           //it's a reply
		{
			SetLock();
			include($dbpath."/posts/".$cat."_".$fid."_".$pid);
			$preplies--; //reduce the counter of replies
			WritePostInfo($cat,$fid,$pid,"");
			unlink($dbpath.'/block');

			$orgauth=$rauthor;
			//delete this reply
			unlink($filename);
			@unlink($dbpath."/search/".$cat."_".$fid."_".$pid."_r_".$reply."_c");    //also the file in the search directory
			$cdreply=1;
			if ($preplies=="0"){  //there is only one post left, so set _lpa and _lpd to _a and _pa
				SetLock();
				include($dbpath."/posts/".$cat."_".$fid."_".$pid);
				$plastauthor=$pauthor;
				$plastdate=$pdate;
				$plastreply='0';
				WritePostInfo($cat,$fid,$pid,"");
				unlink($dbpath.'/block');
			}else{                 //there are other replies. Find out the latest and set those in _lpd and _lpa
				include($dbpath."/posts/".$cat."_".$fid."_".$pid);
				$num=$plastreply;
				$lfilename=$dbpath."/posts/".$cat."_".$fid."_".$pid."_r_";
				$filename=$lfilename.$num;
				while (!file_exists($filename)) //walk through replies from highest to get latest reply
				{
					$num--;
					$filename=$lfilename.$num;
				}
				SetLock();
				include($dbpath."/posts/".$cat."_".$fid."_".$pid."_r_".$num);
				$plastauthor=$rauthor;
				$plastdate=$rdate;
				WritePostInfo($cat,$fid,$pid,"");
				unlink($dbpath.'/block');
			}
			//Now put the lastauthor, lasturl and lastdate into the forum-file in cats
			SetLock();
			include($dbpath."/cats/".$cat."_".$fid);
			$freplies--;
			$flastpost=$plastdate;
			$flastauthor=$plastauthor;
			$flasturl="post.php?cat=$cat&fid=$fid&pid=$pid&page=1";
			WriteForumInfo($cat,$fid);
			unlink ($dbpath.'/block');

			if ($type==3){
				include($dbpath."/posts/".$cat."_".$fid."_".$pid);
				$allposts=$plastreply;
				for ($i=$allposts;$i>=1;$i--){
					$filename=$dbpath."/posts/".$cat."_".$fid."_".$pid."_r_".$i;
					if (file_exists($filename)){
						echo "<meta http-equiv=\"Refresh\" content=\"0; URL=delpost.php?cat=$cat&fid=$fid&pid=$pid&t=3&r=$i\">";
						exit;
					}
				}
				echo "<meta http-equiv=\"Refresh\" content=\"0; URL=delpost.php?cat=$cat&fid=$fid&pid=$pid\">";
				exit;
			}

		} else {                        //it's the first post

			if ($replies>"0" && $admin=="1"){        //admin may delete the first post even if there are replies, it's equal to deleting the whole topic
				include($dbpath."/posts/".$cat."_".$fid."_".$pid);
				$allposts=$plastreply;
				for ($i=$allposts;$i>=1;$i--){
					$filename=$dbpath."/posts/".$cat."_".$fid."_".$pid."_r_".$i;
					if (file_exists($filename)){
						echo "<meta http-equiv=\"Refresh\" content=\"0; URL=delpost.php?cat=$cat&fid=$fid&pid=$pid&t=3&r=$i\">";
						exit;
					}
				}
			}elseif ($replies=="0"){           //without any replies
				//this one can be deleted - action happens below
			}else{         //this isn't needed...??
				ErrorMessage($DeletePostNotAllowed,$username);
				exit;
			}
			include($dbpath."/posts/".$cat."_".$fid."_".$pid);
			$orgauth=$pauthor;
			@unlink($filename);
			@unlink($dbpath."/search/".$cat."_".$fid."_".$pid."_c");

			//reduce the number of topics in the category
			SetLock();
			include($dbpath."/cats/".$cat."_".$fid);
			$ftopics--;
			if ($flastpostnumber>$pid){
			}else{
				$flastpostnumber--;
			}
			WriteForumInfo($cat,$fid);
			unlink($dbpath.'/block');
			//find  the last post in this forum
			$handle=opendir($dbpath."/posts");
			$maxtopics=$flastpostnumber;
			$found=0;
			for ($i=1;$i<=$maxtopics;$i++){
				$filename=$dbpath."/posts/".$cat."_".$fid."_".$i;
				if (file_exists($filename)){
					$found=1;
					$CFileTime=@filemtime($filename);
					if ($CFileTime>$TopFileTime)
					{
						include($filename);
						$TopFileTime=$CFileTime;
						$TopAuthor=$plastauthor;
						$Topdate=$plastdate;
						//fclose($fd);
						$Topid=$i;
					}
				}
			}  //end for
			SetLock();
			include($dbpath."/cats/".$cat."_".$fid);
			if ($found){
				$flastpost=$Topdate;
				$flastauthor=$TopAuthor;
				$flasturl="post.php?cat=$cat&fid=$fid&pid=$Topid&page=1";
				WriteForumInfo($cat,$fid);
			}else{
				$flastpost="";
				$flastauthor="";
				$flasturl="";
				WriteForumInfo($cat,$fid);
			}
			unlink($dbpath.'/block');
		}
		//reduce  author's postings-counter
		include ($dbpath."/members/".$orgauth);
		$userposts--;
		WriteUserInfo($orgauth);
		if ($userrank!="6" && $userrank!="7" && $userrank!="8" && $userrank!="9"){
			include ($dbpath."/members/".$orgauth);
			updatestatus($orgauth);
			WriteUserInfo($orgauth);
		}
	}
}

//return to index (can we return to the forum? Should be possible. Look into that later
if ($auto=="1"){
}else{
     echo "<meta http-equiv=\"Refresh\" content=\"0; URL=index.php\">";
}

ob_end_flush();

?>

