<?php
/***************************************************************************
 *                            logout.php  - PBLang
 *                            -------------------
 *
 *                  see the file copyright.txt in the docs-folder!!!
 ***************************************************************************/

error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
                                                     // always modified
header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");  

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include($dbpath."/settings.php");
include_once("functions.php");
include_once("ffunctions.php");

$username=$HTTP_COOKIE_VARS[$cookieid];
if ($username=="") {
        $loggedin="0";
        $admin="0";
        $allow="1";
} else {
     $allow="1";
     $filename = "$dbpath/members/$username";
     if (!file_exists($filename)) {
          $loggedin="0";
     } else {
          $loggedin="1";
          $language=SetLanguage($username);
          include("$temppath/$template/language/lang_$language.php");
          $ip = GetIPAddress();
          include($filename);
          $admin=$useradmin;
          $moder=$usermod;
          $ban=$userban;
     }
}
if ($ban=="1") {
     writeheader($newestm,$cat,$fid,$pid,$uname,$login,$VBanned);
     ErrorMessage($banreason,$username);
     setcookie ($cookieid, "", time() - 3600, "/");
     exit;
} else {
     if ($maint=="1" && $admin=="0") {
          writeheader($newestm,$cat,$fid,$pid,$uname,$login,$VMaintenanceMode);
          ErrorMessage($mreason,$username);
          setcookie ($cookieid, "", time() - 3600, "/");
          exit;
     } else {
          if ($allow=="1") {
               setcookie ($cookieid, "", time() - 3600, "/");
               @unlink("$dbpath/online/$username");
               echo "<meta http-equiv=\"Refresh\" content=\"0; URL=index.php\">";
          }
     }
}
ob_end_flush();
?>
