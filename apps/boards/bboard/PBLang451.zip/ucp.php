<?php
/***************************************************************************
 *                            ucp.php - PBLang
 *                            -------------------
*              see the file copyright.txt in the docs-folder
 ***************************************************************************/

error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include($dbpath."/settings.php");
include($dbpath."/settings/styles/styles.php");
include_once("functions.php");
include_once("ffunctions.php");
include_once("scan.php");

$liusername=$HTTP_COOKIE_VARS[$cookieid];
$permit=CheckLoginStatus($liusername,"1","0");
if ($permit=="1") {
	$language=SetLanguage($liusername);
	include($temppath.'/pb/language/lang_'.$language.'.php');

	$reg=$HTTP_GET_VARS['id'];
	$te=$HTTP_GET_VARS['te'];
	writeheader($newestm,0,0,0,$liusername,$loggedin,$VUserCP);
	$uname=$liusername;
	if ($reg!="2") {
		if (trim($te)=="") {
		} else {
			if ($admin=="1") {
					$uname=$te;
			}
		}
		if ($loggedin=="0") {
			echo "<meta http-equiv=\"Refresh\" content=\"0; URL=login.php\">";
			exit;
		} else {
//               ucp($uname,$language);
			include($dbpath."/members/".$uname);
			$realname=$userrealname;
			$alias=$useralias;
			$loc=$userlocation;
			$msn=$usermsn;
			$aim=$useraim;
			$yah=$useryahoo;
			$em=$useremail;
			$emhide=$useremhide;
			$pt=$userslogan;
			$sig=$usersig;
			$sig=stripslashes($sig);
			$sig=str_replace("<br>","\n",$sig);
			$uav=$useravatar;
			$uwebav=$userwebavatar;
			$web=$userhomepage;
			$icq=$usericq;
			$qq=$userqq;
			$animsm=$useranimsmilies;
			$userlng=$userlang;

			echo "<script language=\"JavaScript1.2\" src=\"ubbc.js\" type=\"text/javascript\"></script>";
			WriteTableTop();
			echo "\n";
			echo "<tr><td class=\"header\" colspan=\"2\">";
			echo "<a href=\"index.php\">$sitetitle</a> :: $VUserControlPanel";
			echo "</td></tr>\n<form method=\"post\" action=\"ucp.php?id=2&user=$uname\">";
			echo "<tr>";
			echo "<td class=\"subheader\" colspan=\"2\">$VPersonal $VSettings :: </td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VNewPassword:<br></font></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"password\" name=\"npass\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VRepeatPassword:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"password\" name=\"npass2\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VRealname:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"realname\" value=\"$realname\"></td></tr>\n";
			if ($allowalias=="1" || $admin=="1"){
				echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VAlias:</font><br></td>";
				echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"alias\" value=\"$alias\">&nbsp;$VExplainAlias</td></tr>\n";
			}
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VLocation:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"loc\" value=\"$loc\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">MSN:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"msn\" value=\"$msn\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">ICQ $VNumber:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"icq\" value=\"$icq\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">AIM:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"aim\" value=\"$aim\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">Yahoo:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"yah\" value=\"$yah\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">QQ:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"qq\" value=\"$qq\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VWebsite:</font><br></td>";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"web\" value=\"$web\"></td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VEmail:<br>";
			echo $VHideEmail."</font>";
			if ($emhide=="hide"){
				echo "<input type=\"checkbox\" name=\"emhide\" value=\"hide\" checked>";
			}else{
				echo "<input type=\"checkbox\" name=\"emhide\" value=\"hide\">";
			}

			echo "</td><td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"em\" value=\"$em\"></td></tr>\n";
			echo "<tr><td class=\"subheader\" colspan=\"2\">$VUser $VOptions :: </td></tr>\n";
			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VPersonalText:</font><br></td>
					<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"pt\" value=\"$pt\"></td></tr>\n";
			if ($ave=="1") {
				echo "<SCRIPT LANGUAGE=\"JavaScript\">\n";
				echo "function avchange(URL_List)\n";
				echo "{\n","var URL = URL_List.options[URL_List.selectedIndex].value;\n","document.avatari.src=\"templates/pb/images/avatars/\"+URL;\n";
				echo "}\n","</SCRIPT>\n";
				echo "<tr bgcolor=\"$fmenucolor\"><td height=\"25\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VAvatar:<br></font></td>";
				echo "<td height=\"25\" width=\"80%\" bgcolor=\"$menucolor\"><select name=\"av\" OnChange=\"avchange(this);\">";
				if (trim($uav)=="" && $uwebav==""){
					echo "<option value=\"none\" selected=\"selected\">$VNoAvatar</option>";
				}else{
					echo "<option value=\"none\">$VNoAvatar</option>";
				}
				$dir=$temppath."/pb/images/avatars/";
				if (file_exists($dir)){
					$handle = opendir("$dir");
					while ($file = readdir($handle)) {
						if ($file != "." && $file != "..") {
							echo "<option value=\"$file\"";
							if ($file==$uav) {
								echo "selected=\"selected\"";
							}
						echo ">$file</option>\n";
						}
					}
					closedir($handle);
				}
				if ($webave){
					if ($uwebav!=""){
							echo "<option value=\"webav\" selected>$VURLAvatar</option></select>";
					}else{
							echo "<option value=\"webav\">$VURLAvatar</option></select>";
					}
				}else{
					echo '</select>';
				}
				if ($uav!="" && $uav!="none" && $uav!="webav"){
					echo "&nbsp;<img src=\"templates/pb/images/avatars/$uav\" NAME=\"avatari\" alt=\"$VImage\">";
//                         echo "&nbsp;<img src=\"templates/pb/images/avatars/$uav\" NAME=\"$VAvatar $VImage\" alt=\"$VImage\">";
				}elseif($uwebav!=""){
					echo "&nbsp;<img src=\"$uwebav\" NAME=\"$VAvatar $VImage\" alt=\"$VImage\">";
				}
				echo "</td></tr>\n";
				if ($webave){
					echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VURLAvatar</font><br></td>";
					echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><input type=\"text\" name=\"webav\" value=\"$uwebav\">$AvatarURLtip</td></tr>\n";
				}
			}


			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"25\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VEnableAnimSmilies:<br></font></td>";
			echo "<td height=\"25\" width=\"80%\" bgcolor=\"$menucolor\">";
			if ($animsm=="1"){
				echo "<input type=\"checkbox\" name=\"animsm\" value=\"1\" checked>";
			}else{
				echo "<input type=\"checkbox\" name=\"animsm\" value=\"1\">";
			}
			echo "</td></tr>\n";

			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"25\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VDisableAvatars:<br></font></td>";
			echo "<td height=\"25\" width=\"80%\" bgcolor=\"$menucolor\">";
			if ($noavatars=="1"){
				echo "<input type=\"checkbox\" name=\"noavatars\" value=\"1\" checked>";
			}else{
				echo "<input type=\"checkbox\" name=\"noavatars\" value=\"1\">";
			}
			echo "</td></tr>\n";

			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"25\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VLanguageSelection:<br></font></td>";
			echo "<td height=\"25\" width=\"80%\" bgcolor=\"$menucolor\"><select name=\"ulang\">";
			LanguageSelection($userlng);
			echo "</select> $langexpl</td></tr>\n";

			echo "<tr bgcolor=\"$fmenucolor\">";
			echo "<td height=\"18\" width=\"20%\" align=\"right\"><font color=\"$menufont\">$VSignature:</font> <BR>
			(<a href=\"help.php\">$PBCodeAllowed</a>)<br></td>\n";
			echo "<td height=\"18\" width=\"80%\" bgcolor=\"$menucolor\"><textarea name=\"sig\" cols=\"60\" rows=\"4\">$sig</textarea></td></tr>\n";

			echo "<tr bgcolor=\"$subheadercolor\"><td height=\"18\" background=\"$subheadergif\" colspan=\"2\"><font color=\"$subheaderfont\">$VSubmitForm :: </font></td></tr>\n";

			echo "<tr bgcolor=\"$fmenucolor\"><td height=\"18\" width=\"20%\"><br></td>";
			echo "<td height=\"18\" width=\"80%\"><input type=\"submit\" name=\"Submit2\" value=\"$VSubmit\">\n";
			sbot();

		}
	} else {
		$user=$HTTP_GET_VARS['user'];
		include($dbpath."/members/".$user);
		$userrealname=$HTTP_POST_VARS['realname'];
		$alias=$HTTP_POST_VARS['alias'];
		$pass=$HTTP_POST_VARS['npass'];
		$pass2=$HTTP_POST_VARS['npass2'];
		if ($pass!=$pass2){
			ErrorMessage($PWNoMatch,$liusername);
			exit;
		}elseif (trim($pass!="")) {
			$password=md5($pass);
		}
		$sig=stripslashes($HTTP_POST_VARS['sig']);
		$usersig=replacestuff($sig);
		$userlocation=stripslashes($HTTP_POST_VARS['loc']);
		$usermsn=$HTTP_POST_VARS['msn'];
		$useraim=$HTTP_POST_VARS['aim'];
		$useryahoo=$HTTP_POST_VARS['yah'];
		$userhomepage=$HTTP_POST_VARS['web'];
		$userqq=$HTTP_POST_VARS['qq'];
		$usericq=$HTTP_POST_VARS['icq'];
		$userwebavatar=$HTTP_POST_VARS['webav'];
		$useremail=$HTTP_POST_VARS['em'];
		$useremhide=$HTTP_POST_VARS['emhide'];
		$av=$HTTP_POST_VARS['av'];
		$noavatars=$HTTP_POST_VARS['noavatars'];
		if ($av==$userwebavavatar){
			$useravatar="webav";
		}else{
			$useravatar=$av;
		}
		$userlang=$HTTP_POST_VARS['ulang'];
		$useranimsmilies=$HTTP_POST_VARS['animsm'];
		$userslogan=stripslashes($HTTP_POST_VARS['pt']);
		$userslogan=textparse($userslogan);

		if ($alias!=$useralias){
			if ($allowalias){
				$mindate=$lastaliaschange+($changealias*86400);
				if (time()<$mindate && $admin!="1"){
					ErrorMessage($ChangeAliasNotAllowed,$liusername);
					exit;
				}else{
					if (strpos($aliaslist)){
						$allowaliaschange='1';
						$usedalias='1';
					}else{
						$allowaliaschange=CheckAlias($alias);
					}
					if ($allowaliaschange=="1"){
						$useralias=$alias;
						$lastaliaschange=time();
						AddAlias($alias,$useralias);
						if (!$usedalias){
							$aliaslist=$aliaslist.'|'.$useralias;
						}
					}else{
						ErrorMessage($AliasAlreadyInUse,$liusername);
						exit;
					}
				}
			}
		}
		WriteUserInfo($user);
		echo "<meta http-equiv=\"Refresh\" content=\"0; URL=profile.php?u=$user\">";
		msg("$VUpdated","$user $ProfileUpdated!");
	}
	writefooter($newestm);
}
ob_end_flush();
?>


