<?php
/***************************************************************************
 *                           setcookie.php - part of PBLang
 *                            -------------------
 *              see the file copyright.txt in the docs-folder
 *
 * modified 17 Dec 2002
***************************************************************************/


error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
                                                     // always modified
header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");                          // HTTP/1.0

define('IN_PB', "true");
define('IN_PBG', "true");

$uname=$HTTP_GET_VARS['u'];
include("global.php");
include($dbpath.'/settings.php');
include_once("functions.php");
include_once("ffunctions.php");
@include($dbpath.'/'.$uname.'temp');
@unlink($dbpath.'/'.$uname.'temp');

$username=$HTTP_COOKIE_VARS[$cookieid];
if ($username=="") {
        $loggedin="0";
        $admin="0";
} else {
     $filename = $dbpath."/members/".$username;
     if (!file_exists($filename)) {
          $loggedin="0";
     } else {
          include($dbpath."/members/".$username);
          $admin=$useradmin;
          $ban=$userban;
     }
}
$language=SetLanguage($username);
include($temppath."/pb/language/lang_".$language.".php");
if ($ban=="1") {
     setcookie ($cookieid, "$username",-3600,"/");
     writeheader('',0,0,0,'',0,$VBanned);
     ErrorMessage($banreason,$username);
     exit;
} else {
     if ($loggedin=="1" && ($maint!="1" || $admin=="1")) {
          echo "<meta http-equiv=\"Refresh\" content=\"0; URL=index.php\">";
     } else {
          $filename = "$dbpath/members/$u";
          if (!file_exists($filename)) {
               writeheader('',0,0,0,'',0,$VError);
               ErrorMessage($NoSuchUser,$username);
               exit;
          } else {
               include($dbpath."/members/".$u);
               if ($password==$p) {
                    if ($maint=="1"){
                         if (!$useradmin) {
                              echo "<meta http-equiv=\"Refresh\" content=\"0; URL=logout.php\">";
                              exit;
                         }
                    }
                    setcookie ($cookieid, "$u",mktime(0,0,0,1,1,2020),"/");
                    include($dbpath."/members/".$u);
                    $userip=GetIPAddress();
                    WriteUserInfo($u);
                    echo "<meta http-equiv=\"Refresh\" content=\"0; URL=index.php?cookie=1\">";
               } else {
                    writeheader('',0,0,0,'',0,$VError);
                    ErrorMessage($InvalidPassword,$username);
               }
          }
     }
}
ob_end_flush();
?>
