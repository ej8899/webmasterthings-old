<?php
/*****************************************************************************

   Date: 3rd October 2002
   Done by Martin Senftleben - E-Mail: drmartinus@gmx.net
   http://www.drmartinus.de/
   my forum is at http://www.drmartinus.de/forum/index.php
   Support for PBLang you get at http://www.drmartinus.de/PBL/index.php

   *****************************************************************************

   This translation's language: Spanish
   The author of this translation: Symbol
   Website: http://www.emulespana.com

**********************************************************************************/

$NoSuchForum="No existe ese foro"; 
$ViewForum="Ver Foro";
$NoTopics="No hay temas en este foro";
$DeleteForum="Borrar Foro";
$VLockForum="Bloquear Foro";
$VUnlockForum="Desbloquear Foro";
$OpenTopic20="Un tema abierto, con m�s de 20 mensajes";
$OpenTopic="Un tema abierto";
$LockedTopic="Un tema cerrado";
$PMAlreadyDeleted="Este PM ya ha sido borrado";
$DeletePostNotAllowed="No tienes permiso para borrar este mensaje";
$NoEditInLockedForum="No se puede editar un foro bloqueado";
$EditPost="Editar mensaje";
$VError="Error"; 
$ContactAdmin="Contacta con el administrador en";
$VHelp="Ayuda";
$VExplanation="Explicaci�n";
$VExplanationPoint="Punto de exclamaci�n";
$VHelpIMG="Esto sirve para incluir im�genes en tus mensajes o firmas";
$VDisplays="Muestra";
$VHelpURL="Esto sirve para incluir enlaces en tus mensajes o firmas";
$VUsage="Uso";
$VHelpEMAIL="Esto para a�adir enlaces mailto : e-mail en tus mensajes o firmas";
$VHelpGLOW="Esto a�ade texto resaltado a tu mensajes o firma. Reemplaza COLOR con el color que quieras (red,blue,orange,green)";
$GlowText="Texto resaltado";
$VHelpITALICS="Esto pone el texto de tus mensajes o firmas en cursiva";
$ItalicText="Texto en cursiva";
$VHelpBold="Esto pone el texto de tus mensajes o firmas en negrita";
$BoldText="Texto en negrita";
$VIndex="�ndice";
$WhoIsThere="�Qui�n est� conectado?";
$AlreadyLoggedIn="Ya est�s validado";
$RegistrationRequired="Para leer en este foro debes estar validado o <a href=\"register.php\">registrarte</a>";    
$NonExistingUser="El usuario no existe";
$UsernameRequired="Debes escribir el nombre de usuario";
$PasswordRequired="Debes escribir la contrase�a";
$PasswordMessage="Tu password es";
$PasswordLost="He perdido mi contrase�a en";
$PasswordSent="Tu contrase�a ha sido enviado a tu e-mail";
$MemberList="Lista de miembros";
$PostReply="Respuesta al mensaje";
$NoReplyInLockedForum="No puedes contestar mensajes en un foro bloqueado";
$NoReplyInLockedTopic="No puedes contestar mensajes en un tema cerrado";
$UploadsNotAllowed="�No se permite enviar ficheros! El mensaje ha sido enviado";
$PostWait="Por favor, espera; se te est� redireccionando a tu mensaje";
$NoNewTopicInLockedForum="No puedes a�adir temas a un foro bloqueado";
$LangLocale="es_ES";
$PrivateMessaging="Mensajes privados";
$NoMessages="No hay mensajes en la bandeja de entrada";
$ViewPost="Ver mensaje";
$VFunctions="Funciones";
$DeleteTopic="Borrar tema";
$LockTopic="Cerrar tema";
$UnlockTopic="Desbloquear tema";
$AlreadyMember="Ya eres miembro";
$NoNewUsers="No se permiten nuevos usuarios";
$VRegister="Registrarse";
$PleaseComplete="Por favor, rellena todos los campos requeridos";
$WelcomeMessage="Bienvenido a";
$WelcomeMessage1=" : Foros";
$ThanksMessage="Gracias por apuntarte";
$UsernameTaken="Ese nombre de usuario ya existe";
$VSearch="Buscar";
$NoResults="No hay resultados";
$SendPM="Enviar PM";
$AuthorRequired="Debes rellenar el campo Autor/a";
$MessageSent="Tu mensaje privado ha sido enviado";
$InvalidUsername="Nombre de usuario no v�lido";
$NoSuchUser="Ese usuario no existe";
$InvalidPassword="Contrase�a incorrecta";
$VUserCP="Perfil";        //"UserCP";
$ProfileUpdated=" : Su perfil ha sido actualizado";
$Updated="Actualizado";
$VMembers="miembros";        //"members";
$VMembers1="miembro";        //"member";            //singular form
$VMembers24="miembros";        //"members";          //plural form
$VMembers59="miembros";        //"members";          //plural form - 2 forms needed for Russian language - hence also in other languages a second plural form
                        //$VMember="";        //"member"; - no longer needed
$VAdministrator="Administrador";
$VAdminPC="Admin: Panel de control";
$VModerator="Moderador";
$VUser="Usuario";
$AccessDenied="Acceso denegado";
$AdminCenter="Centro de Administraci�n";
$PbNews="Noticias PBLang";
$VWhatIsThe="Qu� es el";
$AdminCenterExplain="�ste es tu 'Centro de Administraci�n Powerboards'. Desde aqu� puedes modificar tus preferencias y plantillas, as� como mantener el foro. Por favor, ten cuidado ya que hay algunas configuraciones que podrian liar tu foro.";
$VVersionCompare="Comparaci�n de versi�n";
$CompareString="El m�s nuevo/El tuyo";
$LatestRelease="Tienes la �ltima versi�n";
$NewerRelease="�Hay una nueva versi�n!";
$VForumSettings="Configuraci�n del Foro";
$VTitle="T�tulo";
$VTemplate="Plantilla";
$VSiteMotto="SiteMotto";        //"SiteMotto";
$VFooter="Pie";
$VSubmit="Enviar";
$VReset="Borra";
$VStylesColors="Estilos/Colores";
$VBackground="Fondo";
$VBody="Fondo de p�gina";
$VAlternatingColor1="Alternar con Color 1";
$VAlternatingColor2="Alternar con Color 1";
$VHeaderColor="Color de la cabecera";
$VHeaderBG="Fondo de la cabecera";
$VSubheaderColor="Color de la sub-cabecera";
$VSubheaderBG="Fondo de la sub-cabecera";
$VExtraBorderColor="Color de borde extra";
$VExtraBorderWidth="Ancho de borde extra";
$VStandardBorderColor="Color de borde est�ndard";
$VBorderColor="Color de borde";
$VLinkColor="Color de los enlaces";
$VVisitedLinkColor="Color de los enlaces visitados";
$VHoverLinkColor="Color de los enlaces al pasar el puntero";
$AdminOptionsExplain="Estas opciones aprovechan muy poco de la capacidad de Powerboards para trabajar con plantillas; los usuarios avanzados deber�ais provar la secci�n de Plantillas para editarlo todo.";
$VDone="hecho";
$VTemplate="Plantilla";
$TemplateEditWarning="Los ficheros de plantilla utilizan algo de PHP que resulta b�sico, por favor, �ten mucho cuidado al cambiarlos!";
$ChooseTemplate="Escoge una plantilla para editar. Editando estas plantillas lo puedes editar todo.";
$VMenu="Men�";
$VView="Ver";      
$VMain="Principal";
$VSettings="Configuraci�n";
$VTemplates="Plantillas";
$VMemberGroups="Grupos del miembro";
$VBanMembers="Banear a los miembros";
$VBanMember="Banear al miembro";
$VEmailMembers="Enviar e-mail a los miembros";
$VGrantStatus="Cambiar status";
$VCategories="Categor�as";
$VForum="Foro";
$VForums="Foros";
$VAddForums="A�adir Foros";
$VEditForums="Editar Foros";
$VEditForum="Editar Foro";
$VPrevPage="P�gina Anterior";
$VNextPage="Siguiente P�gina";
$VPage="P�gina";
$VOf="de";
$VSubject="Asunto";
$VAuthor="Autor";
$VReplies="Respuestas";
$VLastReply="�ltima respuesta";
$VViews="Vistas";
$VOptions="Opciones";
$VUsername="Nombre de usuario";
$SubjectIcon="Icono de Asunto &amp; Mensaje";
$VSmiley="Smiley";
$VShocked="Sorprendido";        //"Shocked";
$VHuh="��Eh??";
$VTongue="Sacar la lengua";
$VWink="Gui�o";
$VEvil="Malo";
$VEmbarassed="Avergonzado";
$VGoofy="Goofy";        //"Goofy";
$VRollEyes="Girar los ojos";        //"Roll Eyes";
$VHyperlink="Enlace";
$VImage="Im�gen";
$VEmail="E-mail";
$VGlow="Destacado";        //"Glow";
$VBold="Negrita";
$VItalicize="Cursiva";
$VContent="Contenido";
$VAttachment="Archivo adjunto";
$NoAttachments="No se permite adjuntar archivos";
$VSubmitForm="Enviar";
$VHello="Hola";
$VYouHave="tienes";
$VMessages="mensajes";
$VMessages1="mensaje";
$VMessages24="mensajes";
$VMessages59="mensajes";
$VPlease="Por favor";
$VLogin="Iniciar sesi�n";
$VLogout="Cerrar Sesi�n";        //"log out";
$VRegister="reg�strate";        //"register";
$VHome="Inicio";
$VSearch="Buscar";
$VHelp="Ayuda";
$VPM="Mensajes privados";
$AdminPC="Administraci�n del foro";
$VTopics="Temas";
$VTopics1="Tema";
$VTopics24="Temas";
$VTopics59="Temas";
$VLastPost="�ltimo mensaje";
$TimeDate="La fecha y hora actual es";
$VPassword="Contrase�a";
$RetrievePassword="Recuperar la contrase�a";
$EmailFrom="E-mail de";
$VPosts="Mensajes";
$VPosts1="Mensaje"; 
$VPosts24="Mensajes";
$VPosts59="Mensajes";
$VPosition="Posici�n";
$VPost="Mensaje";
$VDeletePost="Borrar tu mensaje";
$VNewTopic="Nuevo tema";
$VStandard="Est�ndard";
$VThumbsUp="Pulgar arriba";
$VThumbsDown="Pulgar abajo";
$VExplanationPoint="Punto de explicaci�n";
$VQuestionMark="Signo de pregunta";
$VAngry="Enfadado";
$VMad="Loco";
$VSad="Triste";
$VSendPM="Enviar PM";
$VReply="Contestar";
$VDelete="Borrar";
$VStatus="Estado";
$VProfileFor="Perfil de";
$VModify="Modificar";
$VAvatar="Avatar";
$NoAvatars="Ahora no se permiten Avatares";
$VEnableAvatars="Permitir Avatares";
$VLocation="Poblaci�n";
$VWebsite="P�gina Web";
$VSignature="Firma";
$VRegistrationComplete="Proceso de registro completo";
$ThanksForSigning="Gracias por apuntarte";
$VHere="aqu�";
$NoNewUsers="Ahora no se permite el registro de nuevos miembros";
$VProfile="Perfil";
$VNumber="N�mero";
$VRequired="Requerido";
$VTopicReview="Sumario del tema";
$VSearchTerms="Palabras a buscar";        //"Search Terms";
$VSearchResults="Resultados de la b�squeda";
$VSendMessage="Enviar mensaje";
$VInbox="Bandeja de entrada";
$VMessage="Mensaje";
$VStats="Estad�sticas";
$VCurrentMembers="Actualmente hay";
$VCurrentMember="Actualmente hay";
$VLatestMember="El �ltimo miembro registrado es";
$VTheSearchTerm="La b�squeda";        //"The Search Term";
$VFoundResults="encontr� los siguientes resultados";
$VUserControlPanel="Panel de Control de usuario";
$VUserControlCenter="Centro de Control de usuario";
$VPersonal="Personal";
$VNewPassword="Nueva contrase�a";
$VPersonalText="Texto personal";
$VList="Listar";
$AvatarURLtip="(Nota: tienes que seleccionar URL Avatar de la lista anterior para usar esta funci�n)";
$PBCodeAllowed="PBcode y smilies permitidos";
$VPasswordAgain="Repite la contrase�a";
$VWhoIsOnline="�Qui�n est� conectado?";
$VLoggedIn="conectados";        //"logged in";
$VLoggedOn="conectado";        //"logged on";
$VLoggedOff="desconectado";        //"logged off";
$VOr="o";
$NoAccess="No tienes acceso. Si crees que deber�as tenerlo, refresca la p�gina";
$VDisableAttachments="No permitir adjuntar archivos";
$VEnableHTML="Permitir HTML";
$VCensorWords="Censurar las palabrotas";
$VEnableBBCode="Permitir BB code";
$VEnableSmilies="Permitir smilies";
$VAllowNewUsers="Permitir nuevos usuarios";
$VMaintenanceMode="Modo mantenimiento";
$VOnlyAdmins="S�lo los administradores tienen acceso";
$RequireLogin="Los usuarios deben estar validados";
$VToViewForum="para ver los mensajes";
$VMaintReason="Motivo del mantenimiento";
$VBannedReason="Motivo del baneo";
$AdminEmail="E-mail del administrador";
$AdminEmailReason="la direcci�n de e-mail aparecer� en las p�ginas de error para permitir mandar avisos del error";
$VComplete="Completo";        //"Complete";
$VTemplateEditor="Editor de plantillas";
$VInfinity="Infinidad";
$VBanned="Baneado";
$VCategory="Categor�a";
$VAddCategory="A�adir categor�a";
$VEditCategories="Editar categorias";
$VEditCategory="Editar categoria";
$ExplainAddCategory="Rellena este formulario para a�adir una categor�a";
$VName="Nombre";
$VDesc="Descripci�n";
$VVia="Via";
$VPrivateMessage="Mensaje privado";
$VWhichStatus="en qu� estado";
$VBan="Banear";
$VUnban="Volver a admitir";
$VNever="Nunca";
//$AdministrativeFunctions="";        //"administrative functions";  - not needed any more
$VOn="en";        //"on";         //  a particular date
$VBy="por";        //"by";         //  a particular person
$VSent="Enviado";        
$NoPermission="�No tienes permiso para realizar esta acci�n!";        
$VLocked="El tema ha sido cerrado - no es posible responder";

// status 19 Sept 2002
$VHideEmail="Esconder el e-mail de los otros miembros";
$VHidden="Oculto";
$Charset="iso-8859-1";
// status 21 Sept 2002
$VNewMember="Nuevo miembro";
$VWith="con";
$VAllowEmail="Permitir e-mails";
$VThereIs="hay";       
$VThereAre="hay";      
$VEdited="Editado";
$VEditMembergroups="Editar grupos del miembro";
//status 22 Sept 2002
$VAnd="&amp;";
$SetRequireLogin="Los usuarios deben estar registrados";
$VTo="Para"; 
$VSmilies="Smilies";
$VPBCode="PBCode";
$CVLogin="'Log in', empieza con una letra may�scula";                  //"Log in"; start with capital letter
//status 23 Sept 2002
$VPosted="Escrito";                 //"Posted"; a message has been posted...
$PBLSupportLink="Ayuda PGLang";	
$NotifyReplySent="Hola,\n\n Alguien ha respondido a tu mensaje en ".$sitetitle.", con el t�tulo ";
$VNotifyByEmail="�Quieres que te avisemos cuando se enviee un mensaje?";
$EmailNotification="Notificaci�n de -mail";
$VAdministrativeFunctions="Funciones Administrativas";
$VURLAvatar="URL Avatar";               //URL Avatar";
//status 27 Sept. 2002
$ForumLocked="Este grupo est� bloqueado";              
$WrongUsername="El nombre de usuario s�lo puede contener caracter.jpg o y n�meros"; 
$WrongEmailAddress="�sa direcci�n de e-mail no es v�lida";   
//status 2 Oct 2002
$VWrote="escribir";
$VFrom="de";               
$VNoTemplatesEdit="No deberias editar plantillas utilizando esta interface. Por favor, usa un editor apropiado para editar los archivos que contengan c�digo.";
//status 3. Oct. 2002
$VFontColor="Color de letra";
$VFontsize="Tama�o de letra...";
$DateFormat1="%d/%m/%y";
$DateFormat2="%A, %d de %B %Y, %R";
$VLessThan="Menos que";
$VLanguageEdit="Editar fichero de idioma";
$VRemoveMembers="Borrar Usuarios";
$VRemove="Borrar";
$VMemberRemoved="El usuario ha sido borrado";

$Vpicturebuttons="Usar botones";
$profilealt="Perfil";
$profiletitle="Perfil";
$Vprofil="Perfil";
$emailalt="Enviar email";
$emailtitle="Enviar email";
$Vemail="Enviar email";
$editalt="Editar mensaje";
$edittitle="Editar mensaje";
$Vedit="Editar mensaje";
$sendpmalt="Enviar MP";
$sendpmtitle="Enviar MP";
$Vsendpm="Enviar MP";
$yimalt="Enviar YIM";
$yimtitle="Enviar YIM";
$Vyim="Enviar YIM";
$aimalt="Enviar AIM";
$aimtitle="Enviar AIM";
$Vaim="Enviar AIM";
$msnalt="Enviar MSN";
$msntitle="Enviar MSN";
$Vmsn="Enviar MSN";
$icqalt="Enviar ICQ";
$icqtitle="Enviar ICQ";
$Vicq="Enviar ICQ";
$wwwalt="P�gina web";
$wwwtitle="P�gina web";
$Vwww="P�gina web";
//Posts
$newthreadalt="Mensaje nuevo";
$newthreadtitle="Mensaje nuevo";
$replyalt="Responder";
$replytitle="Responder";
$lockedalt="cerrado";
$lockedtitle="cerrado";
//header images
$homealt="Inicio";
$hometitle="Inicio";
$searchalt="Buscar";
$searchtitle="Buscar";
$helpalt="Ayuda";
$helptitle="Ayuda";
$logoutalt="Cerrar sesi�n";
$logouttitle="Cerrar sesi�n";
$ucpalt="Perfil";
$ucptitle="Perfil";
$pmalt="MP";
$pmtitle="MP";
$loginalt="Iniciar sesi�n";
$logintitle="Iniciar sesi�n";
$registeralt="Registrar";
$registertitle="Registrar";
$adminalt="PCAdmin";
$admintitle="PCAdmin";
$memberslistalt="Miembros";
$memberslisttitle="Miembros";
//status 5th Oct. 2002
$VPreviousMessages="Mensajes anteriores";
$VTextColor="Color del texto";
$VMoreThan="M�s de";
//status 8th October
$NoSuchFile="�El archivo no existe!";
//status 9th October
$VRE="RE";
//status 10th October
$PWNoMatch="La password es incorrecta. Prueba de nuevo.";
$VDefault="Por defecto";
$VStars="Estrellas";
$VFlames="Llamas";
$VRankImages="Im�genes de los rangos";
$VMaxPostsReply="N� de mensajes a mostrar cuando se contesta";
$VEditPost="Editar mensaje";
//status 11th October
$VReplied="Contestado";
$VNew="Nuevo";
$VOriginalPM="MP Original";
$VRead="Leer";
//status 12 Oct 2002
$VNoSubject="Sin asunto";
//status 13 Oct 2002
$VOrderOfReplies="Onden de las respuestas";
$VFirstReplyFirst="Primera respuesta primero";
$VFirstReplyLast="�ltima respuesta primero";
//status 14 Oct 2002
$VStyleHeaderFont="Estilo de la letra";
$VStyleHeaderPage="Fondo de la p�gina";
$VStyleHeaderTitle="Cabecera del foro";
$VStyleHeaderMenu="Men� de cabecera del foro";
$VStyleHeaderDate="Etiqueta de fecha";
$VStyleHeaderContainer="Contenedor de formulario";
$VStyleHeaderHeader="Cabecera";
$VStyleHeaderSubheader="Subcabecera";
$VStyleHeaderMenu="Men�";
$VStyleHeaderForumButton="Boton(es) del foro";
$VStyleHeaderUserColors="Colores de usuario";
$VStyleHeaderLinkColors="Colores de los enlaces";

$VBackground="Fondo";
$VForm="Fondo Interior";
$VFormBorder="Borde del fondo interior";
$VFormBorderSize="Tama�o del borde el fondo interior";
$VForumHeaderBorder="Color del borde de la cabecera";
$VForumHeaderBorderSize="Tama�o del borde";
$VForumHeader="Color de la cabecera";
$VForumHeaderTitle="Color de la letra de la cabecera";
$VForumHeaderTitleSize="Tama�o de la letra de la cabecera";
$VForumHeaderCaption="Color de la letra del t�tulo de la cabecera";
$VForumHeaderWelcome="Color de la letra de bienvenida de la cabecera";
$VForumHeaderMenu="Color del men� de la cabecera";
$VForumHeaderMenuFont="Color de la letra del men� de la cabecera";
$VDateColor="Fuente de la fecha";
$VContainerBorder="Color del borde del contenedor";
$VContainerBorderSize="Tama�o del borde del contenedor";
$VContainerInner="Color del contenedor";
$VHeaderColor="Color de la cabecera";
$VHeaderGif="Imagen de la cabecera";
$VHeaderFont="Color de la letra de la cabecera";
$VSubheaderColor="Color de la subcabecera";
$VSubheaderGif="Imagen de la subcabecera";
$VSubheaderFont="Color de la letra de la subcabecera";
$VMenuColor="Color de men�";
$VFMenuColor="Color del men� fijo";
$VMenuFont="Color de la letra del men� fijo";
$VForumButtonColor="Color del bot�n del foro";
$VForumButtonOver="Color por encima del bot�n del foro";
$VForumButtonTopics="Color de los temas del foro";
$VForumButtonReplies="Color de las respuestas del foro";
$VForumButtonLast="Color de la �ltima respuesta del foro";
$VAdminColor="Color de la letra de Administrador";
$VModColor="Color de la letra de Moderador";
$VUserColor="Color de la letra de Usuario";
//status 16 Oct 2002
$VServerTimezone="Zona horaria del servidor";
$VLocalTimezone="Hora local";
$VExplainTimezone="Si la hora local no es correcta, por favor ajustala seleccionando el n�mero correcto";
$VTimeZone="Zona horaria";
$VBurningFlames="Burning flames";
//status 17 Oct 2002
/*The following 3 variables allow a better output in the stats-line. Ending 1 is the singular form for the beginning of the sentence like
"There is currently 1 members". Ending 24 und 59 are the plural forms for the beginning of the sentence like "There are currently 7 members".
If you had the variables $VCurrentMember and $VCurrentmembers in older lang-files, you can remove them now - they are no longer used.
*/
$VCurrentMembers1="Actualmente hay";
$VCurrentMembers24="Actualmente hay";
$VCurrentMembers59="Actualmente hay";
//status 18 Oct 2002
$VEMSupport="El servidor soporta email mediante PHP";
$VNoEMSupport="Lo siento, el servidor no soporta emails mediante PHP";
$VDefaultSlogan="Eslogan por defecto";
$VExplainSlogan="El eslogan est� debajo del avatar";
//status 19 Oct 2002
$VPredefStyles="Estilos predefinidos";
$VNotWriteable="Lo siento, no se puede escribir el fichero";
//status 20 Oct 2002
$VRemoveStatus="Estado normal";
$VOfTheseNew="Nuevos";
//status 21 Oct 2002
$VMaxAtchSize="Tama�o m�x. del fichero vinculado en bytes (0= sin l�mite)";
$VFileTooBig="Lo siento, el fichero es demasiado grande. El tama�o est� restringido. No puedes subir el fichero. Pon un enlace en su lugar.";
$VCookieError="Este foro requiere las cookies habilitadas. Tu navegador parece que no las tiene habilitadas, comprueba su configuraci�n.";
//status 22 Oct 2002
$VNotice="Noticia";
$VUsernameGiven="El nombre de usuario ya est� cogido";
//status 28 Oct 2002
$VUsernameLimits="^[a-zA-Z0-9]+$";       /*this is to check the username for invalid characters (important where Windows is the server) -
                                                            leave the string as it is for ordinary names in Latin characters, otherwise check the ereg-rules.
                                                            If you leave it empty, it will not check the username for valid characters.*/
$VDate="Fecha";
$VLanguagechoice="de=Alem�n, el=Griego, en=Ingl�s, es=Espa�ol, fi=Finland�s, ro=Rumano, ru=Ruso, se=Servio, zh=Chino";
$VLanguageSelection="lenguaje";
//status 29 Oct 2002
$VRepeatPassword="repetir password";                    //"repeat password";
//status 31 Oct 2002
$qqalt="QQ";
$qqtitle="QQ";
//status 2 Nov 2002
$VStyleButtonChoice="Selecci�n de bot�n";
$VButtonLimits="Esta selecci�n s�lo tendr� efecto si no usas unos botones espec�ficos para este lenguaje.";


?>
