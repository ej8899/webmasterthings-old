<?php
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   Dies ist die DEUTSCHE Sprachendatei. Sie k�nnen die Texte bearbeiten, aber Vorsicht: jede �nderung k�nnte eine Nachricht in der Software unbrauchbar machen!
//   Wenn Sie etwas �ndern, senden Sie mir bitte die Datei, damit ich sie in das komplette Paket einbinden kann.
//   Bitte markieren Sie gut sichtbar die Zeilen, in denen Sie �nderungen vorgenommen haben!
//   Version: 2.3.9a
//   Datum: 18. September 2002
//   Erstellt von Martin Senftleben - E-Mail: drmartinus@gmx.net
//   http://www.drmartinus.de/
//   Mein Forum ist unter http://www.drmartinus.de/forum/index.php zu erreichen
//
// Bu bir T�rkce dil dosyasidir.Dosyayi istediginiz sekilde yeniden d�zenleyebilirsiniz,ancak yapacaginiz
// her degisiklik programin calismasinda hata olusturabilir!
// Herhangi bir degisiklik yaptiginizda ,l�tfen dosyanin bir kopyasini Scripti programlayan sayin
// Martin Senftleben - E-Mail: drmartinus@gmx.net 

// g�nderiniz Site adresi: http://www.drmartinus.de/forum/index.php
// L�tfen degisiklik yaptiginiz kisimlari anlasilir olmasi icinbelirgin sekilde isaretleyiniz!
// Version: 4.0
// Tarih:08 Subat 2003
// Duzenleye-Ceviren : Cengiz Kibaroglu
// e-mail:admin@lazebura.com
// http://www.lazebura.com
// Forum adresi : http://www.lazebura.com/forum/index.php

///////////////////////////////////////////////////////////////////////////////////////////////////////////
$NoSuchForum="B�yle bir Forum yok!";
$ViewForum="Forum";
$NoTopics="Forumda herhangi bir konu yok!";
$DeleteForum="Forumu sil";
$VLockForum="Forumu kullanimdan cikar";
$VUnlockForum="Forum ac";
$OpenTopic20="20 den fazla konu ile acilmis Forum";
$OpenTopic="Acik konular";
$LockedTopic="Kapali konular";
$PMAlreadyDeleted="Bu haberi sildiniz!";
$DeletePostNotAllowed="Haberi silme yetkisine sahip degilsiniz!";
$NoEditInLockedForum="Kapali forumda konu �zerinde d�zeltme yapamazsiniz!";
$EditPost="Haberi d�zenle";
$VError="Hata";
$VFunctions="Fonksiyonlar";
$ContactAdmin="Eger giriste sorun yasiyorsaniz Administrator ile baglantiya geciniz";
$VHelp="Yardim";
$VExplanation="Aciklama";
$VExplanationPoint="Devam isareti";
$VHelpIMG="Bununla resim ve yazi g�r�nt�leyebilirsiniz";
$VDisplays="Yandaki gibi g�r�n�r";
$VHelpURL="Burada link yada �zel ekleri d�zenleyebilirsiniz";
$VUsage="Degisiklik";
$VHelpEMAIL="Bununla link yada �zel ekleri link seklinde olusturabilirsiniz";
$VHelpGLOW="Bununla link ekleyebilir,d�zenleyebilirsiniz.Renk olustur.Kirmizi (=rot), mavi (=blau), turuncu yada yesil (=gr�n)";
$GlowText="Parlak yazi";
$VHelpITALICS="Bununla yazinizi yada �zel ekinizi kursiv olusturabilirsiniz";
$ItalicText="Kursiv yazi";
$VHelpBold="Bununla yazinizi kalinlastirabilirsiniz";
$BoldText="Kalin yazi";
$VIndex="Icerik";
$WhoIsThere="Kimler giris yapti?";
$AlreadyLoggedIn="Su anda giris yaptiniz";
$RegistrationRequired="Admin sizin buradan <a href=\"register.php\">kayit</a>olmanizi istiyor.Ancak bu sekilde foruma yazi yazabilirsiniz";
$NonExistingUser="B�yle bir �ye mevcut degil";
$UsernameRequired="Kullanici adi  girmeniz gerekiyor";
$PasswordRequired="Sifre girmeniz gerekiyor";
$PasswordMessage="Sifrenizi admin tarafindan onaylandiktan sonra e-mailinize yollanacaktir";
$PasswordLost="Kullanici tarafindan unutulan Sifre";
$PasswordSent="Sifreniz e-mail adresinize g�nderildi";
$MemberList="�ye";
$PostReply="Cevap yaz";
$NoReplyInLockedForum="Kapali Foruma mesaj yazamazsiniz";
$NoReplyInLockedTopic="Kapali forumda cevap yazamazsiniz";
$UploadsNotAllowed="Dosya y�klenemedi.Mesaj yollandi";
$PostWait="L�tfen bekleyin! Mesaj yollaniyor";
$NoNewTopicInLockedForum="Kapali forumda yeni haber ekleyemezsin";
$DateFormat1="%e.%m.%y";
$DateFormat2="%e. %B %Y, %H:%M";
$LangLocale="de_DE";
$PrivateMessaging="�zel Mesaj";
$NoMessages="Yeni mesaj yok";
$ViewPost="Mesajlari g�r";
$DeleteTopic="Konu sil";
$LockTopic="Konuyu kullanimdan kaldir";
$UnlockTopic="Konuyu baskalarina kapat";
$AlreadyMember="Zaten �yesiniz";
$NoNewUsers="Yeni �yelere kapali";
$VRegister="Kayit";
$PleaseComplete="L�tfen butun bosluklari doldurunuz";
$WelcomeMessage="Hosgeldiniz";
$WelcomeMessage1="s Forum";
$ThanksMessage="Kayit oldugunuz icin tesekk�rler";
$UsernameTaken="Kullanici adi mevcut";
$VSearch="Ara";
$NoResults="Bulunamadi";
$SendPM="�zel mesaj yolla";
$AuthorRequired="Kullanici adi gerekiyor";
$MessageSent="�zel mesajiniz yollandi!";
$InvalidUsername="Gecersiz uye adi";
$NoSuchUser="Himm, iyi bir deneme ama uye mevcut";
$InvalidPassword="Gecersiz sifre";
$VUserPC="Uyelik Bilgileri";
$VMaintenanceMode="Bekleme modu";
$ProfileUpdated=" - Uyelik bilgileri degistirildi";
$VUpdated="�zerinde calisildi";
$VMembers="�yelik";
$VMembers1="�ye";                  //Singularform
$VMembers24="�yelik";               // Pluralform
$VMembers59="�ye";               //Pluralform  - 2 Pluralformen werden f�r Russisch ben�tigt, daher auch hier in Deutsch
//$VMember="�ye";
$VAdministrator="Administrator";
$VAdminPC="Administrator Yonetim bolumu";
$VModerator="Moderator";
$VUser="�ye";
$AccessDenied="Giris engellendi";
$AdminCenter="Yonetim merkezi";
$PBNews="Lazeburaya Yeni mesaj";
$WhatIsThe="Bu nedir?";
$AdminCenterExplain="Bu yonetim kismidir.Burada bilgileri degistirebilir yeniden d�zenleyebilirsiniz.";
$VVersionCompare="Versiyon karsilastirma";
$CompareString="En yeni versiyon";
$LatestRelease="Yeni versiyona sahipsiniz";
$NewerRelease="Bask yeni evrsiyon yok";
$VForumSettings="Forum ayarlari";
$VTitle="Forum ismi";
$VTemplate="Vorlage (Template)";
$VSiteMotto="�zel mesaj";
$VFooter="Dipnot";
$VSubmit="Tamam";
$VReset="Yeniden baslat";
$VStylesColors="Renk ayarlari";
$VBackground="Arkaplan";
$VBody="K�rper";
$VAlternatingColor1="Wechselfarbe 1";
$VAlternatingColor2="Wechselfarbe 2";
$VHeaderColor="Titelfarbe";
$VHeaderBG="Titel Hintergrundfarbe";
$VSubheaderColor="Untertitel Farbe";
$VSubheaderBG="Untertitel Hintergrundfarbe";
$VExtraBorderColor="Au�enrahmenfarbe";
$VExtraBorderWidth="Au�enrahmenbreite";
$VStandardBorderColor="Standard Rahmenfarbe";
$VBorderColor="Rahmenfarbe";
$VLinkColor="Link Farbe";
$VVisitedLinkColor="Farbe eines besuchten Links";
$VHoverLinkColor="Farbe, wenn Maus �ber Link steht (hover)";
$AdminOptionsExplain="Diese Einstellungen kratzen nur an der Oberfl�che. Fortgeschrittene Anwender k�nnen in der Vorlagensektion bis zum HTML-Level alle Einstellungen ver�ndern";
$VDone="Fertig";
$VTemplate="Vorlage";
//$TemplateEditWarning="Vorlagendateien verwenden einige PHP-Elemente, bitte seien Sie sehr vorsichtig, wenn Sie diese �ndern wollen!";
$ChooseTemplate="W�hlen Sie eine Vorlage. Hier k�nnen Sie wirklich alles ver�ndern.";
$VMenu="Men�";
$VView="G�r�n�m";
$VMain="Genel";
$VSettings="Ayarlar";
$VTemplates="Vorlagen";
$VMemberGroups="�ye statusunu degistir";
$VBanMembers="�ye statusu kaldir";
$VBanMember="�ye statusu kapat";
$VEmailMembers="�yelere e-mail yolla";
$VGrantStatus="Statu atama";
$VCategories="B�l�mler";
$VForums="Forumlar";
$VAddForums="Forum ekle";
$VEditForums="Forum d�zenle";
$VEditForum="Forum degistir";
$VPrevPage="�nceki sayfa";
$VNextPage="Sonraki sayfa";
$VPage="Sayfa";
$VOf="den";
$VSubject="Baslik";
$VAuthor="Yazar";
$VReplies="Yanitlanan";
$VLastReply="En son cevap";
$VViews="G�z at";
$VOptions="Islemleri";
$VUsername="�ye ismi";
$SubjectIcon="Baslik &amp; Icon";
$VSmiley="Gulec";
$VShocked="sasirmis";
$VHuh="He?";
$VTongue="dil";
$VWink="Nanik";
$VEvil="Kizgin";
$VEmbarassed="Panik";
$VGoofy="Kafayi yemis";
$VRollEyes="D�nen g�zler";
$VHyperlink="Hyperlink";
$VImage="Resim";
$VEmail="E-Mail";
$VGlow="Parlak";
$VBold="Kalin";
$VItalicize="Kursiv";
$VContent="Icerik";
$VAttachment="Ek";
$NoAttachments="Su an ekleme yapilamiyor";
$VSubmitForm="Sorgulama islemini baslatmak icin tiklayin";
$VHello="Merhaba";
$VYouHave="sana ait";
$VMessages="Mesaj";
$VMessages1="Mesaj";
$VMessages24="Mesaj";
$VMessages59="Mesaj";
$VPlease="L�tfen";
$VLogin="Giris";
$VRegister="L�tfen �ye olunuz.�yelik �cretsizdir";
$VHome="Anasayfa";
$VSearch="Arama";
$VHelp="Yardim";
$VLogout="Cikis";
$VPM="�zel mesaj";
$AdminPC="Administrator yonetim";
$VTopics="Konu";
$VTopics1="Konu";      //Singular- und Pluralform - f�r Erkl�rung s. oben unter $VMembers
$VTopics24="Konu";
$VTopics59="Konu";
$VLastPost="Son haber";
$TimeDate="Bu g�n ";
$VPassword="Sifre";
$RetrievePassword="Sifre yolla";
$VPosts="Haber";
$VPosts1="Haber";                 //Singular- und Pluralform - f�r Erkl�rung s. oben unter $VMembers
$VPosts24="Haber";
$VPosts59="Haber";
$VPosition="Konum";
$VPost="Haber";
$VDeletePost="Haberi sil";
$VNewTopic="Yeni Konu";
$VStandard="Standard";
$VThumbsUp="Yukari";
$VThumbsDown="Asagi";
$VExplanationPoint="Virg�l";
$VQuestionMark="Soru isareti";
$VAngry="Kizgin";
$VMad="Kafayi yemis";
$VSad="�zg�n";
$VSendPM="�zel mesaj yolla";
$VReply="Cevapla";
$VDelete="Sil";
$VStatus="Konum";
$VProfileFor="Profil ";
$VModify="Desitir";
$VAvatar="Avatar";
$NoAvatars="Su an Avatar m�mk�n degil";
$VEnableAvatars="Avatara izin ver";
$VLocation="Yer";
$VWebsite="Webseite";
$VSignature="Imza";
$VRegistrationComplete="�yelik isleminiz tamamlandi";
$ThanksForSigning="Kayit oldugunuz icin tesekk�rler";
$VHere="burada";
$NoNewUsers="Su an icin yeni �yelik mumkun degil";
$VProfile="Profil";
$VNumber="Numara";
$VRequired="Zorunlu";
$TopicReview="Konuya bakis";
$VSearchTerms="Aranan kelime";
$VSendMessage="Mesaj yolla";
$VInbox="giriniz";
$VMessage="Haber";
$VStats="Istatistikler";
$VLatestMember="Yeni �ye";
$VThereIs="Su anda";
$VThereAre="Su an ";
$VSearchResults="Arama sonucu";
$VTheSearchTerm="Aranan kelime";
$VFoundResults="Bulunan ";
$VUserControlPanel="�ye ayarlari";
$VUserCP="Mitgliedereinstellungen";
$VUserControlCenter="uye Ayarlari";
$VPersonal="�zel";
$VNewPassword="Yeni sifre";
$VPersonalText="�zel Mesaj";
$VList="Liste";
$PBCodeAllowed="PBCode und Smilies sind zul�ssig";
$PasswordAgain="Sifre tekrar";
$VWhoIsOnline="Kimler online?";
$VLoggedIn="giris yapti";
$VLoggedOn="giris yapti";
$VLoggedOff="cikis yapti";
$VOr="yada";
$NoAccess="Giris hakkiniz yok";
$VDisableAttachments="Yasaklandi";
$VEnableHTML="HTML erlauben";
$VCensorWords="beleidigende W�rter zensieren";
$VEnableBBCode="BBCode erlauben";
$VEnableSmilies="Smilies erlauben";
$VAllowNewUsers="neue Mitglieder zulassen";
$Mode="Bearbeitungsmodus";
$VOnlyAdmins="Dadece Admin icin secilmis alan";
$RequireLogin="�yeler giris yapmali";
$VToViewForum="Mesajlari g�rmek icin";
$VMaintReason="Grund f�r Bearbeitungsmodus";
$VBannedReason="Grund f�r Ausschlu�";
$AdminEmail="Admin e-mail adresleri";
$AdminEmailReason="Die E-Mail-Adresse wird auf Fehlerseiten angezeigt, damit Fehlerberichte �bermittelt werden k�nnen.";
$VComplete="Tamamlandi";
$VTemplateEditor="Vorlageneditor";
$VInfinity="sonsuz";
$VBanned="Sutlandi";
$VAddCategory="Grup ekle";
$VEditCategories="Grup d�zenle";
$VEditCategory="Grup yeniden d�zenle";
$VCategory="Gruplar";
$ExplainAddCategory="Grup eklemek icin Formu doldurunuz";
$VName="isim";
$VDesc="Aciklama";
$VVia="hakkinda";
$VPrivateMessage="Forum ici �zel mesaj";
$VWhichStatus="Hangi konum";
$VBan="Tamamla";
$VUnban="tekrar izin ver";
$VNever="Hen�z yok";
//$AdministrativeFunctions="Adminstrative Funktionen";
$VOn="de";         // soundsovielten
$VBy="den";        // einer Person
$VSent="Yollandi";
$NoPermission="Izin yok!";
$VLocked="Konu kapandi, cevaplama m�mk�n degil";
$VHideEmail="E-Mail Adresini baska �yelerden gizle";
$VHidden="gizlendi";
$Charset="iso-8859-9";
$VNewMember="Yeni �ye";
$VWith="ile";
$VAllowEmail="automatische Emails erlauben";
$VEdited="D�zenlendi";
$VEditMembergroups="Mitgliedergruppen bearbeiten";
//Stand 22. Eyl�l. 2002
$VAnd="&amp;";
$VLanguageSelection="Sprache (de=Deutsch, en=Englisch, ru=Russisch)";
$SetRequireLogin="�yeler giris yapmali";
$VTo="e";
$VSmilies="G�l�c�k";
$VPBCode="PBCode";
$CVLogin="Giris";
//Stand 23. Eyl�l. 2002
$VPosted="Y�kle";
$PBLSupportLink="PBLang icin Englizce destek";
$VReplySent="Yeni mesajiniz var";         //�berschrift der Email
$NotifyReplySent="Merhaba,\n\n    Konu hakkinda yeni mesaj yollanmadi ".$sitetitle."Lazebura Forum";     //Inhalt der Email
$VNotifyByEmail="Mesajiniza cevap yazildiginda E-mailinize de yollansin mi?";
$EmailNotification="E-Mail �zerinden haber";
$VAdministrativeFunctions="Admin Foksiyon";
$VURLAvatar="URL ile Avatar";
//Stand 27. Eyl�l. 2002
$VForumLocked="Bu Grup kulanimdan kaldirildi";
$WrongUsername="Uyelik ismi yanlis.L�tfen dogru sekilde giriniz";
$WrongEmailAddress="Gecersiz e-mail adresi";
//Stand 2. Ekim 2002
$VFrom="den";
$VNoTemplatesEdit="Burada yazinizi d�zenleyemezsiniz.L�tfen yazinizi d�zenlemek icin herhangi bir Edit�r Programi kullaniniz!";
//status 3. Ekim. 2002
$VFont="Font";
$VFontColor="Font rengi";
$VFontsize="Font b�y�kl�g�";
$VLessThan="den az";
$VLanguageEdit="Dil secenegini yeniden d�zenle";
//status 4. Ekim. 2002
$VRemoveMembers="�yeleri iptal et";
$VRemove="kaldir";
$VMemberRemoved="Bu �ye mevcut degil";

//imagelinks
$Vpicturebuttons="Button degistir";
$profilealt="Profile bak";
$profiletitle="Profile bak";
$Vprofile="Profile bak";
$emailalt="E-Mail yolla";
$emailtitle="E-Mail yolla";
$Vemail="E-Mail yolla";
$editalt="Yaziyi d�zenle";
$edittitle="Yaziyi d�zenle";
$Vedit="Yaziyi d�zenle";
$sendpmalt="�zel Mesaj yolla";
$sendpmtitle="�zel Mesaj yolla";
$Vsendpm="Private Nachricht senden";
$yimalt="YIM yolla";
$yimtitle="YIM yolla";
$Vyim="YIM yolla";
$aimalt="AIM yolla";
$aimtitle="AIM yolla";
$Vaim="AIM yolla";
$msnalt="MSN yolla";
$msntitle="MSN yolla";
$Vmsn="MSN yolla";
$icqalt="ICQ yolla";
$icqtitle="ICQ yolla";
$Vicq="ICQ yolla";
$wwwalt="Websitesi";
$wwwtitle="Websitesi";
$Vwww="Websitesi";
//Beitr�ge
$newthreadalt="Yeni Konu";
$newthreadtitle="Yeni Konu";
$Vnewthread="Yeni Konu";
$replyalt="Cevapla";
$replytitle="Cevapla";
$Vreply="Cevapla";
$lockedalt="Kapatildi";
$lockedtitle="Kapatildi";
$Vlocked="Kapatildi";
//header images
$homealt="Foruma Bakis";
$hometitle="Foruma Bakis";
$searchalt="Ara";
$searchtitle="Ara";
$helpalt="Yardim";
$helptitle="Yardim";
$logoutalt="Kayit sil";
$logouttitle="Kayit sil";
$ucpalt="Kullanici ayari";
$ucptitle="Kullanici ayarlari";
$pmalt="�zel mesaj";
$pmtitle="�zel Mesaj";
$loginalt="Kayit";
$logintitle="Kayit";
$registeralt="Kayit ol";
$registertitle="Kayit ol";
$adminalt="Administrator";
$admintitle="Administrator";
$memberslistalt="Uye";
$memberslisttitle="�ye";
//Stand 5. Ekim 2002
$VPreviousMessages="�nceki Mesajlar";
$VTextColor="Yazi rengi";
$VMoreThan="den fazla";
//Stand 8. Ekim
$NoSuchFile="B�yle bir dosya yok!";
//Stand 9. Oktober
$VRE="Cevap.";
//status 10th October
$PWNoMatch="Sifre yanlis! L�tfen tekrar giriniz.";
$VDefault="Normal";
$VStars="Yildiz";
$VFlames="Bayrak";
$VRankImages="Resim";
$VMaxPostsReply="Cevaplamada birden fazla haberi g�ster";
$VEditPost="Habei tekrar d�zenle";
//Stand 11. Ekim
$VReplied="Cevaplandi";
$VNew="Yeni";
$VOriginalPM="Cevaplanan yazi";
$VRead="Okundu";
//status 12 Oct 2002
$VNoSubject="Baslik yok";
//status 13 Oct 2002
$VOrderOfReplies="Vevabin d�zenlenmesi";
$VFirstReplyFirst="Ilk cevap";
$VFirstReplyLast="Ilk cevap";
//status 14 Oct 2002
$VStyleHeaderFont="Yazi sekli";
$VStyleHeaderPage="Arkaplan";
$VStyleHeaderTitle="Forum baslik";
$VStyleHeaderMenu="Forum baslik men�";
$VStyleHeaderDate="Tarih";
$VStyleHeaderContainer="Dosya alani";
$VStyleHeaderHeader="Baslik";
$VStyleHeaderSubheader="Altbaslik";
$VStyleHeaderMenu="Men�";
$VStyleHeaderForumButton="Forum g�r�n�m";
$VStyleHeaderUserColors="Kullanici rengi";
$VStyleHeaderLinkColors="Link rengi";

$VBackground="Arkaplan";
$VForm="Arkaplan Bord";
$VFormBorder="Cerceve rengi";
$VFormBorderSize="Cerceve b�y�kl�g�";
$VForumHeaderBorder="Baslik cerceve rengi";
$VForumHeaderBorderSize="Baslik b�l�m� cerceve b�y�kl�g�";
$VForumHeader="Baslik b�l�m� arkaplan rengi";
$VForumHeaderTitle="Bord isminin baslik rengi";
$VForumHeaderTitleSize="Bord siminin buyuklugu";
$VForumHeaderCaption="Altbaslik yazi rengi";
$VForumHeaderWelcome="Hosgeldin yazisinin rengi";
$VForumHeaderMenu="Baslik kismi yazi buyuklugu";
$VForumHeaderMenuFont="Baslik kismi yazi rengi";
$VDateColor="Tarih yazisinin rengi";
$VContainerBorder="Yazi alani yazi rengi";
$VContainerBorderSize="Yazi alaninin buyukligu";
$VContainerInner="Yazi alaninin arka plan rengi";
$VHeaderColor="Yazi alani baslik kisminin rengi";
$VHeaderGif="Yazi alani baslik kisminin arka plan rengi";
$VHeaderFont="Yazi alani yazi rengi";
$VSubheaderColor="Yazi alani altbaslik rengi";
$VSubheaderGif="Yazi alani altbaslik arkaplan rengi";
$VSubheaderFont="Yazi alani baslik yazi rengi";
$VMenuColor="Forum arkaplan rengi";
$VFMenuColor="Forum baslik rengi";
$VMenuFont="Forum anabaslik yazi rengi";
$VForumButtonColor="Forum listesi arkaplan rengi";
$VForumButtonOver="Forum listesi degisken rengi";
$VForumButtonTopics="Forum listesi yan kutucuk konu arkaplan rengi";
$VForumButtonReplies="Forum listesi yan kutucuk Cevap arkaplan reng";
$VForumButtonLast="Forum listesi yan kutucuk son haber arkaplan rengi";
$VAdminColor="Administrator yazi rengi";
$VModColor="Moderator yazi rengi";
$VUserColor="�ye yazi rengi";

$VServerTimezone="Kaldigi s�re";
$VLocalTimezone="Forumda kalis s�resi";
$VExplainTimezone="Forumdaki zaman dogru degilse,l�tfen seceneklerden ayarlayin";
$VTimeZone="Zaman dilimi";
$VBurningFlames="Yanan bayrak";
$VCurrentMembers1="Su anda";    //The variables $VCurrentMember and $VCurrentmembers can be removed!
$VCurrentMembers24="Su anda";
$VCurrentMembers59="Su anda";
$VEMSupport="PHP ile e-mail desteklensin";
$VNoEMSupport="�zg�n�z, su an icin PHP �zerinden E-mail m�mk�n degil";
$VDefaultSlogan="Ana Slogan";
$VExplainSlogan="Slogan-Avatar";
$VPredefStyles="Hazirlanmis Styles";
$VNotWriteable="Hata olustu";
$VRemoveStatus="Normal Konum";
$VOfTheseNew=" Yeni mesaj sayisi ";
$VMaxAtchSize="Max. Dosya b�y�kl�g� (0=sinirsiz)";
$VFileTooBig="Dosya gereginden b�y�k.";
$VCookieError="L�tfen Cookies ayarlarini acik tutunuz";
$VNotice="Aciklama";
$VUsernameGiven="Kullanici adi mevcut";
$VUsernameLimits="^[a-zA-Z0-9]+$";
$VDate="Tarih";
$VLanguagechoice="tr=Turkce, de=Deutsch, el=Griechisch, en=Englisch, es=Spanisch, fi=Finnisch, ro=Rum�nisch, ru=Russisch, se=Serbisch, zh=Chinesisch";
$VLanguageSelection="Dil secimi";
$VRepeatPassword="Sifre tekrar";
$qqalt="QQ";
$qqtitle="QQ";
//status 2 Nov 2002
$VStyleButtonChoice="Button-Secimi";
$VButtonLimits="Bu secenek, eger yeni bir dil secimi yapacaksaniz etkili olacaktir.";
//status 4 Nov 2002
$VIn="de";
$VRealname="Gercek isim";
$VAlias="Nick";
$VExplainAlias="Uyelik isminiz yaninda baska bir Nick ile bulunabilirsniz.";
$VSlogan="Slogan";
//status 5 Nov 2002
$VStyleHeaderMemgroupColors="Farben der Mitgliedergruppen";
$VDateJoined="Giris tarihi";
$VLastVisit="En son uye";
$VLastPost="En son yanitlayan";
$VGroupColors="Grup rengini etkili kil";
$VGroupcolorsExplain="Bununla Grup sat�s�nde olanlarin kendi renk secimin yapabilmelerini onayliyorsunuz";
//status 6 November 2002
$VIPLogged="IP-Numarasi kaydedildi";
$VSiteLogo="Platform icin logo";
$VSiteLogoExplain="Resmin templates/pb/images dizininin altina copyalanmasi gerekiyor.L�tfen dosyanin adini giriniz.";
$VMaxPPP="Her sayfada ne kadar haberin yayinlanacagi";
//status 11 Nov 2002
$VRequestConfirmation="Uyelik onay E-Mail �zerinden";
$VPleaseConfirm="L�tfen uyeliginizi asagidaki linki tiklayarak onaylayiniz:";
//status 11 Nov 2002
$VNoAvatar="Avatar yok"; //in the selection list, choose this if you don't want an avatar
$AvatarURLtip="(Tipp:Yukardaki listeden Avatar seciniz,bu sekilde Avatari etkili kilmis olursunuz)";
//status 13 Nov 2002
$VDeleteCat="Grup sil";
$VConfirmation="�yelik Onaylama";
$VWrongConfirmationCode="Sifre dogru degil";
$VConfirmationError="Onaylama sirasinda bir hata olustu";
$VNoCatDelete="Grup silemezsiniz.�nce forumu siliniz";
//status 15 Nov 2002
$VStyleAnnouncementFont="Ek bilgi-Ayarlari";
//status 16 Nov 2002
$Vgladg="G�l�c�k";
$Vgrinsg="Stresli";
$Vbadg="Keyifsiz";
$Vschluckg="ohjeh";
$Vsunglg="G�nes g�zl�g�";
$Vteardrop="G�zyasi";
$Vsurprised="sasirmis";
$Vsleeping="uykulu";
$Vthmbup="okey";
$Vthmbdn="berbat";
$Vpfeilrg="ok saga";
$Vbulb="Fikir";
$VHelpg="Yardim!";
$Vbounceg="Sallanma";
$Vdanceg="Dans";
$Vredface2g="Kizarmis y�z";
$Vdevilg="Seytan";
$Vschimpfg="sikayetci";
$Vwallbashg="Kafayi duvara carpma";
$Vofftopicg="acik konu!";
$VEnableAnimSmilies="animasyon";
//status 19 Nov 2002
$VAllowAlias="Aliase izin veriliyor";
$VChangeAlias="Aliase degistirilebilir";
$VDays="G�nler";
$ChangeAliasNotAllowed="Alis degistiremezsiniz";
$AliasAlreadyInUse="Alis kullanimda";
$VAllowAccess="Asagidaki �yeler bu Forumu kullanabilir";
$VAll="herkes";
$VModerators="Moderatoren";
$VFriend="Arkadas";
$VExplainFriend="Ayni grup icinde yer alan �ye kisiler, arkadas grubuna girer";
$VExpectConformationMail="E-mail adresinize yollaniyor.E-mailde belirtilen linki tiklayarak uyeliginizi onaylayiniz";
//status 20 Nov 2002
$VWelcomeMessage="Merhaba";
//status 21 Nov 2002
$VCheckIP="Ek g�venlik: IP numaraniz kaydedilsin mi?";
$VSitelogoWidth="Logo genislik(pixel)";
$VSitelogoHeight="Logo y�kseklik(pixel)";
//status 22 Nov 2002
$VAnnounce="Giris sayfasinda �zel mesaj";
//status  27 Nov 2002
$VToday="Bu gun";
$VVisits1="Misafir";
$VVisits24="Misafir";
$VVisits59="Misafir";
$VTotalVisits="Toplan ziyaretci sayisi";
$VLastVisitors="Son ziyaretci";
//status 30 Nov 2002
$VUsernameTooLong="Uyelik ismi fazla uzun max 25";
$VNotifyAdmin="Yeni yazi eklendiginde Admini uyar";
$VNotifyAdminReplies="Her yeni mesajda Admini uyar";
//status 1 Dec 2002
$VNewReply="Yeni cevap";
//status 4 Dec 2002
$VAlreadyUpdated="Upload basarisiz";
//status 7 Dec 2002
$VFolderIconChoice="Dizin secimi";
$ficonalt="Dizin sembolu";
//status 8 Dec 2002
$VForbiddenType="Yasak dosya t�rleri. Resim olarak (gif, jpg, tif), Teks olarak (txt) ve arsiv olarak (zip, rar) upload yapabilirsiniz.";
$VUserIsOnline="�ye su anda online silemezsiniz";
$VQuotaExceeded="Dosyayi upload edebilmeniz icin yeterinde kayit alani mevcut degil";
$VMinimumSpace="Sabitdisk alani (in Bytes)";
//status 10 Dec 2002
$VGuestVisits="Misafir";
$VTotalGuests="Toplam Ziyaretci";
$VAllVisits="Misafir ve �yeler";
//status 11 Dec 2002
$VRules="Ana Kurallar";
//status 12 Dec 2002
$DateFormat3="%d.%m.%y, %H:%M";
//status 13 Dec 2002
$VGuests1="Misafir";
$VGuests24="Ziyaretci";
$VGuests59="Ziyaretci";
//status 16 Dec 2002
$VUnknown="Tanimlanmamis";
$VRemoved="silindi";
$VMaxAvatarWidth="Maksimum genisli-Avatar resim icin(pixel)";
$VMaxAvatarHeight="Maksimum uzunluk-Avatar resim icin(pixel)";
//status 17Dec 2002
$VAcceptRules="Kurallari okudum ve kabul ediyorum";
$VRulesMustBeAccepted="�ncelikle kurallari kabul etmeniz gerekiyor.L�tfen kutucugun icini isaretleyiniz";


?>
