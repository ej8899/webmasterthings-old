<?php
$NoSuchForum="Ok�nt forum!";
$ViewForum="Visa Forum";
$NoTopics="Inga Rubriker i detta forum!";
$DeleteForum="Radera Forum";
$VLockForum="L�s Forum";
$VUnlockForum="L�s upp Forum";
$OpenTopic20="�ppen rubrik med fler �n 20 inl�gg";
$OpenTopic="�ppen rubrik";
$LockedTopic="L�st rubrik";
$PMAlreadyDeleted="Detta meddelande har redan raderats!";
$DeletePostNotAllowed="Du kan inte radera annans meddelande!";
$NoEditInLockedForum="Du kan inte editera i l�st forum";
$EditPost="Editera inl�gg";
$VError="Fel";
$ContactAdmin="Kontakta Admin p�";
$VHelp="Hj�lp";
$VExplanation="F�rklaring";
$VExplanationPoint="Utropstecken";
$VHelpIMG="Anv�nds f�r att visa bilder i inl�gg eller signaturer";
$VDisplays="Visar";        //"Displays";
$VHelpURL="Anv�nds f�r att l�gga till hyperl�nkar i inl�gg eller signatur";        //"This is used to add web hyperlinks in your posts or signatures";
$VUsage="Anv�ndning";
$VHelpEMAIL="Anv�ndas f�r att l�gga till mailto: email-l�nkar i inl�gg eller signatur";        //"This is to add mailto: email links to your posts or signatures";
$VHelpGLOW="L�gger till gl�dande text i inl�gg eller signatur. Byt till valfri f�rg (r�d, bl�, orange, gr�n)";
$GlowText="Gl�dande text";
$VHelpITALICS="Anv�nds f�r att g�ra kursivera text i inl�gg eller signatur";        //"This makes your text italic in your post or signature";
$ItalicText="Kursiv text";        //"Italic Text";
$VHelpBold="Anv�ndas f�r att gj�ra text fet i inl�gg eller signatur";        //"This makes your text bold in your post or signature";
$BoldText="Fet text";
$VIndex="Index";
$WhoIsThere="Vilka �r inloggade?";
$AlreadyLoggedIn="Du �r redan inloggad";
$RegistrationRequired="Forumets administrat�r kr�ver att alla medlemmar loggar in eller <a href=\"register.php\">registrerar</a> sig innan de l�ser inl�gg i forumet";        //"The board administrator requires that all veiwers login or <a href=\"register.php\">register</a> before viewing the board";
$NonExistingUser="Anv�ndare ok�nd";
$UsernameRequired="M�ste ange anv�ndarnamn";
$PasswordRequired="M�ste ange l�senord";
$PasswordLost="F�rlorat l�senordet p�";   //"Lost Password at" - used as subject of the email in which the lost password is sent, it follows the name of the forum;
$PasswordSent="Ditt l�senord har skickats till angiven emailadress";        //"Your password has been sent to your email address";
$MemberList="Medlemslista";
$PostReply="Posta Svar";
$NoReplyInLockedForum="Du kan inte svara i l�st forum";
$NoReplyInLockedTopic="Du kan inte svara under l�st rubrik";
$UploadsNotAllowed="Uppladdningar ej till�tna. Meddelandet publicerat";
$PostWait="V�nligen v�nta, dirigerar om inl�gg";
$NoNewTopicInLockedForum="Du kan inte skapa nya rubriker i l�st forum";        //"You can not make new topics in a locked forum";
$LangLocale="en_SV";        //"en_EN"; or "de_DE" or "ru_RU" or "fi_FI" etc.
$PrivateMessaging="Privat Meddelande";
$NoMessages="Inget meddelande i inl�da";
$ViewPost="L�s Meddelande";
$VFunctions="Funktioner";
$DeleteTopic="Radera Rubrik";
$LockTopic="L�s Rubrik";
$UnlockTopic="L�s upp Rubrik";
$AlreadyMember="Du �r redan medlem";
$NoNewUsers="Forumet adminsitrat�r till�ter inte nya medlemmar";        //"The board administrator does not allow new users";
$VRegister="Registrera";
$PleaseComplete="V�nligen fyll i alla obligatoriska f�lt";
$WelcomeMessage="V�lkommen till";
$WelcomeMessage1="s forum";
$ThanksMessage="Tack f�r Ditt medlemskap";
$UsernameTaken="Anv�ndarnamnet upptaget";
$VSearch="S�k";
$NoResults="Inga tr�ffar";
$SendPM="Skicka Meddelande";
$AuthorRequired="M�ste ange f�rfattare";
$MessageSent="Privat meddelande s�nt";
$InvalidUsername="Ogiltigt Anv�ndarnamn";
$NoSuchUser="Bra f�rs�k, men anv�ndarnamnet existerar inte";
$InvalidPassword="Ogiltigt L�senord";
$VUserCP="Medlemmars Kontrollpanel";
$ProfileUpdated="s profil har updaterats";        //"'s profile has been updated";
$VUpdated="Uppdaterat";        //"Updated";
$VMembers="Medlemmar";
$VMembers1="medlem";        //"member";            //singular form
$VMembers24="medlemmar";        //"members";          //plural form
$VMembers59="medlemmar";        //"members";          //plural form - 2 forms needed for Russian language - hence also in other languages a second plural form
                        //$VMember="";        //"member"; - no longer needed
$VAdministrator="Administrat�r";
$VAdminPC="Administrat�rens Kontrollpanel";
$VModerator="Moderator";
$VUser="Anv�ndare";
$AccessDenied="Tilltr�de F�rbjudet";
$AdminCenter="Administrat�rscenter";
$PbNews="PBLang News feed";        //"PBLang News Feed";
$VWhatIsThe="Vad �r";
$AdminCenterExplain="Detta �r kontrollpanelen f�r PBLang. Du kan �ndra bla. generella inst�llningar och spr�kinst�llningar h�r.";
$VVersionCompare="Versionj�mf�relse";
$CompareString="Nyast/Ditt";        //"Newest/Yours";
$LatestRelease="Du har senaste versionen";
$NewerRelease="Uppdaterat version finns att tillg�.";
$VForumSettings="Foruminst�llningar";
$VTitle="Titel";
$VTemplate="Mall";
$VSiteMotto="Forumm�tto";
$VFooter="Fotnot";
$VSubmit="Posta";
$VReset="Nollst�ll";
$VStylesColors="Utseende/F�rger";
$VBackground="Bakgrund";
$VBody="Body";        //"Body";
$VAlternatingColor1="Alternativ F�rg 1";
$VAlternatingColor2="Alternativ F�rg 2";
$VHeaderColor="Header Color";        //"Header Color";
$VHeaderBG="Header Background";        //"Header Background";
$VSubheaderColor="Sub Header Color";        //"Sub Header Color";
$VSubheaderBG="Sub Header Background";        //"Sub Header Background";
$VExtraBorderColor="Extra Ramf�rg";        //"Extra Border Color";
$VExtraBorderWidth="Extra Ramtjocklek";        //"Extra Border Width";
$VStandardBorderColor="Standard Ramf�rg";        //"Standard Border Color";
$VBorderColor="Ramf�rg";        //"Border Color";
$VLinkColor="L�nkf�rg";
$VVisitedLinkColor="Bes�kt l�nkf�rg";        //"Visited Link Color";
$VHoverLinkColor="Hovrande l�nkf�rg";        //"Hover Link Color";
$AdminOptionsExplain="These options only scratch the surface of Powerboards template capability, for advanced users, try the templates section to edit everything down to the HTML tables.";
$VDone="Klart";        //"done";
$VTemplate="Mall";        //"Template";
$ChooseTemplate="V�lj mall att editera. Genom att editera dessa mallar kan Du �ndra allt ner till HTML-niv�.";        //"Choose a template to edit. By editing these templates you can edit everything down to the HTML tables."
$VMenu="Meny";
$VView="Visa";
$VMain="Hem";
$VSettings="Inst�llningar";        //"Settings";
$VTemplates="Mallar";        //"Templates";
$VMemberGroups="Medlemsgrupper";        //"Member Groups";
$VBanMembers="Porta Medlemmar";        //"Ban Members";
$VBanMember="Porta Medlem";        //"Ban Member";
$VEmailMembers="Maila Anv�ndare";        //"Email Members";
$VGrantStatus="Tilldela Status";        //"Grant Status";
$VCategories="Kategorier";
$VForum="Forum";
$VForums="Forum";
$VAddForums="L�gg till Forum";
$VEditForums="Editera Forum";
$VEditForum="Editera Forum";
$VPrevPage="F�rg�ende Sida";
$VNextPage="N�sta Sida";
$VPage="Sida";
$VOf="av";        //"of";
$VSubject="�mne";
$VAuthor="F�rfattare";
$VReplies="Svar";
$VLastReply="Senast svar";        //"Last Reply";
$VViews="L�sningar";        //"Views";
$VOptions="Alternativ";
$VUsername="Anv�ndarnamn";
$SubjectIcon="�mne &amp; Postikon";        //"Subject &amp; Post Icon";
$VSmiley="Smiley";        //"Smiley";
$VShocked="Shockad";        //"Shocked";
$VHuh="�h?";        //"Huh?";
$VTongue="Tunga";        //"Tongue";
$VWink="Blink";        //"Wink";
$VEvil="Elak";        //"Evil";
$VEmbarassed="Pinsam";        //"Embarassed";
$VGoofy="Stollig";        //"Goofy";
$VRollEyes="Rulla med �gonen";        //"Roll Eyes";
$VHyperlink="Hyperl�nk";
$VImage="Bild";        //"Image";
$VEmail="Email";        //"Email";
$VGlow="Lysa";        //"Glow";
$VBold="Fet";        //"Bold";
$VItalicize="Kursivera";
$VContent="Inneh�ll";
$VAttachment="Bilaga";
$NoAttachments="Inga bilagor till�tna f�r n�rvarande";        //"No attachments are allowed right now";
$VSubmitForm="Skicka Meddelande";
$VHello="Hej";
$VYouHave="du har";
$VMessages="meddelanden";        //"messages";
$VMessages1="meddelande";        //"message";
$VMessages24="meddelanden";        //"messages";
$VMessages59="meddelanden";        //"messages";
$VPlease="V�nligen";        //"Please";
$VLogin="logga in";        //"log in";
$VLogout="logga ut";        //"log out";
$VRegister="registrera";        //"register";
$VHome="Hem";        //"Home";
$VSearch="S�k";
$VHelp="Hj�lp";        //"Help";
$VPM="Privata Meddelanden";
$AdminPC="AdminPC";        //"AdminPC";
$VTopics="�mnen";
$VTopics1="�mne";                  //singular and plural forms - see above under $VMembers for explanation!
$VTopics24="�mnen";
$VTopics59="�mnen";
$VLastPost="Senaste Inl�gg";
$TimeDate="Aktuellt datum och tid �r ";
$VPassword="L�senord";
$RetrievePassword="�terskapa l�senord och f� l�senordet skickat via email";        //"Retrieve password"; on the button at registration to get the password via email
$VPosts="Inl�gg";
$VPosts1="Inl�gg";        //"Post";                        //singular and plural forms - see above under $VMembers for explanation!
$VPosts24="Inl�gg";        //"Posts";
$VPosts59="Inl�gg";        //"Posts";
$VPosition="Status";        //"Status";
$VPost="Meddelande";        //"Post";
$VDeletePost="Radera meddelande";        //"Delete your post";
$VNewTopic="Ny rubrik";
$VStandard="Standard";
$VThumbsUp="Tummen upp";        //"Thumbs up";
$VThumbsDown="Tummen ner";        //"Thumbs down";
$VExplanationPoint="F�rklaring";        //"Explanation point";
$VQuestionMark="Fr�getecken";        //"Question mark";
$VAngry="Arg";        //"Angry";
$VMad="Galen";        //"Mad";
$VSad="Ledsen";        //"Sad";
$VSendPM="Skicka Meddelande";        //"Send PM";
$VReply="Svara";        //"Reply";
$VDelete="Radera";
$VStatus="Status";
$VProfileFor="Profil f�r";
$VModify="Modifiera";
$VAvatar="Avatar";
$NoAvatars="Avatar ej till�tna f�r n�rvarande";        //"No Avatars are allowed at this time";
$VEnableAvatars="Aktivera Avatar";        //"Enable Avatars";
$VLocation="Ort";        //"Location";
$VWebsite="Hemsida";        //"Website";
$VSignature="Signatur";        //"Signature";
$VRegistrationComplete="Registrering komplett";
$ThanksForSigning="Tack f�r att Du registrerade Dig";
$VHere="h�r";
$NoNewUsers="Inga nya meddlemmar till�tna f�r n�rvarande";
$VProfile="Profil";
$VNumber="Nummer";        //"Number";
$VRequired="Kr�vs";        //"Required";
$VTopicReview="Rubrik�versikt";        //"Topic Review";
$VSearchTerms="S�kord";        //"Search Terms";
$VSearchResults="S�kresultat";
$VSendMessage="Skicka Meddelande";
$VInbox="Inl�da";
$VMessage="Meddelande";
$VStats="Statistik";
$VLatestMember="Den nyaste medlemmen �r";        //"The newest member is";
$VTheSearchTerm="S�kordet";
$VFoundResults="fick f�ljande tr�ffar";        //"found the following results";
$VUserControlPanel="Anv�ndarkontrollpanel";        //"User Control Panel";
$VUserControlCenter="Anv�ndarkontrollcenter";        //"User Control Center";
$VPersonal="Personligt";        //"Personal";
$VNewPassword="Nytt L�senord";
$VPersonalText="Personlig Text";
$VList="Visa";        //"List";
$PBCodeAllowed="PBkod och smilies till�tna";        //"PBcode and smilies allowed";
$VPasswordAgain="Repetera l�sneord";        //"Password Again";
$VWhoIsOnline="Vilka �r inloggade";        //"Who is online?";
$VLoggedIn="inloggade";        //"logged in";
$VLoggedOn="inloggad";        //"logged on";
$VLoggedOff="utloggad";        //"logged off";
$VOr="eller";
$NoAccess="Du har inte tilltr�de. Om Du tror att detta �r fel, l�s om sidan (F5).";
$VDisableAttachments="Avaktivera Bilagor";
$VEnableHTML="Aktivera HTML";
$VCensorWords="Censurera ord";
$VEnableBBCode="Aktivera BB-kod";
$VEnableSmilies="Aktivera smileys";
$VAllowNewUsers="Till�t nya medlemmar";
$VMaintenanceMode="Adminstrationsl�ge";
$VOnlyAdmins="Endast administrat�rer har tilltr�de";
$RequireLogin="Kr�v att anv�ndare �r p�loggade";
$VToViewForum="f�r att l�sa meddelandena";
$VMaintReason="Administrationsorsak";
$VBannedReason="Orsak till portning";
$AdminEmail="Adminstrat�rens email";
$AdminEmailReason="Emailadressen kommer att framg� p� felmdddelanden f�r att inbjuda till felrapportering";        //"the email address will be seen on error pages to allow error reports";
$VComplete="F�rdig";        //"Complete";
$VTemplateEditor="Malleditor";
$VInfinity="Infinity";        //"Infinity";
$VBanned="Portad";
$VCategory="Kategori";
$VAddCategory="L�gg till Kategori";
$VEditCategories="Editera Kategorier";
$VEditCategory="Editera Katagori";  //"Rad 269":
$ExplainAddCategory="Fyll i denna blankett f�r att l�gga till kategori";
$VName="Namn";
$VDesc="Beskrivning";
$VVia="Via";
$VPrivateMessage="Privat Meddelande";
$VWhichStatus="Vilken status";
$VBan="Porta";
$VUnban="�ngra portning";
$VNever="Aldrig";
//$AdministrativeFunctions="adminstrativa funktioner";
$VOn="vid";        //"on";         //  a particular date
$VBy="av";
$VSent="Skickat";
$NoPermission="Du har inte till�telse att utf�ra denna aktivitet";
$VLocked="Rubriken �r l�st - inget svar m�jligt";

// status 19 Sept 2002
$VHideEmail="G�m emailadress f�r �vriga medlemmar";
$VHidden="G�md";              //"Hidden";
$Charset="iso-8859-1";
// status 21 Sept 2002
$VNewMember="Ny medlem";
$VWith="med";
$VAllowEmail="Aktivera email";
$VThereIs="Det finns";
$VThereAre="Det finns";
$VEdited="Editerad";
$VEditMembergroups="editera medlemsgrupper";
//status 22 Sept 2002
$VAnd="&amp;";                  //"&amp;";
$SetRequireLogin="Kr�v att medlemmar �r p�loggade";
$VTo="Till";
$VSmilies="Smilies";
$VPBCode="PB-kod";
$CVLogin="Logga in";
//status 23 Sept 2002
$VPosted="Postats";                 //"Posted"; a message has been posted...
$PBLSupportLink="Support f�r PBLang";             //"Support for PBLang";  Headline for the link to the PBLang-forum
$VReplySent="Du har f�tt svar";
$NotifyReplySent="Hej \n\n   Du har f�tt svar p� inl�gget ".$sitetitle." ang�ende ";     //Hi,\n\n    A reply was sent to your post on ".$sitetitle." to the subject ";  //end then follows the subject line
$VNotifyByEmail="Vill Du f� meddelande n�r svar postas";
$EmailNotification="Notifikation via email";
$VAdministrativeFunctions="Adminstrativa funktioner";
$VURLAvatar="Avatar via URL";
//status 27 Sept. 2002
$ForumLocked="Denna grupp �r l�st";
$WrongUsername="Anv�ndarnamnet f�r endast inneh�lla bokst�ver och siffror";
$WrongEmailAddress="Ej giltig emailadress";
//status 2 Oct 2002
$VFrom="fr�n";               //"from";  it's used in a line like "Message $VFrom: author"
$VNoTemplatesEdit="Du b�r ej editera mallar via detta gr�nssnitt. Anv�nds texteditor och editera k�llfilerna";           //"You should not edit any templates using this interface. Please use an appropriate editor to edit the source files";
//status 3. Oct. 2002
$VFont="Font";
$VFontColor="Fontf�rg";
$VFontsize="Fontstorlek"; 
//Following are datevariables which need to be filled in with so called placeholders, since time changes every time a page is called up. Fill in the appropriate string
//for your language!
/***************************************
usage of placeholders in datevariables:
%a= shortened name of weekday in local language
%A= full name of weekday in local language
%b= shortened name of month
%B= full name of month
%c= date and time in a format matching the format of the local language (if you don't know what to fill in, use this one)
%C= century
%d= day of month (00 to 31)
%D= shows "m/d/y", i.e. "06/23/02" (see example below)
%e= day of month as number, 0 to 31
%h= like %b
%H= hour in 24-hour format (00 to 24)
%I= hour in 12-hour format (01 to 12)
%j= day of year (��1 to 366)
%m= month as decimal (01 to 12)
%M= minute as decimal (00 to 60)
%n= new line
%p= "am" or "pm", depending on time of the day and on the local language
%r= time in am- or pm formatting
%R= time in 24-hour format
%S= seconds as decimals
%t= tabulator
%T= actual time, represents %H%M%S
%u= day of week as decimal (1= Monday)
%U= number of week as decimal; Sunday is the first day of the week
%V= Calendarweek. Week begins Monday, first week is the week with at least 4 days in the new year
%w= weekday as decimal, Sunday is 0
%W= number of the week, first Monday in the year is the first day of the first week
%x= preferred date depending on set language
%X= preferred time depending on set language
%y= year as two-number-digit
%Y= year as four-number-digit
%Z= timezone
%%= the %-sign
***************************************/
$DateFormat1="%D";
$DateFormat2="%Y-%m-%d, %R";
//$DateFormat2="%B %e, %Y, %r";         //"%A $%e, %Y, %r";  this would be eg "June 23, 2002, 03:15 pm"
$VLessThan="Mindre �n";        //"Less than";
$VLanguageEdit="Editera spr�kfil";
//status 4. Oct. 2002
$VRemoveMembers="Radera Medlemmar";
$VRemove="Radera";
$VMemberRemoved="Medlemmen har raderats";

/*imagelinks - you can use them almost completely. Just
change the filenames to the names of your language. You
should use the format name_ln.gif, where "ln" is the language code for your country. Example: profile.gif becomes 
profile_de.gif if the button has been changed to German
If you don't have any language specific buttons, leave the �paths as they are so the default English buttons are chosen*/
$Vpicturebuttons="Anv�nd Knappar";
$profilealt="Profil";
$profiletitle="Profil";
$emailalt="S�nd email";
$emailtitle="S�nd email";
$Vemail="S�nd email";
$editalt="Editera Inl�gg";
$edittitle="Editera Inl�gg";
$Vedit="Editera Inl�gg";
$sendpmalt="S�nd meddelande";
$sendpmtitle="S�nd meddelande";
$Vsendpm="S�nd meddelande";
$yimalt="S�nd YIM";
$yimtitle="S�nd YIM";
$Vyim="S�nd YIM";
$aimalt="S�nd AIM";
$aimtitle="S�nd AIM";
$Vaim="S�nd AIM";
$msnalt="S�nd MSN";
$msntitle="S�nd MSN";
$Vmsn="S�nd MSN";
$icqalt="S�nd ICQ";
$icqtitle="S�nd ICQ";
$Vicq="S�nd ICQ";
$wwwalt="Hemsida";
$wwwtitle="Hemsida";
$Vwww="Hemsida";
//Posts
$newthreadalt="Nytt Inl�gg";
$newthreadtitle="Nytt Inl�gg";
$Vnewthread=$newthreadtitle;
$replyalt="Posta Svar";
$replytitle="Posta Svar";
$lockedalt="l�st";
$lockedtitle="l�st";
//header images
$homealt="Hem";
$hometitle="Hem";
$searchalt="S�k";
$searchtitle="S�k";
$helpalt="Hj�lp";
$helptitle="Hj�lp";
$logoutalt="Logga ut";
$logouttitle="Logga ut";
$ucpalt="Anv�ndarkontrollpanel";
$ucptitle="Anv�ndarkontrollpanel";
$pmalt="Meddelande";
$pmtitle="Meddelande";
$loginalt="Logga in";
$logintitle="Logga in";
$registeralt="Registrera";
$registertitle="Registrera";
$adminalt="Adminkontrollpanel";                    //"AdminCP";
$admintitle="Adminkontrollpanel";                    //"AdminCP";
$memberslistalt="Medlemmar";
$memberslisttitle="Medlemmar";
//status 5th Oct. 2002
$VPreviousMessages="F�reg�ende Meddelande";
$VTextColor="textf�rg";
$VMoreThan="Fler �n";                    //"More than";
//status 8th October
$NoSuchFile="Filen existerar ej!";
//status 9th October
$VRE="Ang�ende";
//status 10th October
$PWNoMatch="L�senorden st�mmer ej �verens. F�rs�k igen!";                    //"The password doesn't match. Please try again!";
$VDefault="Default";
$VStars="Stj�rnor";                    //"Stars";
$VFlames="Flammor";                    //"Flames";
$VRankImages="Ranka bilder";                    //"Rank images";
$VMaxPostsReply="Visa s� m�nga inl�gg vid svar";                    //"show so many posts when replying";
$VEditPost="Editera inl�gg";
//status 11th October
$VReplied="Svarade";                    //"Replied";
$VNew="Ny";                    //"New";
$VOriginalPM="Originalmeddelande";                    //"Original PM";
$VRead="L�st";                    //"Read";
//status 12 Oct 2002
$VNoSubject="Inget �mne";                    //"No subject";
//status 13 Oct 2002
$VOrderOfReplies="Svarsordning";                    //"Order of replies";
$VFirstReplyFirst="f�rsta svaret f�rst";                    //"first reply first";
$VFirstReplyLast="f�rsta svaret sist";                    //"first reply last";
//status 14 Oct 2002
$VStyleHeaderFont="Fontstil";                    //"Font style";
$VStyleHeaderPage="Sidbakgrund";                    //"Page background";
$VStyleHeaderTitle="Forumhuvud";                    //"Forum header";
$VStyleHeaderMenu="Forumhuvudmeny";                    //"Forum header menu";
$VStyleHeaderDate="Datumstil";                    //"Date label";
$VStyleHeaderContainer="Form container";                    //"Form container";
$VStyleHeaderHeader="Huvud";                    //"Header";
$VStyleHeaderSubheader="Subheader";                    //"Subheader";
$VStyleHeaderMenu="Meny";                    //"Menu";
$VStyleHeaderForumButton="Forumknapp(ar)";                    //"Forum button(s)";
$VStyleHeaderUserColors="Anv�ndarf�rger";                    //"User colors";
$VStyleHeaderLinkColors="L�nkf�rger";                    //"Link colors";

$VBackground="Bakgrund";                    //"Background";
$VForm="Inre bakgrund";                    //"Inner background";
$VFormBorder="Inre bakgrundsram";                    //"Inner background border";
$VFormBorderSize="Inre bakgrundsramsstorlek";                    //"Inner background border size";
$VForumHeaderBorder="Huvudets ramf�rg";                    //"Header border color";
$VForumHeaderBorderSize="Huvudets ramstjocklek";                    //"Header border size";
$VForumHeader="Huvudets f�rg";                    //"Header color";
$VForumHeaderTitle="Huvudets titelfontf�rg";                    //"Header title font color";
$VForumHeaderTitleSize="Huvudets titelfonttjocklek";                    //"Header title font size";
$VForumHeaderCaption="Header caption font color";                    //"Header caption font color";
$VForumHeaderWelcome="Header welcome font color";                    //"Header welcome font color";
$VForumHeaderMenu="Header menu color";                    //"Header menu color";
$VForumHeaderMenuFont="Header menu font color";                    //"Header menu font color";
$VDateColor="Datumfont";                    //"Date font";
$VContainerBorder="Container border color";                    //"Container border color";
$VContainerBorderSize="Container border size";                    //"Container border size";
$VContainerInner="Container color";                    //"Container color";
$VHeaderColor="Huvudets f�rg";                    //"Header color";
$VHeaderGif="Huvudets bild";                    //"Header image";
$VHeaderFont="Huvudets fontf�rg";                    //"Header font color";
$VSubheaderColor="Subheader f�rg";                    //"Subheader color";
$VSubheaderGif="Subheader bild";                    //"Subheader image";
$VSubheaderFont="Subheader fontf�rg";                    //"Subheader font color";
$VMenuColor="Menyf�rg";                    //"Menu color";
$VFMenuColor="Fixed menu color";                    //"Fixed menu color";
$VMenuFont="Fixed menu font color";                    //"Fixed menu font color";
$VForumButtonColor="Forumknapparnas f�rg";                    //"Forum button color";
$VForumButtonOver="Forumknapparnas �vre f�rg";                    //"Forum button over color";
$VForumButtonTopics="Forumets rubrikf�rg";                    //"Forum topics color";
$VForumButtonReplies="Forumets svarsf�rg";                    //"Forum Replies color";
$VForumButtonLast="Forumets senast-postat-f�rg";                    //"Forum last post color";
$VAdminColor="Administrat�rens fontf�rg";                    //"Administrator font color";
$VModColor="Moderatorns fontf�rg";                    //"Moderator font color";
$VUserColor="Anv�ndarnas fontf�rg";                    //"User font color";
$VServerTimezone="Serverns tidszon";                    //"Server timezone";
$VLocalTimezone="Lokal tid";
$VExplainTimezone="Om den lokal tiden ovan �r inkorrekt, justera den genom att v�lja l�mplig siffra";                    //"If the local time is not correct, please adjust adjust it by selecting the appropriate number.";
$VTimeZone="Tidszon";
$VBurningFlames="Brinnande flammor";                    //"Burning flames";
/*The following 3 variables allow a better output in the stats-line. Ending 1 is the singular form for the beginning of the sentence like
"There is currently 1 members". Ending 24 und 59 are the plural forms for the beginning of the sentence like "There are currently 7 members".
If you had the variables $VCurrentMember and $VCurrentmembers in older lang-files, you can remove them now - they are no longer used.
*/
$VCurrentMembers1="Det finns f�r n�rvarande";                    //"There is currently";
$VCurrentMembers24="Det finns f�r n�rvarande";                    //"There are currently";
$VCurrentMembers59="Det finns f�r n�rvarande";                    //"There are currently";
$VEMSupport="Server st�der email via PHP";                    //"Server supports email by PHP";
$VNoEMSupport="Server st�der ej email via PHP";                    //"Sorry, the server does not support email by PHP";
$VDefaultSlogan="Default slogan";
$VExplainSlogan="Slogan �r raden under Avatar-bilden";                    //"The slogan is the line beneath the avatar picture";
$VPredefStyles="F�rdefinierade stilar";
$VNotWriteable="Kan ej skriva p� filen";
$VRemoveStatus="vanlig status";
$VOfTheseNew="Av dessa nya";
$VMaxAtchSize="Maximal storlek p� bifogade filer i bytes (0 = obegr�nsad)";                    //"max. size of attachment in bytes (0= unlimited)";
$VFileTooBig="Filen �r f�r stor. Ange l�nk ist�llet.";
$VCookieError="Forumet kr�ver st�d f�r cookis. Aktivera l�sarens cookies.";                    /*"This board requires cookie-support,  while your browser does not seem to accept cookies. Please enable cookies, otherwise this board will not function proplery. Thank you!";*/
$VNotice="OBS";                    //"Notice";
$VUsernameGiven="Anv�ndarnamnet �r upptaget";
$VUsernameLimits="^[a-zA-Z0-9������]+$";        /*this is to check the username for invalid characters (important where Windows is the server) - leave the string as it is for ordinary names in Latin characters, otherwise check the ereg-rules. If you leave it empty, it will not check the username for valid characters.*/
$VDate="Datum";
$VLanguageSelection="Spr�k";
$VRepeatPassword="Upprepa l�senordet";
$qqalt="QQ";
$qqtitle="QQ";
$VStyleButtonChoice="Knappval";
$VButtonLimits="Detta val anv�nds endast om spr�kspecifik knappupps�ttning anv�nds.";  //sid 545
//status 4 Nov 2002
$VIn="i";                    //""in"; like: Messagetitle $VIn Forumtitle
$VRealname="Verkligt namn";
$VAlias="Alias";
$VExplainAlias="�ven om Ditt anv�ndarnamn ej �ndras, kan Du �ndra Alias.";
$VSlogan="Slogan";
//status 5 Nov 2002
$VStyleHeaderMemgroupColors="Medelandegruppernas f�rg";                    //"Colors of member groups";
$VDateJoined="Ansl�t";                    //"Joined on";
$VLastVisit="Senaste bes�k";
$VLastPost="Senaste inl�gg";
$VGroupColors="Aktivera gruppf�rger";                    //"Enable group colors";
$VGroupcolorsExplain="Detta aktiverar olika f�rger f�r alla medlemsgrupper i anv�ndarstatistiken";                    //"This will enable different colors for each membergroup in the user online statistics display";
//status 6 November 2002
$VIPLogged="IP loggad";
$VSiteLogo="Forumloggans URL";                    //"Site logo URL";
$VSiteLogoExplain="Bildfilen m�ste finns i templates/pb/images-folder och det r�cker med att endast ange filnamnet.";                    //"Your image must be in the templates/pb/images-folder. It's enough to write the filename in the box";
$VMaxPPP="Visa f�ljande antal inl�gg per sida";
//status 11 Nov 2002
$VRequestConfirmation="Beg�r registreringsbekr�ftelse via email";                    //"Request confirmation of registration via email";
$VPleaseConfirm="V�nligen bekr�fta Din registrering genom att bes�ka f�ljande sida:";                    //"Please confirm your registration by going to the following page:";
//status 12 Nov 2002
$VNoAvatar="Ingen Avatar";                    //"No Avatar"; //in the selection list, choose this if you don't want an avatar
/*Following variable: Do not change the part &quot;$VURLAvatar&quot;, it will be translated automatically
with the words that you have put into the variable $VURLAvatar
This variable was in use earlier but has changed, so please remove it from the upper region of the file, if you are updating
an existing language file*/
$AvatarURLtip="(tips: Du m�ste v�lja &quot;$VURLAvatar&quot; i rullgardinsmenyn ovan f�r att detta skall fungera!";        //"(tip: You have to select &quot;$VURLAvatar&quot; from the above list to use this function!)";
//status 13 Nov 2002
$VDeleteCat="Radera Kategori";
$VConfirmation="Registreringsbekr�ftelse";
$VWrongConfirmationCode="Bekr�ftelsekoden �r inkorrekt";        //"The confirmation code is not correct";
$VConfirmationError="Det uppstod ett fel vid bekr�ftelse";        //"There was an error during confirmation";
$VNoCatDelete="Du kan inte radera katagori som fortfarande inneh�ller forum";        //"You may not delete a category which still contains a forum";
//status 15 Nov 2002
$VStyleAnnouncementFont="Stil p� meddelandel�da";        //"Styles in Announcement Box"
//status 16 Nov 2002
$Vgladg="glatt flin";        //"glad grin";
$Vgrinsg="stort flin";        //"bright grin";
$Vbadg="d�ligt hum�r";        //"bad mood";
$Vschluckg="hoppsan!";        //"oops";
$Vsunglg="ledsen";        //"unhappy";
$Vteardrop="t�r";        //"teardrop";
$Vsurprised="�verraskad";        //"surprised";
$Vsleeping="sover";        //"sleeping";
$Vthmbup="tummen upp";        //"thumb's up";
$Vthmbdn="tummen ner";        //"thumb's down";
$Vpfeilrg="pil h�ger";        //"arrow right";
$Vbulb="Id�";        //"Idea";
$VHelpg="Hj�lp!";
$Vbounceg="studsar";        //"bouncing";
$Vdanceg="dansar";        //"dancing";
$Vredface2g="r�d i ansiktet";        //"red face";
$Vdevilg="dj�vulen";        //"devil";
$Vrespektg="respektfull";        //"respectful";
$Vschimpfg="reta";        //"scolding";
$Vwallbashg="h�na";        //"wall bashing";
$Vofftopicg="opassande �mne!";
$VEnableAnimSmilies="Anv�nd animerade smilies (tar l�ngre tid)";        //"Use animated smilies (longer loading time when editing messages)";
//status 19 Nov 2002
$VAllowAlias="Till�t alias";
$VChangeAlias="Till�t �ndring av alias efter";
$VDays="dagar";
$ChangeAliasNotAllowed="Du kan f�r n�rvarande inte byta alias. F�rs�k senare";
$AliasAlreadyInUse="Alias upptaget av annan medlem.";
$VAllowAccess="Till�t f�ljande medlemmar tillg�ng till forumet";
$VAll="alla";
$VModerators="moderatorer";
$VFriend="V�n";
$VExplainFriend="En V�n �r en medlem som ges samma beh�righeter som Moderatorn till vissa forum.";        /*"A friend is a member who can get access to certain forums. (S)he will not have rights to manipulate forums and topics, like the
     moderator has.";*/
$VExpectConformationMail="Du kommer att erh�lla ett email med en l�nk f�r att bekr�fta Ditt medlemskap. Efter att Du klickat p� l�nken kommer Du att f� tillg�ng till forumet.";        /*"You'll receive an email with a link to confirm your membership. After you have visited that link, you will have
     access to this forum.";*/
//status 20 Nov 2002
$VWelcomeMessage="Meddelande f�r att via email v�lkomna medlem till forumet";
//status 21 Nov 2002
$VCheckIP="Tillkommande s�kerhet: Vill Du kontrollera IP-adresserna hos bes�kande medlemmar";        //"Additional security: do you want to check the IP of the visiting computer?";
$VSitelogoWidth="Forumlogotypens bredd i pixlar";
$VSitelogoHeight="Forumlogotypens h�jd i pixlar";
//status 22 Nov 2002
$VAnnounce="Speciellt meddelande p� f�rstasidan";
//status  27 Nov 2002
$VToday="Idag";
$VVisits1="bes�k";
$VVisits24="bes�k";
$VVisits59="bes�k";
$VTotalVisits="Antal inloggade bes�k";        //"Total visits";
$VLastVisitors="Senaste bes�kare";
//status 30 Nov 2002
$VUsernameTooLong="Anv�darnamnet �r f�r l�ngt. Maxl�ngd 25 tecken.";
$VNotifyAdmin="Meddela Administrat�ren vid nya inl�gg (endast rubriker)";
$VNotifyAdminReplies="Meddela Administrat�ren vid alla nya inl�gg";
//status 1 Dec 2002
$VNewReply="Nytt svar";
//status 4 Dec 2002
$VAlreadyUpdated="Du har redan uppdaterat - inget att g�ra";        //"You have already updated - nothing to do";
//status 7 Dec 2002
$VFolderIconChoice="mappikon best�md";        //"folder icon set";
$ficonalt="mappikon";        //"folder icon";
//status 8 Dec 2002
$VForbiddenType="F�rbjuden filtyp. Du f�r endat ladda upp bildfiler (gif, jpg, tif), textfiler (txt) eller arkivfiler (zip, rar)";        //"Forbidden filetype. You may only upload images (gif, jpg, tif), text files (txt) or archives (zip, rar)";
$VUserIsOnline="Anv�ndaren �r fn inloggad och kan ej raderas";        //"User is currently online and cannot be removed";
$VQuotaExceeded="Det finns otillr�ckligt med diskutrymme f�r att l�gag till denna fil.";
$VMinimumSpace="Min diskutrymme p� servern (antal Bytes)";        //"Minimum space that must remain free on server (in Bytes)";
//status 10 Dec 2002
$VGuestVisits="G�stbes�k";        //"Guest visits";  //for counter of guests
$VTotalGuests="Antal g�stbes�k";        //"All guests";
$VAllVisits="Totalt antal bes�k";        //"All visits";
//status 11 Dec 2002
$VRules="Medlemsvillkor";
//status 12 Dec 2002
$DateFormat3="%D, %X";        /*shall return e.g. "23.12.2002, 13:03" or "12/23/2002, 1:03 pm" */
//status 13 Dec 2002
$VGuests1="g�st";
$VGuests24="g�ster";
$VGuests59="g�ster";
//status 15 Dec 2002
/*If you are updating an existing language file, please edit the string for this variable in the
upper section of your file where $PasswordMessage has already been set, to show the contents
of the string below.*/
$PasswordMessage="Du m�ste be Administrat�ren om nytt l�senord";        //"You need to ask the admin to give you a new password";
//status 16 Dec 2002
$VUnknown="ok�nd";        //"unknown";
$VRemoved="raderad";        //"removed";
$VMaxAvatarWidth="Max bredd f�r Avtalar-fil i antal pixlar";        //"Maximum width of avatar picture in pixels";
$VMaxAvatarHeight="Max h�jd f�r Avtalar-fil i antal pixlar";        //"Maximum height of avatar picture in pixels";
//status 17Dec 2002
$VAcceptRules="Jag accepterar ovanst�ende regler";
$VRulesMustBeAccepted="Du m�ste acceptera reglerna f�rst. Klicka i applicerbar ruta.";
//status 7 Jan 2003
$VMaxLastPosts="Maximalt antal senaste inl�gg att visa";        //"max. number of last posts to display";
$VLatestPosts="Senaste inl�ggen";
$Vreplies1="svar";
$Vreplies24="svar";
$Vreplies59="svar";
//status 13 Jan 2003
$quotetitle="citat";
$quotealt="citat";
$VGenerell="generell";
$VStyleQuoteFont="fontinst�llningar f�r citat";
//status 20 Jan 2003
$VStickyMessage="G�r detta till ett aktivt meddelande";        //"Make this a sticky message";
$VStickyMessageExplain="Ett aktivt meddelande visas alltid �verst p� sk�rmen. L�mplig f�r varningsmeddelanden och dylikt.";        //"A sticky message always appears at the top of a forum - suitable for welcome or warning messages";
//3 March 2003
$VMaxRPP="Maximalt antal svar per sida";
//10 March 2003
$VBoardwidth="Forumets bredd (f�rre �n 101 anses vara procent och fler �n 300 anses vara pixlar.";
$VBackgroundimage="Namnet p� bakgrundsbild (lagras i templates/pb/images)";        //"name of background image (locate in templates/pb/images)";
//status 10 April 2003
$VEnableWebAvatars='Till�t web-Avatar (Avatar som lagras p� annan server)';
//status 16 April 2003
$VAlign='Placering';
$VLeft='v�nster';
$VCenter='center';
$VRight='h�ger';
//status 19 April 2003
$VAllowReplyInLockedForum='Till�t medlemmar att besvara inl�gg i detta forum, trots att det �r l�st';        //'Allow members to reply if this forum is locked';
$VExplainLockedForum='Endast Adminsitrat�ren och Moderatorer kan posta nya inl�gg i detta forum';        //'Only admin and moderators can post new messages in this forum';
//status 10 May 2003
$VBoardidentity='Inst�llningar f�r Forumidentitiet';        //'Board Identity Settings';
$VBoardappearance='Utseende p� Forumet';        //'Appearance of the Board';
$VBoardsettings='Generella Foruminst�llningar';        //'General Board Settings';
$VNotificationsettings='Meddelandeinst�llningar';        //'Notification Settings';
$VAliassettings='Aliasinst�llningar';        //'Alias Settings';
$VAvatarsettings='Avatar-inst�llningar';        //'Avatar Settings';
$VPostsettings='Inl�ggsinst�llningar';        //'Post Settings';
$VMembershipsettings='Medlemskapsinst�llningar';        //'Membership Settings';
$VQuoteBorder='ramvidd f�r citat';        //'borderwidth of quotes';
$VQuote='citat';
//status 12 May 2003
$VDisableAvatars='Visa inte Avatarer (bra f�r l�ngsamma f�rbindelser)';        //''Don&#39;t display any avatars (helpful if you have a slow speed connection)';
$VIncompleteUpdate='Forumet har inte uppdaterats ordentligt. L�s dokumentationen i PBLang-doc.txt ordentligt.';        //'The board hasn&#39;t been updated properly. Please read the documentation in PBLang-doc.txt carefully.';
//status 14 May 2003
$VNoNews='Det finns f�r n�rvarande inga nyheter';        //'There are currently no news available';
$TestRelease='Du tesstar en ny version. Tack f�r Din support! V�nligen informera mig om uppkomna fel.';        //'You are testing a new version. Thank you for your support! Please inform me about any problems you might encounter.';
$StillBeta='Du anv�nder fortfarande en testversion, trots att skarp version finns tillg�nglig. V�nligen ladda hem den senaste versionen!';
//15 May 2003
$VReplyallowed='Du f�r posta inl�gg i detta forum, men Du f�r inte skapa en ny tr�d.';
$OpenTopic20read='�ppen rubrik med fler �n 20 inl�gg - l�st';
$OpenTopicread='�ppen rubrik - l�st';
$LockedTopicread='L�st rubrik - l�st';
$StickyMessage='Aktivt meddelande';
$StickyMessageread='Aktivt meddelande - l�st';
$VTextareawidth='bredd p� textf�lt';
$VExplainTextareawidth='Ifall forumet �r placerat i f�nster-baserad (frames) hemsida kan textf�lt ibland bli f�r l�ngt vid postning av inl�gg eller svar p� inl�gg. �ven dessa sidor kommer att passa in i f�nstren.';        /*'If the board is located in a frame based site, the text input field is sometimes too wide to fit into the available space
	when a message is posted or answered to. If this value is decreased accordingly, also these pages will fit into the frame.';*/
//17 May 2003
$VStylePrefix='Utseendeprefix';
$VExplainStylePrefix='Utseendeprefixet avg�r vilka knappar och bilder som kommer att anv�ndas f�r denna stil. V�nligen l�s dokumentationen i styles.txt i doc-mappen f�r mer information.';        /*'The style prefix determines which buttons and images are to be used for this style. Please read the doc styles.txt
	in the doc folder for more details.';*/
$VRestrictedForum='Begr�nsat forum. Du kan besvara inl�gg, men inte starta ny tr�d i detta forum.';
//22 May 2003
$VAttachmenttypes='Till�t f�ljande filtyper som bilagor';


?>
