Hi,

if you want to add a new language file, just use the lang_temp.php file and
give it a name replacing "temp" with your language's ISO-code. Best thing
is of course you copy the original to the file with the new name.
This way you can test it with your distribution.
Contact me to make sure that no later language file has been released,
and dto get your language file included in the sets of available languages.

