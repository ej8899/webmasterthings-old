<?php
/***************************************************************************
 *                          PBLang -  index.php
 *                            -------------------
 *             see copyright.txt in the docs-folder
 *
 *  modified 5 May 2003
 ***************************************************************************/

error_reporting  (E_ERROR | E_WARNING | E_PARSE);
//error_reporting  (E_ALL);
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

session_cache_limiter('nocache');
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0");
header("Pragma: no-cache");

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include($dbpath."/settings.php");
@include($dbpath."/stats");
include_once("functions.php");
include_once("ffunctions.php");
include($dbpath."/settings/styles/styles.php");
include($temppath."/pb/language/lang_".$language.".php");


$cookieset=$HTTP_GET_VARS['cookie'];
$liusername=$HTTP_COOKIE_VARS[$cookieid];
if ($liusername=="") {
	if ($cookieset=="1"){
		writeheader($newestm,$cat,$fid,$pid,$liusername,$login,$VError);
		ErrorMessage($VCookieError,$liusername);
		exit;
	}
	$loggedin="0";
	$admin="0";
	$allow="1";
	$ip=GetIPAddress();
	$filename=$dbpath."/guests";
	$iplist=@file($filename);
	$ipcount=count($iplist);
	$found="0";
	$exptime=time()+21600;
	for ($i=0;$i<=$ipcount;$i++){
		$idcont=$iplist[$i];
		$ipaddr=strtok($idcont,",");
		$iptime=strtok(",");
		if ($ip==$ipaddr && trim($ipaddr)!=""){
			$content.=$ipaddr.",".$exptime."\n";
			$found="1";
		}else{
			if ($iptime>time()){
					$content.=$ipaddr.",".$iptime."\n";
			}
		}
	}
	$fp=@fopen($filename,"w");
	if ($found=="0"){
		$content.=$ip.",".$exptime."\n";
		SetLock();
		UpdateGuestCount("1");
		unlink($dbpath.'/block');
	}
	@fputs($fp,$content);
	@fclose($fp);
//     CheckGuestStatus();
} else {
	$filename = $dbpath."/members/".$liusername;
	if (!file_exists($filename)) {
		$loggedin="0";
	} else {
		$ip = GetIPAddress();
		include($filename);
		if ($userip!=$ip && $checkip=="1") {
			echo "<meta http-equiv=\"Refresh\" content=\"0; URL=logout.php\">";
			$allow="0";
			exit;
		} else {
			$allow="1";
		}
		$loggedin="1";
		if ($cookieset=="1"){
			$userprevvisit=$userlastvisit;
			$uservisits++;
			$userlastvisit=time()+($timezone*3600);
			WriteUserInfo($liusername);
			UpdateStats($liusername,$useralias);
			SetLock();
			UpdateGuestCount("0");
			unlink($dbpath.'/block');
			include($dbpath.'/stats');
		}
		$admin=$useradmin;
		$moder=$usermod;
		$ban=$userban;
	}
}

if ($ban=="1") {
		ErrorMessage($banreason,$liusername);
		exit;
} else {
		if ($maint=="1" && $admin=="0") {
			writeheader($newestm,$cat,$fid,$pid,$liusername,$login,$VError);
			ErrorMessage($mreason,$liusername);
			exit;
		} else {
		if ($loginreq=="1" && $loggedin=="0") {
				echo "<meta http-equiv=\"Refresh\" content=\"0; URL=login.php?do=req\">";
				exit;
		} else {
			$titlesize=substr($fontsize,0,strlen($fontsize)-2);
			$descrsize=$titlesize-1;
			if ($allow=="1") {
				$language=SetLanguage($liusername);
				include($temppath."/pb/language/lang_".$language.".php");
				$totposts="0";
				$tottop="0";
				$filename = $dbpath."/mems";
				$fd = fopen ($filename, "r");
				$mems = fread ($fd, filesize ($filename));
				fclose ($fd);
				$filename = $dbpath."/settings/newestm";
				$fd = @fopen ($filename, "r");
				$newestuser = @fread ($fd, filesize ($filename));
				$newestm="top";
				@fclose ($fd);
				if ($newestuser){
					@include($dbpath.'/members/'.$newestuser);
				}
				$newestmem=$useralias;
				writeheader($newestm,0,0,0,$liusername,$loggedin,"Forum ".$VIndex);
				//                    listtop($liusername);
				WriteTableTop();
//				echo "\n<tr><td width=\"5%\" class=\"header\">&nbsp;</td>\n";
				echo "\n<tr>";
				echo "<td width=\"62%\" colspan=2 class=\"header\"><B>$VForum</B></td>\n";
				echo "<td width=\"6%\" class=\"header\"><B>$VTopics</B></td>\n";
				echo "<td width=\"5%\" class=\"header\"><B>$VReplies</B></td>\n";
				echo "<td width=\"22%\" class=\"header\"><B>$VLastPost</B></td></tr>\n";

				$filename = $dbpath."/cats/cats";
				$fd = fopen ($filename, "r");
				$totalcats = fread ($fd, filesize ($filename));
				fclose ($fd);
				$i="1";
				while ($i<=$totalcats) {
					// START CAT
					if (file_exists($dbpath.'/cats/'.$i.'_d')){
						ErrorMessage($VIncompleteUpdate,$liusername);
						exit;
					}
					$filename=$dbpath."/cats/".$i;
					if (file_exists($filename)){
						include($filename);
						$name=$cname;
						$desc=$cdescription;
					}else{
						$name="";
						$desc="";
					}

					if (trim($name)!=""){
						if ($name=="delplz") {
						} else {
							echo "<tr bgcolor=\"$subheadercolor\">";
							if ($admin!="1"){
								$colsp=5;
							}else{
								$colsp=2;
							}
							echo "<td colspan=\"$colsp\" class=\"subheader\">";
							echo "$name<br><font style=\"font-size:".$descrsize."px\">$desc</font></td>\n";
							if ($admin=="1"){
								echo "<td class=\"subheader\" colspan=3>";
								$delcatimg=GetImage($stylepref,'deleteforum','');
								if ($picturebuttons=='Yes' && $delcatimg){
									echo "$VAdministrativeFunctions: <a href=\"admin.php?do=delcat&cnum=$i\">
										<img src=\"$delcatimg\" border=\"0\" alt=\"$VDeleteCat\" title=\"$VDeleteCat\"></a></td>\n";
								}else{
									echo "$VAdministrativeFunctions: <a href=\"admin.php?do=delcat&cnum=$i\">$VDeleteCat</a></td>\n";
								}
							}
						}
				// END SHOW CAT

						$forumnum = $cforums;
						$e="1";
						while ($e<=$forumnum) {
							if (file_exists($dbpath.'/cats/'.$i.'_'.$e.'_f_d')){
								ErrorMessage($VIncompleteUpdate,$liusername);
								exit;
							}
							$filename=$dbpath."/cats/".$i."_".$e;
							if (file_exists($filename)){
									include($filename);
							}else{
									$fname="";
									$fdescription="";
							}

							if ($fname=="" && $fdescription==""){
							}else{
								if (strstr($fvisitors,$liusername)){
									$fread="1";
								}else{
									$fread="0";
								}
								$accallowed=CheckPermissions($i,$e,$liusername);

								$tottop=$tottop+$ftopics;
								$totposts=$totposts+$freplies;

								//display forum details
								$lastp=$ftopics-$maxppp;
								if (trim($fname)=="delplz") {
								} else {
									echo "<tr bgcolor=\"$forumbuttoncolor\">
										<td class=\"leftindex\" width=\"5%\" height=\"20\" align=\"center\" bgcolor=\"$forumbuttoncolor\">\n";
									if ($fread != "1" && $accallowed=="1"){
										$forumimg=GetImage($stylepref,'ficon_n','');
									}elseif ($accallowed=="0"){
										$forumimg=GetImage($stylepref,'ficon_accessdenied','');
									}elseif ($fread=="1" && $accallowed=="1"){
										$forumimg=GetImage($stylepref,'ficon_read','');
									}
									if ($flastpost==$VNever){
									}else{
										$flastpost=strftime($DateFormat3,$flastpost);
									}
									echo "<img src=\"$forumimg\" alt=\"$VImage\"></td>\n";
									echo "<td width=\"50%\" ";
									echo "onMouseOver=\"this.style.backgroundColor='$forumbuttonover';this.style.cursor='hand'\"";
									echo "onClick=\"document.location.href='board.php?fid=$e&cat=$i&e=$lastp&s=$ftopics'\"";
									echo "onMouseOut=\"this.style.backgroundColor='$forumbuttoncolor';this.style.cursor='hand';\" height=\"18\" bgcolor=\"$forumbuttoncolor\">\n";
									echo "<a href=\"board.php?fid=$e&cat=$i&e=$lastp&s=$ftopics\">$fname</a><br>\n";
									echo "<font style=\"font-size:".$descrsize."px\">$fdescription</font></td>";
									echo "<td width=\"6%\" height=\"18\" bgcolor=\"$forumbuttontopics\"><div align=\"center\">$ftopics</div></td>\n";
									echo "<td width=\"5%\" height=\"18\" bgcolor=\"$forumbuttonreplies\"><div align=\"center\">$freplies</div></td>\n";
									echo "<td width=\"34%\" height=\"18\" style=\"text-align:left; background-color=$forumbuttonlast;\">\n";
									if (file_exists($dbpath."/members/".$flastauthor)&&$loggedin=="1" && $flastauthor!=""){
										include($dbpath."/members/".$flastauthor);
										$lastauthor="<a href=\"profile.php?u=$flastauthor\" title=\"$VProfileFor $useralias\" alt=\"$VProfileFor $useralias\">".$useralias."</a>";
									}elseif (file_exists($dbpath."/members/".$flastauthor) && $flastauthor!=""){
										include($dbpath."/members/".$flastauthor);
										$lastauthor=$useralias;
									}else{
										$lastauthor=$flastauthor;
									}
									echo "$flastpost&nbsp;$VBy&nbsp;$lastauthor";
									if ($accallowed=="1"){
										$lastimg=GetImage($stylepref,'last','');
										echo "<a href=\"$flasturl\"><img src=\"$lastimg\" border=\"0\" alt=\"$VImage\"></a></td></tr>\n";
									}else{
										echo "</td></tr>\n";
									}
								}
							}

							$e++;
						}
					}
					$i++;
				}
				echo "</table></td></tr></table></td></tr></table>";
				$memimg=GetImage($stylepref,'mem','');
				if ($loggedin=="0") {
					echo "<br>";
					WriteTableTop();
					echo "<tr><td colspan=\"4\" class=\"header\" ><b>$VLogin</b></td></tr>\n";
					echo "<tr bgcolor=\"$fmenucolor\"><td class=\"leftindex\" colspan=\"2\" height=\"33\" align=\"center\">";
					echo "<img src=\"",$memimg,"\" alt=\"",$VImage,"\"></td>\n";
					echo "<td width=\"95%\" height=\"33\" valign=\"middle\" bgcolor=\"$menucolor\"><form method=\"post\" action=\"login.php?id=2\">";
					echo "$VUsername:&nbsp;<input type=\"text\" name=\"user\">";
					echo "&nbsp;&nbsp;$VPassword:&nbsp;<input type=\"password\" name=\"pass\">\n";
					echo "<input type=\"submit\" name=\"Submit\" value=\"$VSubmit\">";
					sbot();
				}
				if ($loggedin=="1") {
					echo "<br>";
					WriteTableTop();
					echo "<tr bgcolor=\"$headercolor\"><td colspan=\"4\" class=\"header\"><b>$VUserControlCenter";
					if ($admin=="1") {
						echo "&nbsp;(<a href=\"admin.php\">$AdminCenter</a>)<br>";
					}
					echo '</b></td></tr>',"\n";
					echo '<tr bgcolor="',$fmenucolor,'"><TD class="indexleft" align="center">';
					echo "<img src=\"",$memimg,"\" alt=\"",$VImage,"\"></td>\n";
					echo "<td width=\"33%\" height=\"5\" valign=\"top\" bgcolor=\"$menucolor\"><b><a href=\"ucp.php\">$VUserControlPanel</a></b><br></td>";
					echo "<td width=\"33%\" height=\"5\" valign=\"top\" bgcolor=\"$menucolor\"><b><a href=\"pm.php\">$PrivateMessaging</a></b></td>";
					echo "<td width=\"33%\" height=\"5\" valign=\"top\" bgcolor=\"$menucolor\"><b><a href=\"logout.php\">$VLogout</a></b></td></tr>";
					echo "</table></td></tr></table></td></tr></table>";
				}

			echo "<br>";
			WriteTableTop();
			$listlatestposts=@file($dbpath."/settings/latestposts");
			$nrofposts=@count($listlatestposts);
			$halfone=ceil($nrofposts/2);
			if ($halfone > "2"){
					$colspn="3";
			}else{
					$colspn="2";
			}
			echo "<tr bgcolor=\"$headercolor\"><td colspan=\"$colspn\" class=\"header\">";
			echo "<b>$sitetitle :: $VLatestPosts</b></td></tr>";
			echo "<tr bgcolor=\"$fmenucolor\"><td  class=\"indexleft\" height=\"25\" align=\"center\">";
			$newestimg=GetImage($stylepref,'ficon_newest','');
			echo "<img src=\"$newestimg\" alt=\"$VImage\"></td>";
			if ($halfone > "2"){
					echo "<td width=\"47%\" height=\"25\" valign=\"top\" bgcolor=\"$menucolor\"><font style=\"font-size:".$descrsize."px\">";
			}else{
					echo "<td width=\"95%\" height=\"25\" valign=\"top\" bgcolor=\"$menucolor\"><font style=\"font-size:".$descrsize."px\">";
			}
			$noofposts=1;
//               echo $VLatestPosts.":<br>";
			for ($i=0;$i<=$nrofposts;$i++){
					if($listlatestposts[$i]!=""){
						$catid=strtok($listlatestposts[$i],"|");
						$forid=strtok("|");
						$postid=trim(strtok("|"));
						if (substr_count($listlatestposts[$i],'|')==3){
							$repid=trim(strtok('|'));
							$filename=$dbpath.'/posts/'.$catid.'_'.$forid.'_'.$postid.'_r_'.$repid;
							$isreply="1";
						}else{
							$filename=$dbpath.'/posts/'.$catid.'_'.$forid.'_'.$postid;
							$isreply="";
						}

						if ($halfone>"2" && ($noofposts-1)==$halfone && $seccol!="1"){
							echo "</font></td>\n";
							echo "<td width=\"47%\" height=\"25\" valign=\"top\" bgcolor=\"$menucolor\"><font style=\"font-size:".$descrsize."px\">";
							$seccol="1";
						}
						if (file_exists($filename)){
							include($filename);
							if ($isreply){
								include($dbpath.'/members/'.$rauthor);
								if ($repid>$maxrpp){
										$pageno=floor($repid/$maxrpp)+1;
								}else{
										$pageno="1";
								}
								$latestpostlink='<a href="post.php?cat='.$catid.'&fid='.$forid.'&pid='.$postid.'&page='.$pageno.'">'.$rsubject.'</a> - '.$useralias;
							}else{
								include($dbpath.'/members/'.$pauthor);
								$latestpostlink='<a href="post.php?cat='.$catid.'&fid='.$forid.'&pid='.$postid.'&page=1">'.$psubject.'</a> - '.$useralias;
							}
							$showitem=CheckPermissions($catid,$forid,$liusername);
							if ($showitem){
								echo $noofposts.". - ".$latestpostlink."<br>\n";
								$noofposts++;
							}
						}
					}
			}
			echo "</font></td>\n";
			echo "</table></td></tr></table></td></tr></table><br>";

			WriteTableTop();
			echo "<tr><td colspan=\"3\" class=\"header\"><b>$sitetitle :: $VStats</b></td></tr>";
			echo "<tr bgcolor=\"$fmenucolor\">";
			$statsimg=GetImage($stylepref,'stats','');
			echo "<TD class=\"indexleft\"><IMG src=\"",$statsimg,"\" alt=\"",$VImage,"\"></td>";
			echo "<TD width=\"47%\" height=\"25\" valign=\"top\" bgcolor=\"$menucolor\"><font style=\"font-size:".$descrsize."px\">";
			$ph = get_phrase_for_num('$VCurrentMembers', $mems,$liusername);
			echo "$ph $mems ";
			$ph = get_phrase_for_num('$VMembers', $mems,$liusername);
			echo "$ph.<br>";
			echo "$VLatestMember&nbsp;";
			if ($loggedin=="1" && $newestmem !="---"){
				echo "<a href=\"profile.php?u=$newestuser\">$newestmem</a>";
			}else{
				echo "$newestmem";
			}
			echo "<br>$tottop ";
			$ph = get_phrase_for_num('$VTopics', $tottop,$liusername);
			echo "$ph.<br>$totposts ";
			$ph = get_phrase_for_num('$Vreplies', $totposts,$liusername);
			echo "$ph. <BR>";
			echo "$VToday $todaysvisits ";
			$ph = get_phrase_for_num('$VVisits',$todaysvisits,$liusername);
			echo "$ph";

			include($dbpath."/guestcount");
			echo " &amp; $todaysguests ";
			$ph = get_phrase_for_num('$VGuests',$todaysguests,$liusername);
			echo "$ph.<br>\n";
			$allvisits=$totalguests+$totalvisits;
			echo "$VTotalVisits: $totalvisits<br>$VTotalGuests: $totalguests<br>$VAllVisits: $allvisits</td>";
			echo "<td width=\"48%\" height=\"25\" valign=\"top\" bgcolor=\"$menucolor\"><font style=\"font-size:".$descrsize."px\">";
			echo "<b>$VLastVisitors</b>: <br>\n";
			$separator=',';
			if ($lastvis1!=""){echo $lastvis1;}
			if ($lastvis2!=""){echo ', '.$lastvis2;}
			if ($lastvis3!=""){echo ', '.$lastvis3;}
			if ($lastvis4!=""){echo ', '.$lastvis4;}
			if ($lastvis5!=""){echo ', '.$lastvis5.'<br>';}
			if ($lastvis6!=""){echo $lastvis6;}
			if ($lastvis7!=""){echo ', '.$lastvis7;}
			if ($lastvis8!=""){echo ', '.$lastvis8;}
			if ($lastvis9!=""){echo ', '.$lastvis9;}
			if ($lastvis10!=""){echo ', '.$lastvis10.'<br>';}
			echo "</font></td>\n";
			echo "</table></td></tr></table></td></tr></table>";

				echo "<br><table width=\"100%\" border=\"0\" cellpadding=\"$containerbordersize\" cellspacing=\"0\">";
				echo "<tr bgcolor=\"$containerborder\"><td height=\"9\">";
				echo "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
				echo "<tr bgcolor=\"$containerinner\"><td height=\"2\">";
				echo "<table width=\"100%\" border=\"0\" cellpadding=\"7\" cellspacing=\"1\">";

				echo "<tr><td colspan=\"5\" class=\"header\"><b>$WhoIsThere</b></td></tr>";
				echo '<tr bgcolor="',$fmenucolor,'">';
				echo '<td colspan ="1" class="indexleft" height="17" align="center">';
				$onlineimg=GetImage($stylepref,'online','');
				echo '<img src="',$onlineimg,'" alt="',$VImage,'"></td>';
				echo "<td width=\"95%\" height=\"17\" valign=\"top\" bgcolor=\"$menucolor\">";

			include('useronline.php');

				echo '</td></tr></table></td></tr></table></td></tr></table>';
				writefooter($newestm);
			}
		}
	}
}
ob_end_flush();
?>




