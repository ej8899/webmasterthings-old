<?php
/***************************************************************************
 *                            help.php
 *                            -------------------
 *             see copyright.txt in the docs-folder
 **************************************************************************/

error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
                                                     // always modified
header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

define('IN_PB', "true");
define('IN_PBG', "true");


include("global.php");
include($dbpath."/settings.php");
include_once("functions.php");
include_once("ffunctions.php");
include_once($dbpath."/settings/styles/styles.php");

$username=$HTTP_COOKIE_VARS[$cookieid];
$permit=CheckLoginStatus($username,"0","0");

if ($permit=="1") {
     $language=SetLanguage($username);
     include("$temppath/$template/language/lang_$language.php");
     $new="nope";
     writeheader($new,0,0,0,$username,$loggedin,$VHelp);
     WriteTableTop();
     echo "<tr>";
     echo "<td bgcolor=\"$headercolor\" height=\"27\" background=\"$headergif\">$sitetitle :: $VHelp</td></tr>";
     echo "<tr bgcolor=\"$subheadercolor\"><td height=\"36\" align=\"left\" bgcolor=\"$menucolor\" width=\"45%\" valign=\"middle\">";
     echo "<p>BBCode $VExplanation:</p><p>[img][/img] $VHelpIMG.<br>";
     echo "<font color=\"$fontcolor\"><br>$VUsage: [img]http://www.yourdomain.com/PBLang/imagespath/help.gif[/img]</font> <br>";
     echo "<font color=\"$fontcolor\">$VDisplays: <img src=\"templates/pb/images/top/help.gif\"></font><br>";
     echo "<br><font color=\"$fontcolor\"><br>[url][/url] $VHelpURL.<br><br>
	 	$VUsage: [url]http://www.yourdomain.com[/url]</font><br>";
     echo "$VDisplays: <a href=\"http://yourdomain.com\">www.yourdomain.com</a><br><br><br>";
     echo "[email][/email] $VHelpEMAIL.<br><br>$VUsage: [email]yourname@yourdomain.com[/email]<br>";
     echo "$VDisplays: <a href=\"mailto:yourname@yourdomain.com\">yourname@yourdomain.com</a><br><br><br>";
     echo "[glowCOLOR][/glowCOLOR] ".$VHelpGLOW."<br><br>".$VUsage.": [glowred]".$GlowText."[/glowred]<br>";
     echo "$VDisplays</font></font></p><table style=\"Filter: Glow(Color=red, Strength=2)\" width=300>$GlowText</table><br>";
     echo "[i][/i] ".$VHelpITALICS.".<br><br>".$VUsage.": [i]".$ItalicText."[/i] <br><font color=\"$fontcolor\">";
     echo "$VDisplays: <i>$ItalicText</i><br><br>";
     echo "[b][/b] ".$VHelpBold.".<br><br>".$VUsage.": [b]".$BoldText."[/b]<br>".$VDisplays.":<b> ".$BoldText."</b><br> </font><br>";
     sbot();
     writefooter($newestm);
}
ob_end_flush();
?>
