<?php
/*If you don't want your visitors to see the button of Paypal, just remove the following lines that begin with "echo".
If you want to show your own image in the top right corner of PBLang instead of the Paypal button, then fill in your URL in
the image tag below and remove the two backslashes in the beginning of the line. Note that
you must not alter anything else, otherwise you might get an error message!
*/

//echo "<img src=\"http://your_image_URL_here\">";

echo "<form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\">";
echo "<input type=\"hidden\" name=\"cmd\" value=\"_xclick\">";
echo "<input type=\"hidden\" name=\"business\" value=\"DrMartinus@gmx.net\">";
echo "<input type=\"hidden\" name=\"item_name\" value=\"PBLang\">";
echo "<input type=\"hidden\" name=\"no_shipping\" value=\"1\">";
echo "<input type=\"hidden\" name=\"cn\" value=\"Donation to PBLang\">";
echo "<input type=\"image\" src=\"templates/pb/images/x-click-but04.gif\" name=\"submit\" alt=\"Make payments with PayPal - it's fast, free and secure!\">";
echo "</form>";
?>
