English translation is available at the end of this document.

----------------------------------------------------------------------
LEESMIJ bestand voor NL update van PBLang 4.5

Eerste versie gepubliceerd op 26 December 2002
Werkt vermoedelijk ook op versie 4.0, maar dit is niet getest.

----------------------------------------------------------------------
Installatie;
1)  Hernoem in templates\pb\language het Nederlandse taalbestand (lang_nl.php).
1a) Mochten er toch problemen optreden kunt u het nieuwe bestand verwijderen en het oude bestand weer wijzigen in de originele naam.
2)  Kopieer alle bestanden naar de gelijknamige map op uw web/forum server.
3)  Kies vervolgens als beheerder in het instellingenmenu voor de NL (nederlandse) taal.
4)  Alles zou vanaf nu omgezet moeten zijn en na een refresh ziet u de teksten en knoppen in het Nederlands.

Bijgewerkt en aangepast per 28 dec. 2002:
* Terms of use is vertaald en er is nu ook een nederlands document voor de voorwaarden aanwezig.
* QQB button is gecorrigeerd, van de top naar de butt directory verplaatst
* Enkele buttons zijn (op verzoek) alsnog vertaald
* De randen rondom de buttons zijn doorschijnend gemaakt zodat ze geen kleurenschema's be�nvloeden.
* Enkele kleine typefouten gecorrigeerd in het NL-taal bestand. Er zijn geen correcties op de vertaling aangebracht.

Bijgewerkt en aangepast per 5 jan. 2003:
* Gerapporteerde en gevonden taalfouten in het lang_nl.php bestand gecorrigeerd.
* Taalaanpassingen en enkele fouten gecorrigeerd in het termsofuse_nl bestand.

Bijgewerkt en aangepast per 24 apr. 2003:
* lang_nl.php bestand aangepast en bijgewerkt voor versie 4.5
* Taalaanpassingen en enkele fouten gecorrigeerd in het termsofuse_nl bestand.

======================================================================
Readme file for NL update of PBLang 4.0

First version has been publiced on 26 December 2002
Will probably also work with version 3.0, but this has not been tested.

----------------------------------------------------------------------
Installation;
1)  Rename in the templates\pb\language the Dutch language file (lang_nl.php).
1a) If problems would occur you can delete the new lang_nl.php file and give the old (renamed) file its original name back.
2)  Copy all files to the folder with the same name on your web/forum/board server.
3)  Choose as admin in the Admin control panel for the NL (Dutch) language.
4)  If everything went right after you press/klick refresh in your browser everthing should be changed into the Dutch language (with appropriate buttons)

Updated and changed on 28 dec. 2002:
* Terms of use has now been translated into the Dutch language and is included in this package.
* QQB button has been corrected and moved from the top to the butt directory.
* Some other buttons have (on request) been translated in to Dutch
* The outside areas of the buttons have been made transparent, so the do not mess up other colors.
* Some typing errors in the NL-language file have been corrected. New translation was not neccesary.

Updated and changed on 5 jan. 2003:
* Reported and found language errors in the lang_nl.php file corrected.
* Some sentences adjusted and some language errors corrected in the termsofuse_nl.txt file.

Updated and changed on 24 apr. 2003:
* lang_nl.php file adjusted and updated for the PBL 4.5 version
* Some sentences adjusted and some language errors corrected in the termsofuse_nl.txt file.

----------------------------------------------------------------------
