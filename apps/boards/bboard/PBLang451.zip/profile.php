<?php
/***************************************************************************
 *                            profile.php  - PBLang
 *                            -------------------
 *
 *             read the file copyright.txt in the docs-folder
 *		updated 21 May 2003
 ***************************************************************************/

error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
                                                     // always modified
header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");  

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include($dbpath."/settings.php");
include($dbpath."/settings/styles/styles.php");
include_once("scan.php");
include_once("functions.php");
include_once("ffunctions.php");
$sendpmimg=GetImage($stylepref,'sendpm','butt/');

$liusername=$HTTP_COOKIE_VARS[$cookieid];
$permit=CheckLoginStatus($liusername,"1","0");
if ($permit=="1") {
	$language=SetLanguage($liusername);
	$sendpmimg=GetImage($stylepref,'sendpm','butt/');
	include($temppath."/pb/language/lang_".$language.".php");
	$user=$HTTP_GET_VARS['u'];
	if (!$user)
	{
		ErrorMessage($AccessDenied,$user);
		exit;
	}
	writeheader($newestm,0,0,0,$liusername,$loggedin,$VProfile);
	include($dbpath."/members/".$user);

	$realname=$userrealname;
	$alias=$useralias;
	$posts=$userposts;
	$pt=$userslogan;
	$msn=$usermsn;
	$yah=$useryahoo;
	$aim=$useraim;
	$icq=$usericq;
	$qq=$userqq;
	$loc=$userlocation;
	$sig=$usersig;
	$av=$useravatar;
	$type=$userrank;
	$em=$useremail;
	$emhide=$useremhide;
	$web=$userhomepage;
	$webav=$userwebavatar;
	$statn=GetRank($type);

	$filet="$dbpath/online/$user";
	if (file_exists($filet)) {
		$on="$VLoggedOn";
	} else {
		$on="$VLoggedOff";
	}
	if ($type=="6") {
		$type="12";
	}
	if ($type=="7") {
		$type="12";
	}
	if ($type=="8") {
		$type="1";
	}
	$stati="rank$type.gif";
	$sig=replacestuff($sig);

	WriteTableTop();
	echo "<form method=\"post\" action=\"\">";
	echo "<tr><td class=\"header\" colspan=\"3\"><font color=\"$headerfont\">$sitetitle :: $VProfileFor $alias";
	if ($admin=="1") {
		print " :: <a href=\"ucp.php?te=$user\">$VModify</a>";
	}
	echo "</td></tr>";
	echo "<tr ><td class=\"subheader\" width=\"20%\">$VAvatar :: ";
	echo "</td><td class=\"subheader\" width = \"80%\" colspan=2><font color=\"$subheaderfont\">$VSettings :: </font></td></tr>";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" align=\"center\" bgcolor=\"$fcolormenu\" width=\"20%\" valign=\"bottom\" rowspan=11>";
	echo "<font color=\"$menufont\"><p>&nbsp;</p>";
	if ($ave=="1") {
		if ($av=="webav") {
				$avsize=@getimagesize($webav);
				$avheight=$avsize[1];
				$avwidth=$avsize[0];
				if (($avmaxheight || $avmaxwidth) && ($avheight>$avmaxheight || $avwidth>$avmaxwidth)){
					$heightratio=$avheight/$avmaxheight;
					$widthratio=$avwidth/$avmaxwidth;
					if ($heightratio>$widthratio){
						$avheight=round($avheight/$heightratio);
						$avwidth=round($avwidth/$heightratio);
					}else{
						$avheight=round($avheight/$widthratio);
						$avwidth=round($avwidth/$widthratio);
					}
					echo "<img src=\"$webav\" alt=\"$VImage\" width=\"$avwidth\" height=\"$avheight\">";
				}else{
					echo "<img src=\"$webav\" alt=\"$VImage\">";
				}
		} elseif (trim($av)!="" && $av!="none") {
				echo "<img src=\"templates/$template/images/avatars/$av\" alt=\"$VImage\">";
		}else{
			echo $VNoAvatar;
		}
	} else {
		print $NoAvatars;
	}
	echo "<p>$pt</p></td>"; //<td height=\"42\" bgcolor=\"$fmenucolor\" width=\"70%\" valign=\"top\">";
	echo "<td height=\"15\" bgcolor=\"$fmenucolor\" width=\"20%\" align=\"right\" valign=\"top\"><font color=\"$menufont\">$VRealname:</td>
		<td align=\"left\" width=\"80%\">$realname</td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">$VAlias:</td>
		<td align=\"left\" width=\"80%\">$alias</td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">$VLocation:</td>
		<td align=\"left\" width=\"80%\">$loc</td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">MSN:</td>
		<td align=\"left\" width=\"80%\">$msn</td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">AIM:</td>
		<td align=\"left\" width=\"80%\"><a href=\"aim:goim?screenname=$aim&message=Hello+Are+you+there?\">
		<font color=\"$menufont\">$aim</font></a></td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">ICQ #:</td>
		<td align=\"left\" width=\"80%\"><a href=\"http://wwp.icq.com/scripts/search.dll?to=$icq\"><font color=\"$menufont\">$icq</font></a></td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">QQ:</td>
		<td align=\"left\" width=\"80%\">$qq</td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">$VWebsite: </td><td align=\"left\">";
	if ($web!="http://" && trim($web)!="" && $web!="http:///") {
		echo "<a href=\"$web\" target=\"_blank\"><font color=$menufont>$web</font></a>";
	}
	echo "</td></tr><tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">Yahoo:</td><td align=\"left\">";
	if (trim($yah)!="") {
		echo "<a href=\"http://edit.yahoo.com/config/send_webmesg?.target=$yah&.src=pg\"><font color=\"$menufont\">$yah</font></a>";
	}
	echo "</td></tr>";
	if (($emhide=="hide" && $admin!="1") || $loggedin=="0"){
		echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">$VEmail:</td>
			<td align=\"left\" width=\"80%\">$VHidden</td></tr>\n";
	}else{
		echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">$VEmail:</td>
			<td align=\"left\" width=\"80%\"><a href=\"mailto:$em\"><font color=$menufont>$em</font></a></td></tr>\n";
	}
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" width=\"20%\" align=\"right\" valign=\"top\">$VStatus:</td>
		<td align=\"left\" width=\"80%\">$on</td></tr>\n";
	echo "</td></tr><tr>";
	echo "<td class=\"subheader\" width=\"20%\">$VSignature :: </td>";
	echo "<td class=\"subheader\" width=\"80%\" colspan=2><font color=\"$menufont\">$VPosts $VAnd $VStatus :: </font></td></tr>\n";
	echo "<tr bgcolor=\"$fmenucolor\"><td height=\"15\" align=\"center\" width=\"20%\" valign=\"middle\"><font color=\"$menufont\">$sig</font></td>";
	echo "<td height=\"15\" bgcolor=\"$fmenucolor\" width=\"80%\" colspan=2><font color=\"$menufont\">$statn<br>";
	echo "<img src=\"templates/$template/images/ranks/$stati\"><br>";
	echo "$VPosts: $posts</font>";
//     echo $VPosts.": ".$posts;
	if ($picturebuttons=="Yes"){
		if ($loggedin=="1"){
			echo "<br><BR><a href=\"sendpm.php?to=$user\"><img src=\"$sendpmimg\" border=\"0\" alt=\"$sendpmalt\" title=\"$sendpmtitle\"></a>";
		}
	}else{
		if ($loggedin=="1"){
			echo "<br><br><a href=\"sendpm.php?to=$user\">$Vsendpm</a>";
		}
	}
	echo "<br>";
	sbot();

	writefooter($newestm);
}
ob_end_flush();
?>
