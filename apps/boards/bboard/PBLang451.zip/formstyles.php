<?php
include ("global.php");
include ($dbpath."/settings/styles/styles.php");

?>

A {
     font-family= <?php echo $font; ?>;
}

P {
     font-family= <?php echo $font; ?>;
}

TD {
          font-size: <?php echo $fontsize; ?>;
          color: <?php echo $fontcolor; ?>;
          font-family: <?php echo $font; ?>;
}

.adminform{
	width:81%;
	height:399;
	background-color:<?php echo $menucolor; ?>;
	vertical-align: top;
}

.nobuttonshead{
          font-size: <?php echo $fontsize; ?>;
          color: <?php echo $forumheadermenufont; ?>;
          font-family: <?php echo $font; ?>;
}

.indexleft{
     width:5%;
     height:15px;
     background-color:<?php echo $fmenucolor; ?>;
     text-align:center;
     vertical-align:middle
}

.quote{
     background-color:<?php echo $quotebackground; ?>;
     text-align:left;
     vertical-align:middle;
	 color: <?php echo $quotefontcolor; ?>;
}

.subheader{
	background-image: url(<?php echo $subheadergif; ?>);
	background-color: <?php echo $subheadercolor; ?>;
	vertical-align:middle;
	line-height: 12px;
}

.header{
	background-image: url(<?php echo $headergif; ?>);
	background-color: <?php echo $headercolor; ?>;
	vertical-align:middle;
	color: <?php echo $headerfont; ?>;
	font-weight: bold;
	font-size:  <?php echo $fontsize; ?>;
	line-height: 15px;
}

IMG{
margin-left:auto;
margin-right:auto;
}

.announcement{
     font-size: <?php echo $annfontsize; ?>;
     color: <?php echo $annfontcolor; ?>;
     font-family: <?php echo $annfont; ?>;
     vertical-align:middle;
     text-align:left;
}

A:link{
     text-decoration: none;
     color: <?php echo $linkcolor; ?>;
}

A:visited{
     text-decoration: none;
     color: <?php echo $vlinkcolor; ?>;
}

A:hover{
     text-decoration: none;
     color: <?php echo $hlinkcolor; ?>;
     font-style: normal;
     background-color: transparent;
     text-decoration: underline;
}

