<?php
/***************************************************************************
 *                            delpm.php
 *                            -------------------
 *
 *             see copyright.txt in the docs-folder
 ***************************************************************************/


error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

ob_start();

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
                                                     // always modified
header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");  

define('IN_PB', "true");
define('IN_PBG', "true");

include("global.php");
include($dbpath."/settings.php");
include_once("functions.php");
include_once("ffunctions.php");

$username=$HTTP_COOKIE_VARS[$cookieid];
$permit=CheckLoginStatus($username,"1","0");
if ($permit=="1") {
     $language=SetLanguage($username);
     include("$temppath/pb/language/lang_$language.php");
     $id=$HTTP_GET_VARS['id'];
     $a=$HTTP_GET_VARS['a'];
     $filename = "$dbpath/pm/$a"."_$id"."_c";
     if (!file_exists($filename)){
	 	$filename=str_replace("_"," ",$filename);
	}
     $fd = fopen ($filename, "r");
     $tease = fread ($fd, filesize ($filename));
     fclose ($fd);
     if ($tease=="delplz") {
          ErrorMessage($PMAlreadyDeleted,$username);
     } else {
          $des="delplz";
          $fp = fopen($dbpath."/pm/".$a."_".$id."_c", "w");
          fputs($fp, $des);
          fclose($fp);

          $filename = $dbpath."/pm/".$a."_tot";
          if (!file_exists($filename)){
               $filename=str_replace("_"," ",$filename);
		}
          $fd = fopen ($filename, "r");
          $num = fread ($fd, filesize ($filename));
          fclose ($fd);
          $num--;
          $fp = fopen("$dbpath/pm/$a"."_tot", "w");
          fputs($fp, $num);
          fclose($fp);
          echo "<meta http-equiv=\"Refresh\" content=\"0; URL=pm.php\">";
     }
}
ob_end_flush();
?>
