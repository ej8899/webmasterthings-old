# MySQL dump 8.12
#
# Host: localhost    Database: 
#--------------------------------------------------------
# Server version	3.23.33-log

#
# Table structure for table 'board'
#

CREATE TABLE board (
  id int(10) unsigned NOT NULL auto_increment,
  board_id int(10) unsigned NOT NULL default '0',
  parent_id int(10) unsigned NOT NULL default '0',
  thread_id int(10) unsigned NOT NULL default '0',
  pdate datetime default NULL,
  name varchar(50) default NULL,
  email varchar(50) default NULL,
  subject varchar(100) default NULL,
  body text,
  PRIMARY KEY (id),
  UNIQUE KEY id(id),
  KEY id_2(id,board_id,parent_id,thread_id)
) TYPE=MyISAM;

