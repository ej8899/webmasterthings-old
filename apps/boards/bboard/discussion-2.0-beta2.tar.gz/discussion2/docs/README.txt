------------
* discussion
------------
discussion is a simple, threaded discussion board. it uses PEAR for dataase
independence. you should use the latest version for best results. discussion 
has been tested on access and mysql.

consider using http://mindhost.net for php/mysql hosting.

written by paul gareau <paul@xhawk.net>

--------------
* installation
--------------
1) extract discussionxxxxxxxxx.tar.gz to a published directory
     $ tar zxvf discussionxxxxxxxx.tar.gz
2) run the command:
     $ mysql -p -u username databasename < board.sql
   this will create the table named 'board' for you.
3) you must set your servername, username, password and database name 
   in class.discussion.php
   if you want your config files in a different directory, change the value
   of config_dir
4) if you want to use the admin page, you will need to make discussion.inc.php
   world-writable. here's how:
     $ chmod o+w discussion.inc.php
   this obviously presents some security issues, you've been warned :)
5) send me an email so i can see your site (paul@xhawk.net)

thats it!

---------------
* configuration
---------------
* use caching only if you get many hits (greater than 1 hit per minute(?)). 
  otherwise pages can fall out of sync. using caching with a low volume site
  wouldnt help you much anyway.

* move the cache, config and admin dir for security. the cache and config dir
  should be below your web root. password protect the admin dir.

* make sure the cache directory and config file(s) are world writable.

* the index.php file included with discussion is just an example. be creative,
  do your own thing. when you get your discussion all perty, send me an email 
  and ill add your link to xhawk.net

* to display different boards, change the value of
    $d1 = new discussion('table name', x, $use_cookies);
  where x is the board you wish to display.
  x can also be a variable, maybe named $board. it would look like this:
    $d1 = new discussion('table name', $board);
  you will have to pass this variable throughout all the pages, you will need this:
    $d1->xtra_args = "board=$board";
  the link pointing to the page with the forum will also need to pass it that value

* you can have different config files for each table. make a file named
  discussion_x.inc.php where x is the name of the table that the config file
  will apply to. you do NOT need a config file for each table. if it cant find 
  the right config file, it will use the default discussion.inc.php

* you may want to delete posts at some point. all you need to do is set either:
    $admin = 1;
  or:
    $d1->admin = 1;
  to keep other people from deleting posts you can hide the page where admin
  is enabled, or you can use something more advanced like http auth to set:
    $d1->admin = 1; 
  if the user is validated

* IMPORTANT * if you use cookies, you must use output buffering on your page!
  at the very top of your page add:
    ob_start();
  and at the very bottom add:
    ob_end_flush();
  output buffering only works with php4 and up - that means you can only use cookies
  with php4 and up!

* if you have any other questions, email me

------------
* change log
------------

version 2.0 beta
* themes
* lang files
* lots of misc improvements
* no implementation (object interface) changes

version 20010820
* added list caching
* got PEAR fully working on access and mysql
* new admin interface
* more config options
* slightly different appearance

version 20010624
* small implementation changes
* database independance using PEAR! :)

version 20010602
* email append property
* neater, more standard code

version 20010527
* implementation change
* mark posts as new only if they were added since the last session
* config files now based on table name not board id

version 20010508
* mail reply fixes
* other potential bug fixes
* cookie changes
* implementation change
* can handle multiple config files, one for each board

version 20010502
* fixed bug that would mail all thread starters when new thread is started
* added user and email properties to class for form completion
* added ubb2html function to class (rather than included)
* small misc changes

version 20010427
* added cookies to store name and email
* unread posts marked 'new' (uses cookies)
* cleaned code
* added config file
* added admin front end for config file
* get_topics function now takes only one argument
* better support for multiple forums + styles
* xtra_args can pass other url args thru discussion board links
* max_indent can be set to prevent 'crunching' of deep posts
* htmlentities used instead of strip_tags for posts
* checks gpc settings and acts accordingly

version 20010420
* added optional duplicate post check
* added error reporting
* table name is not hard-coded anymore
* optionally disable javascript
* fixed ubb code glitches
* trim fields before adding to db
* database connection is made inside class
* more ubb2html fixes

version 20010407
* fixed date bug for older versions of php
* finished ubb code implementation
* changed name of display property to style
* added nested view
* removed nokids view
* bleep dirty words
* added admin features (delete)
* cleaned code a bit
* added multi page capability

------
* todo
------
these are things that could be added at some point

* multi languages
* maybe allow editing of posts
* allow opt-out email replies for user (db change)
* post moderation (db change)
* any ideas?

------
* bugs
------
* none that i know of :)

-----------------------
* problems, ideas, etc?
-----------------------
email me. paul@xhawk.net
thanks!

