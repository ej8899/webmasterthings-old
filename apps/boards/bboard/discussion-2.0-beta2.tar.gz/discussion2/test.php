<?

error_reporting(E_ALL);
ob_start();

function getmicrotime() {
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
}
$time_start = getmicrotime();

include_once 'discussion/discussion.class.php';

echo '<html>';
echo '<head>';
echo '<title>discussion</title>';
echo "<body  bgcolor='#FFFFFF' link='blue' alink='blue' vlink='blue'>";
echo '<style>';
echo 'a {color: blue}';
echo 'a.black{color: black}';
echo '</style>';

if(!isset($post)) $post = '';
if(!isset($show)) $show = '';
if(!isset($view)) $view = '';
if(!isset($delete)) $delete = '';
if(!isset($offset)) $offset = '';

$d1 = new Discussion('board',2,1);

print "\n\n<!-- discussion ver. $d1->version -->\n\n";

if($post) {
    if(! $d1->addPost($parent_id, $thread_id, $name, $email, $subject, $body)) {
        print $d1->error();
    }
}
if($d1->admin && $delete) {
    if(! $d1->deletePost($delete)) {
        print $d1->error();
    }
}
if($show=='form') {
    print $d1->formHTML();
} else {
    if($view) {
        $post_html = $d1->getPost($view);
        if($post_html) {
            print $post_html;
            print $d1->formHTML();
        } else {
            print $d1->error();
        }
    } else {
        print $d1->addNewLinkHTML();
        print $d1->getTopics($offset);
    }
}

print "\n\n<!-- end of discussion -->\n\n";

$time_end = getmicrotime();
print '<br><br>';
print "<font face='verdana' size=1 style='background: #FFFF99'>&nbsp;&nbsp;".number_format($time_end-$time_start,5).'&nbsp;seconds&nbsp;&nbsp;</font>';

echo '</body>';
echo '</html>';

ob_end_flush();

?>