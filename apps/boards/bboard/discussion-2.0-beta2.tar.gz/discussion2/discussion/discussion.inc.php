<?php

// discussion 2.0 beta config file
// #iniread_spacer = 'this is a spacer';
// #iniread_comment = 'this is a comment';

#iniread_spacer	= "General Options";
$admin	= 0;	// (boolean) enable admin features
$app_name	= "discussion";	// (string) name of app
$lang_file	= "";	// (string) eg. piglatin.lang.php
$tpl_dir	= "phorum/";	// (string) eg. original, phorum
$date_format =  "m-d-y H:m"; //"M jS g:ia"
#iniread_spacer	= "Caching";
$use_caching	= 0;	// (boolean) 1 enables list caching
$max_age	= 30;	// (integer) max age in minutes before refreshing cache file
#iniread_spacer	= "List Options";
$depth_multiplier	= 17;	// (integer) level * this = indent
$num_posts	= 5;	// (integer) number of parent posts in list
$order_parents	= "DESC";	// (string) order parents are displayed (ASC or DESC)
$max_indent	= 10;	// (integer) max times to indent children
$multi_page	= 1;	// (boolean) multi page listing
$all_replies	= 1;	// (boolean) show all replies after post
$full_parent	= 0;	// (boolean) display full parent post
$full_reply_list	= 0;	// (boolean) display full reply in list
$full_reply_post	= 0;	// (boolean) display full reply under post
#iniread_spacer	= "Post options";
$use_ubb_code	= 1;	// (boolean) 1 uses ubb code for posts
$use_javascript	= 1;	// (boolean) 1 enables javascript
$censor	= 1;	// (boolean) 1 enables post censoring
$dup_check	= 1;	// (boolean) 1 enables duplicate post checking
$mail_reply	= 0;	// (boolean) 1 mails previous posters of same thread

?>
