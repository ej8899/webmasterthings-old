<?php

/*************************************************************************\
 
  discussion.class.php - a php class for displaying a discussion board
  Copyright (C) 2001 Paul Gareau <paul@xhawk.net>
 
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 
\*************************************************************************/

class Discussion 
{
    function Discussion($table_name='board', $board_id=1, $use_cookies=0) 
	{

        /////////////////////////////////////////////////////////////
        ///// you must enter values for the following variables /////
        /////////////////////////////////////////////////////////////

        // your database connnection info
        $db_type    = 'mysql'; // (string)  mysql, pgsql, ibase, msql, mssql, oci8, odbc, sybase, ifx, fbsql
        $db_persist = 1;       // (boolean) persistant db connection

        $db_host = 'localhost';
        $db_user = '';
        $db_pass = '';
        $db_name = '';

        // directory that contains discussion*.inc.php
        $config_dir = dirname(__FILE__).'/';
        // directory that contains cache files
        $cache_dir = dirname(__FILE__).'/cache/';
        // _template directory
        $theme_dir = dirname(__FILE__).'/themes/';
        // translation files
        $lang_dir  = dirname(__FILE__).'/lang/';

        // all other settings are in discussion*.inc.php

        ////////////////////////////////////////////////////////////////
        ///// you shouldnt have to worry about anything below here /////
        ////////////////////////////////////////////////////////////////

        $this->version      = '2.0 beta';
        $this->date_col     = 'pdate';
        $this->table_name   = $table_name;
        $this->board_id     = $board_id;
        $this->use_cookies  = $use_cookies;
        $this->cache_dir    = $cache_dir;
        $this->lang_dir     = $lang_dir;
        $this->depth        = 0;
        $this->last_id      = 0;
        $this->last_post    = 0;
        $this->post_num     = 0;
        $this->prev_post    = 0;
        $this->next_post    = 0;
        $this->xtra_args    = '';
        $this->email_append = '';

        // if a table specific config file exists, use it
        if(file_exists("{$config_dir}discussion_{$this->table_name}.inc.php")) {
            include_once("{$config_dir}discussion_{$this->table_name}.inc.php");
        } else {
            include_once("{$config_dir}discussion.inc.php");
        }
        // set values from config file
        $this->max_indent       = $max_indent;      // (integer) max times to indent children
        $this->all_replies      = $all_replies;     // (integer) show all replies after post
        $this->max_age          = $max_age;         // (integer) max age in minutes before refreshing cache file
        $this->depth_multiplier = $depth_multiplier;
        $this->num_posts        = $num_posts;       // (integer) number of posts per page
        $this->mail_reply       = $mail_reply;      // (boolean) 1 mails previous posters of same thread
        $this->dup_check        = $dup_check;       // (boolean) 1 enables duplicate post checking
        $this->use_ubb_code     = $use_ubb_code;    // (boolean) 1 uses ubb code for posts
        $this->use_javascript   = $use_javascript;  // (boolean) 1 enables javascript
        $this->censor           = $censor;          // (boolean) 1 enables post censoring
        $this->use_caching      = $use_caching;     // (boolean) 1 enables list caching
        $this->admin            = $admin;           // (boolean) enable admin features
        $this->multi_page		= $multi_page;
        $this->full_parent		= $full_parent;
        $this->full_reply_list	= $full_reply_list;
        $this->full_reply_post	= $full_reply_post;
        $this->order_parents    = $order_parents;   // (string) order parents are displayed (ASC or DESC)
        $this->tpl_dir          = $theme_dir.$tpl_dir;
        $this->app_name         = $app_name;
        $this->lang_file        = $lang_file;
		$this->date_format		= $date_format;

        $this->cookie_read_name  = 'cookie_read_ids_'.$this->table_name;
        $this->cookie_lsession_name = 'cookie_last_session_'.$this->table_name.'_'.$this->board_id;

        if($this->use_cookies) {
            // give each board a cookie whose name is based on its table name and board id
            // prevents multi table/board interference
            $cookie_last_load = 'cookie_last_load_'.$this->table_name.'_'.$this->board_id;
            $cookie_session = 'cookie_session_'.$this->table_name.'_'.$this->board_id;

            global ${$this->cookie_lsession_name}, ${$cookie_last_load}, ${$cookie_session};

            // the last session should be set to the last page load if
            // a new session is being started, or 0 if its a first view
            if(!${$cookie_session}) {
                if(!${$cookie_last_load}) {
                    ${$cookie_last_load} = 0;
                }
                ${$this->cookie_lsession_name} = ${$cookie_last_load};
                setcookie($this->cookie_lsession_name, ${$this->cookie_lsession_name});
            }
            setcookie($cookie_session, 1);
            setcookie($cookie_last_load, time(), time()+518400);
        }

        include_once 'DB.php';
        $this->db = DB::connect("$db_type://$db_user:$db_pass@$db_host/$db_name", $db_persist);
        if (DB::isError($this->db)) {
            die($this->db->getMessage());
        }
        $this->db->setFetchMode(DB_FETCHMODE_ASSOC);
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    ///// GET FUNCTIONS:
    ///// These call the database and use the HTML methods to print output.
    //////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Retrieve posts and generate html according to $this->style to display them.
     *
     * @param 	$offset (int) show this post first
     * @return 	$out (string) the html to display discussion board
     * @author 	Paul Gareau <paul@xhawk.net>
    */

    function getTopics($offset=0) 
	{
        global $PHP_SELF;

        if($offset=='') $offset = 0; // $offset may be set but empty

        $cache_file = $this->table_name.'_'.$this->board_id.'_'.$offset.'.cache';
        if($this->use_caching) {
            if(file_exists($this->cache_dir.$cache_file)) {
                if(filemtime($this->cache_dir.$cache_file)>(time()-(60*$this->max_age))) {
                    $fp = fopen($this->cache_dir.$cache_file, 'r');
                    $out = fread($fp, filesize($this->cache_dir.$cache_file));
                    fclose($fp);
                    return $out;
                } else {
                    unlink($this->cache_dir.$cache_file);
                }
            }
        }
        $sql = "SELECT count(id) FROM $this->table_name
               WHERE board_id=$this->board_id AND thread_id=0";
        $num_total = $this->db->getOne($sql);
        if(DB::isError($num_total)) {
            echo $num_total->getMessage();
            return false;
        }
        $sql = "SELECT id, $this->date_col, name, email, subject, body
               FROM $this->table_name
               WHERE board_id=$this->board_id
               AND thread_id=0
               ORDER BY $this->date_col DESC";
        $result = $this->db->query($sql);
        if(DB::isError($result)) {
            echo $result->getMessage();
            return false;
        }
        $res = $rec = 0;
        $links = $out = '';
        $this->depth = 1; //_getKids will use this value
        while(is_array($record = $result->fetchRow())) {
            if(++$res>$offset && ++$rec<=$this->num_posts) {
                if($this->full_parent) {
                    $links.= $this->_postHTML($record['id'], $record['subject'], $record['name'],
                                             $record['email'], $record[$this->date_col], $record['body']);
                } else {
                    $links.= $this->_linkHTML($record['id'], $record['subject'], $record['name'],
                                             $record['email'], $record[$this->date_col], $record['body'], 0);
                }
                $links.= $this->_getKids($record['id']);
            }
        }
        $result->free();
        if($links) {
            $tpl = $this->_template('list');
            $out.= $this->_replace($tpl, array('content'=>$links));
        } else {
            $out.= $this->_template('br');
        }
        if($this->multi_page) {
            $out.= $this->_pageNavHTML($offset, $this->num_posts, $num_total);
        }
		$out.= base64_decode("PGZvbnQgZmFjZT0ndGFob21hJyBzaXplPTE+WyZuYnNwO1Bvd2VyZWQgYnkgP".
							 "GEgdGFyZ2V0PSdfYmxhbmsnCWhyZWY9J2h0dHA6Ly94aGF3ay5uZXQvcHJvamV".
							 "jdHMvZGlzY3Vzc2lvbi8nPmRpc2N1c3Npb248L2E+Jm5ic3A7XTwvZm9udD4=");
        if($this->use_caching) {
            $fp = fopen($this->cache_dir.$cache_file, 'w');
            fwrite($fp, ereg_replace("[\r\n]", '', $out));
            fclose($fp);
        }
        return $out;
    }

    /**
     * Get and display an individual post and its children according to $this->style
     *
     * @param	$id (int) the id of the post to display
     * @return	$out (string) the html to display the nav, post, kids and form
     * @author	Paul Gareau <paul@xhawk.net>
     */

    function getPost($id) 
	{
        global $PHP_SELF, ${$this->cookie_read_name};

        $sql = "SELECT id, parent_id, thread_id, $this->date_col, name, email, subject, body
               FROM $this->table_name
               WHERE id=$id";
        $result = $this->db->query($sql);
        if(DB::isError($result)) {
            echo $result->getMessage();
            return false;
        }
        $record = $result->fetchRow();
        $result->free();

        if(is_array($record)) {
            $this->post_num = $record['id']; //used in _linkHTML, _getKids
            if($this->use_cookies) {
                $viewed_ids = explode('.', ${$this->cookie_read_name});
                if(! in_array($id, $viewed_ids)) {
                    ${$this->cookie_read_name}.=$id.'.';
                    setcookie($this->cookie_read_name, ${$this->cookie_read_name});
                }
            }
            $kids = $out = '';
			if($record['thread_id'] == 0) $record['thread_id'] = $id;
			if($record['parent_id'] == 0) $record['parent_id'] = $id;
            $out.= $this->_navHTML($record['thread_id'], $record['parent_id']);
            $out.= $this->_postHTML($record['id'], $record['subject'], $record['name'],
                                   $record['email'], $record[$this->date_col], $record['body']);
            if($this->all_replies && !$this->full_reply_post) {
                $this->depth++;
                if($record['thread_id']==0) {
					// if we are at a top level thread, get its kids
                    $top = $this->_linkHTML($record['id'], $record['subject'], $record['name'],
                                           $record['email'], $record[$this->date_col], $record['body'], 0);
                    $kids = $this->_getKids($id);
					if($kids) $kids = $top.$kids;
                } else {
					// if we are not at a top level thread, find main thread, then get its kids
					$sql = "SELECT id, parent_id, thread_id, $this->date_col, name, email, subject, body
						   FROM $this->table_name
						   WHERE id=".$record['thread_id'];
					$result = $this->db->query($sql);
					if(DB::isError($result)) {
						echo $result->getMessage();
						return false;
					}
					$record2 = $result->fetchRow();
					$result->free();
					// top thread info
					if(is_array($record2)) {
						$top = $this->_linkHTML($record2['id'], $record2['subject'], $record2['name'],
											   $record2['email'], $record2[$this->date_col], $record2['body'], 0);
					}
					// top thread child post
                    $kids = $this->_getKids($record['thread_id']);
					if($kids) $kids = $top.$kids;
                }
            } else {
                $kids = $this->_getKids($record['id']);
            }
            if($kids) {
                $out.= $this->_threadNavHTML();
                $tpl = $this->_template('list');
                $out.= $this->_replace($tpl, array('content'=>$kids));
            } else {
                $out.= $this->_template('br');
            }
            //$out.= $this->_navHTML($record['thread_id'], $record['parent_id']);
            $subject = (! strstr($record['subject'], 'Re:')) ? 'Re: '.$record['subject'] : $record['subject'];

            // formHTML() needs these values to be set
            // it is called after this method on the implementation page
            $this->post_id = $record['id'];
            $this->post_thread_id = $record['thread_id'];
            $this->post_subject = $record['subject'];

            return $out;
        } else {
            $this->error = $this->_trans('Post not found!');
            return false;
        }
    }

    /**
     * Recursively find follow-ups to each post and generate html according 
     * to $this->style to display them.
     *
     * @param 	$parent_id (int) id of the post to start at when getting kids
     * @return	$out (string) to display children of a post
     * @author	Paul Gareau <paul@xhawk.net>
     */

    function _getKids($parent_id) 
	{
        global $PHP_SELF;

        $sql = "SELECT id, name, email, $this->date_col, subject, body
               FROM $this->table_name
               WHERE parent_id=$parent_id
               ORDER BY $this->date_col ASC";
        $result = $this->db->query($sql);
        if(DB::isError($result)) {
            echo $result->getMessage();
            return false;
        }
        $depth = ($this->depth>$this->max_indent) ? $this->max_indent : $this->depth;
        $out = $kids = '';
        while(is_array($record = $result->fetchRow())) {
            if($this->post_num==$record['id']) { 
                $this->prev_post = ($this->last_post==0) ? $parent_id : $this->last_post; //used by _threadNavHTML
            }
            if(!$this->next_post && ($this->post_num==$this->last_post || $parent_id==$this->post_num)) {
                $this->next_post = $record['id']; //used by _threadNavHTML
            }
            $this->last_post = $record['id'];
            if((!$this->post_num && $this->full_reply_list) || ($this->post_num && $this->full_reply_post)) {
                $kids.= $this->_postHTML($record['id'], $record['subject'], $record['name'],
                                        $record['email'], $record[$this->date_col], $record['body']);
            } else {
                $kids.= $this->_linkHTML($record['id'], $record['subject'], $record['name'],
                                        $record['email'], $record[$this->date_col], $record['body'], $this->depth);
            }
            ++$this->depth;
            $kids.= $this->_getKids($record['id']);
            --$this->depth;
        }
        $result->free();
        if($kids && $this->depth>0 && $this->depth-1<$this->max_indent) {
            $tpl = $this->_template('kids');
            $out.= $this->_replace($tpl, array('content'=>$kids));
        } else {
            $out.= $kids;
        }
        return $out;
    }


    //////////////////////////////////////////////////////////////////////////////////////////
    ///// HTML FUNCTIONS:
    ///// These prepare data for templates, parse them and return the output.
    ///// They are called by either the GET functions, or directly in the implementation.
    //////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Generate html to display add new link
     *
     * @return	$out (string) the html to display the link
     * @author	Paul Gareau <paul@xhawk.net>
     */

    function addNewLinkHTML()
	{
        global $PHP_SELF;

        $url = "$PHP_SELF?show=form";
        if($this->xtra_args) $url.= "&$this->xtra_args";

        $tpl = $this->_template('add_new');
        $out = $this->_replace($tpl, array('url'=>$url));

        return $out;
    }

    /**
     * Generate html to display an error message
     *
     * @param	$msg (string) error message, if blank $this->error will be used
     * @return	$out (sring) the html to display the message
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function error() 
	{
        $tpl = $this->_template('error');
        $out = $this->_replace($tpl, array('message'=>$this->error));
        return $out;
    }

    /**
     * Generate html to display the post form
     *
     * @return	$out (string) the html to display the form
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function formHTML() 
	{
        global $PHP_SELF, ${$this->cookie_read_name}, $cookie_user_inf;
        $msg = $out = '';

        // get values from object properties
        // set by getPost()
        $parent_id = (isset($this->post_id)) ? $this->post_id : 0;
        $thread_id = (isset($this->post_thread_id) && $this->post_thread_id!=0) ? $this->post_thread_id : $parent_id;
        $subject   = (isset($this->post_subject)) ? $this->post_subject : '';

        if($parent_id) {
            $action = $this->_trans('Reply to this message');
        } else {
            $action = $this->_trans('New Topic');
        }
        // try to get user's name and email from properties
        // failing that try from cookie
        $name = $email = '';
        if($this->use_cookies) {
            if(isset($cookie_user_inf[0])) $name  = $cookie_user_inf[0];
            if(isset($cookie_user_inf[1])) $email = $cookie_user_inf[1];
        } else {
            if(isset($this->name))  $name  = $this->name;
            if(isset($this->email)) $email = $this->email;
        }
        if($this->mail_reply) {
            $msg.= $this->_trans('You will recieve replies to this post by email.');
            $msg.= $this->_template('br');
        }
        if($this->use_ubb_code) {
            $msg.= $this->_trans('UBB code is enabled in this forum.');
            $msg.= $this->_template('br');
        }
        if($this->use_caching) {
            $msg.= $this->_trans('Your post may not appear immediately.');
            $msg.= $this->_template('br');
        }
        $tpl = $this->_template('form');
        $out.= $this->_replace($tpl, array('url'=>$PHP_SELF,'action'=>$action,'name'=>$name,
                                          'email'=>$email,'subject'=>$subject,'message'=>$msg,
                                          'parent'=>$parent_id,'thread'=>$thread_id));
		$out.= base64_decode("PGZvbnQgZmFjZT0ndGFob21hJyBzaXplPTE+WyZuYnNwO1Bvd2VyZWQgYnkgP".
							 "GEgdGFyZ2V0PSdfYmxhbmsnCWhyZWY9J2h0dHA6Ly94aGF3ay5uZXQvcHJvamV".
							 "jdHMvZGlzY3Vzc2lvbi8nPmRpc2N1c3Npb248L2E+Jm5ic3A7XTwvZm9udD4=");
        return $out;
    }

    /**
     * Generate html to display nav links for a post
     *
     * @param	$thread_id (int) the thread being viewed
     * @param	$parent_id (int) the parent of the thread being viewed
     * @return	$out (string) the html to display the nav links
     * @author	Paul Gareau <paul@xhawk.net>
     */

    function _navHTML($thread_id, $parent_id) 
	{
        global $PHP_SELF;

        $list = $PHP_SELF;
        if($this->xtra_args) $list.= "&$this->xtra_args";
        $top = "$PHP_SELF?view=$thread_id";
        if($this->xtra_args) $top.= "&$this->xtra_args";
        $parent = "$PHP_SELF?view=$parent_id";
        if($this->xtra_args) $parent.= "&$this->xtra_args";

        $tpl = $this->_template('post_nav');
        $out = $this->_replace($tpl, array('list'=>$list,'top'=>$top,'parent'=>$parent));

        return $out;
    }

    /**
     * Generate html to display thread navigation
     *
     * @return	$out (string) html to display thread nav links
     */

    function _threadNavHTML() 
	{
        global $PHP_SELF;

        $b_url = "$PHP_SELF?view=$this->prev_post";
        if($this->xtra_args) $list.= "&$this->xtra_args";
        $n_url = "$PHP_SELF?view=$this->next_post";
        if($this->xtra_args) $list.= "&$this->xtra_args";

        $tpl = $this->_template('post_thread_nav');
        $out = $this->_replace($tpl, array('back'=>$b_url,'next'=>$n_url));

        return $out;
    }

    /**
     * Generate html to display navigation for threads
     *
     * @param	$offset (int) the post to start at
     * @param	$limit (int) how many posts to show starting at $offset
     * @param	$num_rows_all (int) how many parent posts (threads) are in the table
     * @return	$out (string) the html to display the nav links
     * @author	Paul Gareau <paul@xhawk.net>
     */

    function _pageNavHTML($offset, $limit, $num_rows_all) 
	{
        global $PHP_SELF;

        $num_pages = ceil($num_rows_all/$limit);

        if($num_pages > 1) {
            $offset_back  = $offset-$limit;
            $offset_next  = $offset+$limit;
            $current_page = $offset/$limit;
            $nav = '';

            if($offset_back >= 0) {
                $b_url = "$PHP_SELF?offset=$offset_back";
                if($this->xtra_args) $b_url.= "&$this->xtra_args";
                $b_tpl = $this->_template('list_nav_back');
                $nav.= $this->_replace($b_tpl, array('url'=>$b_url));
            }
            for($page=0; $page<$num_pages; ++$page) {
                if( ($current_page-5) < $page && ($current_page+5) > $page ) {
                    $offset_page = $page * $limit;
                    $page_num = $page+1;
                    if($current_page==$page) {
                        $c_tpl = $this->_template('list_nav_num_current');
                        $nav.= $this->_replace($c_tpl, array('num'=>$page_num));
                    } else {
                        $p_url = "$PHP_SELF?offset=$offset_page";
                        if($this->xtra_args) $b_url.= "&$this->xtra_args";
                        $n_tpl = $this->_template('list_nav_num');
                        $nav.= $this->_replace($n_tpl, array('url'=>$p_url,'num'=>$page_num));
                    }
                }
            }
            if($offset_next < $num_rows_all) {
                $n_url = "$PHP_SELF?offset=$offset_next";
                if($this->xtra_args) $n_url.= "&$this->xtra_args";
                $n_tpl = $this->_template('list_nav_next');
                $nav.= $this->_replace($n_tpl, array('url'=>$n_url));
            }
            $tpl = $this->_template('list_nav');
            $out = $this->_replace($tpl,array('content'=>$nav));

            return $out;
        } else {
            return false;
        }
    }

    /**
     * Generate html to display a bulleted link to a post
     *
     * @param	$id (int) the id of the post
     * @param	$subject (string) the subject of the post
     * @param	$name (string) name of the poster
     * @param	$email (string) the email address of the poster
     * @param	$date (string) the date of the post
     * @return	$out (string) the html to display the link
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function _linkHTML($id, $subject, $name, $email, $date, $body, $depth) 
	{
        global $PHP_SELF, ${$this->cookie_read_name}, ${$this->cookie_lsession_name};
		static $link_num;
        $new = $admin = $time_stamp = '';

        //if($email) $name = "<a href='mailto:$email'>$name</a>";
        if($date) {
            $time_stamp = strtotime($date);
            $date = date($this->date_format, $time_stamp);
        }
        $url = "$PHP_SELF?view=$id";
        if($this->use_cookies) {
            $viewed_ids = explode('.', ${$this->cookie_read_name});
            if(! in_array($id, $viewed_ids) && $time_stamp > ${$this->cookie_lsession_name}) {
                $new = $this->_template('new');
            }
        }
        if($this->admin) {
            $del_url = "$PHP_SELF?delete=$id";
            if($this->xtra_args) $del_url.= "&$this->xtra_args";
            $tpl = $this->_template('admin');
            $admin = $this->_replace($tpl, array('url'=>$del_url));
        }
        $depth = $depth * $this->depth_multiplier;
        if(isset($this->post_num) && $id==$this->post_num && $this->all_replies) {
            $s_tpl = $this->_template('list_subject_current');
            $subject = $this->_replace($s_tpl, array('subject'=>$subject));
        }
        $link = ($link_num++ % 2) ? 'link_even' : 'link_odd';

		$tpl = $this->_template($link);
        $out = $this->_replace($tpl, array('depth'=>$depth,'subject'=>$subject,'url'=>$url,'new'=>$new,
                                          'name'=>$name,'date'=>$date,'admin'=>$admin));
        return $out;
    }

    /**
     * Generate html to display a post
     *
     * @param	$id (int) the id of the post
     * @param	$subject (string) the subject of the post
     * @param	$name (string) name of the poster
     * @param	$email (string) the email address of the poster
     * @param	$date (string) the date of the post
     * @param	$body (string) the body of the post
     * @return	$out (string) the html to display the link
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function _postHTML($id, $subject, $name, $email, $date, $body) 
	{
        global $PHP_SELF, ${$this->cookie_read_name}, ${$this->cookie_lsession_name};
        $new = $admin = '';

        if($email) {
            $tpl = $this->_template('email');
            $name = $this->_replace($tpl, array('email'=>$email,'name'=>$name));
        }
        $time_stamp = strtotime($date);
        $date = date($this->date_format, $time_stamp);
        $url = "$PHP_SELF?view=$id";
        if($this->use_cookies) {
            $viewed_ids = explode('.', ${$this->cookie_read_name});
            if(! in_array($id, $viewed_ids) && $time_stamp > ${$this->cookie_lsession_name}) {
                $new = $this->_template('new');
            }
        }
        if($this->admin) {
            $del_url = "$PHP_SELF?delete=$id";
            if($this->xtra_args) $del_url.= "&$this->xtra_args";
            $tpl = $this->_template('admin');
            $admin = $this->_replace($tpl, array('url'=>$del_url));
        }
        $tpl = $this->_template('post');
        $out = $this->_replace($tpl, array('subject'=>$subject,'url'=>$url,'new'=>$new,
                                          'name'=>$name,'date'=>$date,'admin'=>$admin,'body'=>$body));
        return $out;
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    ///// DB FUNCTIONS:
    ///// These add or remove posts from the DB.
    //////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Add post to database
     *
     * @param	$parent_id (int) the id of the parent, if post is a follow up
     * @param	$thread_id (int) the id of the thread, if post is a follow up
     * @param	$subject (int) the subject, if post is a follow up
     * @param	$name (string) name of the poster
     * @param	$email (string) the email address of the poster
     * @param	$subject (string) the subject of the post
     * @param	$body (string) the body of the post
     * @return	$out (string) the html to display the form
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function addPost($parent_id, $thread_id, $name, $email, $subject, $body) 
	{
        global $HTTP_HOST, $PHP_SELF, ${$this->cookie_read_name};

        if(! $subject) {
            $this->error = $this->_trans('You must enter a subject!');
            return false;
        }
        if(! get_magic_quotes_gpc()) {
            $name    = addslashes($name);
            $email   = addslashes($email);
            $subject = addslashes($subject);
            $body    = addslashes($body);
        }
        // general clean up of fields
        $name		= htmlentities(trim($name));
        $email      = htmlentities(trim($email));
        $subject    = htmlentities(trim($subject));
        $body       = trim($body);

        if($this->censor) {
            // illegal words
            $bad_words  = "shit|fuck|cunt|twat|pussy|asshole";
            $bw_replace = '[beep]'; //'!@#$%'; // its your choice...
            $name       = eregi_replace($bad_words, $bw_replace, $name);
            $email      = eregi_replace($bad_words, $bw_replace, $email);
            $subject    = eregi_replace($bad_words, $bw_replace, $subject);
            $body       = eregi_replace($bad_words, $bw_replace, $body);
        }
        if(!$name) $name = '['.$this->_trans('anonymous').']';
        if(!$body) $body = '['.$this->_trans('no text').']';

        $mail_body  = $body; //save body now for mailing
        $body       = htmlentities($body); // change html to entities BEFORE _ubb2html
        $body       = str_replace("\n", $this->_template('br'), $body); // better than nl2br()

        if($this->use_ubb_code) {
            $body = $this->_ubb2html($body);
        }

        ///// all post modification must be done ABOVE this point! /////

        if($this->use_cookies) {
            setcookie('cookie_user_inf[0]', $name,  time()+518400);
            setcookie('cookie_user_inf[1]', $email, time()+518400);
        }
        if($this->dup_check) { //dont check top level for repeats
            $sql = "SELECT count(id)
                   FROM $this->table_name
                   WHERE parent_id=$parent_id
                   AND name='$name' AND email='$email' AND subject='$subject' AND body='$body'";
            $dups = $this->db->getOne($sql);

            if($dups) {
                $this->error = $this->_trans('Duplicate posts are not allowed!');
                return false;
            }
        }
        $sql = "INSERT INTO $this->table_name (board_id, parent_id, thread_id, $this->date_col, name, email, subject, body)
               VALUES($this->board_id, $parent_id, $thread_id, NOW(), '$name', '$email', '$subject', '$body')";
        $result = $this->db->query($sql);

        if(!DB::isError($result)) {
            // get id of the post we just added
            $sql = "SELECT id FROM $this->table_name
                   WHERE parent_id=$parent_id
                   AND name='$name' AND email='$email' AND subject='$subject'";
            $post_id = $this->db->getOne($sql);
            if(DB::isError($post_id)) {
                return false;
            }
            // mark this post read
            if($this->use_cookies) {
                ${$this->cookie_read_name}.=$post_id.'.';
                setcookie($this->cookie_read_name, ${$this->cookie_read_name});
            }
            // send if mail_reply is enabled
            // and if it is not a first post
            if($this->mail_reply && $thread_id!=0) {
                // keep slashes from appearing in email
                $mail_name    = stripslashes($name);
                $mail_subject = stripslashes($subject);
                $mail_body    = stripslashes(str_replace("\r", '', $mail_body));

                // we dont want ubb code in email either
                if($this->use_ubb_code) {
                    $mail_body = $this->_stripUBB($mail_body);
                }
                // format subject and body
                $mail_subject = '['.$this->app_name.']'.$mail_subject;
                $mail_body    = "$mail_name ".$this->_trans('says').":\n\n".
                                "$mail_body\n\n\n".
                                $this->_trans('Reply to this message').":\n".
                                "http://$HTTP_HOST$PHP_SELF?view=$post_id&$this->xtra_args";
                $mail_body   .= $this->email_append;

                $sql = "SELECT DISTINCT email FROM $this->table_name
                       WHERE (thread_id=$thread_id OR id=$thread_id)
                       AND email != '$email'";
                $result = $this->db->query($sql);

                while(is_array($record = $result->fetchRow())) {
                    $to = $record['email'];
                    if(ereg(".+@.+\\..+", $to)) { // very simple address checking
                        mail($to, $mail_subject, $mail_body, "From: discussion@$HTTP_HOST");
                    }
                }
            }
            return true;
        } else {
            echo $result->getDebugInfo();
            $this->error = $this->_trans('Could not add post!');
            return false;
        }
    }

    /**
     * Delete a post and its children (recursively)
     *
     * @param	$id (int) id of the post to delete
     * @return	true on success, false on falure
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function deletePost($id) 
	{
        $sql = "SELECT id FROM $this->table_name WHERE parent_id=$id";
        $result = $this->db->query($sql);

        while(is_array($record = $result->fetchRow())) {
            $this->deletePost($record['id']);
        }
        $sql = "DELETE FROM $this->table_name WHERE id=$id";
        $result = $this->db->query($sql);
        if(!DB::isError($result)) {
            return true;
        } else {
            $this->error = $this->_trans('Could not delete post!');
            return false;
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    ///// UBB CONVERSION:
    ///// These convert ubb code to html, or remove ubb code.
    //////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Convert ubb code to html
     *
     * @param	$string (string) the string of text to be converted
     * @return	$string (string) the converted string
     * @author	Paul Gareau <paul@xhawk.net>
     */

    function _ubb2html($string) 
	{
        $string = preg_replace("/\[b\](.*?)\[\/b\]/si", "<b>\\1</b>", $string);
        $string = preg_replace("/\[i\](.*?)\[\/i\]/si", "<i>\\1</i>", $string);
        $string = preg_replace("/\[u\](.*?)\[\/u\]/si", "<u>\\1</u>", $string);
        $string = preg_replace("/\[p\](.*?)\[\/p\]/si", "<p>\\1</p>", $string);
        $string = preg_replace("/\[code\](.*?)\[\/code\]/si", "<blockquote><pre>\\1</pre></blockquote>", $string);
        $string = preg_replace("/\[quote\](.*?)\[\/quote\]/si", "<blockquote>\\1</blockquote>", $string);
        $string = preg_replace("/(^|\s)(http:\/\/\S+)/si", "\\1<a href=\"\\2\">\\2</a>", $string);
        $string = preg_replace("/(^|\s)(www\.\S+)/si", "\\1<a href=\"http://\\2\">\\2</a>", $string);
        $string = preg_replace("/\[url\](http|https|ftp)(:\/\/\S+?)\[\/url\]/si",
                               "<a href=\"\\1\\2\" target=\"_blank\">\\1\\2</a>", $string);
        $string = preg_replace("/\[url\](\S+?)\[\/url\]/si",
                               "<a href=\"http://\\1\" target=\"_blank\">\\1</a>", $string);
        $string = preg_replace("/\[url=(http|https|ftp)(:\/\/\S+?)\](.*?)\[\/url\]/si",
                               "<a href=\"\\1\\2\" target=\"_blank\">\\3</a>", $string);
        $string = preg_replace("/\[url=(\S+?)\](\S+?)\[\/url\]/si",
                               "<a href=\"http://\\1\" target=\"_blank\">\\2</a>", $string);
        $string = preg_replace("/\[email\](\S+?@\S+?\\.\S+?)\[\/email\]/si",
                               "<a href=\"mailto:\\1\">\\1</a>", $string);
        $string = preg_replace("/\[img\](\S+?)\[\/img\]/si",
                               "<img src=\"\\1\" border=0 alt=\"\\1\">", $string);
        return $string;
    }

    /**
     * Strip ubb tags from string
     *
     * @param   $string (string) the string of text to be stripped
     * @return  $string (string) the converted string
     * @author  Paul Gareau <paul@xhawk.net>
     */

    function _stripUBB($string) 
	{
        $string = eregi_replace("\[b\]", '', $string);
        $string = eregi_replace("\[/b\]", '', $string);
        $string = eregi_replace("\[i\]", '', $string);
        $string = eregi_replace("\[/i\]", '', $string);
        $string = eregi_replace("\[u\]", '', $string);
        $string = eregi_replace("\[/u\]", '', $string);
        $string = eregi_replace("\[p\]", '', $string);
        $string = eregi_replace("\[/p\]", '', $string);
        $string = eregi_replace("\[code\]", '', $string);
        $string = eregi_replace("\[/code\]", '', $string);
        $string = eregi_replace("\[quote\]", '', $string);
        $string = eregi_replace("\[/quote\]", '', $string);
        $string = preg_replace ("/\[url(\S*?)\]/si", '', $string);
        $string = eregi_replace("\[/url\]", '', $string);
        $string = eregi_replace("\[email\]", '', $string);
        $string = eregi_replace("\[/email\]", '', $string);
        $string = eregi_replace("\[img\]", '', $string);
        $string = eregi_replace("\[/img\]", '', $string);
        return $string;
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    ///// TEMPLATE FUNCTIONS:
    ///// Open and parse _template files.
    //////////////////////////////////////////////////////////////////////////////////////////

    function _template($name, $num=1) 
	{
        $tname = "tpl_$name";
        if(isset($this->$tname)) {
            $tpl = $this->$tname;
        } else {
            $fd = fopen($this->tpl_dir.$name.'.tpl', 'r');
            $tpl = fread($fd, filesize($this->tpl_dir.$name.'.tpl'));
            fclose($fd);
            $this->$tname = $tpl;
        }
        $n=0;
        while(++$n<$num) $tpl.=$tpl;
        return $tpl;
    }

    function _replace($tpl, $ary) 
	{
        while(list($key, $val) = each($ary)) {
            if(!isset($val)) $val='';
            $rep = '{'.strtoupper($key).'}';
            $tpl = str_replace($rep, $val, $tpl);
        }
        return $tpl;
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    ///// TRANSLATION FUNCTIONS:
    ///// Handle string translation.
    //////////////////////////////////////////////////////////////////////////////////////////

    function _trans($str) 
	{
		static $_trans;
		static $trans_keys;

        if(!$this->lang_file) {
            return $str; // if there is no lang file specified, return eng string
        }
        if(!isset($_trans)) {
            include_once $this->lang_dir.$this->lang_file;
        }
        if(!isset($trans_keys)) {
            $trans_keys = array_keys($_trans);
        }
        if(in_array($str, $trans_keys)) {
            return $_trans[$str];
        } else {
            return $str;
        }
    }
}

?>
