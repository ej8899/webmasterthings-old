<?php

/*************************************************************************\
 
  iniread - php ini file generator
  Copyright (C) 2001 - Paul Gareau
 
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 
\*************************************************************************/

// edit these values
//////////////////////

$app_name = 'discussion administration';
$ary_file_name[] = '../discussion.inc.php';
//$ary_file_name[] = 'another file...';

// ill take it from here
//////////////////////////

$num_files = count($ary_file_name);

if($num_files==1 && ! $file_name)
	header("Location: $PHP_SELF?file_name=$ary_file_name[0]");

// save variables to file
////////////////////////////

if($form_submit) {
	$fp = @fopen($file_name, 'w')
	      or die("Could not open <b>$file_name</b> for writing!");

	fwrite($fp, "<?php\n\n");

	if($other)
		fwrite($fp, stripslashes($other)."\n");

	$num_vars = count($var_name);

	for($line=0; $line<$num_vars; $line++) {
		fwrite($fp, $var_name[$line]."\t= ");

		$var_val[$line] = ereg_replace("\r\n", " ", $var_val[$line]);

		// if variable value is not numeric and it isnt quoted or if its an empty string
		// put quotes around it, otherwise just write string to file
		if(!is_numeric($var_val[$line]) && !ereg("^[\'\"].+[\'\"]$", $var_val[$line]) || $var_val[$line]=='')
			fwrite($fp, "\"".stripslashes($var_val[$line])."\";");
		else
			fwrite($fp, stripslashes($var_val[$line]).";");

		if($var_cmt[$line])
			fwrite($fp, "\t// ".str_replace(";", ",", stripslashes($var_cmt[$line])));

		fwrite($fp, "\n");
	}
	fwrite($fp, "\n?>");
	fclose($fp);
	$msg = "Config file <b>$file_name</b> written!\n";
}

// print form page
////////////////////

echo "<html>\n";
echo "<head><title>$app_name</title></head>\n";
echo "<style>\n";
echo "h1    {font-family: verdana; font-size: 20pt}\n";
echo "h3    {font-family: verdana; font-size: 13pt}\n";
echo "th    {font-family: verdana; font-size: 10pt; font-weight: bold}\n";
echo "td    {font-family: tahoma; font-size: 10pt}\n";
echo "body  {font-family: tahoma}\n";
echo "input {font-family: 'lucida console', courier; font-size: 10pt}\n";
echo "</style>\n";
echo "<body><h1>$app_name</h1>\n";
echo $msg;

if($file_name) {

	// read variables + data into arrays
	///////////////////////////////////////

	$ary_file = file($file_name);
	$num_lines = count($ary_file);
	$var_line = 0;

	for($file_line=0; $file_line<$num_lines; $file_line++) {
		$line_content = $ary_file[$file_line];

		if(ereg('^[\$#].+;', $line_content)) {
			$eq_pos = strpos($line_content, '=');
			$sc_pos = strrpos($line_content, ';');
			$cmt_pos = strpos($line_content, '//', $sc_pos);
			$ary_parsed[$var_line][0] = trim(substr($line_content, 0, $eq_pos));
			$ary_parsed[$var_line][1] = trim(substr($line_content, $eq_pos+1, $sc_pos-$eq_pos-1));

			if($cmt_pos)
				$ary_parsed[$var_line][2] = trim(substr($line_content, $cmt_pos+2, strlen($line_content)-$cmt_pos));

			$var_line++;
		}
		elseif(ereg("[^(\n|<\?php|\?>)]", $line_content))
			$ary_other[] = $line_content;
	}

	// print edit form
	/////////////////////

	$num_vars = count($ary_parsed);
	$num_xtra = count($ary_other);

	echo "<form action='$PHP_SELF' method='POST'>\n";
	echo "<input type='hidden' name='file_name' value='$file_name'>\n";
	echo "<table border=0 cellpadding=2 cellspacing=1>\n";


	for($row=0; $row<$num_vars; $row++) {
		$var_orig = $ary_parsed[$row][0];
		$var_name = $ary_parsed[$row][0];
		$var_name = str_replace("_", " ", ucfirst(str_replace("\$", "", $ary_parsed[$row][0])));
		$var_val  = $ary_parsed[$row][1];
		$var_cmt  = $ary_parsed[$row][2];
		$bgcolor  = ($row % 2) ? '#EEEEEE' : '#DDDDDD';

		if($var_orig=='#iniread_spacer') {
			$var_show = ereg_replace("^[\"\'](.+)[\"\']", '\\1', $var_val);
			$var_val  = ereg_replace("^[\"\'](.+)[\"\']", '\\1', $var_val);
			echo "<input type='hidden' name='var_name[]' value='$var_orig'>\n";
			echo "<input type='hidden' name='var_val[]' value='$var_val'>\n";
			echo "<input type='hidden' name='var_cmt[]' value=''>\n"; //need to hold this space!
			echo "<tr bgcolor='#CCCCCC'><td colspan=3><h3>&nbsp;&nbsp;$var_show</h3></td></tr>\n";
			$after_spacer=1;
			$has_spacer=1;
		} elseif($var_orig=='#iniread_comment') {
			$var_show = ereg_replace("^[\"\'](.+)[\"\']", '\\1', $var_val);
			$var_val  = ereg_replace("^[\"\'](.+)[\"\']", '\\1', $var_val);
			echo "<tr bgcolor='#CCCCCC'>\n";
			echo "<td colspan=3>&nbsp;<b>&#187;</b>&nbsp;$var_show\n";
			echo "<input type='hidden' name='var_name[]' value='$var_orig'>\n";
			echo "<input type='hidden' name='var_val[]' value='$var_val'>\n";
			echo "<input type='hidden' name='var_cmt[]' value=''>\n"; //need to hold this space!
			echo "</td>\n";
			echo "</tr>\n";
		} else {
			if($after_spacer || !$has_spacer) {
				echo "<tr bgcolor='#BBCCDD'>\n";
				echo "<th><b>Variable</b></th>\n";
				echo "<th><b>Value</b></th>\n";
				echo "<th><b>Comment</b></th>\n";
				echo "</tr>\n";
				$after_spacer=0;
				$has_spacer=1;
			}
			echo "<tr bgcolor='$bgcolor'>\n";
			echo "<td valign='top'>&nbsp;$var_name<input type='hidden' name='var_name[]' value='$var_orig'></td>\n";
			echo "<td valign='top'>";

			if(is_numeric($var_val)) {
				echo "<input type='text' size=30 name='var_val[]' value='$var_val'>";
			} else {
				$rows = (strlen($var_val)>30) ? 4 : 1;
				echo "<textarea rows=$rows cols=30 name='var_val[]' wrap='virtual'>$var_val</textarea>";
			}
			echo "</td>\n";
			echo "<td valign='top'><input type='text' size=45 name='var_cmt[]' value='$var_cmt'>&nbsp;&nbsp;</td>\n";
			echo "</tr>\n";
		}
	}

	// print non variables in a text area
	////////////////////////////////////////

	echo "<tr bgcolor='#CCCCCC'><td colspan=3><h3>Non variables</h3></td></tr>\n";
	echo "<tr bgcolor='#DDDDDD'><td colspan=3>\n";
	echo "<textarea rows=5 cols=80 name='other'  style='width: 100%' wrap='virtual'>";

	for($row=0; $row<$num_xtra; $row++)
		echo $ary_other[$row];

	echo "</textarea></td>\n";
	echo "</tr>\n";

	echo "<tr bgcolor='#CCCCCC' colspan=3>\n";
	echo "<td colspan=3>\n";
	echo "<input type='submit' name='form_submit' value='   Save   '>\n";
	echo "<input type='reset' value='  Reset  '>\n";
	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";
	echo "</form>\n";
}

// print drop down file list
///////////////////////////////

echo "<form action='$PHP_SELF' method='POST'>\n<select name='file_name'>\n";

for($file=0; $file<$num_files; $file++)
	echo "<option value='$ary_file_name[$file]'>$ary_file_name[$file]\n";

echo "</select>\n";
echo "<input type='submit' value='Open'>\n";
echo "</form>\n";
echo "<br>\n";
echo "</body>\n";
echo "</html>\n";

?>