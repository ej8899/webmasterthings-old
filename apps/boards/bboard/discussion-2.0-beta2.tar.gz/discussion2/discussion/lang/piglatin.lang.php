<?

$trans = array();

$trans['Re:'] 
	= 'Eray:';
$trans['Post not found!'] 
	= 'Ostpay otnay oundfay!';
$trans['Reply to this message'] 
	= 'Eplyray otay isthay essagemay';
$trans['New Topic'] 
	= 'Ewnay Opictay';
$trans['You will recieve replies to this post by email.'] 
	= 'Ouyay illway ecieveray epliesray otay isthay ostpay ybay emailway.';
$trans['UBB code is enabled in this forum.'] 
	= 'UBBWAY odecay isway enabledway inway isthay orumfay.';
$trans['Your post may not appear immediately.'] 
	= 'Ouryay ostpay aymay otnay appearway immediatelyway.';
$trans['You must enter a subject!'] 
	= 'Ouyay ustmay enterway away ubjectsay!';
$trans['Anonymous'] 
	= 'Anonymousway';
$trans['No Text'] 
	= 'Onay Exttay';
$trans['Duplicate posts are not allowed!'] 
	= 'Uplicateday ostspay areway otnay allowedway!';
$trans['says'] 
	= 'ayssay';
$trans['Reply to this message'] 
	= 'Eplyray otay isthay essagemay';
$trans['Could not add post!'] 
	= 'Ouldcay otnay ddaay ostpay!';
$trans['Could not delete post!'] 
	= 'Ouldcay otnay eleteday ostpay!';

?>