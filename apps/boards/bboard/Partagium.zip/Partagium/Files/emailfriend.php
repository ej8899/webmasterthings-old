<?php
/*
	XMB 1.8 Partagium
	� 2001 - 2003 Aventure Media & The XMB Developement Team
	http://www.aventure-media.co.uk
	http://www.xmbforum.com

	For license information, please read the license file which came with this edition of XMB
*/

require "./header.php";

$query = $db->query("SELECT * FROM $table_threads WHERE tid='$tid'") or die($db->error());
$thread = $db->fetch_array($query);
$thread[subject] = stripslashes($thread[subject]);
$fid = $thread[fid];

$query = $db->query("SELECT name, type, fup, fid FROM $table_forums WHERE fid='$fid'") or die($db->error());
$forum = $db->fetch_array($query);

if($catsonly == "on" && $forum[type] == "sub") {
	$query = $db->query("SELECT fup FROM $table_forums WHERE fid='$forum[fup]'") or die($db->error());
	$forum1 = $db->fetch_array($query);
	$query = $db->query("SELECT fid, name FROM $table_forums WHERE fid='$forum1[fup]'") or die($db->error());
	$cat = $db->fetch_array($query);
} elseif($catsonly == "on" && $forum[type] == "forum") {
	$query = $db->query("SELECT fid, name FROM $table_forums WHERE fid='$forum[fup]'") or die($db->error());
	$cat = $db->fetch_array($query);
}

if($catsonly == "on") {
	$navigation = "<a href=\"index.php\">$lang[textindex]</a> &raquo; <a href=\"index.php?gid=$cat[fid]\">$cat[name]</a> &raquo; ";
} else {
	$navigation = "<a href=\"index.php\">$lang[textindex]</a> &raquo; ";
}

if($forum[type] == "forum") {
	$navigation .= "<a href=\"forumdisplay.php?fid=$fid\"> $forum[name]</a> &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> &raquo; $lang_textsendtofriend";
} else {
	$query = $db->query("SELECT name, fid FROM $table_forums WHERE fid='$forum[fup]'") or die($db->error());
	$fup = $db->fetch_array($query);
	$navigation .= "<a href=\"forumdisplay.php?fid=$fup[fid]\">$fup[name]</a> &raquo; <a href=\"forumdisplay.php?fid=$fid\"> $forum[name]</a> &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> &raquo; $lang_textsendtofriend";
}
eval("\$header = \"".template("header")."\";");
echo $header;


if(!$sendsubmit) {
	$threadurl = $boardurl;
	$threadurl .= "viewthread.php?tid=$tid";

	if(!$xmbuser) {
		$query = $db->query("SELECT * FROM $table_members WHERE username='$xmbuser'");
		$username = $db->fetch_array($query);
		$email = $username[email];
	}
	eval("\$form = \"".template("emailfriend")."\";");
	$form = stripslashes($form);
	echo $form;
}else{
	if(trim($message) == '') {
		$message = "$lang_frienddefmsg:\n\n$threadurl";
	}
	if(trim($subject) == '') {
		$subject = $thread[subject];
	}
	if(!$fromname) {
		echo "<center><span class=\"12px \">$lang_friendnonamemsg</span></center>";
		exit();
	}
	if(!$fromemail) {
		echo "<center><span class=\"12px \">$lang_friendnoemailmsg</span></center>";
		exit();
	}
	if(!$sendtoname) {
		echo "<center><span class=\"12px \">$lang_friendnotonamemsg</span></center>";
		exit();
	}
	if(!$sendtoemail) {
		echo "<center><span class=\"12px \">$lang_friendnotoemailmsg</span></center>";
		exit();
	}
	mail("$sendtoemail", "$subject", "$message", "From:$fromname <$fromemail>");
	echo "<center><span class=\"12px \">$lang_friendsentmsg</span></center>";
	?>
	<script>
	function redirect()
	{
	window.location.replace("viewthread.php?tid=<?=$tid?>");
	}
	setTimeout("redirect();", 1250);
	</script>
	<?
}

end_time();

eval("\$footer = \"".template("footer")."\";");
echo $footer;
?>