Original File Created By Punker, Modified For XMB 1.8

NOTE:	The first post of each thread will not have an IP address
	assigned to it as this was not stored in the old database
	layout.


                   Upgrade for 1.11d --> 1.8 Final Edition ONE

1. Edit variables at the top of upgrade.php to match the
   settings of your config for 1.11.

2. Upload the specific upgrade.php and the templates.xmb file
    from the 1.8 zipto your xmb directory.

3. Backup your database!!!

4. Run upgrade.php. If you get any kind of sql error 
   reinstall the database because it did not work for some
   reason.

5. If it is error free upload the rest of the 1.8 files and
   delete the upgrade.php file and you do NOT need to 
   run the install file. Delete that file as well. Make sure 
   you have changed your settings in the config file to match
   your old settings.

6. You may have to logout of your board and log back in to get
   U2U messages displaying correctly. Alterations maybe be made
   to the forum settings as well.

            Post any problems you have on the XMB Board.
                        Thank-you ~PuNkEr~
	