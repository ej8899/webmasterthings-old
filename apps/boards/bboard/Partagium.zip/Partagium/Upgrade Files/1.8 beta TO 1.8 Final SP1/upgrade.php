<?php
/*
	XMB 1.8 beta -> XMB 1.8 Final
	Type: Upgrade
	Author: Tularis
	Comments: badly coded, but is not a stressed page, so it will work anyway...
*/

require "./header.php";
$thisbuild = '2003020219';

if(!($versionbuild && $versionbuild != '')){
	$buildtxt = 'Build could not automatically be defined, please change it manually.';
}elseif($versionbuild == $thisbuild){
	$buildtxt = 'Your version appears to be up to date, this info might be false though. If you do know it is not up-to-date, please update.';
}else{
	$versionbuild = str_replace('#', '', $versionbuild);
	$buildtxt = 'Your build appears to be: <b>'.$versionbuild.'</b>, this could be wrong though.';
	${'selected'.$versionbuild} = 'SELECTED';
}


/** START DEFINITION OF FUNCTIONS **/
if(!function_exists(checkInput)){
	function checkInput($input, $striptags='no', $allowhtml='no', $word=''){
		// Function generously donated by FiXato
	
		$input = trim($input);
		if($striptags != 'no'){
			$input = strip_tags($input);
		}
		
		if($allowhtml != 'yes' && $allowhtml != 'on'){
			$input = htmlspecialchars($input, ENT_QUOTES);
		}
		if($word != "")	{
			$input = str_replace($word, "_".$word, $input);
		}
		
		return $input;
	}
}
if(!function_exists(checkOutput)){
	function checkOutput($output, $allowhtml='no', $word=''){
		$output = trim($output);
		if($allowhtml == 'yes' || $allowhtml == 'on'){
			$output = htmlspecialchars_decode($output);
		}
		if($word != "")	{
			$output = str_replace($word, "_".$word, $output);
		}
		
		return $output;
	}
}
if(!function_exists(htmlspecialchars_decode)){
	function htmlspecialchars_decode($string){
		$array = array_flip(get_html_translation_table(HTML_SPECIALCHARS));
		return strtr($string, $array);
	}
}
if(!function_exists(htmlentities_decode)){
	function htmlentities_decode($string){
		$array = array_flip(get_html_translation_table(HTML_ENTITIES));
		return strtr($string, $array);
	}
}
/** END DEFINITION OF FUNCTIONS **/

/** START TEXT TO BE SHOWED WHEN NOT UPGRADING YET **/
?>

<html>
<head>
<title>XMB 1.8 Beta -> Final Upgrade</title>
</head>
<body text="#FFFFFF" bgcolor="#8896A7" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF">

<?php
if(!$_GET['do'] || $_GET['do'] != 'update'){
	?>
	<form action=./upgrade.php?do=update method=POST>
	XMB will now update your current 1.8 database.<br />
	If you are not running version 1.8 yet, PLEASE USE A DIFFERENT upgrade!!!<br />
	This one has a high chance of failing it's purpose in that case....<br />
	<br />
	Choose the version to upgrade from, here:<br />
	<select name="build">
	<option value="">--none--</option>	
	<option value="200301120" <?=$selected200301120 ?>>Build 200301120</option>
	<option value="2002122814" <?=$selected2002122814 ?>>Build 2002122814</option>	
	<option value="2002122422" <?=$selected2002122422 ?>>Build 2002122422</option>
	<option value="2002122112" <?=$selected2002122112 ?>>Build 2002122112</option>
	<option value="14120211PM" <?=$selected14120211PM ?>>Build 14120211PM</option>
	<option value="07120210PM" <?=$selected07120210PM ?>>Build 07120210PM</option>
	<option value="2120211PM" <?=$selected2120211PM ?>>Build 2120211PM</option>
	<option value="20110207PM" <?=$selected20110207PM ?>>Build 20110207PM</option>
	<option value="17110208PM" <?=$selected17110208PM ?>>Build 17110208PM</option>
	<option value="17110202PM" <?=$selected17110202PM ?>>Build 17110202PM</option>
	<option value="16110211PM" <?=$selected16110211PM ?>>Build 16110211PM</option>
	<option value="16110200AM" <?=$selected16110200AM ?>>Build 16110200AM</option>
	<option value="15110204PM" <?=$selected15110204PM ?>>Build 15110204PM</option>
	<option value="14110210PM" <?=$selected14110210PM ?>>Build 14110210PM</option>
	<option value="before">-- older --</option>
	</select> - <?=$buildtxt?>
	<br /><br />
	<input type=radio name=restore value=yes CHECKED/> &raquo; I <b>want</b> upgrade to restore templates to those in the templates.xmb file<br />
	<input type=radio name=restore value=no /> &raquo; I <b>don't want</b> upgrade to restore templates to those in the templates.xmb file<br />
	<br />
	<input type=submit value=Upgrade...!>
	</form>
	
	<?php
/** END TEXT TO BE SHOWED WHEN NOT UPGRADING YET **/
/** START TEXT TO BE SHOWED WHEN UPGRADING **/
}else{
	switch($_POST['build']){
		case 'before':
			$db->query("ALTER TABLE $table_settings ADD `addtime` INT(3) DEFAULT '0' NOT NULL");
			$db->query("ALTER TABLE $table_members ADD `pwdate` BIGINT(30) DEFAULT '0' NOT NULL");
		
		case '14110210PM':
			echo 'Upgraded to 14110210PM';
		case '15110204PM':
			echo 'Upgraded to 15110204PM';
		case '16110200AM':
			echo 'Upgraded to 16110200AM';
		case '16110211PM':
			echo 'Upgraded to 16110211PM';
		case '17110202PM':
			echo 'Upgraded to 17110202PM';
		case '17110208PM':
			echo 'Upgraded to 17110208PM';
		case '20110207PM':
			echo 'Upgraded to 20110207PM';
		case '2120211PM':
			$query = $db->query("SELECT uid, sig FROM $table_members");
			while($member = $db->fetch_array($query)){
				$sig = stripslashes($member[sig]);
				$sig = checkOutput($sig, 'yes');
				$sig = str_replace('&amp;', '&', $sig);
				$sig = checkInput($sig, 'no', 'no');
				$sig = addslashes($sig);
				$db->query("UPDATE $table_members SET sig = '$sig' WHERE uid='$member[uid]'");
			}
						
			$query = $db->query("SELECT pid, message FROM $table_posts");
			while($post = $db->fetch_array($query)){
				$msg = stripslashes($post[message]);
				$msg = checkOutput($msg, 'yes');
				$msg = str_replace('&amp;', '&', $msg);
				$msg = checkInput($msg, 'no', 'no');
				$msg = addslashes($msg);
				$db->query("UPDATE $table_posts SET message = '$msg' WHERE pid='$post[pid]'");
			}
			echo "Upgraded to build '2120211PM'<br />";
			
		case '07120210PM':
			echo "Upgraded to build '07120210PM'<br />";
		case '14120211PM':
			echo "Upgraded to build '14120211PM'<br />";
		case '2002122112':
			$db->query("ALTER TABLE `$table_threads` CHANGE `subject` `subject` VARCHAR( 128 ) NOT NULL default ''");
			$db->query("ALTER TABLE `$table_posts` CHANGE `subject` `subject` tinytext NOT NULL");
			echo "Upgraded to build '2002122112'<br />";

		case '2002122422':
			echo "Upgraded to build $thisbuild<br />";
			echo "<b>NOTICE:</b> A few new variables were added in config.php, we advise to reconfigure it..!!";	
		case '2002122814':
			echo "Upgraded to build '2002122814'<br />";
		case '200301120':
			echo "Upgraded to build '200301120'<br />";
		case '2003020219':
			$db->query("ALTER TABLE `$table_attachments` CHANGE `pid` `pid` int(10) NOT NULL");
			echo "Upgraded to build '2003020219 - Final Edition'<br />";
		/***************/
		case 'none':
			break;
		default:
			echo 'No (known) build selected, could not upgrade from there....';
			exit();
			break;
	}



/** END TEXT TO BE SHOWED WHEN UPGRADING **/
/** START CODE TO BE USED WHEN RESTORING TEMPLATES **/

	if($_POST['restore'] == 'yes'){
		if(!file_exists("./templates.xmb")){
			echo '<h3><b>Templates could not be restored, because the templates.xmb file could not be found. Please upload this file, go to your Admin Panel, templates section. Then, press restore.<br />';
		}else{
			$filesize=filesize('templates.xmb');
			$fp=fopen('templates.xmb','r');
			$templatesfile=fread($fp,$filesize);
			fclose($fp);
			$templates = explode("|#*XMB TEMPLATE FILE*#|", $templatesfile);
			while (list($key,$val) = each($templates)) {
				$template = explode("|#*XMB TEMPLATE*#|", $val);
				$template[1] = addslashes($template[1]);
				$db->query("DELETE FROM $table_templates WHERE name = '".addslashes($template[0])."'");
				$db->query("INSERT INTO $table_templates VALUES ('', '".addslashes($template[0])."', '".addslashes($template[1])."')");
			}
			$db->query("DELETE FROM ".$tablepre."templates WHERE name=''");
			
			echo 'Templates restored to those in templates.xmb<br />';
		}
	}
/** END CODE TO BE USED WHEN RESTORING TEMPLATES **/

/** START OPTIMIZING TABLES **/
	$db->query("OPTIMIZE TABLE `$table_attachments` , `$table_banned` , `$table_buddys` , `$table_favorites` , `$table_forums` , `$table_members` , `$table_posts` , `$table_ranks` , `$table_restricted` , `$table_settings` , `$table_smilies` , `$table_templates` , `$table_themes` , `$table_threads` , `$table_u2u` , `$table_whosonline` , `$table_words`");
	echo 'All tables have been optimized<br />';
/** END OPTIMIZING TABLES **/

/** START TEXT TO BE SHOWED WHEN FINISHED UPGRADE **/
echo "Xmb has successfully updated your database.<br /> Please delete this file from your forum root directory before continuing to the index.php page";
echo "<p></p>
	<b>A few Notices:</b><br />
	<i>
";

if($_POST['build'] < 2002122422 || $_POST['build'] == '2120211PM'){
	echo "
	&raquo; The config.php file has changed extensivly in the 2002122422-build. If you upgraded from a build before that one, we advise to reconfigure your config.php using a new one from this distribution.<br />
	";
}

echo	"
	&raquo; If you chose not to restore templates, you might run into in-compatibilities because the templates have changed to reflect certain changes in the code.<br />
	&raquo; In case you can not log in, please check your config.php first. It is usually the place where everything goes wrong.<br />
	&raquo; If you can not seem to log out, delete your cookies, and log back in. This caused by the change in config.php.<br />
	<br />
	If you still have problems, please visit the XMB support Boards at <a href=\"http://www.xmbforum.com/community/boards/\">xmbforum.com</a><br />
	</i>
	";
/** END TEXT TO BE SHOWED WHEN FINISHED UPGRADE **/
}
?>