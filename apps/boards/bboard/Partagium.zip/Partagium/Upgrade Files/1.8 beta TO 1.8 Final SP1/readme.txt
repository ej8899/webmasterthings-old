/****************************************
 *					*
 *	XMB 1.8 beta Upgrade-readme	*
 *					*
 *	Made by: Tularis		*
 *	developer@xmbforum.com		*
 *					*
 ****************************************/
 
 
Use this upgrade only with a valid 1.8-build.
Please, do NOT try to use it on 1.6, or on 1.11. That won't work. We've added different upgrade scripts for those ...!

If you're not sure if you should upgrade anything. Run this upgrade.php script, and follow instructions. It will check if you should, or should not.