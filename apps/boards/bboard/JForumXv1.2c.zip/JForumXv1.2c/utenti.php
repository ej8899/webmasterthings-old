<?php

include 'dati.inc.php';





$invio = mysql_db_query($DATABASE,"select * from utenti WHERE userid = '$user'") or die (mysql_error());



$countmsg = mysql_db_query($DATABASE,"select count(user) from forum where user = '$user'") or die (mysql_error());

 $rslmsg = mysql_result($countmsg,0);



$lastmsg = mysql_db_query($DATABASE,"select data from forum where user = '$user' order by id desc limit 1 ") or die (mysql_error());

$rslast = mysql_result($lastmsg,0);



$invio = mysql_db_query($DATABASE,"select * from utenti WHERE userid = '$user'") or die (mysql_error());





while ( $valore = mysql_fetch_array ($invio))

{

$user = $valore["userid"];

$dataisc = $valore["dataisc"];

$icq = $valore["icq"];

$vemail = $valore["vemail"];

$email = $valore["email"];

    $homepage = $valore["homepage"];



    }

?>

<html>

<head>

<title>Dettaglio utente: <? echo $user ?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" href="forum.css" type="text/css">

</head>



<body bgcolor="#d0e0f0" text="#000000" leftmargin="0" topmargin="0">

<table width="330" border="0" cellspacing="2" cellpadding="0" height="100">

  <tr>

    <td height="197" align="left"> 

      <table width="300" border="0" cellspacing="0" cellpadding="0" align="center" class="box" height="100">

        <tr>

          <td height="155"> 

            <table width="100%" border="0" cellspacing="4" cellpadding="0" height="101">
              <tr> 
                <td height="87" valign="top"> <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000">User 
                  :</font><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
                  <? echo $user ;?>
                  <br>
                  Email: 
                  <? if ($vemail =='ON') echo "<a href=\"mailto:$email\">$email</a>";  else echo "n.d." ;?>
                  <br>
                  <font color="#FF0000">Icq: 
                  <? if ((!$icq=="")) echo $icq  ;  else echo "n.d." ;?>
                  </font><br>
                  Home Page: 
                  <? if ((!$homepage=="") )echo "<a href=\"$homepage\" target=\"_new\">$homepage</a>"  ;  else echo "n.d." ;?>
                  <br>
                  <font color="#FF0000">Registrato il: 
                  <? echo $dataisc  ; ?>
                  </font> </font> </td>
              </tr>
            </table>

           <font face="Verdana, Arial, Helvetica, sans-serif" size="1">Messaggi: 

              <?php echo $rslmsg ; ?>

              <br>

              <font color="#FF0000">Last msg : 

              <? echo $rslast ?>

              </font></font>

      

          </td>

        </tr>

      </table>

      <br>

      <br>

      <br>

      <br>

    </td>

  </tr>

</table>

</body>

</html>

