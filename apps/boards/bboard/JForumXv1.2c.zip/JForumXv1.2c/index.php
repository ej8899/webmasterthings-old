<?php

session_start();

include 'dati.inc.php' ;

############################## JASX FORUM #####################################

#                                                                             #

#  Creato da Jasx (jasx@inwind.it) nel Dicembre del 2001.                     #

#                                                                             #

#  Lo script � puo essere utilizzato e modificato in ogni sua parte sia per   #

#  uso personale che per uso commerciale ma senza eliminare la firma presente #

#  in index.php (licenza GPL) (JASX FORUM by Antonio Calabrese)               #

#                                                                             #

#  Il progetto � ancora in fase di testing         					          #

#  Per segnalazioni su bug , commenti e opinioni jasx@inwind.it               #

#  Le istruzioni d'uso sono presenti nel file readme.txt                      #                                                 #

###############################################################################





if(isset($Submit))

{





$invio = mysql_db_query($DATABASE,"select userid from utenti where userid='$userlog' AND password = '$passlog' ") or die (mysql_error());

$rst = mysql_num_rows($invio) ;


if ($rst == 1)

{



session_register('userlog',$userlog) ;

session_register('passlog',$passlog) ;



}

else

{

    //SE AUTENTICAZIONE FALLISCE

    $aut = "NO"   ;

     $userlog = "";

     $passlog = "";

}



}



IF (ISSET($userlog) ){

    $benmsg = "<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\"> Utente : <font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\" color=\"red\">$userlog</font></font>"   ;
$benmsg2 =  " <a href=\"logout.php\">Logout </a><br>";
}



mysql_select_db($DATABASE,$link) or die (mysql_error());



//TOTALE MESSAGGI POSTATI

$invio4 = mysql_query("select count(*) from forum ")  ;



@$resultot = mysql_result($invio4,0) ;

 //TOTALE TOPIC INSERITI

 $invio5 = mysql_query("select count(*) from forum WHERE id_msg = '0'")or die (mysql_error()) ;

 @$resulmsg = mysql_result($invio5,0) ;



 //ULTIMO UTENTE REGISTRATO

 @$queryuser  = mysql_db_query ($DATABASE,"select userid from utenti order by id desc") or die (mysql_error());




@$rsluser = mysql_result($queryuser,0) or die (mysql_error());



?>





<html>

<head>

<title>JForumX by Antonio Calabrese</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">

function controllo ()

{

if(document.form1.userlog.value =="")

{

alert('Il campo user non pu� essere vuoto');

document.form1.userlog.focus();

return false;

}



}





<?php if

($aut == NO)

{

ECHO " alert('Autenticazione fallita!!') ";

}



 ?>





<!--

function MM_reloadPage(init) {  //reloads the window if Nav4 resized

  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {

    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}

  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();

}

MM_reloadPage(true);

// -->

</script>

<link rel="stylesheet" href="forum.css" type="text/css">

</head>



<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" link="#000000" vlink="#000000" alink="#000000">

<div align="left"></div>

<div align="center"> </div>

<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">

  <tr> 

    <td width="48%" valign="top" height="95"><img src="img/logo.gif"></td>

    <td width="52%" valign="baseline" height="95"> 

      <div align="center">

        <table width="76%" border="0" cellspacing="0" cellpadding="0">

          <tr> 

            <td width="58%"> 

              <p>&nbsp;</p>

              <form name="form1" method="post" OnSubmit="return controllo()" action="">

                <table width="83%" border="0" cellspacing="0" cellpadding="0">

                  <tr> 

                    <td width="33%" height="34"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">User</font></td>

                    <td width="42%" height="34"> 

                      <input type="text" name="userlog" size="8" class="box"  value="<? echo $userlog ?>">

                    </td>

                  </tr>

                  <tr> 

                    <td width="33%" height="29"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Password</font></td>

                    <td width="42%" height="29"> 

                      <input type="password" name="passlog" size="8" class="box" value="<? echo $passlog ?>">

                    </td>

                  </tr>

                  <tr> 

                    <td width="33%">&nbsp;</td>

                    <td width="42%">

                      <input type="submit" name="Submit" value="login" class="box">

                    </td>

                  </tr>

                </table>

              </form>

            </td>

            <td width="21%"> 

              <div align="center"><a href="iscrizione.php"><img src="img/iscriviti.gif" width="64" height="64" border="0"></a><br>

                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">[ 

                <a href="iscrizione.php">Iscriviti</a> ]</font> </div>

            </td>

            <td width="21%"><a href="cerca.php"><img src="img/cerca.gif" width="64" height="64" border="0"></a><br>

              <font size="2" face="Verdana, Arial, Helvetica, sans-serif">[ <a href="cerca.php">Cerca</a> 

              ]</font></td>

          </tr>

        </table>

      </div>

    </td>

  </tr>

  <tr valign="top"> 

    <td colspan="2"> 

      <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>

        </font><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 

        </font></p>

      <table width="98%" border="0" cellspacing="0" cellpadding="0" align="center">

        <tr>

          <td> <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000">Oggi 

            : 

            <? echo date('d-M-Y h:m'); ?>

            </font><br>

            <font face="Verdana, Arial, Helvetica, sans-serif" size="1">Topic 

            inseriti:<font color="#FF0000"> 

            <? echo $resulmsg ?>

            </font>| Messaggi Totali:<font color="#FF0000"> 

            <? echo $resultot ?>

            </font></font><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
            Ultimo utente registrato</font><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><font color="#FF0000"> 
            <? echo $rsluser ?>
            </font></font><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
            <?php echo $benmsg.$benmsg2; ?>
          
            </font></td>

        </tr>

      </table>

      <br>

      <div align="center"> 

        <table width="98%" border="0" cellspacing="1" cellpadding="4" align="center">
          <tr> 
            <td width="39%" bgcolor="#000000"><font face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF" size="2">Forum</font></td>
            <td width="9%" bgcolor="#000000"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Messaggi</font></td>
            <td width="7%" bgcolor="#000000"> 
              <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Topic</font></div>
            </td>
            <td width="25%" bgcolor="#000000"> 
              <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Ultimo 
                messsaggio </font></div>
            </td>
            <td width="17%" bgcolor="#000000"> 
              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Moderatore</font></div>
            </td>
          </tr>
          <?php

 



  $query = mysql_db_query($DATABASE,"select * from forumarg") or die (mysql_error());
while (  $valore = mysql_fetch_array($query))

  {



  $id = $valore["id"];

  $icona = $valore["icona"];

  $nome = $valore["nome"];

  $descrizione = $valore["descrizione"];

  $moderatore = $valore["moderatore"];



//CALCOLO DEI MESSAGGI TOTALI PER OGNI ARGOMENTO



$invio = mysql_query("select count(argomento) from forum where argomento = '$nome' ") or die (mysql_error());

$resultmsg = mysql_result($invio,0);

//CALCOLO DEI TOPIC TOTALI PER OGNI ARGOMENTO

$invio = mysql_query("select count(argomento) from forum where argomento = '$nome' and id_msg = '0' ") or die (mysql_error());



$resultopic = mysql_result($invio,0);

 

@$invio = mysql_query("select data , user from forum WHERE argomento = '$nome' order by id desc" ) or die (mysql_error());

@$resultdata = mysql_result($invio,0) ;

@$resultuser = mysql_result($invio,0,1) ;



?>
          <tr bgcolor="#4AAEFF" valign="top"> 
            <td width="39%"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="<?echo "veditopic.php?argomento=$nome"; ?>"> 
              <font color="#000000"> <b> 
              <?php echo $nome ?>
              </b> </font></a><br>
              <?php echo $descrizione ; ?>
              <br>
              </font></td>
            <td width="9%"> 
              <div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                <? echo $resultmsg ;?>
                </font></div>
            </td>
            <td width="7%"> 
              <div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                <? echo $resultopic ?>
                </font></div>
            </td>
            <td width="25%"> 
              <div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><b> 
                <? echo $resultdata ?>
                </b><br>
                <font color="#FF0000">
                <? if($resultdata == "") echo "non presenti" ; else  echo "by" ; ?>
                </font> 
                <? echo $resultuser ?>
                </font></div>
            </td>
            <td width="17%"> 
              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 



                                  <? echo $moderatore ?>
                </font></div>
            </td>
          </tr>
          <?php

 }



 



 

?>
        </table>

        <p> <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><br>
          <a href="http://www.jasxscript.cjb.net" target="_blank">JasxForum v1.2b 
          tested</a><br>
          Powered by Antonio Calabrese<br>
          <a href="mailto:jasx@inwind.it">jasx@inwind.it</a><br>
          <br>
          </font><a href="../index.php">Torna a JasxScript<br>
          </a><br>
          <a href="moderazione/index.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Pannello 
          moderatori</font></a></p>

      </div>

      <p>&nbsp;</p>

      <p>&nbsp;</p>

    </td>

  </tr>

</table>

<p align="center">&nbsp;</p>

<p align="center">&nbsp;</p>

</body>

</html>

