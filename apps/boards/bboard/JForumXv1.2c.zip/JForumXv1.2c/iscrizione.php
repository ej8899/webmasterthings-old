<?php



 if (isset($Submit))

 {
//CONTROLLO SE UTENTE GIA ESISTE
include 'dati.inc.php';

$userlower = strtolower($username);

$controllo = mysql_db_query($DATABASE,"select count(userid) from utenti where userid = '$userlower' AND password = '$password'") or die .mysql_error();



$gol = mysql_result($controllo,0) ;

$data = date('d-M-Y');



//SE CONTROLLO DIVERSO DA 1 REGISTRA UTENTE
if ($gol!=1)

{
$insert = mysql_db_query($DATABASE,"INSERT INTO utenti values

('',

'$username',

'$password',

'',

'$email',

'$vemail',

'$icq',

'$homepage',

'$firma',

'$data')") or die (mysql_error());





//$msg = "REGISTAZIONE AVVENUTA CON SUCCESSO" ;
$reg = "ok" ;


}

else

$msg = "UTENTE GIA ESISTENTE CAMBIA USERNAME E RIPROVA" ;



  }





?>



<html>

<head>

<title>Iscriviti per partecipare la nostro forum </title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script Language="javascript">

 <?php if

($reg == ok)

{

echo " alert('Registrazione riuscita'); ";


}


?>

function controllo() 

{

if (document.form.username.value=="")

{



alert ('Inserire un nome utente valido');

document.form.username.focus();

return false ;

}



if (document.form.password.value=="")

{

alert ('Inserire una password valida');

document.form.password.focus();

return false ;

}



if (document.form.password.value != document.form.repassword.value )

{

alert ('Password e Retype password sono diversi');

document.form.password.focus();

return false ;

}



if ((document.form.email.value=="") || (document.form.email.length < 7 ) || (document.form.email.value.indexOf("@") == -1 ))

{

alert ('Inserire un indirizzo email valido');

document.form.email.focus();

return false ;

}



}




</script>


    <?php  if
($reg == ok)

{

echo "  <meta http-equiv=\"refresh\" content=\"0;URL=index.php\"> ";

}

?>

<link rel="stylesheet" href="forum.css" type="text/css">

</head>



<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">

<div align="center">

  <table width="100%" border="0" cellspacing="0" cellpadding="0">

    <tr> 

      <td><img src="img/logo.gif"></td>

    </tr>

    <tr> 

      <td> 

        <form name="form" method="post" OnSubmit="return controllo()" action="<? $PHP_SELF ?>">

          <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000" size="2"><b> 

            <? echo $msg ?>

            </b></font><br>

            <br>

          </div>

          <div align="center"></div>

          <table cellspacing=0 cellpadding=0 width="85%" align=center border=0 height="78">

            <tbody> 

            <tr> 

              <td bgcolor=#000000 height="356"> 

                <table cellspacing=1 cellpadding=6 width="100%" border=0>

                  <tbody> 

                  <tr> 

                    <td class=header colspan=3><font size="2" color="#FFFFFF">Registrati 

                      per partecipare al nosto forum</font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow width="21%" bgcolor=#4AAEFF><font size="2">Username:</font></td>

                    <td class=tablerow bgcolor=#d0e0f0 colspan="2"> <font face="Verdana, Arial, Helvetica, sans-serif"> 

                      <input maxlength=25 size=25 

            name=username class="box">

                      </font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow bgcolor=#4AAEFF width="21%"><font size="2">Password:</font></td>

                    <td bgcolor=#DCE2F8 colspan="2"><font face="Verdana, Arial, Helvetica, sans-serif"> 

                      <input type=password size=25 

            name=password class="box">

                      </font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow bgcolor=#4AAEFF width="21%" height="42"><font size="2">Retype 

                      Password:</font></td>

                    <td class=tablerow bgcolor=#d0e0f0 colspan="2" height="42"> 

                      <font face="Verdana, Arial, Helvetica, sans-serif"> 

                      <input type=password size=25 

            name=repassword class="box">

                      </font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow bgcolor=#4AAEFF width="21%"><font size="2">E-Mail:</font></td>

                    <td class=tablerow bgcolor=#d0e0f0 width="26%"> <font face="Verdana, Arial, Helvetica, sans-serif"> 

                      <input size=25 name=email class="box">

                      </font></td>

                    <td class=tablerow bgcolor=#d0e0f0 width="53%"> 

                      <input type="checkbox" name="vemail" value="ON">

                      <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Mostra 

                      agli utenti il tuo indirizzo email</font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow bgcolor=#4AAEFF width="21%"><font size="2">Home 

                      Page http://</font></td>

                    <td class=tablerow bgcolor=#d0e0f0 colspan="2"><font face="Verdana, Arial, Helvetica, sans-serif">

                      <input size=25 name=homepage class="box">

                      </font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow bgcolor=#4AAEFF width="21%"><font size="2">ICQ 

                      Number:</font></td>

                    <td class=tablerow bgcolor=#d0e0f0 colspan="2"> <font face="Verdana, Arial, Helvetica, sans-serif"> 

                      <input size=25 name=icq class="box">

                      </font></td>

                  </tr>

                  <tr> 

                    <td class=tablerow bgcolor=#4AAEFF valign="top" height="130" width="21%"><font size="2">Firma 

                      :</font></td>

                    <td class=tablerow bgcolor=#d0e0f0 valign="top" height="130" colspan="2"> 

                      <font face="Verdana, Arial, Helvetica, sans-serif"> 

                      <textarea cols="35" name="firma" rows="8" class="box"></textarea>

                      </font></td>

                  </tr>

                  </tbody> 

                </table>

              </td>

            </tr>

            </tbody> 

          </table>

          <div align="center"><br>

            <input type="submit" name="Submit" value="Invia modulo per la registrazione">

            <br>

            <br>

            [

            <a href="index.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">

            Torna indice Argomenti</font></a> ]</div>

          <p>&nbsp;</p>

          <p>&nbsp;</p>

        </form>

      </td>

    </tr>

    <tr>

      <td>&nbsp;</td>

    </tr>

  </table>

</div>



  <div align="center"></div>

  <p></p>

  <div align="center"> <br>

  </div>

  <p>&nbsp;</p>



<p>&nbsp;</p>

<p>&nbsp;</p>

</body>

</html>

