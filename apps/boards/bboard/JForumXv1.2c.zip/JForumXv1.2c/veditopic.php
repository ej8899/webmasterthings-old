<?php

session_start();

include 'dati.inc.php';

//registrazione sessioni



//SE USER � DIVERSO DA OWNER CONTROLLA SE IL MODERATORE � ABILITATO

//PER QUESTO ARGOMENTO

if (isset($user))

                 {

if($user != 'Owner')

{

if ($argomento == $arguser)

{

$admin = '1' ;

}

}

else

{

 $admin = '1';

}

}



//se argomento non definito cerca ultimo id inserito

//cerca ultimo id

if (!isset ($argomento))

 {

$query = mysql_db_query($DATABASE,"select argomento from forum order by id desc limit 1") or die (mysql_error());

while ( $valore = mysql_fetch_array ($query))

    {

$argomento = $valore["argomento"];

}

}




//visualizzazzione separata
$limit = 10 ;
If(!isset($start)) $start = 0 ;


//VisUALIZZAZIONE DI TUTTI I TOPIC PRESENTI
mysql_select_db ($DATABASE,$link)
or die ("Non riesco a selezionare il db $database" .mysql_error()."<br>");



$query1 = mysql_query("SELECT * FROM forum WHERE argomento = '$argomento' and id_msg = '0' order by id_topic DESC",$link) or die .mysql_error();



@$count = mysql_num_rows($query1) ;
$query = mysql_query("SELECT * FROM forum WHERE argomento = '$argomento' and id_msg = '0'
order by id_topic DESC  limit $start , $limit ",$link) or die .mysql_error();



$numero_pagine = ceil($count/$limit) ;
$pagina_corrente  = ceil(($start/$limit)+1);

?>



<html>

<head>

<title>Argomenti di discussione</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css">

<!--

-->

</style>

<link rel="stylesheet" href="forum.css" type="text/css">

</head>



<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">

<p><img src="img/logo.gif"> </p>

<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">

  <tr>

    <td> 

      <form name="form1" method="post" action="delete_topic.php">

        <table width="98%" border="0" cellspacing="1" cellpadding="4" align="center">
          <tr bgcolor="#FFFFFF">  

            <td colspan="7" height="8" align=right"> 

              <div align="right"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Pagina 

                <? echo $pagina_corrente ?>

                <font color="#FF0000">di</font> 

                <? echo $numero_pagine?>

                </b></font> </div>

            </td>

          </tr>

          <tr> 

            <td width="1%" bgcolor="#000000"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>

            <td width="1%" bgcolor="#000000"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>

            <td width="48%" bgcolor="#000000"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Argomento: 

              <? echo $argomento?>

              <font size="1"> Tot discussioni : 

              <? echo $count?>

              </font> </font></td>

            <td width="7%" bgcolor="#000000"> 

              <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Utente</font></div>

            </td>

            <td width="8%" bgcolor="#000000"> 

              <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Risposte</font></div>

            </td>

            <td width="5%" bgcolor="#000000"> 

              <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Letto</font></div>

            </td>

            <td width="30%" bgcolor="#000000"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Data 

              Messaggio </font></td>

          </tr>

          <tr bgcolor="#FFFFFF"> 

            <td colspan="7" height="8">

              <input type="hidden" name="argomento" value="<? echo $argomento ?>">

              <input type="hidden" name="id_topic" value="<? echo $id_topic ?>">

              <input type="hidden" name="id_msg" value="<? echo $id_msg ?>">

            </td>

          </tr>

          <?php






$i = '0';

while ( $valori = mysql_fetch_Array($query))

{

  $i++;

$id = $valori["id"];


$userid = $valori["user"];

$id_msg = $valori["id_msg"];

   $id_topic = $valori["id_topic"];

 $testo = $valori["testo"];

 $data = $valori["data"];

 $click = $valori["click"];

 $risposte = $valori["risposte"];

   $titolo = $valori["titolo"];

   $icona = $valori["icona"];

   $argomento = $valori["argomento"];



//VISUALIZZA IL NUMERO DI RISPOSTE PER TOPIC

$query_risposte =  mysql_query("SELECT * FROM forum WHERE id_topic='$id_topic'AND argomento = '$argomento' ",$link) or die .mysql_error();

$count = mysql_num_rows ($query_risposte) or die .mysql_error();

 

 if ($count >= 10)

 {

 $image = "hotclosed" ;

 }

 else

 {

 $image = "closed" ;

 }

if (($i%2) < 1 )
{

 ?>

          <tr bgcolor="#4AAEFF"> 

            <td width="1%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><img src="img/<? echo $image ?>.gif"></font></td>

            <td width="1%" bgcolor="#4AAEFF"> 

              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <img src="img/img_file/<? echo "$icona" ?>.gif" border="0"> </font></div>

            </td>

            <td width="48%" bgcolor="#4AAEFF"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="vedimsg.php?id_topic=<? echo $id_topic ?>&titolo=<? echo $titolo ?>&argomento=<? echo $argomento ?>&click=<?echo $click ?>"> 

              <? echo $titolo ?>

              </a></font></td>

            <td width="7%" bgcolor="#4AAEFF"> 

              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo $userid ?>

                </font></div>

            </td>

            <td width="8%"> 

              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo ($count-1)?>

                </font></div>

            </td>

            <td width="5%" bgcolor="#4AAEFF"> 

              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo ($click)?>

                </font></div>

            </td>

            <td width="30%"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

              <? echo $data ?>

         <?PHP    if(isset($admin)) echo" <input type=\"checkbox\" name=\"$id\" value=\"ON\">Cancella messaggio " ;?>

              </font></td>

          </tr>
		  
		  
		  <?  } else { ?>
		    
          <tr bgcolor="#DCE2F8"> 
            <td width="1%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><img src="img/<? echo $image ?>.gif"></font></td>

            <td width="1%"> 
              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <img src="img/img_file/<? echo "$icona" ?>.gif" border="0"> </font></div>

            </td>

            <td width="48%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="vedimsg.php?id_topic=<? echo $id_topic ?>&titolo=<? echo $titolo ?>&argomento=<? echo $argomento ?>&click=<?echo $click ?>"> 
              <? echo $titolo ?>
              </a></font></td>

            <td width="7%"> 
              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo $userid ?>

                </font></div>

            </td>

            <td width="8%"> 
              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo ($count-1)?>

                </font></div>

            </td>

            <td width="5%"> 
              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo ($click)?>

                </font></div>

            </td>

            <td width="30%"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <? echo $data ?>
              <?PHP    if(isset($admin)) echo" <input type=\"checkbox\" name=\"$id\" value=\"ON\">Cancella messaggio " ;?>
              </font></td>

          </tr>
		  <? } ?>

          <?php

}



mysql_close ($link);





?>

          <tr bgcolor="#FFFFFF"> 

            <td colspan="7" height="8"> 

              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? if ( $numero_pagine > 1 )

      {



      for ( $pagina=1 ; $pagina <= $numero_pagine ; $pagina++)

      {



      $inistart = (($pagina-1)*$limit ) ;

      echo " <a href=?start=$inistart title=\"Vai a pagina $pagina\">

      [$pagina]</a> " ;

  }

  }

      ?>

                <br>

                <br>

               [ <a href="scrivi.php?action=new&argomento=<? echo $argomento ?>"> 

                Inserisci nuovo messaggio</a | Torna a lista argomenti> ]-[ <a href="index.php">Torna 

                a lista argomenti</a> ]<br>

                <br>

                <img src="img/hotclosed.gif" width="14" height="18"> Hot Topic 

                - Discussione con piu' di 10 risposte</font></div>

            </td>

          </tr>

        </table>

        <div align="center"><? if(isset($admin)) echo "

          <input type=\"submit\" name=\"Submit\" value=\"Cancella messaggi selezionati\">"; ?>

        </div>

      </form>

      <p>





      </p>

      <p>&nbsp;</p>

    </td>

  </tr>

</table>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

</body>

</html>

