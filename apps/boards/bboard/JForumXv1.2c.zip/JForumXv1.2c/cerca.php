
<html>
<head>
<title>Cerca in jasx forum</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="forum.css" type="text/css">
<style type="text/css">
<!--
.boxnew {  border: 1px #000000 solid; background-color: #0099CC}
-->
</style>
<script language="javascript">
function controll()
{
if (document.form.word.value=="")
{
alert("Devi inserire almeno una parola per effettuare la ricerca");

document.form.word.focus();
return false ;
}
}

</script>

</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="85"><img src="img/logo.gif" height="89"> 
      <p>&nbsp;</p>
      </td>
  </tr>
  <tr>
    <td height="192" valign="top"> 
      <form name="form" method="post" OnSubmit="return controll()" action="<? $PHP_SELF ?>" >
        <table width="35%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>
              <table width="100%" border="0" cellspacing="1" cellpadding="4" height="180">
                <tr> 
                  <td colspan="2" height="16"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#FF0000">Inserisci 
                    le opzioni per la ricerca</font></b></font></td>
                </tr>
                <tr> 
                  <td width="46%" height="17"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Parola 
                    da cercare:*</font></td>
                  <td width="54%" height="17"> 
                    <input type="text" name="word" class="boxnew" value="<? echo $word ?>">
                  </td>
                </tr>
                <tr> 
                  <td width="46%" height="12"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Nome 
                    utente: </font></td>
                  <td width="54%" height="12"> 
                    <input type="text" name="nuser"  value="<? echo $tuser ?>" class="boxnew">
                  </td>
                </tr>
                <tr> 
                  <td width="46%" height="2"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Negli 
                    ultimi msg :</font></td>
                  <td width="54%" height="2">
                    <select name="last" class="boxnew">
                      <option value="1" selected>Tutti messaggi</option>
<option value="20">20 messaggi</option>
                      <option value="50">50 messaggi</option>
                      <option value="100">100 messaggi</option>
                      <option value="150">150 messaggi</option>
                      <option value="200">200 messaggi</option>
                      
                    </select>
                  </td>
                </tr>
                <tr>
                  <td width="46%" height="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Cerca 
                    in: </font></td>
                  <td width="54%" height="2">
                    <select name="nforum" class="boxnew">
                      <option value="1" selected>Tutti i forum</option>
                      <? include 'dati.inc.php';
$invio = mysql_db_query ($DATABASE,"select distinct nome from forumarg") or die .mysql_error();

while ( $valore = mysql_fetch_Array($invio))
{
$nome = $valore["nome"];

echo "<option value=\"$nome\">$nome</option>" ;
}
 ?>
                    </select>
                    <input type="submit" name="Submit" value="Invia" class="boxnew">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
        </form>
    </td>
  </tr>
  <tr>
    <td> 
      <div align="left"></div>
        
      <br>
        <table width="90%" border="0" cellspacing="1" cellpadding="4" align="left">
          <tr> 
            <td bgcolor="#000000"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>
            <td width="48%" bgcolor="#000000"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Messaggio</font></td>
            <td bgcolor="#000000"> 
              <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Utente</font></div>
            </td>
            <td width="30%" bgcolor="#000000"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Data 
              Messaggio </font></td>
          </tr>
<?php
if (isset($Submit))
 {
//DEFINISCE SE IL CAMPO USER � VUOTO
if(!empty($nuser)){$tuser ="AND user = '$nuser'" ;}

if ($nforum!=1){$tnforum = "AND argomento = '$nforum'";}

if ($last!=1){$tlast = "order by id desc limit $last";}


$query = "select * from forum Where testo LIKE '%$word%'".$tuser.$tnforum.$tlast ;
$invio1 = mysql_db_query ($DATABASE,$query) or die .mysql_error();

while ( $valore = mysql_fetch_Array($invio1))
{
$titolo = $valore["titolo"];

$user = $valore["user"];
$argomento = $valore["argomento"];
$id_topic = $valore["id_topic"];

?>

          <tr bgcolor="#4AAEFF"> 
            <td> 
              
            <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <? if ($valore["id_msg"] == 0 ) echo "Topic"  ;  else  echo "Risposta" ;?>
              </font></div>
            </td>
            
          <td width="48%" bgcolor="#4AAEFF"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
            <a href="vedimsg.php?id_topic=<? echo $id_topic ?>&argomento=<? echo $argomento ?>">
            <? echo $titolo ?></a> </font></td>
            <td bgcolor="#4AAEFF"> 
              
            <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <? echo $user?>
              </font></div>
            </td>
            
          <td width="30%"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
            <? echo $valore["data"]?>
            </font></td>
          </tr>
<? 

} }?>
          <br>
          <br>
        </table>
        <p>&nbsp;</p>
        
      <p>&nbsp;</p>
      </table>
<p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="index.php">Torna 
  indice Argomenti</a></font></p>
<p>&nbsp;</p>
</body>
</html>
