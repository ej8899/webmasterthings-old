*******************************************
*ISTRUZIONI PER L'INSTALLAZIONE JForumX*
*******************************************
Requisiti tecnici: PHP4/mysql (not tested con php3)

>> Inserite nel file dati.inc il nome del database e i dati per la connessione   (host , user , password).

>> Importate il file db.txt sul vostro server che vi creer� la struttura delle tabelle	(potete usare programmi come 
phpmyadmin , mysqlfront ).

>> Entrate nel menu iscrizione nuovo utente (root_vostro_sito/iscrizione.php)  
   � procede alla registrazione UTILIZZATE come username 'Owner'. 

>> Entrate nel menu root_vostro_sito/moderazione/index.php e accede alla sezione
   dedicata all'Owner per la gestione del forum e create un primo forum di discussione.

>> Per modificare la grafica dei file: 
veditopic.php 
vedimsg.php 
scrivi.php 
iscrizione.php 
scrivi.php
cerca.php
utilizzate un qualasiasi editor visuale html (dreaweaver , GO live ect) senza cancellare    
nessun tag PHP (ancore gialle in dreamweaver).

>> Il gioco � fatto ;)

ATTENZIONE:
Nelle versioni superiori alla 4.06 la variabile register_globals deve essere settata su on
register_globals	=	On


******************************************
*Amministrazione Forum 			 *		
******************************************

Dalla pagina forum/moderazione/index.php potete accedere come Owner 
o moderatore dei forum La prima volta potrete entrare solo come Owner.

>> PROFILO OWNER L'Owner puo creare nuovi forum 
di discussione abilitare i moderatori , cancellare forum esistenti , 
moderare tutti i forum esistenti , eliminare gli utenti.
Puo moderare tutti i forum.

>> PROFILO MODERATORE
Pu� essere selezionato come moderatore qualsiasi utente registrato.
Ogni utente pu� moderare un solo forum.
Ogni forum puo essere moderato da un solo utente.
Pu� solo moderare il forum per il quale � accreditato come moderatore.



******************************************
*FEATURS Forum 				 *		
******************************************
>> Cookies free completa assenza di cookies
>> Gestione moderatore e utenti


Per bugs segnalazioni e info:
Antonio Calabrese
jasx@inwind.it 