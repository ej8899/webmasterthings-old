<?php

session_start();

include 'dati.inc.php';

//CREAZIONE VARIABILE DATA

$data = date('d M Y H:i:s');



//CREAZIONE NUOVO MESSAGGIO

if (isset($action))

{

$titolo_r = "$titolo";



//cerca la varbile action se definita crea LAST ID_TOPIC e setta ID_msg = 0



mysql_select_db($DATABASE,$link) or die .mysql_error();



$query_topic = "SELECT id_topic FROM forum order by id_topic DESC LIMIT 1"   ;





  $query_last_topic = mysql_query($query_topic,$link) or die .mysql_error();



    while ($valore = mysql_fetch_Array($query_last_topic))



    {



    //trovato valore utlimo topic e incrementato di uno

    $id_topic = $valore["id_topic"];



     $id_topic++;



}

 $id_msg = '0';

}

else

{

//ELABORAZIONE RISPOSTE AI MESSAGGI

$titolo_r= "RE:$titolo";



mysql_select_db($DATABASE,$link) or die .mysql_error();



$query_msg = "SELECT id_msg FROM forum where id_topic='$id_topic' order by id_msg DESC LIMIT 1"   ;

$query_last_msg = mysql_query($query_msg,$link) or die .mysql_error();



    while ($valore = mysql_fetch_Array($query_last_msg))



    {

 //trovato valore ULTIMOmsg



     $id_msg = $valore["id_msg"];



$id_msg++;



}



}







             if(isset($Submit) )

  {$controllo = mysql_db_query($DATABASE,"select count(userid) from utenti where userid = '$userlog' AND password = '$passlog'") or die .mysql_error();



$control = mysql_result($controllo,0) ;

       if($control == 1 )

       {

  mysql_select_db($DATABASE,$link) or die .mysql_error();

  $query_insert = "INSERT INTO forum VALUES(

  '',

  '$id_topic',

  '$id_msg',

  '$Radio1',

  '$username',

  '$data',

  '$titolo',

  '$testo',

  '0',

  '0',

  '$argomento'

  );" ;



if (  $inserimento = mysql_query($query_insert,$link) )



     header('location:veditopic.php');

  else



     $msg = "no".mysql_error();



 }  else $msg = "AUTENTICAZIONE UTENTE NON RIUSCITA" ;



}







 ?>

<html>

<head>

<title>Lascia il tuo messaggio !!</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css">

<!--

.boxqui {  border: 1px #000000 groove; background-color: #4AAEFF}

-->

</style>

<script Language="javascript">



function control() 

{

if (document.form.username.value=="")

{



alert ('Inserire un utente valido');

document.form.username.focus();

return false ;

}



if (document.form.titolo.value=="")

{

alert ('Inserire un titolo valido');

document.form.titolo.focus();

return false ;

}



if (document.form.testo.value=="")

{

alert ('Inserire un testo valido');

document.form.testo.focus();

return false ;

}





}



</script>

<link rel="stylesheet" href="forum.css" type="text/css">

</head>







<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><img src="img/logo.gif"></td>
  </tr>
  <tr> 
    <td height="328"> 
      <form name="form" method="post" onSubmit="return control()" action="scrivi.php?inviato=yes">
        <div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b> 
          <? echo $msg ?>
          </b></font><br>
          <br>
        </div>
        <div align="center"></div>
        <table cellspacing=0 cellpadding=0 width="72%" align=center border=0 height="377">
          <tbody> 
          <tr> 
            <td bgcolor=#000000 height="399" valign="top"> 
              <table cellspacing=1 cellpadding=6 width="100%" border=0 height="407">
                <tbody> 
                <tr> 
                  <td class=header colspan=3><font size="2" color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif">Scrivi 
                    qui il tuo messaggio</font></td>
                </tr>
                <tr> 
                  <td class=tablerow width="19%" bgcolor=#4AAEFF><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Username:</font></td>
                  <td class=tablerow bgcolor=#d0e0f0 colspan="2"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input size=25 name=username value="<? echo $userlog ?>" class="boxqui">
                    <a href="iscrizione.php">se non sei registrato clicca qui</a></font></td>
                </tr>
                <tr> 
                  <td class=tablerow bgcolor=#4AAEFF width="19%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Password:</font></td>
                  <td class=tablerow bgcolor=#DCE2F8 colspan="2"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type=password size=25 

            name=passlog value="<?php echo $passlog ?>" class="boxqui">
                    <input type="hidden" name="argomento" value="<? echo $argomento ?>">
                    <input type="hidden" name="id_topic" value="<? echo $id_topic ?>">
                    <input type="HIDDEN" name="id_msg" value="<? echo $id_msg ?>">
                    </font></td>
                </tr>
                <tr> 
                  <td class=tablerow bgcolor=#4AAEFF width="19%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Titolo: 
                    </font></td>
                  <td class=tablerow bgcolor=#d0e0f0 colspan="2"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input size=25 name=titolo value="<? echo $titolo_r ?>" class="boxqui">
                    </font> </td>
                </tr>
                <tr> 
                  <td class=tablerow bgcolor=#4AAEFF valign="top" height="254" width="19%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Testo:</font></td>
                  <td bgcolor=#d0e0f0 valign="top" height="254" width="35%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <textarea cols="43" name="testo" rows="15" class="boxqui"></textarea>
                    </font></td>
                  <td class=tablerow bgcolor=#d0e0f0 valign="top" height="254" width="46%"> 
                    <table cellspacing=0 cellpadding=0 align=center>
                      <tbody> 
                      <tr> 
                        <td width="17"><font size="2"><img height=16 src="img/img_file/1.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio CHECKED value=1 

                            name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/2.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=2 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/3.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=3 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/4.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=4 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=15 src="img/img_file/5.gif" 

                              width=21 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=5 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/6.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=6 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/7.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=7 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=15 src="img/img_file/11.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=11 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/12.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=12 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/13.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=13 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/14.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=14 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=15 src="img/img_file/15.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=15 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/16.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=16 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/17.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=17 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=15 src="img/img_file/21.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=21 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/22.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=22 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/23.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=23 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/24.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=24 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=15 src="img/img_file/25.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=25 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/26.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=26 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=14 src="img/img_file/27.gif" 

                              width=14 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=27 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=15 src="img/img_file/31.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=31 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/32.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=32 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/33.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=33 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/34.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=34 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=15 src="img/img_file/35.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=35 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=23 src="img/img_file/36.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=36 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/8.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=8 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=16 src="img/img_file/41.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=41 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/42.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=42 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/43.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=43 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=17 src="img/img_file/44.gif" 

                              width=17 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=44 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=16 src="img/img_file/45.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=45 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/46.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=46 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/18.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=18 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17" height="21"><font size="2"><img height=15 src="img/img_file/51.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=51 name=Radio1>
                          </font></td>
                        <td width="17" height="21"><font size="2"><img height=15 src="img/img_file/52.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=52 name=Radio1>
                          </font></td>
                        <td width="17" height="21"><font size="2"><img height=15 src="img/img_file/53.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=53 name=Radio1>
                          </font></td>
                        <td width="18" height="21"><font size="2"><img height=16 src="img/img_file/54.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=54 name=Radio1>
                          </font></td>
                        <td width="22" height="21"><font size="2"><img height=15 src="img/img_file/55.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=55 name=Radio1>
                          </font></td>
                        <td width="17" height="21"><font size="2"><img height=15 src="img/img_file/56.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=56 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/28.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=28 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=15 src="img/img_file/61.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=61 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/62.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=62 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/63.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=63 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/64.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=64 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=15 src="img/img_file/65.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=65 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/66.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=66 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/78.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=78 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=15 src="img/img_file/9.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=9 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/10.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=10 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/29.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=29 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/30.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=30 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=15 src="img/img_file/49.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=49 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/50.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=50 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/77.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=77 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17" height="17"><font size="2"><img height=15 src="img/img_file/19.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="17"> <font size="2"> 
                          <input type=radio value=19 name=Radio1>
                          </font></td>
                        <td width="17" height="17"><font size="2"><img height=15 src="img/img_file/20.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="17"> <font size="2"> 
                          <input type=radio value=20 name=Radio1>
                          </font></td>
                        <td width="17" height="17"><font size="2"><img height=15 src="img/img_file/39.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="17"> <font size="2"> 
                          <input type=radio value=39 name=Radio1>
                          </font></td>
                        <td width="18" height="17"><font size="2"><img height=15 src="img/img_file/40.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="17"> <font size="2"> 
                          <input type=radio value=40 name=Radio1>
                          </font></td>
                        <td width="22" height="17"><font size="2"><img height=16 src="img/img_file/59.gif" 

                              width=16 border=0></font></td>
                        <td width="25" height="17"> <font size="2"> 
                          <input type=radio value=59 name=Radio1>
                          </font></td>
                        <td width="17" height="17"><font size="2"><img height=16 src="img/img_file/60.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="17"> <font size="2"> 
                          <input type=radio value=60 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/76.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=76 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=16 src="img/img_file/69.gif" 

                              width=16 border=0></font></td>
                        <td width="23"> <font size="2"> 
                          <input type=radio value=69 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/70.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=70 name=Radio1>
                          </font></td>
                        <td width="17" height="21"><font size="2"><img height=15 src="img/img_file/57.gif" 

                              width=15 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=57 name=Radio1>
                          </font></td>
                        <td width="17" height="21"><font size="2"><img height=16 src="img/img_file/58.gif" 

                              width=16 border=0></font></td>
                        <td width="25" height="21"> <font size="2"> 
                          <input type=radio value=58 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/37.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=37 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/38.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=38 name=Radio1>
                          </font></td>
                        <td width="22"><font size="2"><img height=20 src="img/img_file/75.gif" 

                              width=17 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=75 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=15 src="img/img_file/79.gif" 

                              width=15 border=0></font></td>
                        <td width="23"> <font size="2"> 
                          <input type=radio value=79 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/80.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=80 

                          name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/67.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=67 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/68.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=68 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/47.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=47 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/48.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=48 name=Radio1>
                          </font></td>
                        <td width="18"><font size="2"><img height=15 src="img/img_file/74.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=74 name=Radio1>
                          </font></td>
                      </tr>
                      <tr> 
                        <td width="17"><font size="2"><img height=16 src="img/img_file/71.gif" 

                              width=16 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=71 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=15 src="img/img_file/72.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=72 name=Radio1>
                          </font></td>
                        <td width="17"><font size="2"><img height=16 src="img/img_file/73.gif" 

                              width=15 border=0></font></td>
                        <td width="25"> <font size="2"> 
                          <input type=radio value=73 name=Radio1>
                          </font></td>
                        <td width="18">&nbsp;</td>
                        <td width="25">&nbsp;</td>
                        <td width="22">&nbsp;</td>
                        <td width="25">&nbsp;</td>
                        <td width="17">&nbsp;</td>
                        <td width="25">&nbsp;</td>
                        <td width="17">&nbsp;</td>
                        <td width="25">&nbsp;</td>
                      </tr>
                      </tbody> 
                    </table>
                  </td>
                </tr>
                </tbody> 
              </table>
            </td>
          </tr>
          </tbody> 
        </table>
        <div align="center"><br>
          <input type="submit" name="Submit" value="Invia un messaggio al nostro forum" class="box">
          <br>
          <a  href="veditopic.php?argomento=<?php echo $argomento ;?>"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br>
          Torna ai messaggi</font></a><br>
          <br>
        </div>
      </form>
    </td>
  </tr>
</table>
<p></p>

  <p>

  </p>



</body>

</html>

