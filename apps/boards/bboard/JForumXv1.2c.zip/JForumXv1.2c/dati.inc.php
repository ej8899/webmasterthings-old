<?php

$DATABASE = "forum"; //INSERITE IL NOME DEL DB

$DB_USER = "root"; //USER DEL DB

$DB_LOGIN = ""; //PASSWORD DB

$HOST = "localhost";    //INDIRIZZO DEL DATABASE

$link = mysql_connect("$HOST","$DB_USER","$DB_LOGIN") or die
(mysql_error());

?>
