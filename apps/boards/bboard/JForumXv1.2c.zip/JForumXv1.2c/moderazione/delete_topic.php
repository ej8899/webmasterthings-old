<?php
include '../dati.inc.php' ;

if (!($result = mysql_db_query($DATABASE, "select * from forum" )))
{

echo "no".mysql_error();

   exit() ;

}



while (($row = mysql_fetch_array($result)))
 {

   $id = $row["id"];

// Cancella id selezionato

   if (($$id) && ($$id == "ON"))

   { 

      // Delete the user entry ftom user_profile table

      if (!mysql_db_query($DATABASE, "delete from forum where id='$id'"))
                   {

  echo "no".mysql_error();

         exit() ;


                   //se il msg cancellato � un topic cancella tutti i sotto msg
         if ($id_msg == 0)
             {
if (!mysql_db_query($DATABASE, "delete from forum where id_topic='$id_topic'"))
                   {

  echo "no".mysql_error();

         exit() ;

         }
 }




   }

}// End of if 
     }// End of while 


      header("location:$HTTP_REFERER");


?>
