<?php
session_start();

//SE L'UTENTE NON � OWNON NON ACCEDE ALLA PAGINA
if($user!= 'Owner'){header("location:index.php");}
include '../dati.inc.php';
//modifica campi
if(isset($Submit))
{


$query = " UPDATE forumarg SET descrizione='$descrizione' , moderatore='$moderatore'  WHERE id='$id' "  ;


if( mysql_db_query($DATABASE,$query) )
{
$msgmodifica  = "Modifica riuscita con successo " ;
    }
else
 {
$msgmodifica = "Error:".mysql_error();   }
//exit();
}

//inserisce nuovo argomento nel forum
if(isset($Submit2))
{


$invio1 = mysql_db_query($DATABASE,"select count(nome) from forumarg where  nome = '$nome' ") or die (mysql_error()) ;


//controlla se argomento gia esiste
if (mysql_result($invio1,0)==1 )
{
$msgmodifica = "Error:Argomento gia esistente"   ;
}

else
{

$mod = mysql_db_query ($DATABASE ,"UPDATE utenti SET mod='$nome' WHERE userid = '$moderatore'") or die (mysql_error());

 
$query = "INSERT INTO forumarg VALUES
('',
'',
'$nome',
'$descrizione',
'$moderatore');";

if( mysql_db_query($DATABASE,$query) )
{
$msgmodifica  = "Modifica riuscita con successo " ; 
    }
	 else
       {
$msgmodifica = "Error:".mysql_error(); 
exit();
 }
$invio = mysql_db_query ($DATABASE,"SELECT id_topic from forum order by id_topic desc") or die (mysql_error());
@$rsl = mysql_result($invio,0) ;
$data = date('d M Y H:i:s');
$query2 = "INSERT INTO forum VALUES
('',
'$id_topic',
'0',
'1',
'Owner',
'$data',
'$nome' ,
'$descrizione',
'0',
'0',
'$nome');";

mysql_db_query($DATABASE,$query2) or die (mysql_error());
}
}
?>

<html>
<head>
<title>Pannello Gestione e Moderazione Forum</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="forum.css" type="text/css">
<link rel="stylesheet" href="../forum.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<p><img src="../img/logo.gif" width="391" height="89"></p>
<p><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 
  </font></p>
<div align="center"></div>

  
<table width="90%" border="0" cellspacing="1" cellpadding="4" align="center" height="68">
  <tr> 
    <td width="8%" bgcolor="#000000"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF" size="2">Argomento</font></div>
    </td>
    <td width="18%" bgcolor="#000000"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Descrizione</font></div>
    </td>
    <td width="21%" bgcolor="#000000"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Moderatore</font></div>
    </td>
    <td width="11%" bgcolor="#000000"> 
      <div align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">Gestione</font></div>
    </td>
    <td width="17%" bgcolor="#000000">&nbsp;</td>
    <td width="11%" bgcolor="#000000"> 
      <div align="center"></div>
    </td>
  </tr>
  <?php

  $query = mysql_db_query($DATABASE,"select * from forumarg") or die (mysql_error());

while (  $valore = mysql_fetch_array($query))
  {

  $id = $valore["id"];
 $nome = $valore["nome"];
  $descrizione = $valore["descrizione"];
  $moderatore = $valore["moderatore"];
 $vpassword = $valore["password"];

?>
  <form action="<? echo $PHP_SELF ?>">
    <tr bgcolor="#CCCCCC" valign="top"> 
      <td width="8%" height="25"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="<?echo "veditopic.php?argomento=$nome"; ?>"> 
        </a> 
        <? echo $nome ?>
        <br>
        </font></td>
      <td width="18%" height="25"> 
        <div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
          <input type="text" name="descrizione" value="<? echo $descrizione ?>" size="30" class="box">
          </font></div>
      </td>
      <td width="21%" height="25"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 
          <select name="moderatore">
            <?php

            $list = mysql_db_query($DATABASE,'select * from utenti') or die (mysql_error());

            while ( $valori = mysql_fetch_array ($list))
            {


            ?>
            <option value="<? echo $valori["userid"] ;?>" <? if ($valori["userid"]==$moderatore) echo selected ; ?>
 >
            <? echo $valori["userid"] ;?>
            </option>
            <?} ?>
          </select>
          <input type="hidden" name="id" value="<? echo $id ?>" class="box" size="15">
          </font></div>
      </td>
      <td width="11%" height="25"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000" size="2"><a href="../veditopic.php?argomento=<? echo "$nome&admin=1" ?>">Entra</a></font></div>
      </td>
      <td width="17%" height="25"><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000" size="2"><a href="elimina.php?id=<? echo "$id  "; ?>"><font size="1">Elimina 
        arg</font></a></font><font face="Verdana, Arial, Helvetica, sans-serif" color="#000000" size="2"><a href="elimina.php?id=<? echo "$id &msg=1&argomento=$nome  ";?>"><br>
        <font size="1">Elimina anche msg</font></a></font></td>
      <td width="11%" height="25"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 
          <input type="submit" name="Submit" value="Modifica">
          </font></div>
      </td>
    </tr>
  </form>
  <?php


 }

 
?>
</table>

<p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>&nbsp; 
  </b></font></p>
<p align="center">&nbsp;</p>
<p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font color="#000066">Inserimento 
  nuovo Argomento di discussione</font></b> </font></p>
<table width="68%" border="0" cellspacing="1" cellpadding="4" align="center" height="68">
  <tr> 
    <td width="19%" bgcolor="#000000" height="10"><font face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF" size="2">Argomento</font></td>
    <td width="31%" bgcolor="#000000" height="10"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Descrizione</font></div>
    </td>
    <td width="19%" bgcolor="#000000" height="10"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Moderatore</font></div>
    </td>
    <td width="18%" bgcolor="#000000" height="10"> 
      <div align="center"></div>
    </td>
  </tr>
  <form action="<? echo $PHP_SELF ?>">
    <tr bgcolor="#CCCCCC" valign="top"> 
      <td width="19%" height="25"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="<?echo "veditopic.php?argomento=$nome"; ?>"> 
        <input type="text" name="nome" class="box">
        </a><br>
        </font></td>
      <td width="31%" height="25"> 
        <div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
          <input type="text" name="descrizione" size="40" class="box">
          </font></div>
      </td>
      <td width="19%" height="25"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 
          <select name="moderatore">
            <?php

            $list = mysql_db_query($DATABASE,'select * from utenti') or die (mysql_error());

            while ( $valori = mysql_fetch_array ($list))
            {


            ?>
            <option value="<? echo $valori["userid"] ;?>">
            <? echo $valori["userid"] ;?>
            </option>
            <?} ?>
          </select>
          </font></div>
      </td>
      <td width="18%" height="25"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 
          <input type="submit" name="Submit2" value="Inserisci">
          </font></div>
      </td>
    </tr>
  </form>
</table>
<p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b> 
  <? echo $msgmodifica ?>
  </b></font></p>
<p align="center"><a href="gestioneutenti.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Gestisci 
  utenti </font></a></p>
<p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font color="#FF0000"><a href="../index.php">Torna 
  al forum</a></font></b></font></p>
</body>
</html>
