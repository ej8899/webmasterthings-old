<?php

include '../dati.inc.php' ;






if (!($result = mysql_db_query($DATABASE, "select * from utenti" )))

{

echo "no".mysql_error();
exit() ;
}







while (($row = mysql_fetch_array($result)))

 {



   $id = $row["id"];
         $userid = $row["userid"];


// Cancella id selezionato



   if (($$id) && ($$id == "ON"))



   { 
               
  //evita ke si possa cancella l'Owner
if ($userid=='Owner')
{
  header("location:$HTTP_REFERER");
   exit();
    }






      if (!mysql_db_query($DATABASE, "delete from utenti where id='$id'"))

                   {



  echo "no".mysql_error();



         exit() ;


}
   else

   {

   mysql_db_query($DATABASE, "delete from forum where user='$userid'") ;

}












}// End of if 

     }// End of while 





      header("location:$HTTP_REFERER");





?>

