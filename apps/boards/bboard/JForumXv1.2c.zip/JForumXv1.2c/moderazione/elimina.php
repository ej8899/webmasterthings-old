<?php
include '../dati.inc.php';
$query = " DELETE from forumarg WHERE id='$id' "  ;

if($msg==0)
{
if( mysql_db_query($DATABASE,$query) )
{

header ("location:setup.php") ;


    }

       else
       {

       echo "NO".mysql_error();
   }
}
else
{

mysql_db_query($DATABASE,$query) or die (mysql_error());

   
$deletemsg = "delete from forum where argomento = '$argomento' ";

if (mysql_db_query($DATABASE,$deletemsg))
{

header ("location:setup.php") ;


    }

       else
       {

       echo "NO".mysql_error();
   }


}



?>
