<?php
session_start();
  
include '../dati.inc.php' ;



//CONTROLLA SE SI � LOGGATO OWNER
if ($user=='Owner')
 {
 $login = mysql_db_query ($DATABASE,"select * from utenti Where userid = 'Owner' AND password = '$password'")
or die (mysql_error());

if (mysql_num_rows($login) == 1 )

{
$userlog = $user ;
$passlog = $password;
session_register("user");
session_register("cookies_pwd");
session_register('userlog') ;
session_register('passlog') ;
$cookie_pwd = $password ;
//PER EVENTUALE UTILIZZO DEI COOKIES
//setcookie("admin",$user);
//setcookie("cookie_pwd",$cookie_pwd);

header("location:setup.php");
}
else
{
//MSG DI ERRORE NEL CASO DI PASSWORD SBAGLIATA DEL OWNER
$msg = "User e/o Password errate" ;
header("location:index.php?msg=$msg ");
}

}
else
{

//CONTROLLO SE IL MODERATORE E' LOGGATO
$invio = mysql_db_query ($DATABASE,"select * from utenti Where userid = '$user' AND password = '$password' AND mod = '$moderazione'")
or die (mysql_error());



if (mysql_num_rows($invio) == 1 )

{

$userlog = $user ;
$passlog = $password;
   if (isset($moderazione))
                           {
$userid = $user ;
//controllo per non permettere al moderatore di moderare altri forum
session_register("user");
session_register("cookie_pwd");
session_register("arguser");
session_register('userlog') ;
session_register('passlog') ;
$arguser = $moderazione;

 header("location:../veditopic.php?argomento=$moderazione");
                        }
}
else
{
//MSG SE USER E PASS MODERATORE SONO ERRATE
$msg = "User e/o Password errate" ;
header("location:index.php?msg=$msg ");
}



       }

     ?>







