<?php include '../dati.inc.php';
//visualizzazzione separata
session_start();
if($user!= 'Owner'){header("location:index.php");}
$limit = 10 ;

If(!isset($start)) $start = 0 ;



//VisUALIZZAZIONE DI TUTTI I TOPIC PRESENTI

mysql_select_db ($DATABASE,$link)

or die ("Non riesco a selezionare il db $database" .mysql_error()."<br>");

//CERCA IL NUMERO TOTALE DI UTENTI
$query1 = mysql_query("SELECT * FROM utenti ",$link) or die .mysql_error();
$count = mysql_num_rows($query1) or die (mysql_error());
//MOSTRA GLI UTENTI DELLA TABELLA UTENTI
$query = mysql_query("SELECT * FROM utenti limit $start , $limit ",$link) or die .mysql_error();

$numero_pagine = ceil($count/$limit) ;
$pagina_corrente  = ceil(($start/$limit)+1);

?>

<html>
<head>
<title>Gestione utenti</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<p>&nbsp;</p>
<form name="form1" method="post" action="delete_utenti.php">
  <p align="CENTER"> 
    <? echo $pagina_corrente ?>
    <font color="#FF0000">di</font> 
    <? echo $numero_pagine?>
  </p>
  <table width="90%" border="0" cellspacing="1" cellpadding="4" align="center" height="68">
    <tr> 
      <td width="15%" bgcolor="#000000" height="17"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Nome 
          Utente </font></div>
      </td>
      <td width="12%" bgcolor="#000000" height="17"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Email</font></div>
      </td>
      <td width="8%" bgcolor="#000000" height="17"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Icq</font></div>
      </td>
      <td width="13%" bgcolor="#000000" height="17"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Home 
          Page </font></div>
      </td>
      <td width="16%" bgcolor="#000000" bordercolor="#FFFFFF" height="17"> 
        <div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF">Moderatore</font></div>
      </td>
      <td width="9%" bgcolor="#000000" bordercolor="#FFFFFF" height="17"> 
        <div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF">Messaggi</font></div>
      </td>
      <td width="12%" bgcolor="#000000" bordercolor="#FFFFFF" height="17"> 
        <div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF">Registrato 
          </font><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF">IL</font></div>
      </td>
      <td width="15%" bgcolor="#000000" height="17"> 
        <div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF">Cancella</font></div>
      </td>
    </tr>
    <?php





while (  $valore = mysql_fetch_array($query))
  {

  $id = $valore["id"];
   $userid = $valore["userid"]   ;
  //cerca se l'utente � moderatore di qualche argomento
   $searchmode = mysql_db_Query($DATABASE,"select nome from forumarg Where moderatore = '$userid'") or die (mysql_error());

      @$rslmod = mysql_result($searchmode,0) ;
  //CERCA IL NUMERO TOTALE DEI MESSAGGI PER OGNI UTENTE
  $countmsg = mysql_db_query ($DATABASE,"select count(user) from forum where user = '$userid'") or die (mysql_error());

  @$rslmsg = mysql_result($countmsg,0) ;

?>

    <tr bgcolor="#CCCCCC" valign="top">   
      <td width="15%" height="25"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <? echo $valore["userid"]?>
        <input type="hidden"  name="id" value="<? echo $id ?>"">
		     
        <br>
        </font></td>
      <td width="12%" height="25"> 
        <div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="mailto:<? echo $valore["email"] ?>"> 
          <? echo $valore["email"];?>
          </a>
          <? echo $valore["vemail"] ?>
          </font></div>
      </td>
      <td width="8%" height="25"> 
        <div align="center"> 
          <? echo $valore["icq"] ;?>
        </div>
      </td>
      <td width="13%" height="25"> 
        <div align="center"><a href="http://<? echo $valore["homepage"] ;?>" target="_blank"> 
          <? echo $valore["homepage"] ;?>
          </a></div>
      </td>
      <td width="16%" height="25">
        <? echo $rslmod ?>
      </td>
      <td width="9%" height="25">
        <? echo $rslmsg ?>
      </td>
      <td width="12%" height="25"> 
        <? echo $valore["dataisc"] ;?>
      </td>
      <td width="15%" height="25"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"> 
          <input type="checkbox" name="<? echo $id ?>" value="ON">
          del utente</font></div>
      </td>
    </tr>
    <?php


 }

 
?>
  </table>
  <p>&nbsp;</p>
  <table width="75%" border="0" cellspacing="o" cellpadding="0" align="center">
    <tr> 
      <td> 
        <div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Vai 
          alle pagine: 
          <? if ( $numero_pagine > 1 )

      {



      for ( $pagina=1 ; $pagina <= $numero_pagine ; $pagina++)

      {



      $inistart = (($pagina-1)*$limit ) ;

      echo " <a href=?start=$inistart title=\"Vai a pagina $pagina\">

      [$pagina]</a> " ;

  }

  }

      ?>
          <br>
          <br>
          <input type="submit" name="Submit" value="Elimina utente">
          </font> </div>
      </td>
    </tr>
  </table>
  <div align="center"><br>
    <a href="setup.php">Torna a Menu</a><br>
    <br>
    <br>
  </div>
</form>
<p ALIGN="CENTER">&nbsp;</p>
<p ALIGN="CENTER">&nbsp;</p>
</body>
</html>
