<?php
session_start();
session_destroy();
  ?>




<html>
<head>
<title>Admin pannell</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../forum.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="50%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td> 
      <div align="center"> 
        <p><img src="../img/logo.gif"><br>
          <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Pannello 
          di controllo Moderatori</b></font></p>
        <table width="50%" border="0" cellspacing="0" cellpadding="0" class="box">
          <tr> 
            <td>
<form name="form1" method="post" action="index2.php">
                <table width="66%" border="0" cellspacing="0" cellpadding="0" align="center">
                  <tr> 
                    <td width="54%" height="17"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2">User</font></b></td>
                    <td width="46%" height="17"> 
                      <div align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <input type="text" name="user" size="8" class="box">
                        </font></b></div>
                    </td>
                  </tr>
                  <tr> 
                    <td width="54%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Password</font></b></td>
                    <td width="46%"> 
                      <div align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <input type="password" name="password" size="8" class="box">
                        </font></b></div>
                    </td>
                  </tr>
                  <tr> 
                    <td width="54%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Nome 
                      Forum</font></b></td>
                    <td width="46%"> 
                      <div align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <input type="password" name="moderazione" size="8" class="box">
                        </font></b></div>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2"> 
                      <div align="center">
<input type="submit" name="Submit" value="Invia" class="box">
                        <br>
                        <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"> 
                        <?php echo $msg ?>
                        </font><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
                        </font></div>
                    </td>
                  </tr>
                </table>
              </form>
              <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><b>Demo 
                Moderatore: </b>prova - prova - prova</font></p>
            </td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </div>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
