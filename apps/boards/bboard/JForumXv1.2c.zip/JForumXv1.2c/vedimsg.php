<? session_start()  ;





if (isset($user))

                 {

if($user != 'Owner')

{

if ($argomento == $arguser)

{

$admin = '1' ;

}

}

else

{

 $admin = '1';

}

}





 ?>

<html>

<head>

<title>Vedi messaggi per topic selezionato</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" href="forum.css" type="text/css">



<script language="javascript">



function dett(str) {



        searchWin = window.open(str,'','scrollbars=no,resizable=no,width=330,height=170,left=0,top=0,status=no,location=no,toolbar=no');



}





</script>

</head>



<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0">

<p><img src="img/logo.gif"></p>

<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">

  <tr> 

    <td> 

      <form name="form1" method="post" action="delete_topic.php">

        <table width="98%" border="0" cellspacing="1" cellpadding="4" align="center">
          <tr> 

            <td colspan="7" height="28"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

              </font><font color="#FFFFFF">a</font></td>

          </tr>

          <tr> 

            <td width="3%" bgcolor="#000000" height="28"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>

            <td width="29%" bgcolor="#000000" height="28"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Data 

              </font></td>

      

            <td width="62%" bgcolor="#000000" height="28"> 

              <div align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Testo</font></div>

            </td>

            <td width="6%" bgcolor="#000000" height="28">&nbsp;</td>

          </tr>

          <?



include 'dati.inc.php';





//VISUALIZZAZIONE CLICK PER TOPIC



//echo $click ;

$click++;

//echo $click ;

mysql_select_db ($DATABASE,$link)

 or die ("Non riesco a selezionare il db $database" .mysql_error()."<br>");



mysql_query ("UPDATE forum SET click='$click' where id_topic='$id_topic' ",$link) or die .mysql_error();



mysql_select_db ($DATABASE,$link)

or die ("Non riesco a selezionare il db $database" .mysql_error()."<br>");



//VISUALIZZAZIONE TUTTI I msg per topic



$query = mysql_query("SELECT * , forum.id AS id , utenti.id AS idutenti FROM  forum , utenti WHERE  forum.argomento = '$argomento' And  id_topic='$id_topic' AND utenti.userid = forum.user order by forum.id_msg",$link) or die .mysql_error();


$i = '0';
       while ( $valori = mysql_fetch_Array($query))




{

         $i++;

$id = $valori["id"];

$idutenti = $valori["idutenti"];

$userid = $valori["user"];

$id_msg = $valori["id_msg"];

$id_topic = $valori["id_topic"];

$testo = $valori["testo"];

$data = $valori["data"];

$click = $valori["click"];

$risposte = $valori["risposte"];

$titolo = $valori["titolo"];

$icona = $valori["icona"];

$icq = $valori["icq"];



$countmsg = mysql_db_query($DATABASE,"select count(user) from forum where user = '$userid'") or die (mysql_error());



$rslcount = mysql_result($countmsg,0)   ;



//VISUALIZZA L'ELENCO DI TUTTI I TOPIC ESIOSTENTI

 if (($i%2) < 1 )
{

 ?>

          <tr bgcolor="#4AAEFF"> 

            <td width="3%" valign="top" height="43"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><img src="img/img_file/<? echo $icona ?>.gif" width="15"></font></td>

            <td width="29%" valign="top" height="43"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="vedimsg.php?id_topic=<? echo $id_topic ?>&titolo=<? echo $titolo ?>&argomento=<? echo $argomento ?>&click=<?echo $click ?>"> 

              </a> 

              <? echo $data ?>

              <br>

              by <font color="#FF0000"><b><a href="javascript:dett('utenti.php?user=<? echo $userid ?>');"> 

              <? echo "$userid" ?>

              </a></b></font><br>

              <font size="1" color="#000000">Messaggi: 

              <?php echo

$rslcount ?>

              </font><br>

              <?

              if ( $valori["vemail"]=='ON')

              {



         echo " <a href=\"mailto:".$valori["email"]."\">  <img src=\"img/email.gif\" alt=".$valori["email"]." border=\"0\"><a>  ";

}



if (!$valori["icq"]=="" )

{

          echo "<img src=\"img/icq.gif\" alt=".$valori["icq"]." border=\"0\">";



}





if (!$valori["homepage"]=="" )

{





echo "<a href=\"http://".$valori["homepage"]."\" target=\"_blank\"\"><img src=\"img/home.gif\" alt=".$valori["homepage"]." border=\"0\"></a>";



}





               ?>

              </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

              <?PHP    if(isset($admin)) echo" <input type=\"checkbox\" name=\"$id\" value=\"ON\">Cancella messaggio " ;?>

              </font><font color="#FF0000"> </font></td>

        

            <td width="62%" valign="top" height="43"> 

              <div align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo $titolo?>

                <br>

                </font> 

                <hr>

                <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo $testo?>

                <br>

                <br>

                <? echo $valori["firma"]?>

                </font></div>

            </td>

            <td width="6%" valign="top" height="43"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="scrivi.php?id_topic=<? echo $id_topic ?>&titolo=<? echo $titolo ?>&argomento=<? echo $argomento ?>"> 

              <br>

              Rispondi</a> </font></td>

          </tr> <?  } else { ?>

          <tr bgcolor="#FF0000"> 
            <td width="3%" valign="top" height="43" bgcolor="#DCE2F8"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><img src="img/img_file/<? echo $icona ?>.gif" width="15"></font></td>

            <td width="29%" valign="top" height="43" bgcolor="#DCE2F8"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="vedimsg.php?id_topic=<? echo $id_topic ?>&titolo=<? echo $titolo ?>&argomento=<? echo $argomento ?>&click=<?echo $click ?>"> 
              </a> 
              <? echo $data ?>
              <br>

              by <font color="#FF0000"><b><a href="javascript:dett('utenti.php?user=<? echo $userid ?>');"> 

              <? echo "$userid" ?>

              </a></b></font><br>

              <font size="1" color="#000000">Messaggi: 

              <?php echo

$rslcount ?>

              </font><br>

              <?

              if ( $valori["vemail"]=='ON')

              {



         echo " <a href=\"mailto:".$valori["email"]."\">  <img src=\"img/email.gif\" alt=".$valori["email"]." border=\"0\"><a>  ";

}



if (!$valori["icq"]=="" )

{

          echo "<img src=\"img/icq.gif\" alt=".$valori["icq"]." border=\"0\">";



}





if (!$valori["homepage"]=="" )

{





echo "<a href=\"http://".$valori["homepage"]."\" target=\"_blank\"\"><img src=\"img/home.gif\" alt=".$valori["homepage"]." border=\"0\"></a>";



}





               ?>

              </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

              <?PHP    if(isset($admin)) echo" <input type=\"checkbox\" name=\"$id\" value=\"ON\">Cancella messaggio " ;?>

              </font><font color="#FF0000"> </font></td>

        

            <td width="62%" valign="top" height="43" bgcolor="#DCE2F8"> 
              <div align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo $titolo?>

                <br>

                </font> 

                <hr>

                <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 

                <? echo $testo?>

                <br>

                <br>

                <? echo $valori["firma"]?>

                </font></div>

            </td>

            <td width="6%" valign="top" height="43" bgcolor="#DCE2F8"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="scrivi.php?id_topic=<? echo $id_topic ?>&titolo=<? echo $titolo ?>&argomento=<? echo $argomento ?>"> 
              <br>

              Rispondi</a> </font></td>

          </tr>


          <?php
}
}



mysql_close ($link);





?>

          <tr> 

            <td colspan="7" height="8"> 

              <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FF0000"><br>

                [<a href="veditopic.php"> Torna lista topic </a> ]| [ <a href="index.php">Torna 

                indice Argomenti</a> ] </font></div>

            </td>

          </tr>

        </table>

        <p align="center"> 

          <? if(isset($admin)) echo "

          <input type=\"submit\" name=\"Submit\" value=\"Cancella messaggi selezionati\">"; ?>

        </p>

      </form>

      <p>&nbsp;</p>

      <p>&nbsp;</p>

    </td>

  </tr>

</table>

<p>&nbsp; </p>

</body>

</html>

