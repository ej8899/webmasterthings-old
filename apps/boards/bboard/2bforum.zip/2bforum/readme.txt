---------------------------------------------------------------------
       +-------------------------------------------------+
       |               2BFORUM Version 1.2               |
       |         Forum de Discussion PHP-MySQL           |
       +-------------------------------------------------+
       | Auteur    : Benjamin PY                         |
       | Web       : http://ben3w.free.fr/               |
       | Mail      : ben3w@free.fr                       |
       | Cr�ation  : 4 Octobre 2002                      |
       | Licence   : GPL                                 |
       +-------------------------------------------------+

Cette application permet de g�rer un ensemble de forums de
discussion. Les utilisateurs n'ont pas besoin d'�tre enregistr�s (il
n'y a donc pas de liste nominative sur 2BForum afin d'�viter toute
d�marche administrative).

2Bforum poss�de les fonctionnalit�s de tout forum :
    - Lecture de la liste des forums
    - Lecture de la liste des messages par forum
    - Consultation des r�ponses apport�es
    - Ajout d'un sujet de discussion
    - Ajout d'une r�ponse � un sujet de discussion

2BForum poss�de des fonctionnalit�s d'administration diverses :
    - possibilit� d'ouvrir/fermer les forums
    - possibilit� de rendre visible/invisible aux utilisateurs le
    contenu des forums

Deplus, il permet la personnalisation de l'affichage des pages, ainsi
que le choix de la langue (francais, anglais ou espagnol)



1 - Syst�me requis

Le d�veloppement de 2BForum a �t� r�alis� avec la configuration
suivante : 
PHP Version 4.0.5
MySQL 3.23.32
Apache/1.3.19

Cette application supporte probablement beaucoup d'autres versions
logicielles, mais c'est � valider au cas par cas...

2BForum marche pleinement (au 4 Juillet 2002) sur les serveurs de Free
et de Ifrance.
Navigateurs test�s : IE6.0, NN6.0, NC4.06, Opera5.12


2 - Conditions d'utilisation

En installant, utilisant ou administrant cette application, vous vous
engagez � :
    - laisser accessible et visible le lien vers le site de l'auteur
    http://ben3w.free.fr/ ;
    - envoyer un mail au cr�ateur de l'application pour indiquer sur
    quel site le script est install� (par simple curiosit�) ;
    - accepter tous les risques (perte de donn�es, surcharge du
    serveur, etc.) li�s � l'installation, l'utilisation ou
    l'administration de 2BForum.


3 - Installation

Consulter le fichier Install.txt pour avoir la proc�dure
d'installation, ainsi que l'aide sur l'utilisation de l'interface
d'administration.


4 - Ajouts

v1.2 : possibilit� de choisir la langue du forum (francais ou anglais)

---------------------------------------------------------------------
                     Benjamin Py - ben3w@free.fr
                        http://ben3w.free.fr/
