<?
//AJOUTER.PHP
$txt_ajmsg = "Votre message a �t� enregistr�";
$txt_merci = "Merci de votre contribution";
$txt_retmsg = "Retourner � la liste des messages";
$txt_retf = "Retourner � la liste des forums";
?>
