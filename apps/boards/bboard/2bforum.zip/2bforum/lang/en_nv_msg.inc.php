<?
//NV_MSG.PHP
$txt_nvmsg = "New message";
$txt_pseudo = "Nickname";
$txt_mail = "Email";
$txt_titre = "Title";
$txt_msg = "Your message";
$txt_post = "Post the message";
$txt_ann = "Abort";
?>
