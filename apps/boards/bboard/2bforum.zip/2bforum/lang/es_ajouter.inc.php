<?
//AJOUTER.PHP
$txt_ajmsg = "Tu mensaje ha sido a�adido";
$txt_merci = "";
$txt_retmsg = "Volver a la lista de mensajes";
$txt_retf = "Volver a la lista de foros";
?>
