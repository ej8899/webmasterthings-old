<?
//NV_MSG.PHP
$txt_nvmsg = "Nouveau message";
$txt_pseudo = "Pseudonyme";
$txt_mail = "Email";
$txt_titre = "Titre";
$txt_msg = "Votre message";
$txt_post = "Poster le message";
$txt_ann = "Annuler";
?>
