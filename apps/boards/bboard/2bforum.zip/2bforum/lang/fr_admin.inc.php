<?
//ADMIN.PHP
$txt_titre = "Interface d'administration de 2bforum";
$txt_act1 = "Cr�er un nouveau forum";
$txt_act2 = "Purger un forum";
$txt_act3 = "Voir la liste des forums";
$txt_act4 = "phpinfo sur le serveur";
$txt_act5 = "Initialiser la page";
$txt_aff = "afficher";
$txt_afft = "afficher le contenu du forum";
$txt_suppr = "supprimer";
$txt_supprt = "supprimer le forum";
$txt_ferm = "fermer";
$txt_fermt = "interdire toute �criture dans le forum";
$txt_ouvr = "ouvrir";
$txt_ouvrt = "permettre des �critures dans le forum";
$txt_inv = "invisible";
$txt_invt = "rendre le forum invisible";
$txt_vis = "visible";
$txt_vist = "rendre le forum visible (consultable)";
$txt_param = "parametrer";
$txt_paramt = "changer le titre du forum ou sa description";
$txt_tabtit = "Titre";
$txt_tabmod = "Modif";
$txt_tabetat = "Etat";
$txt_tabvis = "Visible";
$txt_tabnbmsg = "Nb msg";
$txt_tabnblect = "Nb lect";
?>
