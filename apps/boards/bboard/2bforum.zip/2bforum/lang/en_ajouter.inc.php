<?
//AJOUTER.PHP
$txt_ajmsg = "Your message is added";
$txt_merci = "";
$txt_retmsg = "Back to the list of messages";
$txt_retf = "Back to the list of forums";
?>
