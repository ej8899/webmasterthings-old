<?
//INDEX.PHP
$txt_forum = "Forum";
$txt_messages = "Messages";
$txt_deraj = "Dernier ajout";
$txt_entrerf = "Entrez ici dans le forum";
$txt_fferme = "Forum ferm� par l'administrateur";
$txt_mrepart1 = "messages r�partis";
$txt_mrepart2 = "message r�parti";
$txt_sur = "sur";
$txt_infobas = "Ces forums sont libres d'acc�s et ne n�cessitent pas de poss�der un login et mot de passe pour pouvoir �tre consult�s ou pour y poster un nouveau message";
?>
