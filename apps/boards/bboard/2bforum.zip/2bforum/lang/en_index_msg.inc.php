<?
//INDEX_MSG.PHP
$txt_nbm1 = "No message in the forum";
$txt_nbm2 = "message posted in the forum";
$txt_nbm3 = "messages posted in the forum";
$txt_derpost = "Last post";
$txt_vmsg = "Open the message";
$txt_nbrep1 = "replies";
$txt_nbrep2 = "reply";
$txt_infomsg1 = "viewed";
$txt_infomsg2 = "times";
$txt_infomsg3 = "By";

?>
