<?
//INDEX.PHP
$txt_forum = "Foro";
$txt_messages = "Mensaje";
$txt_deraj = "Ultimo Mensaje";
$txt_entrerf = "Entrar en el foro";
$txt_fferme = "Foro cerrado por el administrador";
$txt_mrepart1 = "mensajes";
$txt_mrepart2 = "mesnsaje";
$txt_sur = "en";
$txt_infobas = "No es necesario registrarse en este foro";
?>
