<?
//ADMIN.PHP
$txt_titre = "2BForum - Administraci�n de la Interfaz";
$txt_act1 = "Crear un nuevo Foro";
$txt_act2 = "Purgar un Foro";
$txt_act3 = "Lista de Foros";
$txt_act4 = "phpinfo";
$txt_act5 = "Initialise the page";
$txt_aff = "Mostrar";
$txt_afft = "Mostrar mensajes";
$txt_suppr = "Borrar";
$txt_supprt = "Borrar foro";
$txt_ferm = "Cerrar";
$txt_fermt = "activar protecci�n de escritura del foro";
$txt_ouvr = "abrir";
$txt_ouvrt = "desactivar protecci�n de escritura del foro";
$txt_inv = "Invisible";
$txt_invt = "activar protecci�n de lectura del foro";
$txt_vis = "visible";
$txt_vist = "desactivar protecci�n de lectura del foro";
$txt_param = "configurar";
$txt_paramt = "Cambiar titulo o descipcci�n del foro";
$txt_tabtit = "Titulo";
$txt_tabmod = "Creado";
$txt_tabetat = "Estado";
$txt_tabvis = "Visible";
$txt_tabnbmsg = "N� msg";
$txt_tabnblect = "Visto";
?>
