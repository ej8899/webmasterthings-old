<?
//LECT_MSG.PHP
$txt_par = "Par";
?>
