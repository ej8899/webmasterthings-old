<?
//NV_MSG.PHP
$txt_nvmsg = "Nuevo mensaje";
$txt_pseudo = "Nickname / Apodo";
$txt_mail = "e-mail";
$txt_titre = "Titulo";
$txt_msg = "Tu mensaje";
$txt_post = "Enviar el mensaje";
$txt_ann = "Anular";
?>
