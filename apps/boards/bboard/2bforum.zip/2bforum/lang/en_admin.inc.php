<?
//ADMIN.PHP
$txt_titre = "2BForum - Administration Interface";
$txt_act1 = "Create a new forum";
$txt_act2 = "Purge a forum";
$txt_act3 = "List of forums";
$txt_act4 = "phpinfo";
$txt_act5 = "Initialise the page";
$txt_aff = "display";
$txt_afft = "display messages";
$txt_suppr = "delete";
$txt_supprt = "delete the forum";
$txt_ferm = "close";
$txt_fermt = "enable write protection on the forum";
$txt_ouvr = "open";
$txt_ouvrt = "disable write protection on the forum";
$txt_inv = "unvisible";
$txt_invt = "enable read protection on the forum";
$txt_vis = "visible";
$txt_vist = "disable read protection on the forum";
$txt_param = "configure";
$txt_paramt = "change title or desctiption of the forum";
$txt_tabtit = "Title";
$txt_tabmod = "Change";
$txt_tabetat = "State";
$txt_tabvis = "Visible";
$txt_tabnbmsg = "Nb msg";
$txt_tabnblect = "Viewed";
?>
