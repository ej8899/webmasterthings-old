<?
//INDEX.PHP
$txt_forum = "Forum";
$txt_messages = "Messages";
$txt_deraj = "Last post";
$txt_entrerf = "Enter the forum";
$txt_fferme = "Forum closed by the administrator";
$txt_mrepart1 = "messages";
$txt_mrepart2 = "message";
$txt_sur = "on";
$txt_infobas = "No registration is required to use this forums";
?>
