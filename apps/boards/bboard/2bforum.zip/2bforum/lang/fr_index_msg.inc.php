<?
//INDEX_MSG.PHP
$txt_nbm1 = "Aucun message dans le forum";
$txt_nbm2 = "message post� dans le forum";
$txt_nbm3 = "messages post�s dans le forum";
$txt_derpost = "Dernier post";
$txt_vmsg = "Voir le message";
$txt_nbrep1 = "r�ponses";
$txt_nbrep2 = "r�ponse";
$txt_infomsg1 = "vu";
$txt_infomsg2 = "fois";
$txt_infomsg3 = "Par";

?>
