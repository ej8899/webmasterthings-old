<?
//INDEX_MSG.PHP
$txt_nbm1 = "No hay mensajes en este foro";
$txt_nbm2 = "mensaje escrito en el foro";
$txt_nbm3 = "mensajes escritos en el foro";
$txt_derpost = "�ltimo post";
$txt_vmsg = "Abrir el mensaje";
$txt_nbrep1 = "respuestas";
$txt_nbrep2 = "responder";
$txt_infomsg1 = "visto";
$txt_infomsg2 = "veces";
$txt_infomsg3 = "por";

?>
