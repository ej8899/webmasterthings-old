<?
// -----------------------  S E C T I O N    1  ------------------------    
// ----------------- connexion � la base de donn�es -------------------
//Laisser en commentaire l'une des 2 configurations suivantes.
//La 1�re est destin�e � la version en ligne sur Internet, la seconde au d�veloppement en local  

//version online (sur le serveur de l'h�bergeur)
//$serveur="sql.free.fr";		// hote ("sql.free.fr" pour Free)
//$utilisateur="monnom2compte";		// login 
//$motdepasse="monmdp";			// password
//$database="monnom2compte"; 		// nom de la database sur le serveur

//version offline (en local), suivant la configuration de votre serveur web local et de MySQL
$serveur="localhost"; 			// "localhost"
$utilisateur="root";			// login
$motdepasse="";				// password
$database="test"; 			// nom de la database sur le serveur

// -----------------------  S E C T I O N    2  ------------------------    
// ------------------ Noms des tables de la database -------------------

$tbl_flist = "fliste";
$tbl_fmsg = "fmessages";


// -----------------------  S E C T I O N    3  ------------------------    
// ---------------------------- Variables ------------------------------

$im_nb_msg_max = 20;			//nb max de msg affich�s par page dans index_msg.php3
$lm_nb_msg_max = 10;			//nb max de msg affich�s par page dans lect_msg.php3


// -----------------------  S E C T I O N    4  ------------------------    
// ----------------------------- Langue --------------------------------
$lang = "es";				//choix du fichier langue (fr / en / es)

?>
