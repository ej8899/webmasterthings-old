<html>
<!-- date de creation: 29/11/2001 -->
<head>
<title></title>

<link rel="stylesheet" type="text/css" href="2bforump.css">
<?
require("connect.inc.php");
$lang_filename = "lang/".$lang."_admin.inc.php";
require($lang_filename);
?>

</head>
<body>
<table border=0 width="100%" bgcolor=#96A6D6 cellpadding=3 cellspacing=0>
  <tr><td class="textefont12" width="100%" align="center"><? echo $txt_titre;?></td></tr>
  <tr><td class="textefont12" align="center"><b>v1.2</b></td></tr>
  <tr><td class="textefont12" align="center"><a href="http://ben3w.free.fr/"><img src="images/powered.gif" border=0 width=90 height=26></a></td></tr>
</table>
<br>
<br>

<?
//connexion a la db
($db = mysql_connect("$serveur", "$utilisateur", "$motdepasse")) or die("<CENTER><A style='color:white;background-color:red'> D�sol�, probl�me de serveur<br>Impossible de se connecter au serveur RC1.1 </BODY></HTML>");
(mysql_select_db("$database",$db))  or die("<CENTER><A style='color:white;background-color:red'> D�sol�, probl�me de serveur<br>Impossible de se connecter a la database RC1.2 </BODY></HTML>");

//------------------------------------------------------------
//fermer un forum - interdire les ecritures
if ($action=="fermer_forum")
{  
   $chaine = "update $tbl_flist set State='ferme' where ForumId=$forumid";
   echo "<font class=textefont10>".$chaine."</font><br>\n";
   $request_msg = MYSQL_QUERY($chaine);
   echo "<center><font class=textefont12>-- Forum <b>".$forumid."</b> ferm� --</font></center><br>";
}

//------------------------------------------------------------
//ouvrir un forum - permettre les ecritures
elseif ($action=="ouvrir_forum")
{
   $chaine = "update $tbl_flist set State='ouvert' where ForumId='$forumid'";
   echo "<font class=textefont10>".$chaine."</font><br>\n";
   $request_msg = MYSQL_QUERY($chaine);   
   echo "<center><font class=textefont12>-- Forum <b>".$forumid."</b> ouvert --</font></center><br>";
}
//------------------------------------------------------------
//rendre un forum visible - permettre les consultations
else if ($action=="visible_oui")
{
   $request_msg = MYSQL_QUERY("update $tbl_flist set visible='oui' where ForumId='$forumid'");
   echo "<center><font class=textefont12>-- Forum <b>".$forumid."</b> visible --</font></center><br>";
}
//------------------------------------------------------------
//rendre un forum invisible - interdire les consultations
else if ($action=="visible_non")
{
   $request_msg = MYSQL_QUERY("update $tbl_flist set visible='non' where ForumId='$forumid'");
   echo "<center><font class=textefont12>-- Forum <b>".$forumid."</b> invisible --</font></center><br>";
}
//------------------------------------------------------------
//supprimer un forum
else if ($action == "supprimer")
{
   if ($confirmer=="oui")
   {
     $chaine="delete from ".$tbl_flist." where ForumId=".$forumid;
	 echo "<font class=textefont10>".$chaine."<br>\n";
     $result_query = mysql_query($chaine);
	 $chaine="delete from ".$tbl_fmsg." where ForumId=".$forumid;
	 echo "<font class=textefont10>".$chaine."<br>\n";	 
     $result_query = mysql_query($chaine);
	 echo "<center><font class=textefont12>-- Forum supprim� --</font></center><br>";
 	 
   }
   else
   {  
     echo "<center><font class=textefont12>CONFIRMATION DE SUPPRESSION DU FORUM <b>".$forumid."</b><br>";
     echo "<br><a href=\"admin.php?action=supprimer&forumid=".$forumid."&confirmer=oui\">CONFIRMER</a>";
	 echo "<br><br><a href=\"admin.php\">ANNULER</a></center></font><br>";
  }
}
//------------------------------------------------------------
//cr�er un nouveau forum (cr�ation des parametres titre forum et commentaire forum)
else if ($action == "creer")
{
  echo "<form method=\"post\" action=\"admin.php?action=creer2\">";
  echo "<center><font class=textefont12>Cr�ation d'un nouveau FORUM<br><br>\n";
  echo "ID <font class=textefont10>(obligatoire)</font> : <input type=\"text\" name=\"newforumid\" size=\"50\"><br>\n";
  echo "Titre <font class=textefont10>(obligatoire)</font> : <input type=\"text\" name=\"newforumtitle\" size=\"50\"><br>\n";
  echo "Commentaire : <br><textarea name=\"newforumcomment\" rows=\"5\" cols=\"50\"></textarea><br>\n";
  echo "<input type=\"submit\" name=\"test\" value=\"Cr�er\">\n";
  echo "</font></center></form><br>\n";
}
//------------------------------------------------------------
//cr�er un nouveau forum dans la base
else if ($action == "creer2")
{
  // D�finition de la date de r�daction du message 
  $date = date("Y-m-d");
  $chaine="insert into ".$tbl_flist." (Forumid,Title,LastModification,State,visible,Commentary) values ('$newforumid','$newforumtitle','$date','ferme','oui','$newforumcomment')";
  $result_query = mysql_query($chaine);
  echo "<font class=textefont10>".$chaine."</font><br><br>";
  echo "<center><font class=textefont12>-- Forum cr�� --</font></center><br>";
}
//------------------------------------------------------------
//parametrer un forum existant (affichage des donnees)
else if ($action == "parametrer")
{
  //recuperation du title et commentary
  $chaine="SELECT * FROM $tbl_flist WHERE forumid=".$forumid;
  $request = MYSQL_QUERY($chaine);
  $max = MYSQL_NUMROWS($request);
  $i=0;
  $titre = mysql_result($request,$i,"Title");
  $titre = stripslashes(stripslashes($titre));
  $comment = mysql_result($request,$i,"Commentary");
  
  //echo "<center>Parametrage du forum</center><br>";
  echo "<form method=\"post\" action=\"admin.php?action=parametrer2&forumid=".$forumid."\">";
  echo "<center><font class=textefont12>Edition des param�tres du forum <b>".$forumid."</b><br>";
  echo "<input value='".$titre."' type=\"text\" name=\"newforumtitle\" size=\"50\"><br>";
  echo "<textarea name=\"newforumcomment\" rows=\"5\" cols=\"50\">".$comment."</textarea><br>";
  echo "<input type=\"submit\" name=\"test\" value=\"Modifier\">\n";
  echo "<input type=\"button\" value=\"Annuler\" name=\"annuler\" onClick=\"document.location='admin.php'\">";
  echo "</font></center></form><br>";
}

//------------------------------------------------------------
//parametrer un forum existant (enregistrement des modifs)
else if ($action == "parametrer2")
{
  // D�finition de la date de r�daction du message 
  $date = date("Y-m-d");
  $chaine="update ".$tbl_flist." set Title='".$newforumtitle."',Commentary='".$newforumcomment."',Lastmodification='".$date."' where ForumId=".$forumid;
  $result_query = mysql_query($chaine);
  echo "<font class=textefont10>".$chaine."</font><br><br>\n";
  echo "<center><font class=textefont12>-- Modification effectu�e --</font></center><br>";
}

//------------------------------------------------------------
//afficher le contenu d'un forum
else if ($action == "afficher")
{
  $chaine = "SELECT title FROM $tbl_flist WHERE forumid='".$forumid."'";
  $request_list = MYSQL_QUERY($chaine);
  $titre_forum = mysql_result($request_list,"0","title");
  $titre_forum = stripslashes(stripslashes($titre_forum));
  $titre_forum = ucfirst($titre_forum);
  $request = MYSQL_QUERY("SELECT id FROM $tbl_fmsg WHERE forumid=$forumid");
  $max_mess = MYSQL_NUMROWS($request);
  $chaine="SELECT * FROM $tbl_fmsg WHERE forumid=$forumid ORDER BY $order";
  $req = MYSQL_QUERY($chaine);
  echo "<font class=textefont10>".$chaine."</font><br><br>\n";
  $res = MYSQL_NUMROWS($req);
  // affichage tableau haut -------------
  echo "<div class=\"textefont12\">";
  echo "Forum ".$titre_forum." (id=".$forumid.")<br><br>";

  if ($max_mess == 0)
    {echo "Aucun message dans le forum";}
  elseif ($max_mess == 1)
    {echo "<b>1</b> message post� dans le forum";}
  else
    {echo "<b>".$max_mess."</b> messages post�s dans le forum";}
  echo "</div><br>";
  //tableau contenant la barre de titre et lesdonnees
  echo "<table border=0 cellspacing=1 cellpadding=5 width=100%>";
  echo "<tr><td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=id\">id</a></b></td><td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=nom\">nom</a></b></td>\n";
  echo "<td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=email\">email</a></b></td><td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=date\">date</a></b></td>\n";
  echo "<td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=titre\">titre</a></b></td><td width=200 class=textefont10 bgcolor=#A2A7C6><b>texte</b></td>\n";
  echo "<td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=reponse_a_id\">reponse a id</a></b></td><td class=textefont10 bgcolor=#A2A7C6><b><a href=\"admin.php?action=afficher&forumid=".$forumid."&order=lect\">lect</a></b></td>\n";
  echo "<td class=textefont10 bgcolor=#A2A7C6><b>nb rep</b></td><td class=textefont10 bgcolor=#A2A7C6>&nbsp;</td></tr>\n";
  
  $i=0;
  WHILE($i<$res) 
  {

  $id = mysql_result($req,$i,"id");
  $nom = mysql_result($req,$i,"nom");
  $email = mysql_result($req,$i,"email");
  $date = mysql_result($req,$i,"date");
  $date = $date." ".mysql_result($req,$i,"heure");
  $titre = mysql_result($req,$i,"titre");
  $tex = mysql_result($req,$i,"texte");
 
  $nom = stripslashes($nom);
  $email = stripslashes($email);
  $tex = stripslashes($tex);
  $titre = stripslashes($titre);
  
  $repaid = mysql_result($req,$i,"reponse_a_id");
  $lect = mysql_result($req,$i,"lect");
  
  echo "<tr align=left>";
  echo "<td class=textefont10 bgcolor=#FCF0E0>".$id."</td><td class=textefont10 bgcolor=#FCF0E0>".$nom."</td><td class=textefont10 bgcolor=#FCF0E0>".$email."</td><td class=textefont10 bgcolor=#FCF0E0>".$date."</td>\n";
  echo "<td class=textefont10 bgcolor=#FCF0E0>".$titre."</td><td class=textefont10 bgcolor=#FCF0E0>".$tex."</td><td class=textefont10 bgcolor=#FCF0E0>".$repaid."</td><td class=textefont10 bgcolor=#FCF0E0>".$lect."</td>\n";
  if ($repaid != 0)
  {echo "<td class=textefont10 bgcolor=#FCF0E0>X</td>";}
  else
  {
  	$chaine_2 = "SELECT count(id) FROM $tbl_fmsg WHERE reponse_a_id='".$id."'";
  	$request_list_2 = MYSQL_QUERY($chaine_2);
	$nb_rep = mysql_result($request_list_2,0,"count(id)");
	echo "<td class=textefont10 bgcolor=#FCF0E0>".$nb_rep."</td>";
  }
  echo "<td class=textefont10 bgcolor=#FCF0E0><a href=\"admin.php?action=suppr_msg&id=".$id."\">suppr</a> - <a href=\"admin.php?action=editer&id=".$id."\">edit</a></td>";  
  echo "</tr>";
  $i++;
  } 
  echo "</table>";
  //echo "</td></tr></table>";
}

//------------------------------------------------------------
//supprimer un ou plusieurs messages dans un forum
else if ($action == "suppr_msg")
{
  if ($confirm != "ok")
  {
    echo "<center><font class=textefont12>Confirmation de suppression : <br>";
	$chaine = "SELECT titre FROM $tbl_fmsg WHERE id='".$id."'";
  	$request_list = MYSQL_QUERY($chaine);
	$titre = mysql_result($request_list,0,"titre");
	echo "supprimer le message \"".$titre."\"";
	$chaine_2 = "SELECT count(id) FROM $tbl_fmsg WHERE reponse_a_id='".$id."'";
  	$request_list_2 = MYSQL_QUERY($chaine_2);
	$nb_rep = mysql_result($request_list_2,0,"count(id)");
	if ($nb_rep == 0)
	{echo " (message sans r�ponse) ?<br><br>";}
	else {echo " et ses ".$nb_rep." r�ponses associ�es ?<br><br>";}
	echo "<a href=\"admin.php?action=suppr_msg&id=".$id."&confirm=ok\">OK</a><br><br><a href=\"admin.php\">ANNULER</a></font></center><br><br>";
  }
  else
  {  
     $chaine="delete from ".$tbl_fmsg." where id=".$id;
	 echo "<font class=textefont10>".$chaine."</font><br>\n";
     $result_query = mysql_query($chaine);
	 $chaine="delete from ".$tbl_fmsg." where reponse_a_id=".$id;
	 echo "<font class=textefont10>".$chaine."</font><br>\n";
     $result_query = mysql_query($chaine);
	 echo "<br><center><font class=textefont12>-- Message(s) supprim�(s) --</font></center><br>";
   }
}

//------------------------------------------------------------
//Purger un forum (determiner les parametres)
else if ($action == "purger")
{
  $chaine="SELECT * FROM $tbl_flist";
  $request = MYSQL_QUERY($chaine);
  $max = MYSQL_NUMROWS($request);
  $i=0;
  echo "<form method=\"post\" action=\"admin.php?action=purger2\">";
  echo "<center><font class=textefont12>Dans le forum : <br><select name=forumid>";
  echo "<option value=*>Tous</option>";
  WHILE($i<$max) 
  { 
    $idf = mysql_result($request,$i,"Forumid");
	$titre = mysql_result($request,$i,"Title");
	echo "<option value=".$idf.">".$titre."</option>";
	$i++;
  }
  echo "</select><br><br>";
  echo "Supprimer les messages post�s avant la date (date US. Ex : 2001-11-25) :<br>";
  echo "<input type=\"text\" name=\"date\" size=\"25\"><br>";
  echo "<input type=\"submit\" name=\"test\" value=\"Purger\">&nbsp;";
  echo "<input type=\"button\" value=\"Annuler\" name=\"annuler\" onClick=\"document.location='admin.php'\">";
  echo "</font></center></form<br><br><br>";
}
//------------------------------------------------------------
//purger un forum - validation
else if ($action == "purger2")
{
  if ($confirmer=="oui")
  {
    //mysql_select_db("$database",$db);
	//$chaine="DELETE FROM ".$tbl_fmsg." WHERE (date_verif<'".$date."')";
	//if ($forumid!="*") {$chaine = $chaine." AND forumid=".$forumid;}
	//$result_query = mysql_query($chaine);
	//echo "Suppression effectu�e<br>";
	
	$chaine="SELECT id FROM ".$tbl_fmsg." WHERE (reponse_a_id='0') AND (date_verif<'".$date."')";
	if ($forumid!="*") {$chaine = $chaine." AND forumid=".$forumid;}
	$result_query = mysql_query($chaine);
	$nbrow = MYSQL_NUMROWS($result_query);
	$i=0;
	$nbsupprfils=0;
    WHILE($i<$nbrow) 
    {
       //delete des fils
	   $id = mysql_result($result_query,$i,"id");

	   //$chaine2="SELECT id FROM ".$tbl_fmsg." WHERE reponse_a_id=".$id;
	   $chaine2="DELETE FROM ".$tbl_fmsg." WHERE reponse_a_id=".$id;
	   echo "<font class=textefont10>".$chaine2."</font><br>\n";
	   $result_query2 = mysql_query($chaine2);
       //$nbrow2 = MYSQL_NUMROWS($result_query2);
	   $nbrow2 = mysql_affected_rows();
	   $nbsupprfils=$nbsupprfils + $nbrow2;
       //delete du root
	   $chaine2="DELETE FROM ".$tbl_fmsg." WHERE id=".$id;
	   echo "<font class=textefont10>".$chaine2."</font><br>\n";
	   $result_query2 = mysql_query($chaine2);
	   $i++;
	 }
	echo "<br><center><font class=textefont12>-- ".$nbrow." messages p�res effac�s ; ".$nbsupprfils." messages fils effac�s --</font></center><br>";
	
  }
  else
  {
    $chaine="SELECT id FROM ".$tbl_fmsg." WHERE (reponse_a_id='0') AND (date_verif<'".$date."')";
	if ($forumid!="*") {$chaine = $chaine." AND forumid=".$forumid;}
	$request = MYSQL_QUERY($chaine);
    $max = MYSQL_NUMROWS($request);
	
	$i=0;
	$nbsuppr=0;
    WHILE($i<$max) 
    {
       //calcul du nb de fil a detruire
	   $id = mysql_result($request,$i,"id");
	   $chaine2="SELECT id FROM ".$tbl_fmsg." WHERE reponse_a_id=".$id;
	   $result_query2 = mysql_query($chaine2);
       $nbrow2 = MYSQL_NUMROWS($result_query2);
	   $nbsuppr=$nbsuppr + $nbrow2;
       $i++;
	 }
    echo "<center><font class=textefont12>Attention : <b>".$max."</b> messages p�res sont sur le point d'�tre supprim�s directement !<br>";
	echo "<b>".$nbsuppr."</b> messages fils seront alors supprim�s<br><br>";
	echo "<a href=\"admin.php?action=purger2&date=".$date."&forumid=".$forumid."&confirmer=oui\">Confirmer</a><br><br>";
	echo "<a href=\"admin.php\">Annuler</a></font></center><br><br>";
  }
}
//------------------------------------------------------------
//purger un forum - validation
else if ($action == "phpinfo")
{
phpinfo();
}

//------------------------------------------------------------
//Edition d'un msg (saisie des nvelles valeurs)
elseif ($action == "editer")
{
  $chaine = "SELECT * FROM $tbl_fmsg WHERE id='".$id."'";
  echo "<font class=textefont10>$chaine</font><br><br>";
  $request_list = MYSQL_QUERY($chaine);
  $aid = mysql_result($request_list,0,"id");
  $aforumid = mysql_result($request_list,0,"forumid");
  $anom = mysql_result($request_list,0,"nom");
  $aemail = mysql_result($request_list,0,"email");
  $adate_verif = mysql_result($request_list,0,"date_verif");
  $adate = mysql_result($request_list,0,"date");
  $aheure = mysql_result($request_list,0,"heure");
  $atexte = mysql_result($request_list,0,"texte");
  $areponse_a_id = mysql_result($request_list,0,"reponse_a_id");
  $alect  = mysql_result($request_list,0,"lect");
  $atitre  = mysql_result($request_list,0,"titre");
  
  $anom = stripslashes($anom);
  $aemail = stripslashes($aemail);
  $atitre = stripslashes($atitre);
    
  echo "<table border=0 cellspacing=1 cellpadding=5 align=center bgcolor=#cccccc><tr><td>\n";
  echo "<form name=forumlaire action=\"admin.php?action=editerupdate\" method=\"post\">\n";
  echo "<tr><td class=textefont10>id :</td><td><input type=\"text\" name=\"newid\" size=10 maxlength=40 value=\"$aid\" readonly></td></tr>\n";
  echo "<tr><td class=textefont10><b>forumid :</b></td><td><input type=\"text\" name=\"newforumid\" size=20 maxlength=40 value=\"$aforumid\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>nom :</b></td><td><input type=\"text\" name=\"newnom\" size=20 maxlength=40 value=\"$anom\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>email :</b></td><td><input type=\"text\" name=\"newemail\" size=50 maxlength=50 value=\"$aemail\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>date_verif :</b></td><td><input type=\"text\" name=\"newdate_verif\" size=10 maxlength=40 value=\"$adate_verif\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>date :</b></td><td><input type=\"text\" name=\"newdate\" size=30 maxlength=60 value=\"$adate\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>heure :</b></td><td><input type=\"text\" name=\"newheure\" size=30 maxlength=60 value=\"$aheure\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>texte :<br><font color=red>ATTENTION CARACT SPECIAUX</font></b></td><td><textarea name=\"newtexte\" rows=\"5\" cols=\"40\">$atexte</textarea></td></tr>\n";
  echo "<tr><td class=textefont10>reponse_a_id :</td><td><input type=\"text\" name=\"newreponse_a_id\" size=20 maxlength=40 value=\"$areponse_a_id\" readonly></td></tr>\n";
  echo "<tr><td class=textefont10><b>lect :</b></td><td><input type=\"text\" name=\"newlect\" size=50 maxlength=100 value=\"$alect\"></td></tr>\n";
  echo "<tr><td class=textefont10><b>titre :</b></td><td><input type=\"text\" name=\"newtitre\" size=50 maxlength=100 value=\"$atitre\"></td></tr>\n";
  
  echo "<tr><td colspan=2 align=center><input value=\"Modifier\" type=\"submit\"/>&nbsp;<input value=\"Annuler\" type=\"button\" onclick=\"window.location='admin.php'\"</td></tr>\n";
  echo "</form>";
  echo "</table>\n";
}

//------------------------------------------------------------
//Edition d'un msg (enregistrement des maj)
elseif ($action == "editerupdate")
{
  $newnom = htmlentities($newnom);
  $newnom = addslashes($newnom);
  $newemail = htmlentities($newemail);
  $newemail = addslashes($newemail);
  $newtitre = htmlentities($newtitre);
  $newtitre = addslashes($newtitre);
  //$newtelephone = htmlentities($newtelephone);
  //$newtelephone = addslashes($newtelephone);
  //$newcommentaire = htmlentities($newcommentaire);
  //$newcommentaire = addslashes($newcommentaire);
  //$newcommentaire = nl2br($newcommentaire);
  
  $chaine = "update $tbl_fmsg set forumid='$newforumid',nom='$newnom',email='$newemail',date_verif='$newdate_verif',date='$newdate',heure='$newheure',texte='$newtexte',reponse_a_id='$newreponse_a_id',lect='$newlect',titre='$newtitre' where id=$newid";
  echo "<font class=textefont10>$chaine</font><br><br>";
  $request_msg = MYSQL_QUERY($chaine);
}


?>




<?
//**************************************************************************
//Affichage des infos sur les forums

echo "<br><hr width=80%>\n<br>";

$request_list = MYSQL_QUERY("SELECT * FROM $tbl_flist WHERE state='ouvert'");
$max_list = MYSQL_NUMROWS($request_list);
$chaine="SELECT count(*) FROM ".$tbl_fmsg." v1, ".$tbl_flist." v2 where v1.forumid=v2.forumid AND v2.state='ouvert'";
$request_msg = MYSQL_QUERY($chaine);
$max_mess = mysql_result($request_msg,"0","count(*)");
echo "<div class=\"textefont12\">FORUM OUVERTS : Il y a actuellement <b>".$max_mess."</b> messages acc�ssibles sur <b>".$max_list."</b> forums ouverts<br>";


$request_msg = MYSQL_QUERY("SELECT * FROM $tbl_fmsg");
$max_mess = MYSQL_NUMROWS($request_msg);
$request_list = MYSQL_QUERY("SELECT * FROM $tbl_flist order by forumid");
$max_list = MYSQL_NUMROWS($request_list);
echo "TOUS LES FORUMS : Il y a actuellement <b>".$max_mess."</b> messages r�partis sur <b>".$max_list."</b> forums</div><br>";

echo "<table>\n";
echo "<tr align=center class=\"textefont12\" bgcolor=\"#ccccff\"><td width=50><b>id</b></td><td width=200><b>$txt_tabtit</b></td><td width=100><b>$txt_tabmod</b></td><td width=70><b>$txt_tabetat</b></td><td width=70><b>$txt_tabvis</b></td><td width=60><b>$txt_tabnbmsg</b></td><td width=60><b>$txt_tabnblect</b></td><td><b>Actions</b></td></tr>\n";
$i=0;
WHILE($i<$max_list) 
{
  // on r�cup�re la valeur des differents champs de la table flist
  $id = mysql_result($request_list,$i,"Forumid");
  $titre = mysql_result($request_list,$i,"Title");
  $modif = mysql_result($request_list,$i,"LastModification");
  $etat = mysql_result($request_list,$i,"State");
  $visible = mysql_result($request_list,$i,"visible");
  $chaine = "SELECT count(id),sum(lect) FROM $tbl_fmsg WHERE forumid=".$id;
  $request_msg = MYSQL_QUERY($chaine);
  $nb_msg = mysql_result($request_msg,0,"count(id)");
  $nb_lect = mysql_result($request_msg,0,"sum(lect)");
  //$nb_msg = MYSQL_NUMROWS($request_msg);

  if ($etat=='ouvert') {$bgcoloretat="#2cc43f";} else {$bgcoloretat="#ff5d61";} 
  if ($visible=='oui') {$bgcolorvisible="#E6E6E6";} else {$bgcolorvisible="#8c8c8c";} 
  
  
  echo "<tr class=\"textefont12\" align=center>\n";
  echo "<td bgcolor=#E6E6E6>".$id."</td>\n";
  echo "<td bgcolor=#E6E6E6><a href=\"admin.php?action=afficher&forumid=".$id."&order=date_verif\" title=\"$txt_afft\">".$titre."</a></td>\n";
  echo "<td bgcolor=#E6E6E6>".$modif."</td>\n";
  echo "<td bgcolor=".$bgcoloretat.">".$etat."</td>\n";
  echo "<td bgcolor=".$bgcolorvisible.">".$visible."</td>\n";
  echo "<td bgcolor=#E6E6E6>".$nb_msg."</td>\n";
  echo "<td bgcolor=#E6E6E6>".$nb_lect."</td>\n";
  echo "<td bgcolor=#E6E6E6><a href=\"admin.php?action=supprimer&forumid=".$id."\" title=\"$txt_supprt\">$txt_suppr</a> - ";
  if ($etat=='ouvert')
    {echo "<a href=\"admin.php?action=fermer_forum&forumid=".$id."\" title=\"$txt_fermt\">$txt_ferm</a> - ";}
  else
    {echo "<a href=\"admin.php?action=ouvrir_forum&forumid=".$id."\" title=\"$txt_ouvrt\">$txt_ouvr</a> - ";}
  if ($visible=='oui')
  	{echo "<a href=\"admin.php?action=visible_non&forumid=".$id."\" title=\"$txt_invt\">$txt_inv</a> - ";}
  else 
    {echo "<a href=\"admin.php?action=visible_oui&forumid=".$id."\" title=\"$txt_vist\">$txt_vis</a> - ";}	
  echo "<a href=\"admin.php?action=parametrer&forumid=".$id."\" title=\"$txt_paramt\">$txt_param</a> -";
  echo " <a href=\"admin.php?action=afficher&forumid=".$id."&order=date_verif\" title=\"$txt_afft\">$txt_aff</a>";
  
  echo "</td></tr>\n";
  $i++;
} 
echo "</td></tr></table>\n";	
mysql_close();


?>



<br>
<br><center><div class="textefont12">
<a href="admin.php?action=creer"><? echo $txt_act1;?></a><br>
<br>
<a href="admin.php?action=purger"><? echo $txt_act2;?></a><br>
<br>
<a href="index.php" target="_blank"><? echo $txt_act3;?></a><br>
<br>
<a href="admin.php?action=phpinfo"><? echo $txt_act4;?></a><br>
<br>
<a href="admin.php"><? echo $txt_act5;?></a><br>
<br>
</div></center>
<br><br><hr width=80%><br>
</html>
