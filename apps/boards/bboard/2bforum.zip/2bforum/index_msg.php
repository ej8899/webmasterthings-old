<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?
require("connect.inc.php");
$lang_filename = "lang/".$lang."_index_msg.inc.php";
require($lang_filename);
require("presentation.inc.php");
//affichage menus et presentation reference
HAUTPAGEWEB("2BForum - Liste des messages post�s");

//connexion � la database
($db = @mysql_connect("$serveur", "$utilisateur", "$motdepasse")) or erreurRC("Impossible de se connecter au serveur<br>ERREUR RC2.1");
@mysql_select_db("$database",$db) or erreurRC("Impossible de se connecter � la database<br>ERREUR RC2.2");

//securite 0
ereg("([0-9]*)",$forumid,$secereg); 
if (($forumid != $secereg[0]) OR ($forumid=="")) {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.2<br>");}

// s�curit� 1: v�rification qu'il existe 1 forum � l'id demand�e
$chaine="SELECT forumid FROM $tbl_flist WHERE forumid=".$forumid;
$request = MYSQL_QUERY($chaine);
$res = MYSQL_NUMROWS($request);
if ($res!=1)
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC2.3<br>");
}
// s�curit� 2: v�rification que le forum est bien visible et ouvert
$chaine="SELECT State,visible FROM $tbl_flist WHERE forumid=".$forumid;
$request = MYSQL_QUERY($chaine);
$etat = mysql_result($request,$i,"State");
$visible = mysql_result($request,$i,"visible");
if (($etat=='ferme') or ($visible=='non'))
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC2.4<br>");
}


if ($offset == "") {$offset=0;}

$request_list = MYSQL_QUERY("SELECT title FROM $tbl_flist WHERE forumid=$forumid");
$titre_forum = mysql_result($request_list,"0","title");
$titre_forum = stripslashes(stripslashes($titre_forum));
$titre_forum = ucfirst($titre_forum);
$request = MYSQL_QUERY("SELECT id FROM $tbl_fmsg WHERE forumid=$forumid");
$max_mess = MYSQL_NUMROWS($request);
$req = MYSQL_QUERY("SELECT * FROM $tbl_fmsg WHERE forumid=$forumid AND reponse_a_id='0' ORDER BY date_verif DESC");
$res = MYSQL_NUMROWS($req);
// affichage tableau haut -------------

echo "<table cellpadding=0 cellspacing=0 border=0>\n";
echo "<tr><td><img src=\"images/folder_open.gif\" border=0></td><td colspan=2 class=\"titremsg\"><b>".$titre_forum."</b></td></tr>\n";
echo "</table><br>\n";
echo "<font class=\"contenu\">\n";
if ($max_mess == 0)
  {echo $txt_nbm1."\n";}
elseif ($max_mess == 1)
  {echo "<b>1</b> $txt_nbm2\n";}
else
  {echo "<b>".$max_mess."</b> $txt_nbm3\n";}
echo "</font><br><br>";

echo "<table cellspacing=0 cellpadding=0 bgcolor=#000000 align=center border=0><tr><td>\n";
echo "<table cellspacing=1 cellpadding=0 border=0>\n";
echo "<tr>\n";
echo "<td height=25 class=\"barrehaut\" bgcolor=#5c63a6 width=\"285\">";

//barre de navigation
if ($offset == "") {$offset=0;}
$nb_pages_max = 10; //nb max de liens � afficher 

$nav="";
$index_afficher=1;
$index_msg=0;

if ($res == 0) {$nav = "[<b>1</b>]";}
while ($index_msg < $res)
{
  if ($offset==$index_msg)
      {$nav = $nav."[$index_afficher]&nbsp&nbsp";}
  else
      {$nav = $nav."<a href=\"index_msg.php?forumid=".$forumid."&offset=".$index_msg."\" class=\"barrehautlien\"><b>$index_afficher</b></a>&nbsp&nbsp";}
  $index_afficher++;
  if ($index_afficher == ($nb_pages_max+1))
  {
    $nav = $nav."...";
	$index_msg=$res;
  }
  $index_msg=$index_msg+$im_nb_msg_max;
} 
echo "<font class=\"barrehaut\">&nbsp;&nbsp;&nbsp;&nbsp;<b>Pages</b> :&nbsp&nbsp".$nav."</font>\n";

echo "</td>\n";
echo "<td width=155 class=\"barrehaut\" bgcolor=#5c63a6><center><b>Infos</b></center></td>\n<td width=120 class=\"barrehaut\" bgcolor=#5c63a6><center><b>$txt_derpost</b></center></td>\n</tr>\n";

$req = MYSQL_QUERY("SELECT * FROM $tbl_fmsg WHERE forumid=$forumid AND reponse_a_id='0' ORDER BY date_verif DESC LIMIT $offset,$im_nb_msg_max");
$res = MYSQL_NUMROWS($req);

$i=0;
WHILE($i<$res) 
{

  $id = mysql_result($req,$i,"id");
  $nom = mysql_result($req,$i,"nom");
  $email = mysql_result($req,$i,"email");
  $date = mysql_result($req,$i,"date");
  $heure = mysql_result($req,$i,"heure");
  $titre = mysql_result($req,$i,"titre");
  $lect = mysql_result($req,$i,"lect");
  
  $nom = stripslashes($nom);
  $email = stripslashes($email);
  $titre = stripslashes($titre);
  
  $rep = mysql_query("SELECT reponse_a_id FROM $tbl_fmsg WHERE reponse_a_id='$id'");
  $nb_rep = mysql_numrows($rep);

  if($nb_rep>'1'){ $reptexte = " et les r�ponses apport�es"; }
  elseif($nb_rep=='1'){ $reptexte = " et la r�ponse apport�e"; }
  elseif($nb_rep=='0'){ $reptexte = ""; }
  
  if ($nb_rep>'0')
  {
    $chaine = "SELECT max(date_verif) FROM ".$tbl_fmsg." WHERE reponse_a_id=".$id;//dernier ajout de reponse (date le plus grand)
    $request = MYSQL_QUERY($chaine);
    $dernierajout = mysql_result($request,"0","max(date_verif)");
    $chaine = "SELECT date, heure FROM ".$tbl_fmsg." WHERE reponse_a_id=".$id." AND date_verif='".$dernierajout."'";//derniere modif (date et heure du date_verif)
    $request = MYSQL_QUERY($chaine);
    $date = mysql_result($request,"0","date");
    $heure = mysql_result($request,"0","heure");
  }
  
  //if($linebgcolor=="#E5E1D1"){ $linebgcolor="#C0C0C0"; }else{ $linebgcolor="#E5E1D1"; }
  $linebgcolor=="#FFFFFF";
  echo "<tr height=25 bgcolor=\"".$linebgcolor."\" align=left>\n";
  echo "<td bgcolor=#ffffff>\n<table border=0><tr><td valign=top><img src=\"images/msg.gif\" border=0></td><td width=280><a class=\"titremsg\" href=\"lect_msg.php?rootid=".$id."&forumid=".$forumid."\" title=\"$txt_vms\"><div style=\"text-align:justify;\"><b>".$titre."</b></div></a></td></tr></table>\n</td>\n";
  echo "<td  width=175 class=\"contenu\" align=left bgcolor=#EFEFEF>\n";
  echo "  <table cellspacing=0 cellpadding=3 border=0><tr><td class=\"contenu\" align=left bgcolor=#EFEFEF><div style=\"text-align:justify;\"><b>".$nb_rep."</b>";
  if ($nb_rep > 1)
    {echo " $txt_nbrep1";}
  else
    {echo " $txt_nbrep2";}
  if ($nom=="")
  {$nom="..";}
  echo ", $txt_infomsg1 <b>".$lect."</b> $txt_infomsg2<br>$txt_infomsg3 <font color=#9C0000>".$nom."</font></div>\n";
  echo "  </td></tr></table>\n";
  echo "</td>\n<td align=center class=\"contenu\" bgcolor=#EFEFEF>".$date."&nbsp;&nbsp;&nbsp;".$heure."</td>\n";
  echo "</tr>\n";
    
  $i++;
} 

//bas de page
echo "<tr><td colspan=3 bgcolor=#898ebc>\n";

//tableau de liens
echo "<table cellspacing=0 cellpadding=0 border=0 width=\"100%\"><tr>\n";
echo "    <td bgcolor=#898ebc width=10></td>\n";
echo "    <td bgcolor=#898ebc valign=middle width=\"151\"><a href=\"nv_msg.php?act=new&forumid=".$forumid."\"><img src=\"images/bt_".$lang."_nvmsg.gif\" border=\"0\" width=\"151\" height=\"22\"></a></td>\n";
echo "    <td bgcolor=#898ebc width=20></td>\n";
echo "    <td bgcolor=#898ebc valign=middle width=\"149\"><a href=\"index.php\"><img src=\"images/bt_".$lang."_listf.gif\" border=\"0\" width=\"149\" height=\"22\"></a></td>\n";
echo "    <td bgcolor=#898ebc width=200></td>\n";
echo "    <td align=left bgcolor=#898ebc width=\"90\"><a href=\"http://ben3w.free.fr/\"><img src=\"images/powered.gif\" border=0 width=90 height=26></a></td>\n"; 
echo "</tr></table>\n";

echo "</td></tr></table>\n";
echo "</td></tr></table>\n";




MYSQL_CLOSE();

BASPAGEWEB();
?>
