<?
function HAUTPAGEWEB($letitre)
{
  echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n";
  echo "<HTML>\n"; 
  echo "<HEAD>\n";
  
  //--------------------------------
  //DO NOT REMOVE OR CHANGE THE NEXT LINE !!!!
  echo "  <TITLE>".$letitre."</TITLE>\n";
  //--------------------------------

  echo "  <META http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">";
  echo "  <META name=\"Description\" content=\"2BForum\" lang=fr>";
  echo "  <META name=\"Keywords\" content=\"keywords\">";
  echo "  <META name=\"Author\" content=\"votre nom\">";
  echo "  <META content=index,follow name=robots>";
  echo "  <META content=\"1 month\" name=revisit-after>";
  
  //--------------------------------
  //DO NOT REMOVE OR CHANGE THE NEXT LINE !!!!
  echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"2bforump.css\">\n";
  //--------------------------------
  
  echo "<style>\n";
  echo "</style>\n";

  echo "</head>\n";
  echo "<BODY bgColor=#FFFFFF>\n";
  echo "<TABLE cellSpacing=0 cellPadding=0 width=750 align=center border=0>\n";
  echo "	<tr>\n";
  echo "	  <td>\n";
}


function BASPAGEWEB()
{
  echo "<br>";
  echo "  	  </td>\n";
  echo "	</tr>\n";
  echo "  </table>\n";
  echo "</body>\n";
  echo "</html>\n";
}


function erreurRC( $message )
{ 
  echo "<CENTER><font class=textefont12><font style='color:white;background-color:red'> D�sol�, probl�me serveur</a><br><br>\n";
  echo $message ;
  echo "</font></font></center><br><br>\n";
  BASPAGEWEB();
  exit;
}


?>
