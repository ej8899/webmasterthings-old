<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?
require("connect.inc.php");
require("presentation.inc.php");
//affichage menus et presentation reference
HAUTPAGEWEB("2BForum - Messages post�s");

/* connexion � la base de donn�es ------------------------------------------- */
($db = @mysql_connect("$serveur", "$utilisateur", "$motdepasse")) or erreurRC("Impossible de se connecter au serveur<br>ERREUR RC3.1");
@mysql_select_db("$database",$db) or erreurRC("Impossible de se connecter � la database<br>ERREUR RC3.2");


//securit� 1 : v�rification que forumid en paramatre = forum id du paramatre rootid
$chaine = "SELECT forumid FROM $tbl_fmsg WHERE id=".$rootid;
$request = MYSQL_QUERY($chaine);
$forumid_src = mysql_result($request,0,"forumid");
if ($forumid_src != $forumid)
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC3.3<br>");
}

//securit� 2 : v�rification que le forum est bien visible et ouvert 
$chaine="SELECT State,visible FROM $tbl_flist WHERE forumid=".$forumid_src;
$request = MYSQL_QUERY($chaine);
$etat = mysql_result($request,0,"State");
$visible = mysql_result($request,0,"visible");
if (($etat=='ferme') or ($visible=='non'))
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC3.3<br>");
}

//titre arborescent
$request_list = MYSQL_QUERY("SELECT title FROM $tbl_flist WHERE forumid=$forumid");
$titre_forum = mysql_result($request_list,"0","title");
$titre_forum = stripslashes(stripslashes($titre_forum));
$titre_forum = ucfirst($titre_forum);
$request_list = MYSQL_QUERY("SELECT titre FROM $tbl_fmsg WHERE id=$rootid");
$titre_msg = mysql_result($request_list,"0","titre");
$titre_msg = stripslashes(stripslashes($titre_msg));
$titre_msg = ucfirst($titre_msg);

echo "<table cellpadding=0 cellspacing=0 border=0>\n";
echo "<tr><td><img src=\"images/folder_open.gif\" border=0></td><td colspan=2><a href=\"index_msg.php?forumid=".$forumid."\" class=\"titremsg\"><b>".$titre_forum."</b></a></td></tr>\n";
echo "<tr><td align=center><img src=\"images/coude.gif\" border=0 width=15 height=18></td><td><img src=\"images/msg.gif\" border=0 width=24 height=12></td><td class=\"contenu\"><b>".$titre_msg."</b></td></tr>\n";
echo "</table><br>\n";

echo "<table cellspacing=0 cellpadding=0 border=0 bgcolor=#9C9A9C width=585 align=center><tr><td>\n";
echo "<table cellspacing=1 cellpadding=0 border=0 width=585>\n";
echo "<tr><td height=25 class=\"barrehaut\" bgcolor=#5c63a6>\n";

//barre de navigation
if ($offset == "") {$offset=0;}
$nb_pages_max = 10; //nb max de liens � afficher dans la barre de nav
$request = MYSQL_QUERY("SELECT count(id) FROM $tbl_fmsg WHERE reponse_a_id='$rootid'");
$nb_reponses = mysql_result($request,0,"count(id)");

$nav="";
$index_afficher=1;
$index_msg=0;
if ($nb_reponses==0) {$nav = $nav."[<b>1</b>]";}

while ($index_msg < $nb_reponses)
{
  if ($offset==$index_msg)
      {$nav = $nav."[$index_afficher]&nbsp&nbsp";}
  else
      {$nav = $nav."<a href=\"lect_msg.php?rootid=".$rootid."&forumid=".$forumid."&offset=".$index_msg."\" class=\"barrehautlien\"><b>$index_afficher</b></a>&nbsp;&nbsp;";}
  $index_afficher++;
  if ($index_afficher == ($nb_pages_max+1))
  {
	$nav = $nav."...";
	$index_msg=$nb_reponses;
  }
  $index_msg=$index_msg+$lm_nb_msg_max;
} 
echo "<font class=\"barrehaut\">&nbsp;&nbsp;&nbsp;&nbsp;<b>Pages</b> :&nbsp&nbsp".$nav."</font>\n";



//----------------------------------------------------------------------
// Affichage du message original si l'offset=0
if ($offset==0)
{
$request = MYSQL_QUERY("SELECT * FROM $tbl_fmsg WHERE id='$rootid'");
$id = mysql_result($request,0,"id");
$nam = mysql_result($request,0,"nom");
$mai = mysql_result($request,0,"email");
$dat = mysql_result($request,0,"date");
$heu = mysql_result($request,0,"heure");
$tex = mysql_result($request,0,"texte");
$lec = mysql_result($request,0,"lect");
$tit = mysql_result($request,0,"titre");

$nam = stripslashes($nam);
$mai = stripslashes($mai);
$tit = stripslashes($tit);
$tex = stripslashes($tex);

echo "<tr><td bgcolor=#ffffff class=\"titreforum\" align=right><div align=\"left\"><font color=#0000FF>&nbsp;&nbsp;<b>".$tit."</b></font></div>";
echo "<table cellspacing=0 cellpadding=2 width=500 border=0><tr><td class=\"contenu\"><HR width=\"100%\" color=#999999 SIZE=1>";
echo "<font color=#525552><div style=\"text-align:justify;\">".$tex."</div></font><br>";
echo "<HR width=\"100%\" color=#999999 SIZE=1>";
if ($nam=="")
{$nam="..";}
echo "<font class=\"contenu\"><font color=#525552>n� ".$id." | <b>".$dat."&nbsp;&nbsp;&nbsp;".$heu."</b> | $txt_par <b>".ucfirst($nam)."</b>";
if ($mai != "")
  {echo " | e-mail : <a href=\"mailto:".$mai."\">".$mai."</a>";}

echo "<br><br></font></font></td></tr></table>\n";
echo "</td></tr>";
$linebgcolor="#FFFFFF";
}

//-------------------------------------------------------------------------------
//Affichage des r�ponses

// requete hierarchie (ts les messages reponses du message d'origine)
$request = MYSQL_QUERY("SELECT * FROM $tbl_fmsg WHERE reponse_a_id='$rootid' ORDER BY date_verif LIMIT $offset,$lm_nb_msg_max");
$max_mess = MYSQL_NUMROWS($request);

$i=0;
WHILE($i!=$max_mess)
{
$id = mysql_result($request,$i,"id");
$nam = mysql_result($request,$i,"nom");
$mai = mysql_result($request,$i,"email");
$dat = mysql_result($request,$i,"date");
$heu = mysql_result($request,$i,"heure");
$tex = mysql_result($request,$i,"texte");
$lec = mysql_result($request,$i,"lect");
$tit = mysql_result($request,$i,"titre");

$nam = stripslashes($nam);
$mai = stripslashes($mai);
$tit = stripslashes($tit);
$tex = stripslashes($tex);

  if ($linebgcolor=="") {$linebgcolor="#EFEFEF";}
  if($linebgcolor=="#EFEFEF"){ $linebgcolor="#FFFFFF"; $linetxtcolor="#525552";}else{ $linebgcolor="#EFEFEF"; $linetxtcolor="#000000";}
  
  echo "<tr><td bgcolor=".$linebgcolor." class=\"titreforum\" align=right><div align=\"left\"><font color=#0000FF>&nbsp;&nbsp;<b>".$tit."</b></font></div>";
echo "<table cellspacing=0 cellpadding=2 width=500 border=0><tr><td class=\"contenu\"><HR width=\"100%\" color=#999999 SIZE=1>";
echo "<font color=".$linetxtcolor."><div style=\"text-align:justify;\">".$tex."</div></font><br>";
echo "<HR width=\"100%\" color=#999999 SIZE=1>";
if ($nam=="")
{$nam="..";}
echo "<font class=\"contenu\"><font color=".$linetxtcolor.">n� ".$id." | <b>".$dat."&nbsp;&nbsp;&nbsp;".$heu."</b> | $txt_par <b>".ucfirst($nam)."</b>";
if ($mai != "")
  {echo " | e-mail : <a href=\"mailto:".$mai."\">".$mai."</a>";}

echo "<br><br></font></font></td></tr></table>\n";
echo "</td></tr>";
  $i++;
}



//barre du bas
echo "<tr height=25 bgcolor=#898ebc><td class=\"barrehaut\">";

//tableau de liens
echo "<table cellspacing=0 cellpadding=0 border=0 width=\"100%\"><tr>\n";
echo "    <td bgcolor=#898ebc width=10></td>\n";
echo "    <td bgcolor=#898ebc valign=middle width=\"151\"><a href=\"nv_msg.php?act=rep&forumid=".$forumid."&rootid=".$rootid."\"><img src=\"images/bt_".$lang."_rep.gif\" border=\"0\" width=\"137\" height=\"22\"></a></td>\n";
echo "    <td bgcolor=#898ebc width=20></td>\n";
echo "    <td bgcolor=#898ebc valign=middle width=\"149\"><a href=\"index_msg.php?forumid=".$forumid."\"><img src=\"images/bt_".$lang."_listm.gif\" border=\"0\" width=\"160\" height=\"22\"></a></td>\n";
echo "    <td align=right bgcolor=#898ebc  width=\"265\"><a href=\"http://ben3w.free.fr/\"><img src=\"images/powered.gif\" border=0 width=90 height=26></a></td>\n"; 
echo "</tr></table>\n";
echo "</td></tr>";

echo "</table>";
echo "</td></tr></table>\n";

echo "<br>";
// incr�mente pour "lu" ------------
if ($offset=="")
  {$request = MYSQL_QUERY("SELECT lect FROM $tbl_fmsg WHERE id='$rootid'");
  $lect = mysql_result($request,0,"lect");
  $lect++;
  MYSQL_QUERY("UPDATE $tbl_fmsg SET lect='$lect' WHERE id='$rootid'");
  }

MYSQL_CLOSE();

BASPAGEWEB();
?>
