<?
require("connect.inc.php");
$lang_filename = "lang/".$lang."_index.inc.php";
require($lang_filename);
require("presentation.inc.php");

//affichage menus et presentation reference
HAUTPAGEWEB("2BForum - Liste des Forums");

//connexion � la database
($db = @mysql_connect("$serveur", "$utilisateur", "$motdepasse")) or erreurRC("Impossible de se connecter au serveur<br>ERREUR RC1.1");
@mysql_select_db("$database",$db) or erreurRC("Impossible de se connecter � la database<br>ERREUR RC1.2");

//selectionner les forums acc�ssibles � un utilisateur (forums visibles)
$request_list = MYSQL_QUERY("SELECT * FROM $tbl_flist WHERE visible='oui' order by forumid");
$max_list = MYSQL_NUMROWS($request_list);
//compter le nb de messages acc�ssibles � un utilisateur (nb de msg dans les forums visibles)
$chaine="SELECT count(*) FROM ".$tbl_fmsg." v1, ".$tbl_flist." v2 where v1.forumid=v2.forumid AND v2.visible='oui'";
$request_msg = MYSQL_QUERY($chaine);
$max_mess = mysql_result($request_msg,"0","count(*)");

echo "<table bgcolor=\"#000000\" cellspacing=0 cellpadding=0 border=0 width=\"590\" align=center><tr><td>\n";
echo "<table cellspacing=1 cellpadding=0 border=0 width=\"590\">\n";
echo "<tr><td height=25 class=\"barrehaut\" bgcolor=\"#5c63a6\">&nbsp;&nbsp;&nbsp;&nbsp;<b>$txt_forum</b></td><td width=75 class=\"barrehaut\" bgcolor=#5c63a6><center><b>$txt_messages</b></center></td><td width=130 class=\"barrehaut\" bgcolor=#5c63a6><center><b>$txt_deraj</b></center></td></tr>";

$i=0;
WHILE($i<$max_list) 
{
  // on r�cup�re la valeur des differents champs de la table flist
  $id = mysql_result($request_list,$i,"Forumid");//id forum
  $titre = mysql_result($request_list,$i,"Title");//titre
  $titre = stripslashes(stripslashes($titre));
  $titre = ucfirst($titre);
  $comment = mysql_result($request_list,$i,"Commentary");//commentary
  $comment = stripslashes(stripslashes($comment));
  $comment = ucfirst($comment);
  $etat = mysql_result($request_list,$i,"State");//etat ouvert/ferme (authoris�/interdit d'ecrire)
  $chaine = "SELECT id FROM $tbl_fmsg WHERE forumid=".$id;
  
  $request = MYSQL_QUERY($chaine);
  $nb_msg = MYSQL_NUMROWS($request);//nb msg par forum
  
  if ($nb_msg>'0')
  {
    $chaine = "SELECT max(date_verif) FROM ".$tbl_fmsg." WHERE forumid=".$id;//derniere modif (date_verif le plus grand)
    $request = MYSQL_QUERY($chaine);
    $dernierajout = mysql_result($request,"0","max(date_verif)");
    $chaine = "SELECT date, heure FROM ".$tbl_fmsg." WHERE forumid=".$id." AND date_verif='".$dernierajout."'";//derniere modif (date et heure du date_verif)
    $request = MYSQL_QUERY($chaine);
    //$nb_msg_test = MYSQL_NUMROWS($request);
    //echo "nombre de lignes pour le dernier ajout : ".$nb_msg_test."merci";
    $date = mysql_result($request,"0","date");
    $heure = mysql_result($request,"0","heure");
  }
  else
  {
    $date="__";
	$heure="__";
  }  
  
  //if($linebgcolor=="#F7F7EB"){ $linebgcolor="#E2E2F6"; }else{ $linebgcolor="#F7F7EB"; }
  $linebgcolor="#FFFFFF";
  echo "<tr height=25 bgcolor=\"".$linebgcolor."\" align=left>";
  if ($etat=='ouvert')
    {echo "<td><table border=0 cellpadding=5 cellspacing=3><tr><td class=\"contenu\" valign=middle><a title=\"$txt_entrerf '".$titre."'\" href=\"index_msg.php?forumid=".$id."\"><img src=\"images/folder.gif\" border=0></a></td><td><a class=\"titreforum\" title=\"$txt_entrerf '".$titre."'\" href=\"index_msg.php?forumid=".$id."\"><b>".$titre."</b></a><br><font class=\"contenu\"><div style=\"text-align:justify;\">".$comment."</div></font></td></tr></table></td>";}
  else
    {echo "<td><table border=0 cellpadding=5 cellspacing=3><tr><td class=\"contenu\" valign=top><img src=\"images/folder_red.gif\" border=0></td><td><font class=\"titreforum\"><b>".$titre."</b><br></font><font class=\"contenu\">$txt_fferme</font></td></tr></table></td>";}
  echo "<td class=\"contenu\" align=center bgcolor=#EFEFEF>".$nb_msg."</td><td align=center class=\"contenu\" bgcolor=#EFEFEF>".$date."&nbsp;&nbsp;&nbsp;".$heure."</td>";
  echo "</tr>\n";
  $i++;
} 
echo "<tr>\n";
echo "  <td colspan=3><table cellspacing=0 cellpadding=0 width=\"100%\" border=0><tr>\n";
echo "    <td height=26 class=\"barrehaut\" align=left bgcolor=#898ebc>&nbsp;&nbsp;<b>".$max_mess;
if ($max_mess>1) {echo " $txt_mrepart1 ";} else {echo " $txt_mrepart2 ";}
echo "$txt_sur ".$max_list;
if ($max_list>1)  {echo " forums</b></td>\n";} else {echo " forum</b></td>\n";}
echo "    <td colspan=2 align=right bgcolor=#898ebc><a href=\"http://ben3w.free.fr/\"><img src=\"images/powered.gif\" border=0 width=90 height=26></a></td>\n";
echo "  </tr></table></td>\n";
echo "</tr>";
echo "</table>\n";
echo "</td></tr></table>";
//bas de page
echo "<br>";
echo "<table width=480 border=0 align=center><tr><td align=center class=\"contenu\">$txt_infobas</td></tr>\n";
echo "<tr><td height=5></td></tr></table>\n";

mysql_close();
BASPAGEWEB();

?>
