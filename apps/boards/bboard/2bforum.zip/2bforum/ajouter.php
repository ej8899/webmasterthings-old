<?
require("connect.inc.php");
$lang_filename = "lang/".$lang."_ajouter.inc.php";
require($lang_filename);
require("presentation.inc.php");
//affichage menus et presentation reference
HAUTPAGEWEB("2BForum - Ajout d'un message");

//connexion � la database
($db = @mysql_connect("$serveur", "$utilisateur", "$motdepasse")) or erreurRC("Impossible de se connecter au serveur<br>ERREUR RC4.1");
@mysql_select_db("$database",$db) or erreurRC("Impossible de se connecter � la database<br>ERREUR RC4.2");

//0 variables
//1 forumid existe ?
//2 forumid ouvert ?
//3 action = rep ou new ?
//4 rep : reponse_a_id existe ?

//securite 0 : verification de l'existance, du type, et de la taille des variables
if ($id!="") {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.1<br>");}
ereg("([0-9]*)",$forumid,$secereg); 
if (($forumid != $secereg[0]) OR ($forumid=="")) {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.2<br>");}
$nom = htmlentities($nom);
$nom = addslashes($nom);
if (strlen($nom)>70) {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.3<br>");}
$email = htmlentities($email);
$email = addslashes($email);
if (strlen($email)>70) {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.4<br>");}
$titre = htmlentities($titre);
$titre = addslashes($titre);
if (strlen($titre)>70) {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.5<br>");}
ereg("([0-9]*)",$reponse_a_id,$secereg); 
if (($reponse_a_id != $secereg[0]) OR ($reponse_a_id=="")) {erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.0.6<br>");}

// s�curit� 1 : v�rification que l'id du forum pass� en parametre existe dans la liste des forums existants
$chaine="SELECT forumid FROM $tbl_flist WHERE forumid=".$forumid;
$request = MYSQL_QUERY($chaine);
$secu1 = MYSQL_NUMROWS($request);
if ($secu1!=1)
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.3<br>");
}

// s�curit� 2 : v�rification que le forum est bien ouvert et visible
$chaine="SELECT State,visible FROM $tbl_flist WHERE forumid=".$forumid;
$request = MYSQL_QUERY($chaine);
$etat = mysql_result($request,0,"State");
$vis = mysql_result($request,0,"visible");
if (($etat!='ouvert')or($vis!='oui'))
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.4<br>");
}

//s�curit� 3 : action = rep ou new
if (($act != 'new') and ($act != 'rep'))
{
  erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.5<br>");
}

//securite 4 (RC1.4): dans le cas d'une r�ponse (action=rep), v�rifier que l'id du message d'origine existe, que l'id est dans la forum forumid, que l'id est un msg root
if ($act == 'rep')
{
  //exactement 1 tuple correspondant � rootid
  $chaine="SELECT id,forumid,reponse_a_id FROM $tbl_fmsg WHERE id=".$reponse_a_id;
  $request = MYSQL_QUERY($chaine);
  $secu4 = MYSQL_NUMROWS($request);
  if ($secu4 != 1)
  {
  	  erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.6<br>");
  }
  //forumid donn� en parametre et celui du rootid correspondent ?
  $forumid_root = mysql_result($request,0,"forumid");
  if ($forumid_root != $forumid)
  {
  	  erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.7<br>");
  }
  $reponse_a_id_root = mysql_result($request,0,"reponse_a_id");
  if ($reponse_a_id_root != 0)
  {
  	  erreurRC("Op�ration interdite<br>SECURITY LOCK RC4.8<br>");
  }
  
}
//SECURITE OK -----------------------
	
	/* Les dates ----------------------------------------------- */
    $date = date("d-m-y");
    $dateus = date("Y-m-d");
    $heure = date("H:i");
    $date_verif = "$dateus "."$heure".":00";

    /* Les caract�res sp�ciaux et espaces ---------------------- */
	$titre = ucfirst($titre);
	
	$message = htmlentities($message);
	$message = addslashes($message);
	$message = nl2br($message);
	

    if ($act == 'new') {$reponse_a_id=0;}
	
	
	/* Requ�te ------------------------------------------------- */
    $chaine="INSERT INTO ".$tbl_fmsg." VALUES('','".$forumid."','".$nom."','".$email."','".$date_verif."','".$date."','".$heure."','".$message."','".$reponse_a_id."','0','".$titre."')";
  
    MYSQL_QUERY($chaine);
    

    echo "<br><br><center><font class=textefont10>$txt_ajmsg<br>";
    echo "$txt_merci<br><br>";
	if ($visible=='oui')
      {echo "<a href=\"index_msg.php?forumid=".$forumid."\"><b>$txt_retmsg</b></a></font></center>";}
	else
	  {echo "<a href=\"index.php\"><b>$txt_retf</b></a></font></center>";}
 
    MYSQL_CLOSE();

BASPAGEWEB();
?>
