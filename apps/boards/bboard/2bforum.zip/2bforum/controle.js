function Verif(forumid)
{
if (document.Formulaire.nom.value.length>60)
{
alert("Le PSEUDONYME ne peut pas exc�der 60 caract�res !");
document.Formulaire.nom.focus();
}
else if (document.Formulaire.email.value.length>60)
{
alert("L'EMAIL ne peut pas exc�der 60 caract�res !");
document.Formulaire.email.focus();
}
else if (document.Formulaire.titre.value=="")
{
alert("Merci de renseigner le champ TITRE");
document.Formulaire.titre.focus();
}
else if (document.Formulaire.titre.value.length>60)
{
alert("Le TITRE ne peut pas exc�der 60 caract�res !");
document.Formulaire.titre.focus();
}
else if (document.Formulaire.message.value=="")
{
alert("Merci d'entrer un MESSAGE");
document.Formulaire.message.focus();
}
else
{
document.Formulaire.method = "post";
document.Formulaire.action = "ajouter.php";
document.Formulaire.submit();
}
}
