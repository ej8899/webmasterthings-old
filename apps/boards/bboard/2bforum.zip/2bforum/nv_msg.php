<?
require("connect.inc.php");
$lang_filename = "lang/".$lang."_nv_msg.inc.php";
require($lang_filename);
require("presentation.inc.php");
//affichage menus et presentation reference
HAUTPAGEWEB("2BForum - Ajout d'un message");


echo "<SCRIPT language=\"JavaScript\" src=\"controle.js\"></SCRIPT>\n";


echo "<form enctype=\"multipart/form-data\" name=\"Formulaire\">\n";

echo "<table cellspacing=0 cellpadding=0 border=0 bgcolor=#000000 align=center><tr><td>\n";
echo "  <table cellspacing=1 cellpadding=5 border=0 width=588>\n";

if ($act=='rep')
  {
    echo "    <tr><td height=25 class=\"barrehaut\" bgcolor=#5c63a6><b>Ajout d'une r�ponse</b></td></tr>\n";
    $idrep=$rootid;
	/* connexion � la base de donn�es ------------------------------------------- */
    ($db = @mysql_connect("$serveur", "$utilisateur", "$motdepasse")) or erreurRC("Impossible de se connecter au serveur<br>ERREUR RC3.1");
    @mysql_select_db("$database",$db) or erreurRC("Impossible de se connecter � la database<br>ERREUR RC3.2");
	$request_list = MYSQL_QUERY("SELECT titre FROM $tbl_fmsg WHERE id=$rootid");
    $titre_msg = mysql_result($request_list,"0","titre");
	$titre_msg = stripslashes(stripslashes($titre_msg));
	//$titre_msg = ucfirst($titre_msg);
	$titre_msg = "RE : ".$titre_msg;

  }
else if ($act=='new')
  {
    echo "    <tr><td height=25 class=\"barrehaut\" bgcolor=#5c63a6><b>$txt_nvmsg</b></td></tr>\n";
    $idrep=0;
	$titre_msg='';
  }
else echo "    <tr><td height=25 class=\"barrehaut\" bgcolor=#5c63a6><b>erreur : no action</b></td></tr>\n";

echo "    <tr><td align=center bgcolor=#ffffff>\n";
echo "      <table border=0 cellspacing=1 cellpadding=1 bgcolor=#ffffff\n";
echo "        <tr><td><input type=\"hidden\" name=\"reponse_a_id\" value=".$idrep.">\n";
echo "        <input type=\"hidden\" name=\"act\" value=\"".$act."\">\n";
echo "        <input type=\"hidden\" name=\"forumid\" value=\"".$forumid."\"></td><td></td></tr>\n";
echo "        <tr><td><input type=\"text\" name=\"nom\" size=\"48\" style=\"background-color: $bgcolor_box\"></td><td class=textefont10>$txt_pseudo</td></tr>\n";
echo "        <tr><td><input type=\"text\" name=\"email\" size=\"48\" style=\"background-color: $bgcolor_box\"></td><td class=textefont10>$txt_mail</td></tr>\n";
echo "        <tr><td><input type=\"text\" name=\"titre\" size=\"48\" style=\"background-color: $bgcolor_box\" value=\"".$titre_msg."\"></td><td class=textefont10>$txt_titre</td></tr>\n";
echo "        <tr><td class=textefont10 colspan=2>$txt_msg :</td></tr>\n";
echo "        <tr><td valign=\"top\" colspan=2><center><textarea rows=\"10\" name=\"message\" cols=\"53\" WRAP=\"virtual\" style=\"background-color: $bgcolor_box\"></textarea></center></td></tr>\n";
echo "      </table>\n";
echo "    </td></tr>\n";
echo "    <tr><td colspan=2 bgcolor=#898ebc>\n";
echo "      <center><input class=\"bouton\" type=\"button\" value=\"$txt_post\" name=\"envoi\" onClick=\"Verif()\">&nbsp&nbsp&nbsp\n";
echo "      <input class=\"bouton\" type=\"button\" value=\"$txt_ann\" name=\"annuler\" onClick=\"document.location='index_msg.php?forumid=".$forumid."'\">\n";
echo "    </td></tr>\n";

echo "  </table>\n";
echo "</td></tr></table>\n";
echo "</form>\n";
echo "  <br>\n";

BASPAGEWEB();
?>
