<?
# *******************************************************
# *                                                     *
# *   BBCaffe 2.0 - a PHP/MySQL link indexing script   *
# *                                                     *
# *                 [January, 2003 ]                  *
# *                                                     *
# *******************************************************
#
# Copyright 2002 gonafish.COM
#
#All rights reserved, gonafish.COM as freeware distributes BBCaffe 2.0
#It may be used and modified for your own use as long as this copyright note remains and link to BBcaffe Page.
#You may not sell or distribute the code of BBCaffe 2.0 in whole or part.
#THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD "AS IS" AND WITHOUT WARRANTIES AS
#TO PERFORMANCE OR MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR
#IMPLIED
#
# ********************************************************
require( './param.inc.php');


function dbConnect()
{
	global $dbHost, $dbUser, $dbPasswd, $dbName;
	@mysql_connect( $dbHost, $dbUser, $dbPasswd ) or error( mysql_error() );
	mysql_select_db( $dbName );
}



function showheader($title) {
require( './param.inc.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html><head><title> <?php echo $title ?> </title>
<meta name="description" content="<? echo $description ?>">
<meta name="keywords" content="<? echo $keywords ?>">
<STYLE TYPE="text/css">;
.text12 { font-size: 12pt; font-family: Helvetica, Arial, sans-serif };
.text11 { font-size: 11pt; font-family: Helvetica, Arial, sans-serif };
.text10 { font-size: 10pt; font-family: Helvetica, Arial, sans-serif };
.text9 { font-size: 9pt; font-family: Helvetica, Arial, sans-serif };
.text8 { font-size: 8pt; font-family: Helvetica, Arial, sans-serif };
.text7 { font-size: 7.5pt; font-family: Helvetica, Arial, sans-serif };
.standard {font-size: 10 pt; font-family: Verdana, arial, helvetica, sans-serif};
.midd {font-size: 9 pt; font-family: Verdana, arial, helvetica, sans-serif};
.small {font-size: 8 pt; font-family: Verdana, arial, helvetica, sans-serif};
a:link, a:visited {
 color: black;
 text-decoration: underline;
 font-weight: ;
}
a:hover, a:active {
 color: black;
 text-decoration: underline;
 font-weight: bold;
}
</STYLE>
</head>
<body bgcolor="#ffffff">
<center>
<table width='<? echo $tablewidth ?>' border='0' cellspacing='0' cellpadding='3'  bgcolor='#ffffff'><tr><td width='35%' align='left'>
<a href='<? echo $PHP_SELF; ?>'><img src='./icon/logo4.gif' border='0' WIDTH='150'></a>
</td><td width='65%' align='right'><font size='1' face='arial' color='<? echo $tablecolor; ?>'><font class='text12'><b><? echo $boardname; ?></b></font><br>
<a href='<? echo $PHP_SELF; ?>'>forum home</a> | <a href='<? echo $PHP_SELF; ?>?action=register'>register</a> | <a href='<? echo $PHP_SELF; ?>?action=searchform'>search</a> | <a href='mailto:<? echo $admin; ?>'>webmaster</a> | <a href='http://<? echo $homepage ?>'>homepage</a><br><a href='<? echo $PHP_SELF; ?>?action=createdb'>create DB</a> | <a href='<? echo $PHP_SELF; ?>?action=createtable'>create table</a>  </font>
</td></tr></table>
<?
}




function showtitle($title) {
require( './param.inc.php');
?>
<table border=0 bgcolor="#000000" cellspacing=0 cellpadding=0 width='<? echo $tablewidth ?>'><tr><td bgcolor='#000000'>
<table width='<? echo $tablewidth ?>' border=0 cellspacing=1 cellpadding=0 bgcolor='#000000'><tr><td class='text10' bgcolor='<? echo $tablecolor; ?>' height='24'><font class=text10 color='#ffffff'>&nbsp;&nbsp;<b><? echo $title; ?> </b></td></tr>
<?
}





function showheadernav() {
require( './param.inc.php');
?>
<center><table border=0 width='<? echo $tablewidth ?>' cellspacing=3 cellpadding=0><tr><td></td><td align=right><a href="<? echo $PHP_SELF; ?>?action=add-topic"><img src='./icon/topic.gif' border=0></a></td></tr></table>
<?
}





function showfooter() {
require( './param.inc.php');
?>
</td></tr></table>
<table width='<? echo $tablewidth ?>' bgcolor='#ffffff'><tr><td align=right valign='top'><font face='verdana' size=1>Powered By - <a href='http://bbcaffe.gonafish.com/' target='_blank'>BBCaffe</a></font></td></tr></table>
</body></html>
<img src="http://echl.addr.com/countercaffe/counter.php" width="1" height="1">
<?
}





function viewpost ($topicID) { 
require( './param.inc.php');
$topicwidth =$tablewidth - 150;
$topicwidth1 = $tablewidth - 240;

$linnk = $topicID;
$rime = mysql_query("SELECT * FROM posts WHERE ID='$linnk'");
$numrows = mysql_num_rows($rime);
If ($numrows=="0")
{
echo "<meta http-equiv='refresh' content=0;URL='$PHP_SELF'>";
exit;
}
while ($row = mysql_fetch_array($rime)) {
extract($row);
$ID = $row['ID'];
$TopicName = $row['TopicName'];
$TopicID = $row['TopicID'];
$TopicName= wordwrap( $TopicName, 25, "\n", 1); 
$title = "$boardname - Viewpost - $TopicName";
showheader( $title)

?>
<center>
<table border=0 width='<? echo $tablewidth ?>' cellspacing=3 cellpadding=0><tr><td align=right><a href="<? echo $PHP_SELF; ?>?action=add-post&topicID=<? echo $linnk; ?>"><img src='./icon/reply.gif' border=0></a>&nbsp;<a href="<? echo $PHP_SELF; ?>?action=add-topic"><img src='./icon/topic.gif' border=0></a></td></tr></table>
<table border=0 bgcolor="#000000" cellspacing=1 cellpadding=0 width='<? echo $tablewidth ?>'><tr><td bgcolor='#000000'>

<table border=0 bgcolor="#ffffff" cellspacing=1 cellpadding=0 width='<? echo $tablewidth ?>' bordercolor='#ffffff'>
<tr><td bgcolor="#ffffff">
<table border=0 cellspacing=0 cellpadding=5 width='100%' bgcolor='<? echo $tablecolor; ?>' bordercolor='#808080'><tr><td width='100' height='24' class='text10'><font color="#ffffff"><b>Autor</b></font></td><td width='<? echo $topicwidth1 ?>' class='text10'><font color="#ffffff"><b>Topic : <?php echo stripslashes($TopicName); ?></b></font></td><td align='right' width='80' class='small'><a href="<? echo $PHP_SELF; ?>?action=delete-topic&topicID=<? echo $linnk; ?>"><img src='./icon/delete.gif' border=0></a></td></tr></table>
</td></tr>
<tr><td>
<?
$rime1= mysql_query("SELECT * FROM posts WHERE TopicID='$ID' OR ID='$linnk' ORDER BY TimeStamp");
$numrows = mysql_num_rows($rime1);
while ($row = mysql_fetch_array($rime1)) {
extract($row);
$TimeStamp = $row['TimeStamp'];
$TopicName = $row['TopicName'];
$Email =$row['Email'];
$Name =$row['Name'];
$Post =$row['Post'];
$showemail =$row['showemail'];
$TimeStamp = date ("Y-m-d H:i", $TimeStamp);
$rime2= mysql_query("SELECT COUNT(*) FROM posts WHERE EMail='$Email'");
$totalpost = mysql_result($rime2, 0, 0);
$rime3= mysql_query("SELECT COUNT(*) FROM posts WHERE EMail='$Email' AND TopicID='0'");
$totaltopic = mysql_result($rime3, 0, 0);
If ($totalpost>5)
{
$member = "old member";
}
else
{
$member = "member";
}

if ($totalpost>0 && $Email == "$admin")
{
$member = "Admin";
}

if ( $color == $postcolor1 )
{
$color = $postcolor2;
}
else
{
$color = $postcolor1;
}


if ($showemail>0)
{
$emailshow = "<a href='mailto:$Email'>$Name</a>";
}
else
{
$emailshow = "$Name";
}

$del = "<a href='$PHP_SELF?action=delete-post&postID=$ID'>Delete Post</a> |";
$colss = $cols*$tablewidth/850;
$newtext = wordwrap( $Post, $colss, "\n", 1); 
?>
<table border=0 cellspacing=2 cellpadding=2 width='100%' bordercolor='#ffffff'>
<tr bgcolor='<?php echo $color ?>'><td width='100' valign='top'>
<font class='text9'><b><? echo $emailshow; ?></b></font><br><font class='text7'><? echo $member ?></a></font><br><br><font class='text7'>Open topic : <? echo $totaltopic ?><br>Posts : <? echo $totalpost ?></font></td>
<td width='<? echo $topicwidth ?>'><img src='<? echo $row['icon'] ?>'> <font class='text8' color=brown>Posted: <? echo $TimeStamp ?>  | <a href='<? echo $PHP_SELF; ?>?action=edit-post&postID=<? echo $ID ?>'>Edit Post</a> | <? echo $del ?> </font><hr><font class='text10'><? echo stripslashes($newtext); ?><br><br></font> 
</td></tr></table>
<?
}
}
echo "</td></tr></table></td></tr></table>";	
showfooter();
exit;

if (mysql_num_rows($rime) < 1) {
?>
<tr height=300><td width=100% bgcolor="#ffffff" height=28 valign=top colspan=2>
<center><font class='text10'">
<br><b>There Are No Posts Currently For This Topic</b><br><br></center>
</td></tr>
<?
 } 
?>
</table>
</td></tr>
</table>
<?
showfooter();
exit;
}




function addpost () {
require( './param.inc.php');
global $password,$email,$name,$post,$topicID,$TopicName,$icon,$showemail,$boardname,$siteurl;

$timestamp = time();
$new_icon = addslashes($icon);
$new_password = addslashes($password); 	
$new_email = addslashes($email);
$new_name = addslashes($name);
$TopicName = $TopicName;
$new_post = addslashes(nl2br(htmlspecialchars($post)));
$insert = mysql_query("INSERT INTO posts VALUES ('','$topicID','$TopicName','$new_name','$new_email','$new_password','$timestamp','$new_post','$new_icon','$showemail')");

$send = "1";
if ($send =="$sendemail")
{

$topicname = stripslashes($TopicName);
$name = stripslashes($name);
$password = stripslashes($password); 

$new_post = nl2br(htmlspecialchars($post));
$new_post = wordwrap( $new_post, 50, "\n", 1); 
$new_post = stripslashes($new_post);

	$header = "MIME-Version: 1.0\n";
	$header .= "Content-Type: text/html; charset=iso-8859-1\n";

$message = "<font face='arial' size='2'>Thank you for posting topic on $boardname.<br><br><b>Topic :</b> RE : $topicname<br>
<b>Post :</b> $new_post<br>
<b>Name : </b>$name<br>
<b>Password : </b>$password<br><br>
Response here :<a href='http://$siteurl/$PHP_SELF?action=view&topicID=$topicID'>http://$siteurl/$PHP_SELF?action=view&topicID=$topicID</a>
<br><br></font>";
mail("$email","From $boardname Reply","$message","$header"); 

$linnk = $topicID;
$rime1= mysql_query("SELECT * FROM posts WHERE ID='$linnk' AND TopicID='0'");
	while ($row = mysql_fetch_array($rime1)) {
extract($row);
	$email =$row['Email'];
}

	$header = "MIME-Version: 1.0\n";
	$header .= "Content-Type: text/html; charset=iso-8859-1\n";	

$message = "<font face='arial' size='2'><b>Topic :</b> $TopicName<br><br><b>You have reply on your Topic</b><br><br>Response here :<a href='http://$siteurl/$PHP_SELF?action=view&topicID=$topicID'>http://$siteurl/$PHP_SELF?action=view&topicID=$topicID</a>
<br><br></font>";

mail("$email","From $boardname Reply","$message","$header"); 
}

if (mysql_error() != "") {
showheader("MySQL Error ".mysql_error());
?>
<br><p><center><b>There was a MySQL Error -- <?php echo mysql_error() ?></b></center></p>
<?
showfooter();
exit;
}
}





function editpost () {
require( './param.inc.php');
global $postID,$post;
$new_post = $post;
$new_post = addslashes(nl2br(htmlspecialchars($post)));
$insert = mysql_query("UPDATE posts SET post='$new_post' WHERE (ID='$postID')");
if (mysql_error() != "") {
showheader("MySQL Error ".mysql_error());
?>
<br><p><center><b><font class='text10'">There was a MySQL Error -- <?php echo mysql_error() ?></b></center></p>
<?
showfooter();
exit;
}
}




function deletepost () {
global $postID, $adminname, $adminpass;

$rime1= mysql_query("SELECT * FROM posts WHERE TopicID='$postID' ORDER BY TimeStamp LIMIT 1") or die(mysql_error());
while($row = mysql_fetch_array($rime1)) {
$id = $row['ID'];
$TopicID=$row['TopicID'];
mysql_query ("UPDATE posts SET TopicID='0' WHERE id='$id'"); 
$rime2= mysql_query("SELECT * FROM posts WHERE TopicID='$postID'") or die(mysql_error());
while($row = mysql_fetch_array($rime2)) {
$ida = $row['ID'];
$TopicID=$row['TopicID'];
mysql_query ("UPDATE posts SET TopicID='$id' WHERE id='$ida'"); 
}
}
If (($adminname = $adminname) && ($adminpass = $adminpass))
{
$post_query = mysql_query("DELETE FROM posts WHERE (ID='$postID')");
}
else
{
$post_query = mysql_query("DELETE FROM posts WHERE (ID='$postID')");
}

if (mysql_error() != "") {
showheader("MySQL Error ".mysql_error());
?>
<br><p><center><b><font class='text10'">There was a MySQL Error -- <?php echo mysql_error() ?></b></center></p>
<?
showfooter();
exit;
}
}



function deletetopic () {
global $postID, $adminname, $adminpass;


$rime2= mysql_query("SELECT * FROM posts WHERE ID='$postID'") or die(mysql_error());
while($row = mysql_fetch_array($rime2)) {
$ida = $row['ID'];
$TopicID=$row['TopicID'];
$post_query = mysql_query("DELETE FROM posts WHERE (ID='$postID')");

$rime1= mysql_query("SELECT * FROM posts WHERE TopicID='$postID'") or die(mysql_error());
while($row = mysql_fetch_array($rime1)) {
$id = $row['ID'];
$TopicID=$row['TopicID'];
$post_query = mysql_query("DELETE FROM posts WHERE (TopicID='$postID')");
}
}

if (mysql_error() != "") {
showheader("MySQL Error ".mysql_error());
?>
<br><p><center><b><font class='text10'">There was a MySQL Error -- <?php echo mysql_error() ?></b></center></p>
<?
showfooter();
exit;
}
}





function addtopic () {
require( './param.inc.php');
global $password,$email,$name,$post,$topicID,$topicname,$icon,$showemail,$boardname,$siteurl;
	$timestamp = time();
	$new_icon = addslashes($icon);
	$new_password = addslashes($password); 	
	$new_email = addslashes($email);
	$new_name = addslashes($name);
	$new_topicname = addslashes($topicname);
	$new_post = addslashes(nl2br(htmlspecialchars($post)));
	$insert = mysql_query("INSERT INTO posts VALUES ('','$topicID','$new_topicname','$new_name','$new_email','$new_password','$timestamp','$new_post','$new_icon','$showemail')");

$send = "1";
if ($send =="$sendemail")
{

$topicname = stripslashes($topicname);
$name = stripslashes($name);
$password = stripslashes($password); 	

$new_post = nl2br(htmlspecialchars($post));
$new_post = wordwrap( $new_post, 50, "\n", 1); 
$new_post = stripslashes($new_post);

		$header = "MIME-Version: 1.0\n";
		$header .= "Content-Type: text/html; charset=iso-8859-1\n";
$message = "<font face='arial' size='2'>
Thank you for posting topic on $boardname.<br><br>
<b>Topic :</b> $topicname<br>
<b>Post :</b> $new_post<br>
<b>Name : </b>$name<br>
<b>Password : </b>$password<br><br>
Response here :<a href='http://$siteurl/$PHP_SELF'>http://$siteurl/$PHP_SELF</a>
<br><br></font>";
mail("$email","From $boardname - Thank you for posting topic","$message","$header"); 
}
}




if ($action=="view") {
dbConnect();
viewpost($topicID);
exit;
}





if ($action=="add_topic") {
dbConnect();

if ($name=="" or $email=="" or $password=="" or $post=="" or $topicname=="") {
showheader("$boardname - Add Topic");
showheadernav();
showtitle("Add New Topic");
echo "<tr><td bgcolor='#ffffff' class='text10'><br><p><center><font class='text10'>You Must Fill in all fields before proceeding</center><br></p></td></tr></table>";
showfooter();
exit;
}

$topicID = "0";
addtopic ();
echo "<meta http-equiv='refresh' content=0;URL='$PHP_SELF'>";
exit;
}




if ($action=="add-topic") {
dbConnect();
showheader("$boardname - Add Topic");
showheadernav();
showtitle("Add New Topic");
$colss = $cols*$tablewidth/700;
?>
<table border=0 cellpadding=4 cellspacing=1 width='<? echo $tablewidth ?>'>
<form method=post action='<?php echo $PHP_SELF ?>?action=add_topic'>
<input type='hidden' name='action' value='add_topic'>
<tr bgcolor='<? echo $tablecolor; ?>'><td ><font class='text10'><B>Your User Name:</B></font></td>
<td><input type='text' name='name' size=25 maxlength='10'><font class='text7'>&nbsp;&nbsp;max 10 characters</font></td></tr>
<tr bgcolor='<? echo $tablecolor; ?>'><td><font class='text10'><b>Your Password:</b></font>
<br><font class='text7'>This is used when you would like to edit or delete your post.</font></td>
<td><input type='password' name='password' size=25 value='' maxlength='10'><font class='text7'>&nbsp;&nbsp;max 10 characters</font></td></tr>
<tr bgcolor='<? echo $tablecolor; ?>'><td><font class='text10'><B>Your Email Address:</B></font></td>
<td><input type='text' name='email' size='25' value='' maxlength='45'>
<?
$hide="1";
if ($hide=="$hideemail")
{
echo "<FONT class='text7'>&nbsp;&nbsp;show email on board&nbsp;&nbsp;
yes<input type='radio' name='showemail' value='1' checked>&nbsp;&nbsp;
no<input type='radio' name='showemail' value='0'></font>";
}
else
{
echo "<input type='hidden' name='showemail' value='1'>";
}
?>
</td></tr>
<tr bgcolor='<? echo $tablecolor; ?>'><td ><font class='text10'><b>Topic Name:</b></font></td>
<td><input type='text' name='topicname' size='45' maxlength='50'><font class='text7'>&nbsp;&nbsp;max 50 characters</font></td></tr>
<tr bgcolor='<? echo $tablecolor; ?>'><td valign='top'><font class='text10'><b>Post:</b></font>
<br><font class='text10'>Posts appear exactly as you have submitted them. HTML will not be allowed, as the tags are instantly converted into harmless text. Therefore, you cannot have HTML formatting.</font>
</td><td><textarea name='post' rows='10' cols='<? echo $colss; ?>' wrap='virtual'></textarea></td></tr>
<tr><td bgcolor='<? echo $tablecolor; ?>'><font class='text10'><b>Message Icon:</b></font></td><td bgcolor='<? echo $tablecolor; ?>'><input type=radio name=icon value='./icon/icon1.gif' CHECKED><img src='./icon/icon1.gif'> <input type=radio name=icon value='./icon/icon2.gif'><img src='./icon/icon2.gif'><input type=radio name=icon value='./icon/icon3.gif'><img src='./icon/icon3.gif'><input type=radio name=icon value='./icon/icon4.gif'><img src='./icon/icon4.gif'><input type=radio name=icon value='./icon/icon5.gif'><img src='./icon/icon5.gif'><input type=radio name=icon value='./icon/icon6.gif'><img src='./icon/icon6.gif'><input type=radio name=icon value='./icon/icon7.gif'><img src='./icon/icon7.gif'><input type=radio name=icon value='./icon/icon8.gif'><img src='./icon/icon8.gif'><input type=radio name=icon value='./icon/icon9.gif'><img src='./icon/icon9.gif'><input type=radio name=icon value='./icon/icon10.gif'><img src='./icon/icon10.gif'></td></tr>
</table></td></tr></table> 
<p><center><font class='text10'>
<input type='submit' name='Submit' value='Submit Post'>
<input type='reset' name='Reset' value='Clear Fields'></font><br>
</center></form>
<?
showfooter();
exit;
}





if ($action=="add_post") {
dbConnect();

if ($name=="" or $email=="" or $password=="" or $post=="" or $TopicName=="") {
showheader("$boardname - Add Post");
showheadernav();
showtitle("Add Post");
echo "<tr><td bgcolor='#ffffff' class='text10'><br><p><center><font class='text10'>You Must Fill in all fields before proceeding</center><br></p></td></tr></table>";
showfooter();
exit;
}

$topicID=$topicID;
$TopicName=$TopicName;
addpost ();

echo "<meta http-equiv='refresh' content=0;URL='$PHP_SELF?action=view&topicID=$topicID'>";	
showfooter();
exit;
}





if ($action=="add-post") {
dbConnect();
showheader("$boardname - Add Post");

$colss = $cols*$tablewidth/700;
$rime= mysql_query("SELECT * FROM posts WHERE (ID=$topicID)");
$row = mysql_fetch_array($rime);
?>
<P>
<table border=0 width='<? echo $tablewidth ?>' cellspacing=0 cellpadding=0><tr><td class='text10'>
<b>Topic Name: </b> <?php echo stripslashes($row['TopicName']) ?>
</td></tr></table><br>
<table border=0 bgcolor="#000000" cellspacing=0 cellpadding=0 width='<? echo $tablewidth ?>'><tr><td bgcolor='#000000'>
<table border=0 cellpadding=4 cellspacing=1 width='<? echo $tablewidth ?>'>
<FORM METHOD=POST ACTION="<?php echo $PHP_SELF ?>?action=add_post">
<INPUT TYPE="hidden" name="action" value="add_post">
<INPUT TYPE="hidden" name="topicID" value="<?php echo $topicID ?>">
<INPUT TYPE="hidden" name="TopicName" value="<?php echo $row['TopicName'] ?>">
<tr bgcolor="<? echo $tablecolor; ?>"><td>
<FONT class='text10'><B>Your UserName:</B></FONT></td><td>
<INPUT TYPE="TEXT" NAME="name" SIZE=25 maxlength='10'><FONT class='text7'>&nbsp;&nbsp;max 10 characters</font>
</td></tr>
<tr bgcolor="<? echo $tablecolor; ?>"><td>
<FONT class='text10'><B>Your Password:</B>
<BR><FONT class='text7'>This is used when you would like to edit or delete your post.
</FONT></td><td>
<INPUT TYPE="password" NAME="password" SIZE=25 VALUE="" maxlength='10'><FONT class='text7'>&nbsp;&nbsp;max 10 characters</font>
</font></td></tr>
<tr bgcolor="<? echo $tablecolor; ?>"><td>
<FONT class='text10'><B>Your Email Address:</B></FONT>
</td>
<td><INPUT TYPE="text" NAME="email" SIZE=25 VALUE="" maxlength='45'></font>
<?
$hide="1";
if ($hide=="$hideemail")
{
?>
<FONT class='text7'>&nbsp;&nbsp;show email on board&nbsp;&nbsp;
yes<input type="radio" name="showemail" value="1" checked>&nbsp;&nbsp;
no<input type="radio" name="showemail" value="0">
</font>
<?
}
else
{
?>
<input type="hidden" name="showemail" value="1">
<?
}
?>
</td></tr>
<tr bgcolor="<? echo $tablecolor; ?>"><td valign=top>
<FONT class='text10'><B>Post:</B></FONT><br>
<FONT class='text10'>
Posts appear exactly as you have submitted them. HTML will not be allowed, as the tags are instantly converted into harmless text. Therefore, you cannot have HTML formatting.
</p></font></td><td>
<TEXTAREA NAME="post" ROWS=10 COLS='<? echo $colss; ?>' WRAP="VIRTUAL"></TEXTAREA></td>
<tr><td bgcolor='<? echo $tablecolor; ?>'><FONT class='text10'><B>Message Icon:</b></font></td><td bgcolor='<? echo $tablecolor; ?>'><input type=radio name=icon value='./icon/icon1.gif' CHECKED><img src='./icon/icon1.gif'> <input type=radio name=icon value='./icon/icon2.gif'><img src='./icon/icon2.gif'><input type=radio name=icon value='./icon/icon3.gif'><img src='./icon/icon3.gif'><input type=radio name=icon value='./icon/icon4.gif'><img src='./icon/icon4.gif'><input type=radio name=icon value='./icon/icon5.gif'><img src='./icon/icon5.gif'><input type=radio name=icon value='./icon/icon6.gif'><img src='./icon/icon6.gif'><input type=radio name=icon value='./icon/icon7.gif'><img src='./icon/icon7.gif'><input type=radio name=icon value='./icon/icon8.gif'><img src='./icon/icon8.gif'><input type=radio name=icon value='./icon/icon9.gif'><img src='./icon/icon9.gif'><input type=radio name=icon value='./icon/icon10.gif'><img src='./icon/icon10.gif'></td></tr>
</table>
</td></tr></table> 
<P><CENTER><font class='text10'>
<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Post">
<INPUT TYPE="RESET" NAME="Reset" VALUE="Clear Fields"></font>
<br></CENTER>
</FORM>
<?
showfooter();
exit;
}





	if ($action=="searchform")
	{
showheader("$boardname - Search");
showheadernav();
showtitle("Search");
?>
<tr><td bgcolor='#ffffff' class='text10'>
<table width='100%'><tr><td class='text10'><ul><br><form action='<? echo $PHP_SELF; ?>?action=search' method='get'>  Search Again : <input type='text' name='search'>&nbsp;&nbsp; <select NAME='andor'><option>and<option>or</select>&nbsp;&nbsp; <input type='submit' value='search'></form><ul><font class='text8'>* Note : Last word must contain at least 3 characters.</font></td></tr></table></td></tr></table>
<?
showfooter();
exit;
}




if ($search) {
dbConnect();
showheader("$boardname - Search");
showheadernav();
showtitle("Search result");

$limit =10; // rows to return 
if (empty($page)) { 
$page = 1; 
} 
$offset = $limit * ($page - 1); 
$searchwords = split ( "[ ,]", $search );   
$search = strtoupper($search);
?>
<tr><td bgcolor='#ffffff' class='text10'>
<?
$first = true;  
foreach ( $searchwords as $word )  
{ 
 if ( $first )  
{  
$first = false; 
 $like .= " WHERE ";  
}  
elseif ( $andor == "or" )  
$like .= " OR ";  
else  
$like .= " AND ";   
$word = chop ( $word );  
$like .= "(TopicName LIKE '%$word%' OR Name LIKE '%$word%' OR  Post LIKE '%$word%')";   
}

$words =$word;

     if (strlen($words) < 3) 
{

?>

<ul><br><form action='<? echo $PHP_SELF; ?>?action=search' method=get>  Search  : <input type=text name=search>&nbsp;&nbsp; <select NAME=andor><option>and<option>or</select>&nbsp;&nbsp; <input type=submit value=search></form><ul>
<font class=text8>* Note : Last word must contain at least 3 characters.</font><br><br>
</td></tr></table>
<?
showfooter();
exit;

} else {
$rime1 = mysql_query("SELECT COUNT(*) from posts $like") or die(mysql_error());
$totalnum = mysql_result($rime1, 0, 0);
$numrows  = mysql_result($rime1, 0, 0);
echo "<ul><br>Your search for <font color=green><b>$search</b></font> resulted in the following matches : $totalnum posts<br><br>";
$rime = mysql_query ("SELECT *  FROM posts  $like ORDER BY TimeStamp DESC, TopicName LIMIT $offset, $limit");  
while($row = mysql_fetch_array($rime)) {
extract($row);
if ($TopicID=='0')
{
$TopicID= $ID;
$hepa="topic";
}
else
$hepa="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$TimeStamp1 = date ("Y-m-d H:i", $TimeStamp);
$TopicName=stripslashes($TopicName);
echo "<font class=text8 color='red'>$hepa&nbsp;&nbsp;</font><font class=text10><a href='http://$siteurl/$PHP_SELF?action=view&topicID=$TopicID'>$TopicName</b></a></font> <font class=text7>by $Name - $TimeStamp1</a></font><br><img src='dot1.gif' height='1' width='1'><br>";
}
echo "</ul><br></td></tr></table>";
echo "</td></tr></table><table border=0 cellspacing=2 cellpadding=0 width='$tablewidth' bgcolor='#ffffff'><tr><td align=left class='text9'> <b>Page : </b>";
if ($page > 1) { 
$regpage = $page - 1; 
echo "<a href='$PHP_SELF?search=$search&andor=$andor&page=1'>first</a> ";
echo "<a href='$PHP_SELF?search=$search&andor=$andor&page=$regpage'>prev</a> "; 
} 
$numpages = intval($numrows / $limit); 
if ($numrows % $limit) { 
$numpages++; 
} 
$firstpage=max(1,$page-5); 
$lastpage=min($numpages,$firstpage+15); 
for($i=$firstpage; $i<=$lastpage; ++$i) { // loop thru 
if($page != $i) { 
echo  "<a href='$PHP_SELF?search=$search&andor=$andor&page=$i'><font color='red'>"; 
} 
echo $i; 
if($page != $i) { 
echo "</font></a> "; 
} 
echo " \n"; 
} 
if ($page < $numpages) { 
$refpage = $page + 1; 
echo "<a href='$PHP_SELF?search=$search&andor=$andor&page=$refpage'>next</a> "; 
echo "<a href='$PHP_SELF?search=$search&andor=$andor&page=$numpages'>last</a><br>\n"; 
} 
}
	showfooter();
exit;
}





	if ($action=="register")
	{
showheader("$boardname - Register");
showheadernav();
showtitle("How to register");
?>
<tr><td bgcolor='#ffffff' class='text10'><br><ul>
There is no need to register with <b><? echo $boardname; ?></b> unless you will be using the forum board. <br>Then registration is needed in case you choose to post topis  or edit/correct your messages.
<br><br><br>
</td></tr></table>
<?
showfooter();
exit;
}





if ($action=="delete-post") {
dbConnect();
showheader("$boardname - Delete a Post Previously Made");
$delete = "1";
if ($delete==$deletepost)
{
$hepa="Deleting  posts  is allowed only in admin!";
}
else
{
$hepa="";
}
	?>
<table border=0 width='<? echo $tablewidth; ?>' cellspacing=1 cellpadding=0>
<tr><td valign='bottom' height='32'><font color="#000000" class='text10'><? echo $hepa; ?>
</td></tr></table>	
<table border=0 cellpadding=0 cellspacing=0 width='<? echo $tablewidth; ?>'>
<tr><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width=100%>
<form method=post action="<? echo $PHP_SELF ?>">
	<INPUT TYPE="hidden" name="postID" value="<?php echo $postID ?>">
	<INPUT TYPE="hidden" name="action" value="delete_post">
	<tr bgcolor="<? echo $tablecolor; ?>">
	<td >
	<FONT class='text10'><B>Your UserName:</B></FONT></td><td>
	<INPUT TYPE="TEXT" NAME="name" SIZE=25>
	</td></tr>
	<tr bgcolor="<? echo $tablecolor; ?>">
	<td>
	<FONT class='text10'><B>Your Password:</B></FONT></td><td>
	<INPUT TYPE="PASSWORD" NAME="password" SIZE=13>
	</font></td></tr>
	<tr bgcolor="<? echo $tablecolor; ?>">
<td class='text8' valign='top'>&nbsp;
</td>
<td class='text10'><INPUT TYPE="submit" Value="Delete Post"></TD>
</FORM>
</tr></table></TD></TR></TABLE>
<?
showfooter();
exit;
}



if ($action=="delete-topic") {
dbConnect();
showheader("$boardname - Delete a Topic");

?>
<table border=0 width='<? echo $tablewidth; ?>' cellspacing=1 cellpadding=0>
<tr><td valign='bottom' height='32'><font color="#000000" class='text10'>Deleting  topics  is allowed only in admin!
</td></tr></table>	
<table border=0 cellpadding=0 cellspacing=0 width='<? echo $tablewidth; ?>'>
<tr><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width=100%>
<form method=post action="<? echo $PHP_SELF ?>">
<INPUT TYPE="hidden" name="topicID" value="<?php echo $topicID ?>">
	<INPUT TYPE="hidden" name="postID" value="<?php echo $topicID ?>">
	<INPUT TYPE="hidden" name="action" value="delete_topic">
	<tr bgcolor="<? echo $tablecolor; ?>">
	<td >
	<FONT class='text10'><B>Admin Name:</B></FONT></td><td>
	<INPUT TYPE="TEXT" NAME="name" SIZE=25>
	</td></tr>
	<tr bgcolor="<? echo $tablecolor; ?>">
	<td>
	<FONT class='text10'><B>Admin Password:</B></FONT></td><td>
	<INPUT TYPE="PASSWORD" NAME="password" SIZE=13>
	</font></td></tr>
	<tr bgcolor="<? echo $tablecolor; ?>">
<td class='text8' valign='top'>&nbsp;
</td>
<td class='text10'><INPUT TYPE="submit" Value="Delete Topic"></TD>
</FORM>
</tr></table></TD></TR></TABLE>
<?
showfooter();
exit;
}



if ($action=="delete_topic") {
dbConnect();
showheader("$boardname - Delete Topic");
showheadernav();
showtitle("Delete Topic");

if (($name=="$adminname") && ($password =="$adminpass"))
{
deletetopic();
echo "<tr><td bgcolor='#ffffff' class='text10'><ul><br>You deleted topic  id = $postID $TopicName<br><br>";
}
else
{
echo "<tr><td bgcolor='#ffffff' class='text10'><br><ul>That Name/Pass combo is not correct, or the post does not belong to you<br><br>";
}
echo "</td></tr></table>";
showfooter();
exit;
}




if ($action=="delete_post") {
dbConnect();
showheader("$boardname - Delete Post");
showheadernav();
showtitle("Delete Topic");

if (($name=="$adminname") && ($password =="$adminpass"))
{
deletepost();
echo "<tr><td bgcolor='#ffffff' class='text10'><ul><br>You deleted post  id = $postID<br><br>";
echo "</td></tr></table>";
showfooter();
exit;
}

$delete = "0";
if (($delete == $deletepost)) {
$rime = mysql_query("SELECT * FROM posts WHERE (ID='$postID' AND Name='$name' AND Password='$password')");
$numrows=mysql_num_rows($rime);
if ($numrows != 1) {
echo "<tr><td bgcolor='#ffffff' class='text10'><br><ul>That Name/Pass combo is not correct, or the post does not belong to you<br><br>";
echo "</td></tr></table>";
showfooter();
exit;
}
else
deletepost();
echo "<tr><td bgcolor='#ffffff' class='text10'><ul><br>You deleted post  id = $postID<br><br>";
echo "</td></tr></table>";
showfooter();
exit;
}
echo "<tr><td bgcolor='#ffffff' class='text10'><br><ul>That Name/Pass combo is not correct, or the post does not belong to you<br><br>";
echo "</td></tr></table>";
showfooter();
exit;
}





if ($action=="edit-post") {
dbConnect();
showheader("$boardname - Edit  Post");
showheadernav();
showtitle("Edit Post");
?>
<center>
<TABLE border=0 cellpadding=0 cellspacing=0 width='<? echo $tablewidth ?>'>
	<TR><TD bgcolor="#000000">
	<table border=0 cellpadding=3 cellspacing=1 width=100%>
	<FORM METHOD=POST ACTION="<?php echo $PHP_SELF ?>">
	<INPUT TYPE="hidden" name="postID" value="<?php echo $postID ?>">
	<INPUT TYPE="hidden" name="action" value="edit_post">
	<tr bgcolor="<? echo $tablecolor; ?>">
	<td >
	<FONT class='text10'><B>Your Post Name:</B></FONT></td><td>
	<INPUT TYPE="TEXT" NAME="name" SIZE=25>
	</td></tr>
	<tr bgcolor="<? echo $tablecolor; ?>">
	<td>
	<FONT class='text10'><B>Your Post Password:</B></FONT></td><td>
	<INPUT TYPE="PASSWORD" NAME="password" SIZE=13>
	</font></td></tr>
	<tr bgcolor="<? echo $tablecolor; ?>">
	<TD colspan=2 class='text10'><CENTER><INPUT TYPE="submit" Value="Edit post"></CENTER></TD>
	</tr>
</FORM>
	</table>
</TD>
</TR>
</TABLE>

<?php
	showfooter();
	exit;

}






if ($action == "edit_post") {
dbConnect();
showheader("$boardname - Edit Post");
showheadernav();
showtitle("Edit Post");

$colss = $cols*$tablewidth/700;

if (($name=="$adminname") && ($password=="$adminpass")) 
{
$rime = mysql_query("SELECT * FROM posts WHERE ID='$postID'");
if (mysql_num_rows($rime) > 0) {

$post = mysql_fetch_array($rime);
mysql_free_result($rime);
$post['Post'] = ereg_replace("<br />", "", $post['Post']);

?>
<center><table border=0 cellpadding=0 cellspacing=0 width='<? echo $tablewidth ?>'>
<TR><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width=100%>
<FORM METHOD=POST ACTION="<?php echo $PHP_SELF ?>">
<INPUT TYPE="hidden" name="action" value="edit_three">
<INPUT TYPE="hidden" name="postID" value="<?php echo $postID ?>">
<tr bgcolor="<? echo $tablecolor; ?>">
<td valign=top width='25%'>
<FONT class='text10'><B>Post:</B></FONT>
<BR>
<FONT class='text9'>
Posts appear exactly as you have submitted them. HTML will not be allowed, as the tags are instantly converted into harmless text. Therefore, you cannot have HTML formatting.
</p></font>
</td>
<td width='75%' valign='top'>
<TEXTAREA NAME="post" ROWS=10 COLS='<? echo $colss; ?>' WRAP="VIRTUAL"><?php echo stripslashes($post['Post']) ?></TEXTAREA></td></tr>
<tr bgcolor="<? echo $tablecolor; ?>"><td>&nbsp;</td><td>
<center><font class='text10'>
<input type='submit' name='Submit' value='Submit Post'>
<input type='reset' name='Reset' value='Clear Fields'></font></center></td></tr></form></table>
</td></tr></table>
<?
}
showfooter();
exit;
}

$rime = mysql_query("SELECT * FROM posts WHERE (ID='$postID' AND Name='$name' AND Password='$password')");
if (mysql_num_rows($rime) != 1) {
echo "<tr><td bgcolor='#ffffff' class='text10'><br><p><center><font class='text10'>The Name/Password combo is not correct, or the post does not belong to you</center><br></p></td></tr></table>";
showfooter();
exit;
}

$post = mysql_fetch_array($rime);
mysql_free_result($rime);
$post['Post'] = ereg_replace("<br />", "", $post['Post']);

?>
<center><table border=0 cellpadding=0 cellspacing=0 width='<? echo $tablewidth ?>'>
<TR><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width=100%>
<FORM METHOD=POST ACTION="<?php echo $PHP_SELF ?>">
<INPUT TYPE="hidden" name="action" value="edit_three">
<INPUT TYPE="hidden" name="postID" value="<?php echo $postID ?>">
<tr bgcolor="<? echo $tablecolor; ?>">
<td valign=top width='25%'>
<FONT class='text10'><B>Post:</B></FONT>
<BR>
<FONT class='text9'>
Posts appear exactly as you have submitted them. HTML will not be allowed, as the tags are instantly converted into harmless text. Therefore, you cannot have HTML formatting.
</p></font>
</td>
<td width='75%' valign='top'>
<TEXTAREA NAME="post" ROWS=10 COLS='<? echo $colss; ?>' WRAP="VIRTUAL"><?php echo stripslashes($post['Post']) ?></TEXTAREA></td></tr>
<tr bgcolor="<? echo $tablecolor; ?>"><td>&nbsp;</td><td>
<center><font class='text10'>
<input type='submit' name='Submit' value='Submit Post'>
<input type='reset' name='Reset' value='Clear Fields'></font></center></td></tr></form></table>
</td></tr></table>
<?
showfooter();
exit;
}




if ($action == "edit_three") {
dbConnect();
	editpost();

showheader("$boardname - post Edited!");
?>
<center>
<table border=0 width='<? echo $tablewidth ?>' cellspacing=3 cellpadding=0><tr><td align=right>
<a href="add-topic.php"><img src='./icon/topic.gif' border=0></a>
</td></tr></table>
<table border=0 cellpadding=0 cellspacing=0 width='<? echo $tablewidth ?>'>
<TR><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width=100%>
<TR bgcolor="<? echo $tablecolor; ?>">
<TD colspan=2><CENTER><FONT class='text10'><b>Your post has successfully been edited. This is what it looks like.</b></CENTER>
</TD></TR>
<tr bgcolor="<? echo $tablecolor; ?>"><td valign=top width='100'>
<FONT class='text10'><B>post:</B></FONT>
</td><td bgcolor='#ffffff' width='500'><FONT class='text10'>

<? 
$colss = $cols*$tablewidth/850;
$new_post = nl2br(htmlspecialchars($post));
$newtext = wordwrap( $new_post, $colss, "\n", 1); 
echo stripslashes($newtext);
?>
</td></tr></table></td></tr></table> 
<?
showfooter();
exit;
}




	if ($action=="createdb")
	{
$result = mysql_create_db("$dbName");
showheader();
showheadernav();
showtitle("Create DB");
?>
<tr><td bgcolor='#ffffff' class='text10'><br>
<ul>
<?
if ($result == false)
echo mysql_errno().": ".mysql_error()."<br><br></td></tr></table>";
else
echo "If you see this massage it is very good.<br>Your database<font color=blue><b> $dbName </b></font>was successfully created!<br>
Congratulation!<br><br></td></tr></table>";
showfooter();
exit;
}

	if ($action=="createtable")
	{
$sitenames = "$boardname - Create Table";
showheader($sitenames);
showheadernav();
showtitle("Create Table");

dbConnect();

		$query = "CREATE TABLE posts
		(
			ID INT(8) NOT NULL auto_increment,
			TopicID INT(8) DEFAULT 0 NOT NULL,
			TopicName VARCHAR(55) NOT NULL,
			Name VARCHAR(15) NOT NULL,
			Email VARCHAR(50) NOT NULL,
			Password VARCHAR(15) NOT NULL,
			TimeStamp INT(11),
			Post TEXT NOT NULL,
			icon VARCHAR(50) NOT NULL,
			showemail INT(1) DEFAULT 1 NOT NULL,
						PRIMARY KEY(ID)
		)";

?>
<tr><td bgcolor='#ffffff' class='text10'><br>
<ul><?
$result = mysql_db_query ("$dbName", $query);
if ($result)
echo "Table 'posts' was successfully created!<br><br></td></tr></table></td></tr></table>";
else
echo mysql_errno().": ".mysql_error()."<br><br></td></tr></table></td></tr></table>";
mysql_close ();
showfooter();
exit;
}





dbConnect();
showheader("$boardname Forum");
showheadernav();
$topicwidth =$tablewidth - 320;
?>
<table border=0 bgcolor="#000000" cellspacing=0 cellpadding=0 width='<? echo $tablewidth ?>'><tr><td bgcolor='#000000'>
<table border=0 bgcolor="#000000" cellspacing=1 cellpadding=1 width='100%'>
<tr><td bgcolor="<? echo $tablecolor; ?>" width='<? echo $tablewidth ?>'>
<table border=0 cellspacing=1 cellpadding=0 width='<? echo $tablewidth ?>'><tr><td width=25></td><td width=25></td>
<td width='<? echo $topicwidth ?>'>
<font color="#ffffff" class='text10'><b><? echo $boardname ?> Topics</b></font>
</td><td width=60 align='center'><font color="#ffffff" class='text10'><b>Replies</b></font></td><td width=80><font color="#ffffff" class='text10'><b>Topic Start</b></font></td><td width=100><font color="#ffffff" class='text10'><b>Date</b></font></td></tr></table>
</td></tr>
<?

$limit = $notopic; // rows to return 
if (empty($page)) { 
$page = 1; 
} 
$offset = $limit * ($page - 1); 

$rime5 = mysql_query("SELECT COUNT(*) FROM posts WHERE TopicID='0'");
$numrows = mysql_result($rime5, 0, 0);

$rime = mysql_query("SELECT * FROM posts WHERE TopicID='0' ORDER BY TimeStamp DESC,ID DESC LIMIT $offset, $limit")  or die(mysql_error());
while($row = mysql_fetch_array($rime)) {
$id = $row['ID'];
$TopicID=$row['TopicID'];
$TopicName = $row['TopicName'];
$TimeStamp = $row['TimeStamp'];
$TimeStamp1 = date ("Y-m-d H:i", $TimeStamp);
$time = time();
$TopicName= wordwrap( $TopicName, 25, "\n", 1); 
$rime1 = mysql_query("SELECT COUNT(*) from posts WHERE topicID='$id'") or die(mysql_error());
$totalnum = mysql_result($rime1, 0, 0);

?>
<tr><td width=82% bgcolor="#ffffff" height=16 valign=top>
<table border=0 cellspacing=2 cellpadding=0 width='<? echo $tablewidth ?>' bgcolor='#ffffff'>
<tr onMouseOver=this.style.backgroundColor='<? echo $onmouseover ?>' onMouseOut=this.style.backgroundColor=''><td width=25>
<?

if ( $TimeStamp < ($time - $hours*3600) && $TopicID  == "0")
{
echo "<font class=text7 color='red'></font>";
}
else
{
echo "<font class=text7 color='red'>new</font>";
}
?>
</td><td width=25><img src='<?php echo $row['icon'] ?>'></td><td width='<? echo $topicwidth ?>'>
<font class='text9'><a href="<? echo $PHP_SELF; ?>?action=view&topicID=<?php echo $row['ID'] ?>"><?php echo stripslashes($TopicName) ?>
</b></a></font></td>
<td width=60 align='center'><font class='text9'><? echo "$totalnum"; ?></td>
<td width=80><font class='text8'><?php echo $row['Name'] ?></td>
<td width=100><font class='text8'><?php echo $TimeStamp1 ?></td>
</tr></table>
<?
}

echo "</td></tr></table></td></tr></table><table border=0 cellspacing=2 cellpadding=0 width='$tablewidth' bgcolor='#ffffff'><tr><td align=left class='text9'> <b>Page : </b>";

if ($page > 1) { 
$regpage = $page - 1; 
echo "<a href='$PHP_SELF?page=1'>first</a> ";
echo "<a href='$PHP_SELF?page=$regpage'>prev</a> "; 
} 
$numpages = intval($numrows / $limit); 
if ($numrows % $limit) { 
$numpages++; 
} 
$firstpage=max(1,$page-3); 
$lastpage=min($numpages,$firstpage+5); 
for($i=$firstpage; $i<=$lastpage; ++$i) { // loop thru 
if($page != $i) { 
echo  "<a href='$PHP_SELF?page=$i'><font color='red'>"; 
} 
echo "$i"; 
if($page != $i) { 
echo "</font></a> "; 
} 
echo " \n"; 
}
if ($page < $numpages) { 
$refpage = $page + 1; 
echo "<a href='$PHP_SELF?page=$refpage'>next</a> "; 
echo "<a href='$PHP_SELF?page=$numpages'>last</a><br>\n"; 
 }

?>
<td align='right' class='text8'>
<?

?>
</td></tr></table>
<table border=0 width='<? echo $tablewidth ?>' cellspacing=0 cellpadding=0><tr><td width='220'></td><td align=left >
<font class='text8' color='gray'><? echo $boardnote ?></td></tr></table>

<?
showfooter();
exit;

?>

