# *******************************************************
# *                                                     *
# *   BBcaffe 2.0 - a PHP/MySQL counter script   *
# *                                                     *
# *                 [January, 2003 ]                  *
# *                                                     *
# *******************************************************
#
# Copyright 2002 gonafish.com
#
#All rights reserved, gonafish.com as freeware distributor of BBcaffe 2.0
#It may be used and modified for your own use as long as this copyright note remains and link to Home Page.
#You may not sell or distribute the code of BBcaffe 2.0 in whole or part.
#BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE PROGRAM 
#
# ********************************************************

BBcaffe2.0
It's simple, It's cool!

-----------------------
 OVERVIEW
-----------------------

BBcaffe 2.0 is a fast, simple, easy and efficient bulletin board or message board program built in PHP/mySQL. Features include: posting, replying, deleting, editing, searching messages, sending notification email(s) , full templating. Complete customization - only two files run BBcaffe.

 

------------------------
 REQUIREMENTS
------------------------

- PHP 4 
- MySQL database
- Windows NT
- Unix

------------------------
 INSTALLATION
------------------------

Step 1:
Download BBcaffe2.0, unzip and install on your web server.

Step 2:
Edit param.inc.php file and change parameters to reach your data.

Step 3:
Through your browser access BBcaffe script ex. http://yoursite.com/yourBBcaffedir/
Click on link 'createDB'. It will create database.
Click on link 'create table'. It will create table 'posts'.
Your BBcaffe board is ready to run.


Enjoy BBcaffe!
It's simple, it's cool!