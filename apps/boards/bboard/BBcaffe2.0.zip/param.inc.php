<?
$dbHost = "localhost";					// Your mySQL server host address
$dbUser = "username";					// Your mySQL username
$dbPasswd = "userpassword";			// Your mySQL password
$dbName = "bbcaffe";						// The name of the database to use .You can change in diferent name

$adminname = "adminNAME";			//Admin Name to delete or edit posts, delete topic (MUST be changed)
$adminpass = "AdminPass";				//Admin Password to delete or edit posts, delete topic (MUST be changed)

$siteurl = "yoursite.com/BBcaffe";		// URL for your site (exp. altavista.com/BBcaffe)
$homepage = "yourhomesite.com";		// URL for your home page
$PHP_SELF = "index.php";

$deletepost = "1";							// Delete post  1-only admin  0-author & admin
$sendemail = "1";							// Send email for notification of  post  1-send  0-do not send
$hideemail = "1";							// Allowe authors to hide email address on board  1-hide  0-do not hide
$hours = "24";								// Message has a status of being new depending on the no. of hrs

$boardname = "Your BBcaffe";			// Set this to the name of your BBcaffe
$admin = "webmaster@yoursite.com";	// Your admin e-mail adrress
$sitelogo = "logo4.gif";					// Your logo

$notopic = "25";							// Number of topics to shown on Index Page
$tablewidth = "650";						//Table width
$tablecolor= "#3a669a";					//Table color (head)
$postcolor1 = "#ebebeb";
$postcolor2 = "#fffcf2";
$onmouseover = "#dbe7da";
$cols = "60";

$description ="Your forum description";	//Your BBcaffe board description
$keywords = "your forum keywords";		//Your BBcaffe borad keywords

$boardnote = "Thank you for visiting this site.  This site is intended as a guest book, however, it can also be used for comments, suggestions and your concerns.  We will do our best to reply to all the concerns and problems but we would also like to encourage other users if they are able to help to";
?>
