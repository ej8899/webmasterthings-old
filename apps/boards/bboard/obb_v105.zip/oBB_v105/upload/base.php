<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


// +-----------------------------------------------------------+
// | Open Bulletin Board Register Global Compliance            |
// +-----------------------------------------------------------+

if(!isset($_GET))
{
 extract($HTTP_GET_VARS);
 extract($HTTP_POST_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else {
 extract($_GET);
 extract($_POST);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}
/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/

error_reporting(7);

if(isset($_FILES) && @sizeof($_FILES) > 0)
while ($thisfile = each($_FILES) )
{
	$name = $thisfile['key'] . "_name";
	$type = $thisfile['key'] . "_type";
	$error = $thisfile['key'] . "_error";
	$size = $thisfile['key'] . "_size";

	${$thisfile['key']} = $_FILES[$thisfile['key']]['tmp_name'];
	${$name} = $_FILES[$thisfile['key']]['name'];
	${$type} = $_FILES[$thisfile['key']]['type'];
	${$error} = $_FILES[$thisfile['key']]['error'];
	${$size} = $_FILES[$thisfile['key']]['size'];
}

// Define The Error Handler Function
function errorhandler ($errno, $errstr, $errfile, $errline) {
  switch ($errno) {
  case FATAL | C_ERROR | COMP_W | E_ERROR:
    echo "<b>Fatal</b> [$errno] $errstr<br>\n";
    echo "  Fatal error on line ".$errline." of file ".$errfile;
    echo ", PHP ".PHP_VERSION." (".PHP_OS.")<br>\n";
    echo "Aborting...<br>\n";
    exit(1);
    break;
  case ERROR | E_PARSE:
    echo "<b>Error</b> [$errno] $errstr<br>\n";
    break;
  case WARNING | C_WARNING | COMP_E:
    echo "<b>Warning</b> [$errno] $errstr<br>\n";
    break;
  }
}

// Define New Error Handlers
define ("FATAL",E_USER_ERROR);
define ("ERROR",E_USER_WARNING);
define ("WARNING",E_USER_NOTICE);
define ("E_ERROR",E_ERROR);
define ("E_PARSE",E_PARSE);
define ("C_ERROR",E_CORE_ERROR);
define ("C_WARNING",E_CORE_WARNING);
define ("COMP_E",E_COMPILE_ERROR);
define ("COMP_W",E_COMPILE_WARNING);

// Post New Error Reporting
error_reporting(FATAL | ERROR | WARNING | E_ERROR | E_PARSE | C_ERROR | C_WARNING | COMP_E | COMP_W);

// Set Error Handler
set_error_handler("errorhandler");

$mtime1 = microtime();
$mtime1 = explode(" ",$mtime1);
$start_of_openbb = $mtime1[1] + $mtime1[0];

//:: Base Settings
$php = '.php';
include 'lib/functions'.$php;
$true = 'can';
$false = 'cannot';
$obbver = '1.0.5';


//:: Add No Cache Headers
if ($needscache !="true") {
@header("expires: wednesday, Mon, 26 Jul 1997 05:00:00 GMT");
@header("last-modified: " . gmdate("d, d m y h:i:s") . "gmt");
@header("cache-control: no-cache, must-revalidate");
@header("pragma: no-cache");
}

//:: Include Config File And Connect to Database
include 'lib/sqldata.php';
include 'lib/database/'.$database_server['type'].$php;
$SQL = new db;
$result = $SQL->open($database_server['database'], $database_server['hostname'], $database_server['username'], $database_server['password']);

//:: Set Standard Cookie Expiration Time
$expire=time() + 31536000;

if (!$result) {
        show_dberror('Could Not Connect To Database');
}

//:: Get Configuration From The Database
if (isset($SI['settings'])) {
        $SI['settings'] .= ', cookiepath, cookiedomain, boardurl, boardname, time1, time2, time3, usegzip, locked, lockedreason, gzlevel, pmauthor, sendpm, regpm, redirect, lastadd, quickpost, mostusers, mostuserstime, plistperpage, showbdays, smilies, censor, maxuploadsize, uploadextensions';
}


else {
        $SI['settings'] = 'cookiepath, cookiedomain, boardurl, boardname, locked, time1, time2, time3, usegzip, gzlevel, pmauthor, sendpm, regpm, redirect, lastadd, quickpost, mostusers, mostuserstime, plistperpage, smilies, censor, maxuploadsize, uploadextensions';
}


$config = new query($SQL, "SELECT ".$SI['settings']." FROM ".$prefix."configuration");


if (!$config->getrow()) {
        show_dberror('could not get settings from database server');
}


$timeformat[1] = $config->field('time1');
$timeformat[2] = $config->field('time2');
$timeformat[3] = $config->field('time3');
$boardname = $config->field('boardname');
$forumurl = $config->field('boardurl');
$topbar = $boardname;


if ($config->field('usegzip')) {
        ob_start("ob_gzhandler");
}

// Register Globals & Handle Slashes

while(list($mname,$mval) = each($_SERVER)) {
    $$mname = $mval;
}

while(list($mname,$mval) = each($_GET)) {
        if (is_string($mval) && !get_magic_quotes_gpc()) {
                $mval = addslashes($mval);
                $HTTP_GET_VARS[$mname] = $mval;
                $$mname = $mval;
        }
        if (!isset($$mname))
                $$mname = $mval;
}

if (!get_magic_quotes_gpc()) {
        while(list($mname,$mval) = each($HTTP_POST_VARS))
                if (is_string($mval)) {
                        $mval = addslashes($mval);
                        $HTTP_POST_VARS[$mname] = $mval;
                        $$mname = $mval;
                }
        while(list($mname,$mval) = each($HTTP_COOKIE_VARS))
                if (is_string($mval)) {
                        $mval = addslashes($mval);
                        $HTTP_COOKIE_VARS[$mname] = $mval;
                        $$mname = $mval;
                }
}
else {
        while(list($mname,$mval) = each($_POST))
                if (is_string($mval)) {
                        $mval = addslashes($mval);
                        $HTTP_POST_VARS[$mname] = $mval;
                        $$mname = $mval;
                }
        while(list($mname,$mval) = each($_COOKIE))
                if (is_string($mval)) {
                        $mval = addslashes($mval);
                        $HTTP_COOKIE_VARS[$mname] = $mval;
                        $$mname = $mval;
                }
}
set_magic_quotes_runtime(0);

// +-----------------------------------------------------------+
// | Session Management                                        |
// +-----------------------------------------------------------+

if ($HTTP_COOKIE_VARS['record']) {
        define('RECORD',$HTTP_COOKIE_VARS['record']);
        $isrec = 1;
}
else {
        $isrec = 0;
}


define('USERIP',($HTTP_X_FORWARDED_FOR) ? $HTTP_X_FORWARDED_FOR : $REMOTE_ADDR);
// - Begin Ban Code - //


$userip = USERIP;
$subnet = explode(".", $userip);
$subnet = "$subnet[0].$subnet[1].$subnet[2].*";
$checksubnet = mysql_query("SELECT * FROM ".$prefix."ipban WHERE number like '$subnet' OR number like '$userip'");
$checksubnetcount = mysql_num_rows($checksubnet);
if ($checksubnetcount > 0) {
       gen_error('Banned', 'IP Number '.$userip.' has been banned!');
}

//:: Update Active In Database
if ($isrec) {
        $record = RECORD;
}
else {
        $record = '';
}

$query_active = new query($SQL, "SELECT member, record FROM ".$prefix."active WHERE record = '".$record."'");


if ($query_active->getrow() && $isrec != 0) {
        new query($SQL, "UPDATE ".$prefix."active SET lastaction = '".time()."', ip = '".USERIP."', inforum = '', location = '".$SI['ref']."' WHERE record = '".RECORD."'");

        if($member = $query_active->field('member')) {
                define('USERNAME',$member);
        }
        else {
                define('USERNAME',0);
        }

        $query_active->free();
}
else {
        //:: Create New Record And Active Database Entry
        $query_lastid = new query($SQL, "SELECT record FROM ".$prefix."active ORDER BY record DESC LIMIT 1");
        $query_lastid->getrow();
        define('RECORD',uniqid((substr(time(),6,10))));
        $query_lastid->free();
        new query($SQL, "INSERT INTO ".$prefix."active VALUES ('', '".time()."', '".RECORD."', '".USERIP."', 'Viewing Index', '', '')");

        if($config->field('cookiedomain') != '') {
                setcookie('record',$RECORD,$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
        }
        else {
                setcookie('record',RECORD,$expire,$config->field('cookiepath'));
        }
}


// +-----------------------------------------------------------+
// | Define User Information                                   |
// +-----------------------------------------------------------+

        //:: Get Our Last Action
define('LASTACTION',$HTTP_COOKIE_VARS['lastaction']);
if (USERNAME != 'USERNAME') {

        //:: Make Special Arrangements w/ NUKE
                $sq = new query($SQL, "SELECT id, usergroup, vargroup, pmpopup, templategroup, censor, timeoffset, timezone, activated, banned, showavatar, showsig, showhistory, addowntopics, autosubscribe FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");

        //:: Define Standard Member Information
        $sq->getrow();
        define('MEMBER','1');
        define('USERID',$sq->field('id'));
        define('USERGROUP',$sq->field('usergroup'));
        define('VARGROUP',$sq->field('vargroup'));

        if (SCRIPTID == 'cp') {
                define('TEMPLATEGROUP',127);
        }
        else {
                define('TEMPLATEGROUP',$sq->field('templategroup'));
        }

        //:: Define Settings and Other Circumstances (ACTIVATED and BANNED)
        define('ACTIVATED',$sq->field('activated'));
        define('BANNED',$sq->field('banned'));
        define('SHOWAVATAR',$sq->field('showavatar'));
        define('SHOWSIG',$sq->field('showsig'));
        define('SHOWHISTORY',$sq->field('showhistory'));
        define('ADDOWNTOPICS',$sq->field('addowntopics'));
        define('AUTOSUBSCRIBE',$sq->field('autosubscribe'));
        define('CENSOR',$sq->field('censor'));

        if($sq->field('pmpopup')) {
                $query_pm = new query($SQL, "SELECT send, subject FROM ".$prefix."pmsg WHERE owner = '".USERNAME."' AND box = 'inbox' AND isread = '0' ORDER BY time");
                $query_pm->getrow();
                $pmsgsender = $query_pm->field('send');
                $pmsgsubject = $query_pm->field('subject');
                if($pmsgsender) {
                        $pmpopup2 = 'onload="window.open(\'misc.php?action=pmpop\',\'pms\',\'width=300,height=300,top=0,left=0\'); return false;"';
                }
        }
        else {
                $pmpopup2 = '';
        }
        //:: Setup Timezone and Timeset Offset
        $time = $sq->field('timeoffset');
        $timezone = $sq->field('timezone');

        if ($time == 0) {
                $timezone = 'GMT';
        }
        else {
                if ($timezone > '-1') {
                        $timezone = '+' . $timezone;
                }

                $timezone = 'GMT '.$timezone;
        }

        define('TIMEZONE',$timezone);
        define('TIMEOFFSET',$sq->field('timeoffset'));

        //:: Define Moderator Forums

        $qm = new query($SQL, "SELECT forumid FROM ".$prefix."moderators WHERE modid = '".USERID."'");
        while($qm->getrow()) {
                $user_mod[$qm->field('forumid')] = 1;
        }
        $qm->free();

        //:: If the Account Isn't Activated... Kill 'um, errr, Don't Let Them In
        if (!ACTIVATED && SCRIPTID != 'member/logout') {
                $quit_reason = 'Your account is not activated.';
                $show_logout = 1;
        }

        //:: If The Account Is BAN... We Can Kill 'um Because They Were Bad LMFAO
        if (BANNED) {
                $quit_reason = 'You are banned from this community.';
        }

        //:: Lets Freeup This Query
        $sq->free();

}
//:: If It Isn't The Above Then What Else Is There But An "Else" Statement...
else {
        //:: Fine, Fine, They Must Be A Guest... But I Will Still NOT Show You The Microfilm As Proof
        define_guest();
}

// +-----------------------------------------------------------+
// | Open Bulletin Board Load                                  |
// +-----------------------------------------------------------+

//:: Add Base Templates To Cache List... w00h00
if (isset($SI['templates'])) {
        $SI['templates'] .= '|0|99|75|74|208|16|220';
        $templates = str_replace('|', '\',\'', $SI['templates']);
}
else {
        $templates = '0|74|75|99|208|16|220';
}

//:: Get The Template Variables
$templatevars = new query($SQL, "SELECT org, rep FROM ".$prefix."vars WHERE groupid = ".VARGROUP."");


while ($templatevars->getrow()) {
        $tempvars[$templatevars->field('org')] = $templatevars->field('rep');
}


//:: Get Any Variables From The Configuration File
$lengthvars = new query($SQL, "SELECT lgthsubj, lgthdesc FROM ".$prefix."configuration");
$lengthvars->getrow();
$configvars[lgthsubj] = $lengthvars->field('lgthsubj');
$configvars[lgthdesc] = $lengthvars->field('lgthdesc');
$mostusers = $config->field('mostusers');
$mostuserstime = $config->field('mostuserstime');

//:: Cache Templates - In 1 QUERY, Beat That
$query_templates = new query($SQL, "SELECT template, id FROM ".$prefix."templates WHERE groupid = ".TEMPLATEGROUP." AND (id IN ('".$templates."'))");

while ($query_templates->getrow()) {
        $template = stripslashes($query_templates->field('template'));
        $TI[$query_templates->field('id')] = $template;
}


$query_templates->free();


//:: Update profile with current IP and last active


if(MEMBER) {
        new query($SQL, "UPDATE ".$prefix."profiles SET ip = '".USERIP."', lastactive = '".time()."' WHERE username = '".USERNAME."'");
}


//:: Check If New Lastvisit Cookie Needed
if ((time() - LASTACTION) > 900) {

        if($config->field('cookiedomain') != '') {
                setcookie('lastvisit',LASTACTION,$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
        }
        else {
                setcookie('lastvisit',LASTACTION,$expire,$config->field('cookiepath'));
        }
        define('LASTVISIT',LASTACTION);
}
elseif ($HTTP_COOKIE_VARS['lastvisit']) {
        define('LASTVISIT',$HTTP_COOKIE_VARS['lastvisit']);
}
else {
        define('LASTVISIT','');
        if($config->field('cookiedomain') != '') {
                setcookie('lastvisit',time(),$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
        }
        else {
                setcookie('lastvisit',time(),$expire,$config->field('cookiepath'));
        }
}

//:: Renew Lastaction Cookie
if($config->field('cookiedomain') != '') {
        setcookie('lastaction',time(),$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
}
else {
        setcookie('lastaction',time(),$expire,$config->field('cookiepath'));
}

//:: Lets Get The Time w/ Your Timezone... nehehehehheheheheh
$time = gmdate($timeformat[2], (time() + TIMEOFFSET));
$offset = TIMEOFFSET;
$query_checkusergroup = new query($SQL, 'SELECT isadmin FROM '.$prefix.'usergroup WHERE id = '.USERGROUP);
$query_checkusergroup->getrow();


//:: Lets See If The User Is Insane... Well... I Mean Admin
if ($query_checkusergroup->field('isadmin')) {
        define('ADMIN','1');
}
else {
        define('ADMIN','0');
}


$query_checkusergroup->free();

$usern = USERNAME;
//:: So, You Want Special User Navigation huh? Is That It? Well You Got IT! Here below.
if (ADMIN) {
        eval("\$navigation = \"".addslashes($TI[99])."\";");
}
elseif (MEMBER) {
        eval("\$navigation = \"".addslashes($TI[75])."\";");
}
else {
        eval("\$navigation = \"".addslashes($TI[74])."\";");
}

//:: Quit w/ Show Logout
if ($quit_reason && $show_logout) {
        gen_error($quit_reason,'Click <a href="member.php?action=logout ">here</a> to logout.');
}


//:: Quit w/out Show Logout
if ($quit_reason) {
        gen_error($quit_reason,'');
}


//:: Board Locked (MEMBER) - Block 'um
//:: Board Locked (ADMIN( - Let 'um Through
if ($config->field('locked') == '1' && !ADMIN) {

    if (!$send) {
         $lockedmsg = $config->field('lockedreason');
                eval("\$include = \"".addslashes($TI[208])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

     }

        // ### Set User to logged in
        elseif ($send) {


                if ($username == '' ||  $password == '') { gen_error('Fill in all fields please!','Required information is missing.'); }
                $query_checkdata = new query($SQL, "SELECT password, invisible, username FROM ".$prefix."profiles WHERE username = '".trim($username)."'");
                if (!$query_checkdata->getrow()) { gen_error('Username ('.$username.') does not exists!','Please check for typing mistakes. To register click <a href="member.php?action=register">here</a>.'); }
                if ($query_checkdata->field('password') != md5($password)) { gen_error('Wrong Password!','If you lost your password click <a href="member.php?action=forgotpasswd">here</a>.'); }
                $username = $query_checkdata->field('username');
                new query($SQL, "DELETE FROM ".$prefix."active WHERE member = '".addslashes($username)."'");
                new query($SQL, "UPDATE ".$prefix."active SET invisible = '".$query_checkdata->field('invisible')."', member = '".addslashes($username)."', lastaction = '".time()."' WHERE record = '".RECORD."'");

                if($config->field('cookiedomain') != '') {
                        setcookie('record',RECORD,$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
                }
                else {
                        setcookie('record',RECORD,$expire,$config->field('cookiepath'));
                }
                $query_checkdata->free();

                if ($redirect) {
                        gen_redirect('You are now logged in, redirecting you.', $redirect);
                } else {
                        gen_redirect('You are now logged in, redirecting you to mainpage.', 'index.php');
                }

        }
}


$mtime1 = microtime();
$mtime1 = explode(" ",$mtime1);
$base_end = ($mtime1[1] + $mtime1[0]) - $start_of_openbb;
$mtime1 = microtime();
$mtime1 = explode(" ",$mtime1);
$start_of_file = $mtime1[1] + $mtime1[0];

?>
