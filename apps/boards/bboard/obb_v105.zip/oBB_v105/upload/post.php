<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

error_reporting(7);


# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_FILES);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/


// ###############################
//         POST NEW THREAD
// ###############################

$needscache="true";
$action = $HTTP_GET_VARS['action'];
$post = $HTTP_GET_VARS['post'];
$preview = $HTTP_POST_VARS['preview'];
$remthread = $HTTP_POST_VARS['remove'];

if ($action == 'post') {
        // ### 'Post New Topic' Screen


        if (!$post || $preview) {

                $SI['ref'] = 'Posting New Topic';
                $SI['templates'] = '13|55|45|86|94';
                //attachments - added maxuploadsize & uploadextensions to settings
                $SI['settings'] = 'parseurl, dsmiley, maxuploadsize, uploadextensions';
                define('SCRIPTID','post/newthread/screen');
                require 'base.php';
                $templategroup = TEMPLATEGROUP;

                // Check to make sure they are not posting to a category
                $query_type = new query($SQL, "SELECT type FROM ".$prefix."forum_display WHERE forumid = $FID");
                $query_type->getrow();
                $ftype = $query_type->field('type');
                if ($ftype == 1 || $ftype == 2 || $ftype == 4) { gen_error('Invalid Forum!', 'Go back and try again.'); }

                if (!$FID) { gen_error('No Forum specified!','Go back and try again.'); }
                check_perm('thread_canpost',1,$usergroup);
                if ($config->field('parseurl')) { $parseurl = 'checked'; }
                if ($config->field('dsmiley')) { $disablesmilies = 'checked'; }
                if ($parseurl == 'yes' && $preview == 1) { $parseurl = 'checked'; } elseif ($preview == 1) { $parseurl = ''; }
                if ($disablesmilies == 'yes' && $preview) { $disablesmilies = 'checked'; } elseif ($preview) { $disablesmilies = ''; }
                if ($disablesig == 'yes' && $preview) { $disablesig = 'checked'; } elseif ($preview) {$disablesig = '';}
                if ($enablesubsc == 'yes' && $preview) { $enablesubsc = 'checked'; } elseif ($preview) {$enablesubsc = '';}

                $query_geticons = new query($SQL, 'SELECT id, image FROM '.$prefix.'topicicons WHERE id != 0 ORDER BY id');
                if ($preview) {
                        $selectedicon = $HTTP_POST_VARS['icon'];
                }
                while ($query_geticons->getrow()) {
                        if ($preview) {
                                if ($query_geticons->field('id') == $selectedicon) {
                                        $icons .= '<input type="radio" name="icon" value="'.$query_geticons->field('id').'" checked> <img src="images/openbb/'.$query_geticons->field('image').'"> ';
                                } else {
                                        $icons .= '<input type="radio" name="icon" value="'.$query_geticons->field('id').'"> <img src="images/openbb/'.$query_geticons->field('image').'"> ';
                                }
                        } else {
                                $icons .= '<input type="radio" name="icon" value="'.$query_geticons->field('id').'"> <img src="images/openbb/'.$query_geticons->field('image').'"> ';
                        }
                }

                if ($preview) {
                        $iconselected == 'checked';
                        include 'lib/codeparse.php';
                        if ($parseurl == 'CHECKED') { $a = 1; } else { $a = 0; }
                        if ($disablesmilies == 'CHECKED') { $b = 1; } else { $b = 0; }
                        $message = stripslashes(format($message));
                        $temp = $message;
                        $message = codeparse($message, $a, $b, USERNAME);
                        eval("\$preview = \"".addslashes($TI[86])."\";");
                        $message = $temp;
                }
                $nav = getnav('forum:'.$FID) . ' > New Topic';

                if (MEMBER) {
                        $username = USERNAME;
                        eval("\$include = \"".addslashes($TI[55])."\";");
                } else {
                        eval("\$include = \"".addslashes($TI[45])."\";");
                }

                $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
                while ($query_getsmileyset->getrow()) {
                        $smileyset[id] = $query_getsmileyset->field('id');
                        $smileyset[name] = $query_getsmileyset->field('name');
                        eval("\$smilies .= \"".addslashes($TI[94])."\";");
                }
                $query_getsmileyset->free();


                $title = 'Posting New Topic';
                //attachments - added maxuploadsize & uploadextensions variables for template
                $maxuploadsize = $config->field('maxuploadsize');
                $uploadextensions = $config->field('uploadextensions');
                eval("\$include = \"".addslashes($TI[13])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        }

        // ### Insert New Thread Into DB
        elseif ($post) {
                if ($poll == 1) {

                        $SI['ref'] = 'Creating a Poll';
                        $SI['templates'] = '124';
                        define('SCRIPTID','post/newthread/poll');
                        require 'base.php';


                        check_perm('poll_canstart',1,$usergroup);
                        $message = format($message);
                        $subject = format($subject);
                        $title = 'Poll Creation';
                        eval("\$include = \"".addslashes($TI[124])."\";");
                        eval("\$output = \"".addslashes($TI[0])."\";");
                        lose($output);
                }

                $SI['ref'] = 'Posting New Thread';
                define('SCRIPTID','post/newthread/insert');
                require 'base.php';




                // Check to make sure they are not posting to a category
                $query_type = new query($SQL, "SELECT type FROM ".$prefix."forum_display WHERE forumid = $FID");
                $query_type->getrow();
                $ftype = $query_type->field('type');
                if ($ftype == 1 || $ftype == 2 || $ftype ==4) { gen_error('Invalid Forum!', 'Go back and try again.'); }

                if (!$FID) { gen_error('No Forum specified!','Go back to the index page and try again.'); }
                if (!trim(format($message))) { gen_error('No Message specified!','Go back and try again.');  }
                if (!trim(format($subject))) { gen_error('No Subject specified!','Go back and try again.');  }

        //limit smilies
        $query_smilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies");

            while ($query_smilies->getrow()) {
               $limit = $config->field('smilies');
               $total = $total + substr_count($message, $query_smilies->field('smiley'));
               if($total > $limit) {gen_error('Smiley limit exceeded', 'The forum administrator has limited the number of smilies to '.$limit.'');}
           }
            $query_smilies->free();


        //attachments - check if the user is attaching a file

            $attachment = 0;
            if (is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name']) && $HTTP_POST_FILES['attachment']['size'] > 2) {
              //move the file to a path we can read from even in safe mode
              $attachmentfile = './tmp'.substr($HTTP_POST_FILES['attachment']['tmp_name'], strrpos($HTTP_POST_FILES['attachment']['tmp_name'], "/"));
              move_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'],$attachmentfile) or die("Could not move file. Please CHMOD your OpenBB's 'tmp' directory to 777");

              //check to see if uploads are allowed (if $config->field('uploadextensions') is blank then uploads are not allowed)
              if ($config->field('uploadextensions') == "") { gen_error('Attachments Not Allowed!','The forum administrator has turned off file attachments.'); }

              //check the file to make sure it has an allowed extension
              $attachmentextension = strtolower(substr($HTTP_POST_FILES['attachment']['name'], strrpos($HTTP_POST_FILES['attachment']['name'], ".")));

              //check for auto-blackholed extensions
              if (($attachmentextension == '.dll') || ($attachmentextension == '.sys') || ($attachmentextension == '.bat') || ($attachmentextension == '.com') || ($attachmentextension == '.exe')) { gen_error('File Type Not Allowed!','Files of type \''.$attachmentextension.'\' are not allowed to be uploaded. Go back and try again.'); }

              //check to see if they have an allowed extension
              $allowedextensions = explode(',', strtolower($config->field('uploadextensions')));
              $extensionallowed = 0;
              while (list(, $allowedextension) = each($allowedextensions)) {
                if ($attachmentextension == $allowedextension) { $extensionallowed = 1; }
              }
              if ($extensionallowed == 1) {
                if ($HTTP_POST_FILES['attachment']['size'] <= $config->field('maxuploadsize')) {
                  $fp = fopen($attachmentfile, "rb");
                  $attachmentcontents = "";
                  while (!feof($fp)) {
                    $attachmentcontents .= fread($fp, 4096);
                  }
                  fclose($fp);
                  $attachment = 1;
                } else {
                  gen_error('File Too Large!','The forum administrator has set the maximum attachment size to '.$config->field('maxuploadsize').' bytes. The file you uploaded was '.$HTTP_POST_FILES['attachment']['size'].' bytes. Go back and try again.');
                }
              } else {
                gen_error('File Type Not Allowed!','Files of type \''.$attachmentextension.'\' are not allowed to be uploaded. Go back and try again.');
              }
              unlink($attachmentfile);
            } elseif (!(is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'])) && ($HTTP_POST_FILES['attachment']['name'] != "")) {
              gen_error('File Upload Failed!','The upload of the file \''.$HTTP_POST_FILES['attachment']['name'].'\' did not complete correctly. Go back and try again.');
            }
            //end attachments



                if (!MEMBER && $username) {
                        $query_member = new query($SQL, "SELECT password FROM ".$prefix."profiles WHERE username = '$username'");
                        $query_member->getrow();
                        if (strcasecmp($query_member->field('password'), md5($password))) { $query_member->free(); gen_error('Invalid user information.','<a href=member.php?action=login>Click here to login</a>.'); }
                        $realuser = $username;
                        $query_member->free();
                }

                if (isset($poll)) {
                        $message = format($message);
                        $subject = format($subject);
                        $query_getpoll = new query($SQL,"SELECT id FROM ".$prefix."polls ORDER BY id DESC LIMIT 1");
                        $query_getpoll->getrow();
                        $pollid = $query_getpoll->field('id') + 1;
                        new query($SQL,"INSERT INTO ".$prefix."polls VALUES ('".strip_tags($pollid)."', '".strip_tags($option1)."', '".strip_tags($option2)."', '".strip_tags($option3)."', '".strip_tags($option4)."', '".strip_tags($option5)."', '".strip_tags($option6)."', '".strip_tags($option7)."', '".strip_tags($option8)."', '".strip_tags($option9)."', '".strip_tags($option10)."', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '')");
                        $query_getpoll->free();
                }

                if (!MEMBER && !$realuser) { $realuser = 'Guest'; }
                elseif (!$realuser) { $realuser = USERNAME; }

                if ($realuser == 'Guest') { $gquery = 1; $realuser = ''; } else { $gquery = 0; }

                if (!$gquery) {
                        $query_getgroup = new query($SQL, "SELECT usergroup, id FROM ".$prefix."profiles WHERE username = '".addslashes($realuser)."'");
                        $query_getgroup->getrow();
                        $usergroup = $query_getgroup->field('usergroup');
                        $UID = $query_getgroup->field('id');
                        $query_getgroup->free();
                } else {
                        $UID = 0;
                        $usergroup = 0;
                }

                check_perm('thread_canpost',1,$usergroup);

                $check_flood = new query($SQL, "SELECT flood FROM ".$prefix."usergroup WHERE id = '".$usergroup."'");
                $check_flood->getrow();
                if ($lastpost = $HTTP_COOKIE_VARS['lastpost']) {
                        $left = (time() - $lastpost);
                        if ($left <= $check_flood->field('flood')) {
                                $left = $check_flood->field('flood') - $left;
                                gen_error('Flood limit is activated.','Sorry, but a flood limit is activated. You have to wait another '.$left.' seconds before you can post again.');
                        }
                }
                $check_flood->free();
                setcookie('lastpost',time(),$expire,$config->field('cookiepath'),$config->field('cookiedomain'));

                $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."topics ORDER by id DESC LIMIT 1");
                $query_seekid->getrow();
                $TID = $query_seekid->field('id') + 1;
                $query_seekid->free();

                $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."posts ORDER by id DESC LIMIT 1");
                $query_seekid->getrow();
                $PID = $query_seekid->field('id') + 1;
                $query_seekid->free();

                $query_getparent = new query($SQL, "SELECT parent, dcount FROM ".$prefix."forum_display WHERE forumid = $FID");
                $query_getparent->getrow();
                $parent = $query_getparent->field('parent');
                $dcount = $query_getparent->field('dcount');
                $query_getparent->free();
                $message = format($message);
        $subject = format($subject);
                counttag($message);

                 //attachments - put attachment into database, if any
            $AID = 0;
            if ($attachment) {
              $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."attachments ORDER by id DESC LIMIT 1");
              $query_seekid->getrow();
              $AID = $query_seekid->field('id') + 1;
              $query_seekid->free();
              new query($SQL, "INSERT INTO ".$prefix."attachments (id, user, dateline, filename, filesize, filecontent) VALUES($AID, '".addslashes($realuser)."', '".time()."', '".$HTTP_POST_FILES['attachment']['name']."', '".$HTTP_POST_FILES['attachment']['size']."', '".mysql_escape_string($attachmentcontents)."')");
              unset($attachmentcontents);
            }
            //end attachments

                        new query($SQL, "INSERT INTO ".$prefix."topics VALUES ($TID, $FID, '".$subject."', '".time()."', '".addslashes($realuser)."', '".time()."', '', '0', '0', '', '', '', '0', '".$UID."', '0','".$icon."','".$UID."', '".$gquery."','".$gquery."','".$pollid."','".format($description)."', '0',$AID)");


                if ($parseurl == 'yes') { $parseurl = 1; } else {$parseurl = 0; }
                if ($disablesmilies == 'yes') { $dsmiley = 1; } else {$dsmiley = 0; }
                if ($disablesig == 'yes') { $dsig = 1; } else { $dsig = 0; }

                //attachments - added attachid as an insert field & value
                new query($SQL, "INSERT INTO ".$prefix."posts (dsmiley, parseurl, dsig, id, threadid, poster, message, title, dateline, isstarter, forumid, ip, guest, attachid) VALUES ('".$dsmiley."', '".$parseurl."', '".$dsig."', $PID, $TID, '".addslashes($realuser)."', '".$message."', '".$subject."', '".time()."', 1, '".$FID."', '".USERIP."', '".$gquery."', $AID)");

                if (strlen($subject) > 25) { $threadtitle = substr($subject, 0, 22) . '...'; } else { $threadtitle = $subject; }
                new query($SQL, "UPDATE ".$prefix."forum_display SET postcount = (postcount + 1), threadcount = (threadcount + 1), lastposter = '".addslashes($realuser)."', lastpost = '".time()."', lastthread = '".strip_tags($threadtitle)."', lastthreadid = '".$TID."', lastposterid = '".$UID."', guest = '".$gquery."' WHERE forumid = $FID OR forumid = $parent");




                if (ADDOWNTOPICS && !AUTOSUBSCRIBE)        {
                        new query($SQL, "INSERT INTO ".$prefix."favorites VALUES('".addslashes(USERNAME)."','".$FID."','".$TID."','0','1')");
                } elseif (ADDOWNTOPICS && AUTOSUBSCRIBE || $enablesubsc == 'yes')        {
                        new query($SQL, "INSERT INTO ".$prefix."favorites VALUES('".addslashes(USERNAME)."','".$FID."','".$TID."','1','1')");
                }

                if (!$gquery && !$dcount) {
                        new query($SQL, "UPDATE ".$prefix."profiles SET posts = (posts + 1) WHERE username = '".addslashes($realuser)."'");
                }

                new query($SQL, "UPDATE ".$prefix."configuration SET posts = (posts + 1), threads = (threads + 1)");

                if ($enablesubsc == 'yes') {
                        gen_redirect('Your topic has been posted, and you have subscribed to this thread. Redirecting you to your topic.','read.php?TID='.$TID);
                }
                else {
                        gen_redirect('Your topic has been posted, redirecting you to it.','read.php?TID='.$TID);
                }
        }
}


// ###############################
//         REPLY TO THREAD
// ###############################
if ($action == 'reply') {
        // ### 'Reply to Thread' Screen
        if (!$post || $preview) {

                $SI['ref'] = 'Replying to Topic';
                $SI['templates'] = '11|55|45|86|94|84|85';
                //attachments - added maxuploadsize & uploadextensions to settings
                $SI['settings'] = 'parseurl, dsmiley, boardurl, maxuploadsize, uploadextensions, plistperpage';
                define('SCRIPTID','post/reply/screen');
                require 'base.php';

                $templategroup = TEMPLATEGROUP;




                if (!$TID) { gen_error('No Topic specified!','Go back and try again.'); }


                $query_getinfo = new query($SQL, "SELECT locked, title, forumid FROM ".$prefix."topics WHERE id = '".$TID."'");
                if (!$query_getinfo->getrow()) { gen_error('Invalid Topic!','Go back and try again.'); }

                define('LOCK',$query_getinfo->field('locked'));
                define('TOPICTITLE',$query_getinfo->field('title'));
                $FID = $query_getinfo->field('forumid');

                $query_getinfo->free();

                if (LOCK && !ADMIN) { gen_error('Topic is locked.','Sorry, you cannot reply anymore.'); }

                if ($config->field('parseurl')) { $parseurl = 'CHECKED'; }
                if ($config->field('dsmiley')) { $disablesmilies = 'CHECKED'; }
                if ($parseurl == 'yes' && $preview) { $parseurl = 'CHECKED'; } elseif ($preview) { $parseurl = ''; }
                if ($disablesmilies == 'yes' && $preview) { $disablesmilies = 'CHECKED'; } elseif ($preview) { $disablesmilies = ''; }
                if ($enablesubsc == 'yes' && $preview) { $enablesubsc = 'checked'; } elseif ($preview) { $enablesubsc = ''; }

                include 'lib/codeparse.php';
                if ($preview) {
                        if ($parseurl == 'CHECKED') { $a = 1; } else { $a = 0; }
                        if ($disablesmilies == 'CHECKED') { $b = 1; } else { $b = 0; }
                        $message = stripslashes(format($message));
                        $temp = $message;
                        $message = codeparse($message, $a, $b, USERNAME);
                        eval("\$preview = \"".addslashes($TI[86])."\";");
                        $message = $temp;
                }

                $nav = getnav('forum:'.$FID) . '> <a href="read.php?TID='.$TID.'">'.TOPICTITLE.'</a> > Reply';
                check_perm('thread_canreply',1,$usergroup);
                if (MEMBER) {
                        $username = USERNAME;
                        eval("\$include = \"".addslashes($TI[55])."\";");
                } else {
                        eval("\$include = \"".addslashes($TI[45])."\";");
                }


                if ((!isset($PID) || $PID == '') && !$preview) {
                        $quote = '';
                } else {
                check_perm('thread_canreply',1,$usergroup);
                        if (!$preview) {
                                $query_getpostinfo = new query($SQL, "SELECT message, threadid, poster FROM ".$prefix."posts where id = '".$PID."'");
                                $query_getpostinfo->getrow();
				if($query_getpostinfo->field('threadid') != $TID) {
					gen_error('Hack attempt detected','An illegal hack attempt has been detected. Cannot proceed');
				}

                                $info = '[i]Originally posted by '.$query_getpostinfo->field('poster').'[/i]


             ';
                                $quote = '[quote]'.$info.$query_getpostinfo->field('message').'[/quote]';
                                $query_getpostinfo->free();
                        } else {
                                $quote = $message;
                        }
                }


                if (SHOWHISTORY) {
                        if ($reverse == 1) { $query = 'ASC'; } else { $query = 'DESC'; }
                        $historycount = 0;
                        $query_threads = new query($SQL, "SELECT parseurl, dsmiley, poster, message, title FROM ".$prefix."posts WHERE threadid = $TID ORDER BY id $query LIMIT 15");
                        while($query_threads->getrow()) {
                                $historycount++;
                                $poster = $query_threads->field('poster');
                                $title = $query_threads->field('title');
                                $message = preg_replace("/([^\n\r ?&\.\/<>\"\\-]{60})/i"," \\1<br>",$query_threads->field('message'));
                                $message = codeparse($message, $query_threads->field('parseurl'), $query_threads->field('dsmiley'), $poster);
                                eval("\$history .= \"".addslashes($TI[85])."\";");
                        }
                        $query_threads->free();
                        eval("\$history = \"".addslashes($TI[84])."\";");
                }

                $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
                while ($query_getsmileyset->getrow()) {
                        $smileyset[id] = $query_getsmileyset->field('id');
                        $smileyset[name] = $query_getsmileyset->field('name');
                        eval("\$smilies .= \"".addslashes($TI[94])."\";");
                }

                $query_getsmileyset->free();

                $title = 'Replying to Topic \''.TOPICTITLE.'\'';
                //attachments - added maxuploadsize & uploadextensions variables for template
                $maxuploadsize = $config->field('maxuploadsize');
                $uploadextensions = $config->field('uploadextensions');
                eval("\$include = \"".addslashes($TI[11])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        }


        // ### Insert New Reply Into DB
        elseif ($post) {

                $SI['ref'] = 'Posting New Reply';
                $SI['templates'] = '152';
                define('SCRIPTID','post/reply/insert');
                require 'base.php';



                if (!$TID) { gen_error('No Forum specified!','Go back to the index page and try again.'); }
                if (!trim(format($message))) { gen_error('No Message specified!','Go back and try again.');  }

                if (!MEMBER && $username) {
                        $query_member = new query($SQL, "SELECT password FROM ".$prefix."profiles WHERE username = '$username'");
                        $query_member->getrow();
                        if (strcasecmp($query_member->field('password'), md5($password))) { $query_member->free(); gen_error('Invalid user information.','<a href=member.php?action=login>Click here to login</a>.'); }
                        $realuser = $username;
                        $query_member->free();
                }

                if (!MEMBER && !$realuser) { $realuser = 'Guest'; }
                if (MEMBER) { $realuser = USERNAME; }

                if ($realuser == 'Guest') { $gp = 1; $realuser = ''; } else { $gp = 0; }

                $query_seekreply= new query($SQL, "SELECT replies, forumid, title, locked FROM ".$prefix."topics WHERE id = '".$TID."'");
                $query_seekreply->getrow();
                $newreplycount = $query_seekreply->field('replies') + 1;
                if ($query_seekreply->field('locked') == '1' && !ADMIN) { gen_error('Topic is locked.','Sorry, you cannot reply anymore.'); }
                $FID = $query_seekreply->field('forumid');
                $topictitle = addslashes($query_seekreply->field('title'));
                $query_seekreply->free();

                $query_getparent = new query($SQL, "SELECT parent, dcount FROM ".$prefix."forum_display WHERE forumid = $FID");
                $query_getparent->getrow();
                $parent = $query_getparent->field('parent');
                $dcount = $query_getparent->field('dcount');
                $query_getparent->free();


                if (!$gp) {
                        $query_getgroup = new query($SQL, "SELECT id, usergroup FROM ".$prefix."profiles WHERE username = '".addslashes($realuser)."'");
                        $query_getgroup->getrow();
                        $usergroup = $query_getgroup->field('usergroup');
                        $UID = $query_getgroup->field('id');
                        $query_getgroup->free();
                } else {
                        $UID = 0;
                        $usergroup = 0;
                }

                check_perm('thread_canreply',1,$usergroup);

                $check_flood = new query($SQL, "SELECT flood FROM ".$prefix."usergroup WHERE id = '".$usergroup."'");
                $check_flood->getrow();
                if ($lastpost = $HTTP_COOKIE_VARS['lastpost']) {
                        $left = (time() - $lastpost);
                        if ($left <= $check_flood->field('flood')) {
                                $left = $check_flood->field('flood') - $left;
                                gen_error('Flood limit is activated.','Sorry, but a flood limit is activated. You have to wait another '.$left.' seconds before you can post again.');
                        }
                }
                $check_flood->free();
                setcookie('lastpost',time(),$expire,$config->field('cookiepath'),$config->field('cookiedomain'));

                $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."posts ORDER by id DESC LIMIT 1");
                $query_seekid->getrow();
                $PID = $query_seekid->field('id') + 1;
                $query_seekid->free();


                if ($parseurl == 'yes') { $parseurl = 1; }
                if ($disablesmilies == 'yes') { $dsmiley = 1; } else { $dsmiley = 0; }
                if ($disablesig == 'yes') { $dsig = 1; } else { $dsig = 0; }

                $pperpage = $config->field('plistperpage');
                $query_getinfo = new query($SQL, "SELECT replies, forumid FROM ".$prefix."topics WHERE id = '".$TID."'");
                $query_getinfo->getrow();
                counttag($message);
                $replies = ($query_getinfo->field('replies')+1);

                if ($replies < $pperpage) { $page = 1; }

                else {
                        $page = ceil(($replies / $pperpage));
                        }

                 //limit smilies
                 $query_smilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies");

            while ($query_smilies->getrow()) {
               $limit = $config->field('smilies');
               $total = $total + substr_count($message, $query_smilies->field('smiley'));
               if($total > $limit) {gen_error('Smiley limit exceeded', 'The forum administrator has limited the number of smilies to '.$limit.'');}
           }
            $query_smilies->free();




        //attachments - check if the user is attaching a file

            $attachment = 0;
            if (is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name']) && $HTTP_POST_FILES['attachment']['size'] > 2) {
              //move the file to a path we can read from even in safe mode
              $attachmentfile = './tmp'.substr($HTTP_POST_FILES['attachment']['tmp_name'], strrpos($HTTP_POST_FILES['attachment']['tmp_name'], "/"));
              move_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'],$attachmentfile) or die("Could not copy file. Please CHMOD your OpenBB's 'tmp' directory to 777");

              //check to see if uploads are allowed (if $config->field('uploadextensions') is blank then uploads are not allowed)
              if ($config->field('uploadextensions') == "") { gen_error('Attachments Not Allowed!','The forum administrator has turned off file attachments.'); }

              //check the file to make sure it has an allowed extension
              $attachmentextension = strtolower(substr($HTTP_POST_FILES['attachment']['name'], strrpos($HTTP_POST_FILES['attachment']['name'], ".")));

              //check for auto-blackholed extensions
              if (($attachmentextension == '.dll') || ($attachmentextension == '.sys') || ($attachmentextension == '.bat') || ($attachmentextension == '.com') || ($attachmentextension == '.exe')) { gen_error('File Type Not Allowed!','Files of type \''.$attachmentextension.'\' are not allowed to be uploaded. Go back and try again.'); }

              //check to see if they have an allowed extension
              $allowedextensions = explode(',', strtolower($config->field('uploadextensions')));
              $extensionallowed = 0;
              while (list(, $allowedextension) = each($allowedextensions)) {
                if ($attachmentextension == $allowedextension) { $extensionallowed = 1; }
              }
              if ($extensionallowed == 1) {
                if ($HTTP_POST_FILES['attachment']['size'] <= $config->field('maxuploadsize')) {
                  $fp = fopen($attachmentfile, "rb");
                  $attachmentcontents = "";
                  while (!feof($fp)) {
                    $attachmentcontents .= fread($fp, 4096);
                  }
                  fclose($fp);
                  $attachment = 1;
                } else {
                  gen_error('File Too Large!','The forum administrator has set the maximum attachment size to '.$config->field('maxuploadsize').' bytes. The file you uploaded was '.$HTTP_POST_FILES['attachment']['size'].' bytes. Go back and try again.');
                }
              } else {
                gen_error('File Type Not Allowed!','Files of type \''.$attachmentextension.'\' are not allowed to be uploaded. Go back and try again.');
              }
              unlink($attachmentfile);
            } elseif (!(is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'])) && ($HTTP_POST_FILES['attachment']['name'] != "")) {
              gen_error('File Upload Failed!','The upload of the file \''.$HTTP_POST_FILES['attachment']['name'].'\' did not complete correctly. Go back and try again.');
            }
            //end attachments


            //attachments - put attachment into database, if any
            $AID = 0;
            if ($attachment) {
              $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."attachments ORDER by id DESC LIMIT 1");
              $query_seekid->getrow();
              $AID = $query_seekid->field('id') + 1;
              $query_seekid->free();
              new query($SQL, "INSERT INTO ".$prefix."attachments (id, user, dateline, filename, filesize, filecontent) VALUES($AID, '".addslashes($realuser)."', '".time()."', '".$HTTP_POST_FILES['attachment']['name']."', '".$HTTP_POST_FILES['attachment']['size']."', '".mysql_escape_string($attachmentcontents)."')");
              $attachmentcontents = '';
            }
            //end attachments



                //attachments - added attachid as an insert field & value
                new query($SQL, "INSERT INTO ".$prefix."posts (dsmiley, parseurl, dsig, id, threadid, poster, message, title, dateline, isstarter, forumid, ip, guest, attachid) VALUES ('".$dsmiley."', '".$parseurl."', '".$dsig."', $PID, $TID, '".addslashes($realuser)."', '".format($message)."', '".format($subject)."', '".time()."', 0, '".$FID."', '".USERIP."', '".$gp."', '".$AID."')");
                new query($SQL, "UPDATE ".$prefix."topics SET replies = '".$newreplycount."', lastposterid= '".$UID."', lpuser = '".addslashes($realuser)."', lpdate = '".time()."', lastguest = '".$gp."' WHERE  id = '".$TID."'");




                if (strlen($topictitle) > 25) { $threadtitle = substr($topictitle, 0, 22) . '...'; } else { $threadtitle = $topictitle; }
                new query($SQL, "UPDATE ".$prefix."forum_display SET postcount = (postcount + 1),  lastposter = '".addslashes($realuser)."', lastpost = '".time()."', lastthread = '".strip_tags($threadtitle)."', lastthreadid = '".$TID."', lastposterid = '".$UID."', guest = '".$gp."' WHERE forumid = '".$FID."' OR forumid = '".$parent."'");
                if (!$gp && !$dcount) {
                        new query($SQL, "UPDATE ".$prefix."profiles SET posts = (posts + 1) WHERE username = '".addslashes($realuser)."'");
                }

                $query_seekcount = new query($SQL, "SELECT posts FROM ".$prefix."configuration");
                $query_seekcount->getrow();
                $postcount = $query_seekcount->field('posts') + 1;
                new query($SQL, "UPDATE ".$prefix."configuration SET posts = $postcount");
                $query_seekcount->free();

                $query_notify = new query($SQL, "SELECT ".$prefix."profiles.email, ".$prefix."profiles.username AS username from ".$prefix."favorites, ".$prefix."profiles where ".$prefix."profiles.username = ".$prefix."favorites.username and ".$prefix."favorites.threadid = '$TID' and ".$prefix."favorites.visit = '1' and ".$prefix."favorites.email = '1' AND ".$prefix."profiles.username != '".addslashes(USERNAME)."'");
                $query_getadminmail = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = 1 LIMIT 1");
                $query_getadminmail->getrow();
                $admin = $query_getadminmail->field('email');
                $title = stripslashes($topictitle);
                $url_of_board = $config->field('boardurl');
                $url = $url_of_board.'/read.php?TID='.$TID.'&action=lastpost';
                $poster = $realuser;
                $unsubscribe_url = $url_of_board.'/myhome.php?action=unsubscribe&TID='.$TID;

                while ($query_notify->fetch()) {
                        $username = $query_notify->field('username');
                        $email = $query_notify->field('email');
                        eval("\$subscribe_mail = \"".addslashes($TI[152])."\";");
                        mail($email, "Reply to topic '$title'", $subscribe_mail, "From: $admin");
                }
                new query($SQL, "UPDATE ".$prefix."favorites SET visit = '0' WHERE threadid = '$TID'");
                gen_redirect('Your reply has been posted, redirecting you to it.','read.php?TID='.$TID.'&page='.$page.'#'.$PID);
        }
}


// ###############################
//         DISPLAY SMILIES
// ###############################
if ($action == 'smilies') {
        include 'lib/sqldata.php';
        include 'lib/database/'.$database_server['type'].'.php';
        $SQL = new db;
        $result = $SQL->open($database_server['database'], $database_server['hostname'], $database_server['username'], $database_server['password']);

        $query_gettemplate = new query($SQL, "SELECT template, id FROM ".$prefix."templates WHERE id = 93 OR id = 92 AND groupid = '".$templategroup."'");
        while ($query_gettemplate->getrow()) {
                $template[$query_gettemplate->field('id')] =  $query_gettemplate->field('template');
        }
        $query_gettemplate->free();

        $set = $HTTP_GET_VARS['set'];

        if ($set == 'all') {
                $query_getsmilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies WHERE clickable = '1'");
        } else {
                $query_getsmilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies WHERE groupid = $set AND clickable = '1' LIMIT 12");
        }

        while ($query_getsmilies->getrow()) {
                $smiley[code] = $query_getsmilies->field('smiley');
                $smiley[image] = $query_getsmilies->field('image');
                eval("\$include .= \"".addslashes($template[93])."\";");
        }
        $include = stripslashes($include);
        eval("\$output = \"".addslashes($template[92])."\";");
        $output = stripslashes($output);
        print stripslashes($output); flush;
}


// ###############################
//         SEND TO FRIEND
// ###############################
if ($action == 'mail') {

        if ($send == '1') {

                $SI['ref'] = 'Sending a topic';
                define('SCRIPTID','post/mail/insert');
                require 'base.php';

                check_perm('thread_canmail',1);

                $query_getadminmail = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = 1 LIMIT 1");
                $query_getadminmail->getrow();
                $admin = $query_getadminmail->field('email');

                $email = $sendtoemail;
                $name = $sendtoname;
                $from = $sender;
                $mailheaders = "From: $admin\n";
                $subject = $emailsubject;
                $message = $emailmessage;
                mail($email, $subject, $message, $mailheaders);
                gen_redirect('Your friend has been notified.',"read.php?TID=$TID");

        } else {

                $SI['ref'] = 'Sending a topic';
                $SI['templates'] = '43|44';
                define('SCRIPTID','post/mail/screen');
                require 'base.php';

                check_perm('thread_canmail',1);

                $threadurl = $config->field('boardurl').'/read'.$php.'?TID='.$TID;
                $sender = USERNAME;
                $username = USERNAME;
                eval("\$msg = \"".addslashes($TI[44])."\";");

                $title = 'Send to Friend';
                eval("\$include = \"".addslashes($TI[43])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);
        }
}




// ###############################
//         EDIT POST
// ###############################
if ($action == "edit") {

        if ( $send != '1') {

                $SI['ref'] = 'Editing a post';
                $SI['templates'] = '24|94';
                define('SCRIPTID','post/edit/display');
                require 'base.php';

                if (!isset($PID) || $PID == "" ) {
                        gen_error('No Post specified!','Go back and try again.');
                }

                $query_getinfo = new query($SQL, "SELECT ".$prefix."topics.description as description, ".$prefix."topics.locked as locked, ".$prefix."posts.dsmiley as dsmiley, ".$prefix."posts.parseurl as parseurl, ".$prefix."posts.dsig as dsig, ".$prefix."posts.message as message, ".$prefix."posts.threadid as topicid, ".$prefix."posts.forumid as forumid, ".$prefix."posts.title as title, ".$prefix."posts.poster as poster, ".$prefix."topics.title as topic, ".$prefix."posts.attachid as attachid FROM ".$prefix."posts, ".$prefix."topics WHERE ".$prefix."posts.threadid = ".$prefix."topics.id AND ".$prefix."posts.id = $PID");
                $query_getinfo->getrow();

                $islocked = $query_getinfo->field('locked');

                if($islocked && !ADMIN) { gen_error('Topic Locked','This topic is locked, and you may not edit any posts'); }
                $subject = $query_getinfo->field('title');
                $description= $query_getinfo->field('description');
                $message = $query_getinfo->field('message');
                $uploadextensions = $config->field('uploadextensions');
                $maxuploadsize = $config->field('maxuploadsize');
                $FID = $query_getinfo->field('forumid');
                $TID = $query_getinfo->field('topicid');

                if ($query_getinfo->field('attachid') != 0) {
          $query_getattachment = new query($SQL, 'SELECT filename, filesize from '.$prefix.'attachments WHERE (id = '.$query_getinfo->field('attachid').')');
                  $query_getattachment->getrow();
          $deleteattachment = '<input type="checkbox" name="deleteattachment" value="yes"> <b>Delete Attachment:</b> '.$query_getattachment->field('filename').' ('.$query_getattachment->field('filesize').' bytes)<br>';
        }

                if ($query_getinfo->field('parseurl') == '1') { $parseurl = 'checked'; }
                if ($query_getinfo->field('dsmiley') == '1') { $disablesmilies = 'checked'; }
                if ($query_getinfo->field('dsig') == '1') { $disablesig = 'checked'; }

                if ($query_getinfo->field('poster') == USERNAME && USERNAME != 'Guest') {
                        $canedit = check_perm('thread_editown',1); }
                        if(!$canedit) {

                                if($user_mod[$FID]) { define('MODERATOR',1); $ismod = 1; } else { $ismod = 0; }
                                if (!$ismod) {
                                        if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
                                }
                        }
                        if (MODERATOR || ADMIN) { $canedit = 1; }
                        if (!$canedit) { gen_error('No Access!','You cannot edit this post.'); }

                        $nav = getnav('forum:'.$FID) . '> <a href="read.php?TID='.$TID.'">'.$query_getinfo->field('topic').'</a> > Edit Post';
                        $query_getinfo->free();

                        $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
                        while ($query_getsmileyset->getrow()) {
                                $smileyset[id] = $query_getsmileyset->field('id');
                                $smileyset[name] = $query_getsmileyset->field('name');
                                eval("\$smilies .= \"".addslashes($TI[94])."\";");
                        }
                        $query_getsmileyset->free();

                        $title = 'Edit Post';
                        eval("\$include = \"".addslashes($TI[24])."\";");
                        eval("\$output = \"".addslashes($TI[0])."\";");
                        lose($output);

        } else {
                $SI['ref'] = 'Editing a post';
                $SI['templates'] = '24';
                define('SCRIPTID','post/edit/display');
                require 'base.php';

                if ( ! isset($PID) || $PID == '') {
				
                        gen_error('No Post specified!','Go back and try again.');
						
                }

    if ( $delete == "yes") {
	
		include 'lib/delete.php'; 
		
		$FID = deletepost($PID);
		
	}
				
                else {
                        if ($message == '') { gen_error('No message specified!',''); }
                        $query_getinfo = new query($SQL, "SELECT ".$prefix."posts.isstarter as istopic, ".$prefix."posts.threadid as topicid, ".$prefix."posts.title as posttitle, ".$prefix."topics.title as topictitle, ".$prefix."posts.forumid as forumid, ".$prefix."posts.attachid as attachid FROM ".$prefix."posts, ".$prefix."topics WHERE ".$prefix."posts.threadid = ".$prefix."topics.id AND ".$prefix."posts.id = $PID");
                        $query_getinfo->getrow();

                        $TID = $query_getinfo->field('topicid');
                        $FID = $query_getinfo->field('forumid');
                        $attachid = $query_getinfo->field('attachid');

                        if ($query_getinfo->field('istopic') && $subject == '') { gen_error('No Subject specified!',''); }

                        $query_getuid = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".USERNAME."'");
                        $query_getuid->getrow();
                        $userid = $query_getuid->field('id');

             //limit smilies
            $query_smilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies");

            while ($query_smilies->getrow()) {
               $limit = $config->field('smilies');
               $total = $total + substr_count($message, $query_smilies->field('smiley'));
               if($total > $limit) {gen_error('Smiley limit exceeded', 'The forum administrator has limited the number of smilies to '.$limit.'');}
           }
            $query_smilies->free();

        //attachments - check if the user is attaching a file


            $attachment = 0;
            if (is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'])) {
              //check to see if uploads are allowed (if $config->field('uploadextensions') is blank then uploads are not allowed)
              if ($config->field('uploadextensions') == "") { gen_error('Attachments Not Allowed!','The forum administrator has turned off file attachments.'); }


              //check the file to make sure it has an allowed extension
              $attachmentextension = strtolower(substr($HTTP_POST_FILES['attachment']['name'], strrpos($HTTP_POST_FILES['attachment']['name'], ".")));


              //check for auto-blackholed extensions
              if (($attachmentextension == '.dll') || ($attachmentextension == '.sys') || ($attachmentextension == '.bat') || ($attachmentextension == '.com') || ($attachmentextension == '.exe')) { gen_error('File Type Not Allowed!','Files of type \''.$attachmentextension.'\' are not allowed to be uploaded. Go back and try again.'); }


              //check to see if they have an allowed extension
              $allowedextensions = explode(',', strtolower($config->field('uploadextensions')));
              $extensionallowed = 0;
              while (list(, $allowedextension) = each($allowedextensions)) {
                if ($attachmentextension == $allowedextension) { $extensionallowed = 1; }
              }
              if ($extensionallowed == 1) {
                if ($HTTP_POST_FILES['attachment']['size'] <= $config->field('maxuploadsize')) {
                  $fp = fopen($HTTP_POST_FILES['attachment']['tmp_name'], "rb");
                  $attachmentcontents = "";
                  while (!feof($fp)) {
                    $attachmentcontents .= fread($fp, 4096);
                  }
                  fclose($fp);
                  $attachment = 1;
                } else {
                  gen_error('File Too Large!','The forum administrator has set the maximum attachment size to '.$config->field('maxuploadsize').' bytes. The file you uploaded was '.$HTTP_POST_FILES['attachment']['size'].' bytes. Go back and try again.');
                }
              } else {
                gen_error('File Type Not Allowed!','Files of type \''.$attachmentextension.'\' are not allowed to be uploaded. Go back and try again.');
              }
              unlink($HTTP_POST_FILES['attachment']['tmp_name']);
            } elseif (!(is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'])) && ($HTTP_POST_FILES['attachment']['name'] != "")) {
              gen_error('File Upload Failed!','The upload of the file \''.$HTTP_POST_FILES['attachment']['name'].'\' did not complete correctly. Go back and try again.');
            }
            //end attachments

                        //delete attachment if requested
                        if ($deleteattachment == 'yes') {
                          new query($SQL, 'DELETE FROM '.$prefix.'attachments WHERE (id = '.$attachid.')');
                          $AID = 0;
                        } else {
                          $AID = $attachid;
                        }


            //attachments - put attachment into database, if any
            if ($attachment) {
              $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."attachments ORDER by id DESC LIMIT 1");
              $query_seekid->getrow();
              $AID = $query_seekid->field('id') + 1;
              $query_seekid->free();
              new query($SQL, "INSERT INTO ".$prefix."attachments (id, user, dateline, filename, filesize, filecontent) VALUES($AID, '".addslashes($realuser)."', '".time()."', '".$HTTP_POST_FILES['attachment']['name']."', '".$HTTP_POST_FILES['attachment']['size']."', '".mysql_escape_string($attachmentcontents)."')");
              $attachmentcontents = '';
            }
            //end attachments



                        // If Topic, then (possible) update title too!
                        if ($query_getinfo->field('istopic') == '1') {
                                new query($SQL, "UPDATE ".$prefix."topics SET lpdate = '".time()."', title = '".format($subject)."', description = '".format($description)."' WHERE id = '".$TID."'");
                                new query($SQL, "UPDATE ".$prefix."forum_display SET lastthread = '".format($subject)."', lastposter = '".addslashes(USERNAME)."', lastthreadid = '".$TID."', lastposterid = '".$userid."' WHERE forumid = $FID");
                        }

                        // Now Update
                        $message = format($message);
                        $subject = format($subject);
                        if ($parseurl == 'yes') { $parseurl = 1; } else {$parseurl = 0; }
                        if ($disablesmilies == 'yes') { $dsmiley = 1; } else {$dsmiley = 0; }
                        if ($disablesig == 'yes') { $dsig = 1; } else {$dsig = 0; }
                        new query($SQL, "UPDATE ".$prefix."posts SET lastupdate = '".time()."', lastupdateby = '".addslashes(USERNAME)."', title = '".$subject."', dsmiley = '".$dsmiley."', parseurl = '".$parseurl."', dsig = '".$dsig."', message= '".$message."', attachid = '".$AID."' WHERE id = $PID");

                        $query_getinfo->free();
                }

                        gen_redirect('Your post has been updated!','read.php?TID='.$TID.'&page='.$page.'#'.$PID);
        }
}

// ###############################
//         VOTE TO A POLL
// ###############################
if ($action == 'vote') {

        $SI['ref'] = 'Voting on a poll';
        $SI['templates'] = '24|94';
        define('SCRIPTID','post/vote/insert');
        require 'base.php';

        if (!isset($poll) || $poll == '') {
                gen_error('No Poll specified!','Go back and try again.');
        }

        check_perm('poll_canvote',1);
        if (!MEMBER) { gen_error('Only members can vote!','Click <a href="member.php?action=register">Here</a> to register yourself.'); }



        $query_poll = new query($SQL, "SELECT total FROM ".$prefix."polls WHERE id = '".$poll."'");
        if (!$query_poll->getrow()) { gen_error('The selected poll does not exist.','Go back and try again please'); }

        $array = explode(',',$query_poll->field('total'));
        if (in_array(USERNAME,$array)) { gen_error('You already voted on this poll.','You can only vote once on every poll'); }

        if ($query_poll->field('total') != '') {
                $total = $query_poll->field('total').','.addslashes(USERNAME);
        } else {
                $total = addslashes(USERNAME);
        }

        new query($SQL,"UPDATE ".$prefix."polls SET total = '".$total."', answer".$choice." =  (answer".$choice." + 1) WHERE id = '".$poll."'");
        gen_redirect('Your vote has been noted, thank you.','read.php?TID='.$TID);
}


 if ( $action == "delete") {
	
		include 'lib/delete.php'; 
		
		$FID = deletepost($PID);
		
	}
?>
