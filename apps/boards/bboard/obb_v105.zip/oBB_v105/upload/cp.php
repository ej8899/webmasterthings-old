<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


// +-----------------------------------------------------------+
// | Control Panel Init.                                       |
// +-----------------------------------------------------------+

//:: Declare Base File Information
$index = 'selected';

# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/


//:: Redirect To Do Setting Editing
if (!isset($do) || $do == '') {  
	$do = 'index'; $_GET['do'] = 'index'; $HTTP_GET_VARS['do'] = 'index';
}

// +-----------------------------------------------------------+
// | CP Process Settings                                       |
// +-----------------------------------------------------------+
//:: Process Update Of Settings
if ($do == 'updatesettings') {
	//:: Declare Base Info.
	$SI['templates'] = '37|50';
   	$SI['ref'] = 'Forum Cp';
   	define('SCRIPTID','cp');
   	$tmpbn = $boardname;
   	require 'base.php';
   	$boardname = $tmpbn;

	//:: Check Permission
   	check_perm('settings_canchange',0);
   	
	//:: Timezone Settings
	if ($timeoffset) { 
		$getoffset[1] = (substr($timeoffset, 1) * 3600);
      	$getoffset[2] = substr($timeoffset, 0,1);
      	$offset = $getoffset[2] . $getoffset[1];
   	}
   
	//:: Update Data
	
	  $query_checkdesign = new query($SQL, "SELECT v, t FROM ".$prefix."designs WHERE id = $design");
      $query_checkdesign->getrow();
      $vargroup = $query_checkdesign->field('v');
      $templategroup = $query_checkdesign->field('t');
      $query_checkdesign->free();
  	
	new query($SQL, "UPDATE ".$prefix."configuration SET parseurl = '".$parseurl."', dsmiley = '".$disablesmilies."', showavatar = '".$showavatars."', showsig = '".$showsignature."', showhistory = '".$showhistory."', regtype = '".$regtype."',  pmail = '".$pmail."',  vmail = '".$vmail."', actmail = '".$actmail."', sendpm = '".$sendpm."', pmauthor = '".$pmauthor."', rjctmail = '".addslashes($rjctmail)."', regpm = '".$regpm."', comnews = '".$comnews."', boardname = '".$boardname."', boardurl = '".$boardurl."', cookiepath = '".$cookiepath."', mlistperpage = '".$mlistperpage."', vargroup = $vargroup, templategroup = $templategroup, locked = '".$HTTP_POST_VARS['locked']."', lockedreason = '".$HTTP_POST_VARS['lockedreason']."', usegzip = '".$usegzip."', gzlevel = '".$gzlevel."', redirect = '".$redirect."', time1 = '".$time1."', time2 = '".$time2."', time3 = '".$time3."', defaulttimezone = $timeoffset, defaulttimeoffset = $offset, tlistperpage = $tlistperpage, plistperpage = $plistperpage, lgthsubj = $lgthsubj, lgthdesc = $lgthdesc, smilies = $smilies, avsize = '" .$avsize. "', avw = '" .$avw. "', avh = '" .$avh. "', censor = '".$censor."', showbdays = '".$showbdays."', quickpost = '" .$disablequickpost. "', maxuploadsize = '".$maxuploadsize."', uploadextensions = '".$uploadextensions."'");
  
   	if($resetudesign == 1) {
    new query($SQL, "UPDATE ".$prefix."profiles SET templategroup = '$templategroup', vargroup = '$vargroup'");
   	}
	@my_header('cp.php?do=settings&msg='.urlencode('Settings have been updated')); 	
}
//:: End Process Of Update Settings

// +-----------------------------------------------------------+
// | CP Settings Screen                                        |
// +-----------------------------------------------------------+
//:: Show Settings Screen
elseif ($do == 'settings') {
	//:: Declare Base Info.
	$SI['templates'] = '38|50|46';
   	$SI['ref'] = 'Forum Cp';
  	define('SCRIPTID','cp');
  	require 'base.php';
	$settings = 'selected';
   	$nav = ' &raquo; Board Configuration &raquo; General Configuration';

   	//:: Check Permission
	check_perm('isadmin',0);

   	//:: Query Setting Info.
	$q = new query($SQL, "SELECT showsig, showavatar, locked, showhistory, parseurl, dsmiley, boardname, regtype, vmail, pmail, sendpm, pmauthor, regpm, comnews, boardurl, cookiepath, mlistperpage, lockedreason, templategroup, vargroup, gzlevel, usegzip, redirect, time1, time2, time3, defaulttimezone, plistperpage, tlistperpage, lgthsubj, lgthdesc, avsize, censor, rjctmail, avw, avh, actmail, quickpost, showbdays, smilies, maxuploadsize, uploadextensions FROM ".$prefix."configuration LIMIT 1");
   	$q->getrow();
   
	//:: Declare Setting Info.
	$boardname = $q->field('boardname');
   	$boardurl = $q->field('boardurl');
   	$cookiepath = $q->field('cookiepath');
	$lgthsubj = $q->field('lgthsubj');
	$lgthdesc = $q->field('lgthdesc');
   	$time1 = $q->field('time1');
   	$time2 = $q->field('time2');
   	$time3 = $q->field('time3');
   	$comnews = $q->field('comnews');
   	$pmauthor = $q->field('pmauthor');
   	$regpm = $q->field('regpm');
   	$vmail = $q->field('vmail');
   	$pmail = $q->field('pmail');
    $actmail = $q->field('actmail');
   	$regtype[$q->field('regtype')] = 'checked';
   	$lockedreason = $q->field('lockedreason');
   	$gzlevel = $q->field('gzlevel');
   	$tempgroup = $q->field('templategroup');
   	$vgroup = $q->field('vargroup');
	$avsize = $q->field('avsize');
	$avh = $q->field('avh');
	$avw = $q->field('avw');
    $showbdays = $q->field('showbdays');
    $smilies = $q->field('smilies');
    $censor = $q->field('censor');
    $maxuploadsize = $q->field('maxuploadsize');
    $uploadextensions = $q->field('uploadextensions');
	$rjctmail = stripslashes($q->field('rjctmail'));
   	
	//:: End Setting Info.
   
	//:: Get design set information.
	
	 $designselector = '<select name="design">';
      $query_designs = new query($SQL, "SELECT title, t, v, id FROM ".$prefix."designs");
      while ($query_designs->getrow()) {
      	$v = $query_designs->field('v');
        if($v == $vgroup) {
           $designselector .= '<option value="'.$query_designs->field('id').'" selected>'.$query_designs->field('title').'</option>';
      } else {
           $designselector .= '<option value="'.$query_designs->field('id').'">'.$query_designs->field('title').'</option>';
         }
      }
          $query_designs->free();
      $designselector .= '</select>';
          
      //:: End Design Set
	
   	//:: Checkboxes Checking -> This is a tad against our coding standards, but it makes it simpler to look at.
	if ($q->field('locked') == 1) { $islocked = 'checked'; } else { $unlocked = 'checked'; } 
	if ($q->field('redirect') == 1) { $redir = 'checked'; } else { $direct = 'checked'; }
   	if ($q->field('usegzip') == 1) { $gzip = 'checked'; } else { $nogzip = 'checked'; }
   	if ($q->field('sendpm') == 1) { $sendpm = 'checked'; }
   	if ($q->field('showsig') == 1) { $showsignature = 'checked'; } else { $dontshowsignature = 'checked'; }
   	if ($q->field('showavatar') == 1) { $showavatar = 'checked'; } else { $dontshowavatar = 'checked'; }
   	if ($q->field('showhistory') == 1) { $showhistory = 'checked'; } else { $dontshowhistory = 'checked'; }
   	if ($q->field('parseurl') == 1) { $parseurl = 'checked'; } else { $dontparseurl = 'checked'; }
   	if ($q->field('dsmiley') == 1) { $disablesmilies = 'checked'; } else { $dontdisablesmilies = 'checked'; }
	if ($q->field('quickpost') == 1) { $quickpost = 'checked'; } else { $disablequickpost = 'checked'; }
    if ($q->field('showbdays') == 1) { $showbdayson = 'checked'; } else { $showbdaysoff = 'checked'; }

	//:: End Checkbox Checking
   
	//:: Select Box Selecting	
	$g[$q->field('gzlevel')] = 'selected';
   	$o[$q->field('mlistperpage')] = 'selected';
   	$ot[$q->field('tlistperpage')] = 'selected';
   	$op[$q->field('plistperpage')] = 'selected';
	//:: End Select Box Selecting

	//:: Timezone Information
   	$tmz = $q->field('defaulttimezone');
   
	if ($tmz < 0) {
		$tmz = str_replace('-', 'm', $tmz);
	}
	elseif ($tmz > 0) {
		$tmz = 'p'.$tmz;
	}

   	unset ($timezone);
   	$timezone[$tmz] = "selected";
	//:: End Timezone Info.	

	//:: Display The Screen
   	eval("\$timezoneselector = \"".addslashes(template(46,0))."\";");
   	eval("\$include = \"".addslashes($TI[38])."\";"); 
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	lose($output);
   	exit();
} 
//:: End Settings

// +-----------------------------------------------------------+
// | CP Avatar Controler                                       |
// +-----------------------------------------------------------+
//:: Avatar Control
elseif ($do == 'avatars') {
	//:: Declare Base Info.
	$SI['templates'] = '79|50';
   	$SI['ref'] = 'Forum Cp';
   	define('SCRIPTID','cp');
   	require 'base.php';
   
   	//:: Check Permission
	check_perm('cp_avatars',0);

	//:: Avatar Selector 
	$avatarselector = '<select name="avatar">';

   	//:: Query Avatars
	$query_avatars = new query($SQL, "SELECT name, url FROM ".$prefix."avatar");
   
	while($query_avatars->getrow()) {
      	$avatarselector .= '<option value="'.$query_avatars->field('url').'">'.$query_avatars->field('name').'</option>'; 
   	}

   	$avatarselector .= '</select>';
	//:: End Avatar Selector
	
	//:: Send Page To User
   	eval("\$include = \"".addslashes($TI[79])."\";"); 
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	lose($output);
}
//:: End Avatar Control

elseif ($do == 'index') {
	//:: Declare Base Info.
	$SI['templates'] = '200|50';
   	$SI['ref'] = 'Administration Center';
   	define('SCRIPTID','cp');
   	//$index = 'selected';
	require 'base.php';
   
   	//:: Check Permission
	check_perm('isadmin',0);
    $index_info = new query($SQL, "SELECT posts, threads, newestmember, regmembers, mostusers, mostuserstime FROM ".$prefix."configuration");
          $index_info->getrow();
          $posts = $index_info->field('posts');
          $threads = $index_info->field('threads');
          $newestmember = $index_info->field('newestmember');
          $mostusers = $index_info->field('mostusers');
          $mosttime = $index_info->field('mostuserstime');
          $members = $index_info->field('regmembers');

    $query_countmembers = new query($SQL, "SELECT COUNT(record) AS count FROM ".$prefix."active WHERE member != '' AND '".time()."' - lastaction < 600 $adminquery");
      	$query_countmembers->getrow();
      	$activemembers = $query_countmembers->field('count');
      	$query_countmembers->free();
    if(exec('uptime')) { $load = exec('uptime'); } 
          else { $load = 'Unknown'; }

//:: User activation

    $wait_approve = new query($SQL, "SELECT id, username, joindate FROM ".$prefix."profiles WHERE activated = '0' ORDER BY joindate DESC");
    while ($list_notactive = $wait_approve->getrow()) {
	$usern = $wait_approve->field('username');
	$userid = $wait_approve->field('id');
    $joindate = $wait_approve->field('joindate');
    $userlist .= "<a href=\"cp_users.php?do=edit&user=$usern\">$usern</a> -> <a href=\"cp_users.php?do=activate&UID=$userid\">Click to activate</a> | <a href=\"cp_users.php?do=remove&UID=$userid\">Click to remove user</a><br> ";
}
    if(!isset($userlist)) {$actlist = '<b>There are no members awaiting activation</b>'; }
       else {$actlist = $userlist; }
   	eval("\$include = \"".addslashes($TI[200])."\";"); 
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	lose($output);
}
 
?>
