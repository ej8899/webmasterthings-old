<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


// ###############################
//           START INIT
// ###############################

if(!isset($_GET))
{

 extract($HTTP_GET_VARS);

}
else {

 extract($_GET);
 
 
 
}

#extract($_GET);

define('SCRIPTID','board/display');
$SI['settings'] = 'tlistperpage, plistperpage';
$SI['templates'] = '5|7|36|47|91|27|8|75|119|118|117|133|134|2|3|120|121|135|136|139|190';
$SI['ref'] = 'Loading Board <a href="board.php?FID='.$FID.'">'.$FID.'</a>';
require 'base.php';

inforum($FID);

  $privilege = check_perm('forum_canview,thread_canpost,thread_canreply,poll_canstart,thread_editown,thread_candelete',1);
   $frms = explode("|", $HTTP_COOKIE_VARS['forums']);
   $con = 1;
   while (list($key,$val) = each($frms)) {
      $prop = explode("=", $val);
      $cookie_forums[$prop[0]] = $prop[1];
   }
   if ($cookie_forums['lastforum'] && $cookie_forums['lastforum'] != $FID) {
      $ltime = $cookie_forums['lasttime'];
          $cookie_forums[$cookie_forums['lastforum']] = $ltime;
      $cookie_forums['lastforum'] = '';
   }
  
// ###############################
//        CHECK FOR ERRORS
// ###############################
if (!$FID) { gen_error('No Forum specified!','Go back to the index page and try again.'); }


$query_forum = new query($SQL, "SELECT title, threadcount, type FROM ".$prefix."forum_display WHERE forumid = $FID");
if (!$query_forum->getrow()) {
   gen_error('Invalid Board!','Go back to the index page and try again.');
}
if ($query_forum->field('type') != 3 && $query_forum->field('type') != 6) { @my_header("index.php?CID=".$FID);       }


// ###############################
//            GAIN INFO
// ###############################

if (ADMIN) { $adminquery = ''; } else { $adminquery = 'AND '.$prefix.'active.invisible = \'0\''; }
    $query_browse = new query($SQL, "SELECT ".$prefix."active.member, ".$prefix."profiles.id FROM ".$prefix."active, ".$prefix."profiles WHERE member != '' AND ".$prefix."active.member = ".$prefix."profiles.username AND inforum = '".$FID."' AND '".time()."' - lastaction < 600 $adminquery");
	while($query_browse->getrow()) {
	$id = $query_browse->field('id');
	$browsememb = $query_browse->field('member');
    $browsem .= "<a href=\"member.php?action=profile&UID=$id\">$browsememb</a>, ";
 }
    if(!$browsem) {$browsing = 'None'; }
    else {
    $browsing = substr($browsem, 0, (strlen($browsem) - 2));
 }


$FNAME = $query_forum->field('title');
new query($SQL, "UPDATE ".$prefix."active SET location = 'Viewing Board <a href=\"board.php?FID=$FID\">".addslashes($FNAME)."</a>' WHERE record = '".RECORD."'");


$forum_lastvisit = $cookie_forums[$FID];
$nav = getnav('forum:'.$FID);
$query_mods = new query($SQL, "SELECT ".$prefix."moderators.modid, ".$prefix."profiles.username, ".$prefix."profiles.id FROM ".$prefix."moderators, ".$prefix."profiles WHERE ".$prefix."moderators.modid = ".$prefix."profiles.id AND ".$prefix."moderators.forumid = '".$FID."'");
 	while($query_mods->getrow()) {
		$id = $query_mods->field('id');
	 	$modname = $query_mods->field('username');
     	$moderator .= "<a href=\"member.php?action=profile&UID=$id\">$modname</a>, ";
    }

    $moderators = substr($moderator, 0, (strlen($moderator) - 2)); 
	if(empty($moderators)) { $moderators = 'Nobody'; }
    eval("\$moderators = \"".addslashes($TI[139])."\";"); 

// ### Start Page System ###
$tlistperpage = $config->field('tlistperpage');
$count = ($query_forum->field('threadcount') / $tlistperpage);
$pages = ceil($count);
$query_forum->free();

if ($page == '') {
   $page = 1;
}
$topics = 0;
$start = (($page - 1)*$tlistperpage);


// ###############################
//           NESTED FORUMS
// ###############################
$fid = $FID;
$query_forums = new query($SQL, "SELECT guest, forumid, lastpost, lastthread, lastposterid, lastposter, lastthreadid, title, description, type, postcount, threadcount, moderators FROM ".$prefix."forum_display WHERE type = 6 AND parent = '".$FID."' ORDER BY displayorder");
while ($query_forums->getrow()) {

     $nested = 1;
     $FID = $query_forums->field('forumid');
         $lg = $query_forums->field('guest');
     $forumname = $query_forums->field('title');
     $description = $query_forums->field('description');
                 $query_mods = new query($SQL, "SELECT ".$prefix."moderators.modid, ".$prefix."profiles.username, ".$prefix."profiles.id FROM ".$prefix."moderators, ".$prefix."profiles WHERE ".$prefix."moderators.modid = ".$prefix."profiles.id AND ".$prefix."moderators.forumid = '".$FID."'");
 	while($query_mods->getrow()) {
		$id = $query_mods->field('id');
	 	$modname = $query_mods->field('username');
     	$moderator .= "<a href=\"member.php?action=profile&UID=$id\">$modname</a>, ";
    }

    $moderators = substr($moderator, 0, (strlen($moderator) - 2)); 
	if(empty($moderators)) { $moderators = 'Nobody'; }
    eval("\$moderators = \"".addslashes($TI[139])."\";"); 
         if ($cookie_forums[$FID] == '') { $cookie_forums[$FID] = time(); }

    	      $posts = $query_forums->field('postcount');
			  $threads = $query_forums->field('threadcount');
              $check[lastpost] = $query_forums->field('lastpost');
	          if (!($check[lastvisit] = $cookie_forums[$FID])) { $check[lastvisit] = 0; }                
              if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'on.gif'; } else { $icon = 'off.gif'; }               
              if ($FID == $lastforum) { $check[lastvisit] = $ltime; }
              unset($lastpost);        
              $lastpost[poster] = $query_forums->field('lastposter');
              $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
              $lastpost[TID] = $query_forums->field('lastthreadid'); // Lastpost threadid
              $lastpost[UID] = $query_forums->field('lastposterid'); // Lastpost Postid
              $lastpost[title] = $query_forums->field('lastthread'); // Lastpost Postid

                  if ($lg || $posts == '0') {
             if($posts == '0') {
             $posts = '-';
             $threads = "-";
            
             eval("\$lastpost = \"".addslashes($TI[119])."\";"); }
            else {
                     eval("\$lastpost = \"".addslashes($TI[121])."\";"); }
                  } else {
                     eval("\$lastpost = \"".addslashes($TI[120])."\";");
                  }
             eval("\$include .= \"".addslashes($TI[134])."\";");
     }

    $query_forums->free();

if ($nested) {
   eval("\$nested = \"".addslashes($TI[133])."\";");
}
$include = '';
$FID = $fid;



// ###############################
//           LIST TOPICS
// ###############################

$query_topics = new query($SQL, "SELECT ".$prefix."topics.description as description, ".$prefix."topics.pollid as poll, ".$prefix."topics.lastguest as wasguest, ".$prefix."topics.guest as isguest, ".$prefix."topics.dateline as dateline, ".$prefix."topics.id as id, ".$prefix."topics.attachid as attachid, ".$prefix."topicicons.image as topicicon, ".$prefix."topics.title as title, ".$prefix."topics.lpuser as lpuser, ".$prefix."topics.lpdate as lpdate, ".$prefix."topics.locked as locked, ".$prefix."topics.poster as poster, ".$prefix."topics.posterid as UID, ".$prefix."topics.lastposterid as lastposterid, ".$prefix."topics.replies as replies, ".$prefix."topics.mode as mode, ".$prefix."topics.moved as moved, ".$prefix."topics.smode as smode, ".$prefix."topics.toforumid as toforumid, ".$prefix."topics.totopic as totopic, ".$prefix."topics.views as views FROM ".$prefix."topics, ".$prefix."topicicons WHERE forumid = $FID AND ".$prefix."topics.icon = ".$prefix."topicicons.id ORDER by smode DESC, lpdate DESC LIMIT $start,$tlistperpage");

while ($query_topics->getrow()) {
  unset($lastpost);
   $TID = $query_topics->field('id');
   $replies = $query_topics->field('replies');
   $views = $query_topics->field('views');
   $starter = $query_topics->field('poster');
   $description = strip_tags($query_topics->field('description'));
   $gp = $query_topics->field('isguest');
   $gp2 = $query_topics->field('wasguest');
   $poll =  $query_topics->field('poll');
   $UID = $query_topics->field('UID');
   $threadimage = 'images/blank.gif';
   $posttime = gmdate($timeformat[3], ($query_topics->field('dateline') + $offset));

   $lastpost[UID] = $query_topics->field('lastposterid');
   if($query_topics->field('attachid') != '0') { 
   $attachment = '<img src={imagepath}/attachment.gif align="right">';
   } else {
     $attachment = '';
   }
   

// Topic Icons

   $mode = $query_topics->field('smode');
       if($mode == '3') {
           $topicicon = $tempvars['imagepath'] . '/announce.gif';
       }
       elseif($mode == '2' || $mode == '1') {
           $topicicon = $tempvars['imagepath'] . '/sticky.gif';
       }
       elseif($query_topics->field('moved') == '1') {
           $topicicon = $tempvars['imagepath'] . '/moved.gif';
       }
       else {
           $topicicon = 'images/openbb/'.$query_topics->field('topicicon');
       }

       
$plistperpage = $config->field('plistperpage');
//print "$replies >= $plistperpage";
   if ($replies >= $plistperpage) {
      $count = (($replies + 1) / $plistperpage);
      //$tmp2 = explode(".", $count);
      $pages2 = ceil($count);
      //if (!$tmp2[1] || substr($tmp2[1],0,1) > 0) { $pages2++; }
      $tmp = $pages2;
      $i = 0;
      $pagelink = '';
      if ($pages2 > 5)
        $tmp = 3;
      while ($tmp != 0) {
         $i++;
         $tmp--;
         if($s = $query_topics->field('toforumid') && $s2 = $query_topics->field('totopic')) {
            $pagelink .= '<a href="read.php?TID='.$s2.'&page='.$i.'">'.$i.'</a> ';
         } else {
            $pagelink .= '<a href="read.php?TID='.$TID.'&page='.$i.'">'.$i.'</a> ';
         }
      }
if ($pages2 > 5)
        $pagelink .= '... <a href="read.php?TID='.$TID.'&page='.$pages2.'">Last</a>';
      $multipage = '( '.$pagelink.' )';
   } else {
      $multipage = '';
   }


   $check[lastpost] = $query_topics->field('lpdate');
   if ($cookie_forums[$FID.','.$TID]) {
     $check[lastvisit] = $cookie_forums[$FID.','.$TID];
   } else {
     $check[lastvisit] = $forum_lastvisit;
   }

   if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'topic-on'; } else { $icon = 'topic-off'; }

   if ($query_topics->field('lpuser') != '') {
      $lastpost[poster] = $query_topics->field('lpuser');
      $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));

          if (!$gp2) {
         eval("\$lastpost = \"".addslashes($TI[47])."\";");
          } else {
         eval("\$lastpost = \"".addslashes($TI[118])."\";");          }
    }

      else {

      if($gp2 == '1') {
      $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
      eval("\$lastpost = \"".addslashes($TI[118])."\";"); }

      else {
      $lastpost[poster] = $query_topics->field('poster');
          $lastpost[UID] = $UID;
      $lastpost[date] = $posttime;
          if (!$gp) {
         eval("\$lastpost = \"".addslashes($TI[91])."\";");
          } else {
         eval("\$lastpost = \"".addslashes($TI[119])."\";");
          }
   }
   } 
   if ($poll) { $icon .= '-poll'; }

   $dostatus = 1;

    if ($query_topics->field('locked') == '1') {
      $icon .= '-lock';
   } else { }

   $title = strip_tags($query_topics->field('title'));
   $mode = '';

   $icon .= '.gif';
   if ($s = $query_topics->field('toforumid')) {
      $newforumid = $s;
      $TID = $query_topics->field('totopic');
     
      
      eval("\$include .= \"".addslashes($TI[27])."\";");
   } else {
    if (!$gp) {
       eval("\$include .= \"".addslashes($TI[7])."\";");
        } else {
       eval("\$include .= \"".addslashes($TI[117])."\";");
        }
   }
   $topics++;
}



if ($topics == 0) {
   eval("\$include .= \"".addslashes($TI[8])."\";");
}

$query_topics->free();

if (!$pages) { $pages = 1; }

$pagelink = '';
if ($pages > $page + 2 && $pages > 5) {
  $tmp = max($page + 2, 5);
}
else {
  $tmp = $pages;
}
if ($page > 2 && $pages > 5) {
  $pagenumber = min($page - 3, $pages - 5);
}
else {
  $pagenumber = 0;
}

for ($i=0; $i<5 && $tmp != 0 && $pagenumber <= $pages; $i++) {   
   $pagenumber++;
   $tmp--;
   if ($pagenumber == $page) { 
      if ($page == 1) {
		 $prevlast = 1;
	  } 
	  else {
		 $previouspage = $page - 1;
	  }
      eval("\$pagelink .= \"".addslashes($TI[136])."\";");  
	  $getnext = 1;
   } 
   else {   
	  if ($getnext) { 
		 $getnext = 0;
		 $nextpage = $pagenumber;
	  }
	  eval("\$pagelink .= \"".addslashes($TI[135])."\";"); 
   }     
}

if ($prevlast) { 
   $prevlast = 0;
   $previouspage = $pages;
}

if ($getnext) { 
   $getnext = 0;
   $nextpage = 1;
}

// ###############################
//             FINALIZE
// ###############################

if ($privilege->field('thread_canpost') || ADMIN) { $priv[newtopic] = $true; } else { $priv[newtopic] = $false; }
if ($privilege->field('thread_canreply') || ADMIN) { $priv[reply] = $true; } else { $priv[reply] = $false; }
if ($privilege->field('poll_canstart') || ADMIN) { $priv[poll] = $true; } else { $priv[poll] = $false; }
if ($privilege->field('thread_editown') || ADMIN) { $priv[edit] = $true; } else { $priv[edit] = $false; }
if ($privilege->field('thread_candelete') || ADMIN) { $priv[delete] = $true; } else { $priv[delete] = $false; }

$cookie_forums['lasttime'] = time();
$cookie_forums['lastforum'] = $FID;
   while (list($key,$val) = each($cookie_forums)) {
   if ($key != '') {
      $cookie .= $key . '='. $val . '|';
   }
   }
if($config->field('cookiedomain') != '') {
	setcookie('forums',$cookie,$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
}
else {
	setcookie('forums',$cookie,$expire,$config->field('cookiepath'));
}
require 'lib/dropdown.php';
$fs[$FID] = 'selected';

eval("\$selectbox = \"".addslashes(forum_dropdown('forumid'))."\";");
eval("\$forumnav = \"".addslashes($TI[36])."\";");

$title = 'Viewing Board: '.$FNAME;

eval("\$include = \"".addslashes($TI[5])."\";");
eval("\$output = \"".addslashes($TI[0])."\";");

lose($output);
?>
