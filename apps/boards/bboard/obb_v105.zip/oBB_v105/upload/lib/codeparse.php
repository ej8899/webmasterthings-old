<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Code Parse
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

// ##########  C A C H E   E M O T I C O N S  A N D   B B C O D E  ##########

$emots			= array();
$bbcode			= array();
$bbcodeparam		= array();
$bbinsidetreatment	= array();
$bbparaminsidetreatment	= array();
$bbparamtreatment	= array();

$query_emots = new query($SQL, 'SELECT * FROM ' .$prefix. 'smilies');
while($query_emots->getrow() )
{
	$emots[trim($query_emots->field('smiley'))] =  '<img src="images/openbb/smiley/'
	.$query_emots->field('image'). '" border="0" alt="'.$query_emots->field('smiley').'" />';
}

$mecol = '#EE4100';
$emots['%you%'] = '<font color="' .$mecol. '">' .USERNAME. '</font>';


// ##########  T H E   B E E F  ##########

function bbreplace($code, $inside)
{
	global $bbcode, $tempvars;

	$urlinside = str_replace('&amp;', '&', $inside);

	switch(strtolower($code) )
	{
		case 'b':
			$return = '<strong>' .$inside. '</strong>'; break;
		case 'center':
		case 'centre':
			$return = '<div align="center">' .$inside. '</div>'; break;
		case 'email':
			$return = '<a href="mailto:' .htmlspecialchars($inside). '">' .htmlspecialchars($inside). '</a>'; break;
		case 'i':
			$return = '<em>' .$inside. '</em>'; break;
		case 'img':
			if(!preg_match('#(http|https)://(.*?)\.(gif|jpg|jpeg|png)#i', $inside) )
				$return = '[ invalid image ]';
			else
				$return = '<img src="' .str_replace('"', '', $inside). '" alt="User-Posted Image (tm)" border="0" />';
			break;
		case 'php':
/* string */		$inside = preg_replace('#\\\"((.|\n|\r)*?)\\\"#', '<b>\\\"</b><font color="#FF0088">$1</font><b>\\\"</b>', $inside);
/* string */		$inside = preg_replace('#\\\'((.|\n|\r)*?)\\\'#', '<b>\\\'</b><font color="#FF0088">$1</font><b>\\\'</b>', $inside);
/* function */		$inside = preg_replace('#([a-z0-9_]*)\((.*?)\)#i', '<font color="purple">$1</font><b>(</b>$2<b>)</b>', $inside);
/* var */		$inside = preg_replace('#(->|\$)([^;\), \[\n\r-]+)#i', '$1<font color="#009999">$2</font>', $inside);
			$inside = preg_replace('#({|})#', '<font color="#0044AA"><b>$1</b></font>', $inside);
			$return = '<!-- PHP Code BOX Begin --><table width="80%" border="0" cellspacing="0" cellpadding="0" align="CENTER">'.
			'<tr><td><font face="'.$tempvars[fontface].'" size="1"><b>PHP Code:</b></font>'.
			'<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#000000"><tr><td><table '.
			'width="100%" border="0" cellspacing="1" cellpadding="2"><tr><td bgcolor="#FFFFFF">'.
			'<font face="verdana" size="1">' .$inside. '</td></tr></table></td></tr></table></td></tr></table><!-- PHP Code BOX END -->';
			break;
		case 'quote':
		
$return = '<!-- Quote Box BEGIN --><table width="80%" border="0" cellspacing="0" cellpadding="0" align="CENTER">'.
			'<tr><td><font face="'.$tempvars[fontface].'" size="1"><b>Quote:</b></font>'.
			'<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#000000"><tr><td>'.
			'<table width="100%" border="0" cellspacing="1" cellpadding="2"><tr><td bgcolor="#FFFFFF">'.
			'<font face="verdana" size="1">' .$inside. '</font></td></tr></table></td></tr></table></td></tr></table><!-- QUOTE Box END -->';
			break;
		case 'realaudio':
			$return = '<embed src="' .str_replace('"', '', $inside). '" type="audio/x-pn-realaudio-plugin"
			nojava="true" controls="VolumePanel" style="height : 80px; width : 227px;" autostart="true" loop="100">';
		case 'u':
			$return = '<u>' .$inside. '</u>'; break;
		case 'url':
			if(preg_match('#[a-z]+?://#i', $inside) )
				$return = '<a href="' .str_replace('"', '', $urlinside). '" target="_blank">' .$inside. '</a>';
			else
				$return = '[ invalid URL ]';
			break;
		default:
			if(isset($bbcode[$code]) )
			{
				if($bbinsidetreatment[$code] == 'h') $inside = str_replace('"', '', $inside);
				else if($bbinsidetreatment[$code] == 'u') $inside = urlencode($inside);
				$return = str_replace('$inside', $inside, $bbcode[$code]);
			}
			else
				$return = '[ ' .$code. ' ]' .$inside. '[ /' .$code. ' ]';
	}
	
	return $return;
}

function bbreplaceparam($code, $param, $inside)
{
	global $bbcodeparam, $bbparaminsidetreatment, $bbparamtreatment, $tempvars;

	$urlparam = str_replace('&amp;', '&', $param);
	switch(strtolower($code) )
	{
		case 'email':
			$return = '<a href="mailto:' .htmlspecialchars($param). '">' .$inside. '</a>'; break;
		case 'color':
			$return = '<font color="'. htmlspecialchars($param) .'">'. $inside .'</font>'; break;
		case 'glow':
			$param = htmlspecialchars($param);
			$thisthing = '[' .$code. ' ' .$param. ']' .$inside. '[/glow]';
			$return = preg_replace("#\[glow tcolor=(.*?), fcolor=(.*?), size=(.*?), strength=(.*?)\](.*?)\[/glow\]#si",
					'<table style="filter:glow(color=\'\1\', strength=$4)"><tr><td>
					<font color="\2", size="\3">\5</font></td></tr></table>', $thisthing);
			break;
		case 'link':
			$return = '<table><tr> <td style="height : 2; width : 10"><img src="' .$tempvars['imagepath']. '/post.gif" alt="" />'
			.'</td><td height="2"> <font size="2"><a href="read.php?TID=' .rawurlencode($param) .'">' .$inside .'</a>'.
			'</font></td></tr></table>'; break;
		case 'url':
			if(preg_match('#[a-z]+?://#i', $param) )
				$return = '<a href="' .str_replace('"', '', $urlparam). '" target="_blank">' .$inside. '</a>';
			elseif(preg_match('#[a-z]+?.[a-z]+?.{3}#i', $param) ){
				$urlparam = 'http://'.$urlparam;
				$return = '<a href="' .str_replace('"', '', $urlparam). '" target="_blank">' .$inside. '</a>';
			}
			else
				$return = '[ invalid URL ]';
			break;
		default:
			if(isset($bbcodeparam[$code]) )
			{
				if($bbparaminsidetreatment[$code] == 'h') $inside = str_replace('"', '', $inside);
				else if($bbparaminsidetreatment[$code] == 'u') $inside = urlencode($inside);
				if($bbparamtreatment[$code] == 'h') $param = str_replace('"', '', $param);
				else if($bbparamtreatment[$code] == 'u') $param = urlencode($param);
				$return = str_replace('$inside', $inside, $bbcodeparam[$code]);
				$return = str_replace('$param', $param, $return);
			}
			else
				$return = '[ ' .$code. '=' .$param. ' ]' .$inside. '[ /' .$code. ' ]';
	}

	return $return;
}


// ##########  V A L I D A T E   U R L  ##########

function parseurl($string, $before='')
{
	$string = str_replace('"', '', $string);
	$string = str_replace('&amp;', '&', $string);
	return $before . '<a href="'. $string .'" target="_blank">'. $string .'</a>';
}


// ##########  M A I N   F U N C T I O N  ##########

function codeparse($string, $parseurl, $disallow_emots, $username = 'User')
{
	global $config, $emots, $mecol, $SQL;

	$stringnew = addslashes($string);

	do
	{
		$string = $stringnew;
		$stringnew = preg_replace('#\[([a-zA-Z]*?)[= ](.*?)\](.*?)\[/(\\1)\]#ies', 'bbreplaceparam(\'$1\', \'$2\', \'$3\')', $stringnew);
	} while($stringnew != $string);

	do
	{
		$string = $stringnew;
		$stringnew = preg_replace('#\[([a-zA-Z]*?)\](.*?)\[/(\\1)\]#ies', 'bbreplace(\'$1\', \'$2\', \'$3\')', $stringnew);
	} while($stringnew != $string);

	// parse URLs
	if($parseurl)
	{
		$stringnew = preg_replace("#(\n|^| )([a-z]{3,7})://([^, \n\r]+)#ei", "parseurl('$2://$3','$1')", $stringnew);
	}

	$string = stripslashes($stringnew);

	$emots['%me%'] = '<font color="' .$mecol. '">' .$username. '</font>';

	// parse emoticons
	if($disallow_emots != 1)
	{
		$string = strtr($string, $emots);
	}
	else
	{
		$string = str_replace('%me%', $emots['%me%'], $string);
		$string = str_replace('%you%', $emots['%you%'], $string);
	}

	return nl2br($string);
}


?>
