<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Delete Control
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


function deletepost ($PID) { 

      global $SQL, $prefix;
	  
      $query_getinfo = new query($SQL, "SELECT ".$prefix."posts.dateline as date, " . $prefix . "posts.isstarter as istopic, ".$prefix."topics.replies as replies, ".$prefix."posts.threadid as topicid, ".$prefix."posts.forumid as forumid, ".$prefix."posts.poster as poster, ".$prefix."posts.attachid as attachid FROM ".$prefix."posts, ".$prefix."topics WHERE ".$prefix."posts.threadid = ".$prefix."topics.id AND ".$prefix."posts.id = $PID");
	  $query_getinfo->getrow();
	  
	  $FID = $query_getinfo->field('forumid');
	  $TID = $query_getinfo->field('topicid');
	  $attachid = $query_getinfo->field('attachid');

	  
	  if ($query_getinfo->field('poster') == USERNAME && USERNAME != 'Guest') {
			 $canedit = check_perm('thread_candelete',1); }
			 if(!$canedit) {
			
			$query_mods = new query($SQL, "SELECT moderators FROM ".$prefix."forum_display WHERE forumid = '".$FID."'");
			$query_mods->getrow();
			
			$mods = explode(',', str_replace(' ', '', trim($query_mods->field('moderators'))));
			if (in_array(USERNAME,$mods) && USERNAME != '') { define('MODERATOR',1); $ismod = 1; }
			if (!$ismod) {
				if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
			}
		}
		if (MODERATOR || ADMIN) { $canedit = 1; }
	  if (!$canedit) { gen_error('No Access!','You cannot delete this post.'); }  
	  
	 if ($query_getinfo->field('istopic')) {
	  // * First: The post is the thread starter, delete all signs of the thread and all posts
	  // Stage 1.1: Check if the topic is the last topic 
	  
	 $check_lastpost = new query($SQL, 'SELECT lastpost, lastposter, lastthreadid FROM '.$prefix.'forum_display WHERE forumid = \''.$FID.'\'');
	 $check_lastpost->getrow(); 

 if ($check_lastpost->field('lastthreadid') == $TID) { 
	 // Stage 2.2: Find the 2nd last topic and set this as lastpost
	  $check_previous = new query($SQL, 'SELECT '.$prefix.'posts.dateline as id, '.$prefix.'posts.threadid as TID, '.$prefix.'posts.poster as poster, '.$prefix.'posts.title as title, '.$prefix.'topics.title as topictitle, '.$prefix.'profiles.id as UID FROM '.$prefix.'posts, '.$prefix.'topics, '.$prefix.'profiles WHERE '.$prefix.'topics.id != '.$TID.' AND '.$prefix.'topics.forumid = '.$FID.' AND '.$prefix.'posts.threadid = '.$prefix.'topics.id AND '.$prefix.'posts.poster = '.$prefix.'profiles.username ORDER BY '.$prefix.'posts.dateline DESC LIMIT 1');
	   $check_previous->getrow();
	   if ($check_previous->field('title')) { $title = $check_previous->field('title');} else { $title = $check_previous->field('topictitle'); } 
  
      new query($SQL,'UPDATE '.$prefix.'forum_display SET lastpost = \''.$check_previous->field('id').'\', lastposter = \''.$check_previous->field('poster').'\', lastposterid = \''.$check_previous->field('UID').'\', lastthreadid = \''.$check_previous->field('TID').'\', lastthread = \''.addslashes($title).'\' WHERE forumid = '.$FID);
	   $check_previous->free();
	 } 
     $check_lastpost->free();

	 
	 // Stage 2.3: Subtract x from the forums postcount, also form total postcount -- 1 from forums threadcount, also from total threadcount
	 new query($SQL, 'UPDATE '.$prefix.'forum_display SET postcount = (postcount - ('.$query_getinfo->field('replies').' + 1)), threadcount = (threadcount - 1) WHERE forumid = '.$FID);
	 new query($SQL, 'UPDATE '.$prefix.'configuration SET threads = (threads - 1), posts = (posts - ('.$query_getinfo->field('replies').' + 1))');
	 
	 // Stage 2.4: Investigate every post: subtract a post from author and remove it
	 $query_posts = new query($SQL, "SELECT id, poster, attachid FROM ".$prefix."posts WHERE threadid = $TID");
	 $subtract = array();
	 while ($query_posts->getrow()) {
	    $subtract[$query_posts->field('poster')]++;
		$remove .= $query_posts->field('id') . ',';
		$removeattachments .= $query_posts->field('attachid').',';
	 }

	 $remove = substr($remove,0,(strlen($remove) - 1));
	 $removeattachments = substr($removeattachments,0,(strlen($removeattachments) - 1));
	 new query($SQL, "DELETE FROM ".$prefix."posts WHERE (id IN ($remove))");
	 new query($SQL, "DELETE FROM ".$prefix."attachments WHERE (id IN ($removeattachments))");
	 while(list($key, $val) = each($subtract)) { 
	   new query($SQL, "UPDATE ".$prefix."profiles SET posts = (posts - $val) WHERE username = '".addslashes($key)."'"); 
	 }
	 new query($SQL, "DELETE FROM ".$prefix."topics WHERE id = '".$TID."'");
	 new query($SQL, "DELETE FROM ".$prefix."favorites WHERE threadid = '".$TID."'");
	 } else { 	 // *****************************************************************************************
	 // * Second: The post is not thread starter, remove it with all signs of it
	 // Stage 2.1: Check if the post is the last post
	 $check_lastpost = new query($SQL, 'SELECT lastpost, lastposter, lastthreadid FROM '.$prefix.'forum_display WHERE forumid = \''.$FID.'\'');
	 $check_lastpost->getrow();
	 
	 
	 if ($check_lastpost->field('lastpost') == $query_getinfo->field('date') && $check_lastpost->field('lastthreadid') == $TID && $check_lastpost->field('lastposter') == $query_getinfo->field('poster')) {
	 // Stage 2.2: Find the 2nd last post and set this as lastpost
	   $check_previous = new query($SQL, 'SELECT '.$prefix.'posts.dateline as id, '.$prefix.'posts.threadid as TID, '.$prefix.'posts.poster as poster, '.$prefix.'posts.title as title, '.$prefix.'topics.title as topictitle, '.$prefix.'profiles.id as UID FROM '.$prefix.'posts, '.$prefix.'topics, '.$prefix.'profiles WHERE '.$prefix.'posts.id != '.$PID.' AND '.$prefix.'topics.forumid = '.$FID.' AND '.$prefix.'posts.threadid = '.$prefix.'topics.id AND '.$prefix.'posts.poster = '.$prefix.'profiles.username ORDER BY '.$prefix.'posts.dateline DESC LIMIT 1 ');
	   $check_previous->getrow();
	   if ($check_previous->field('title')) { $title = $check_previous->field('title'); } else { $title = $check_previous->field('topictitle'); }
        new query($SQL,'UPDATE '.$prefix.'forum_display SET lastpost = \''.$check_previous->field('id').'\', lastposter = \''.$check_previous->field('poster').'\', lastposterid = \''.$check_previous->field('UID').'\', lastthreadid = \''.$check_previous->field('TID').'\', lastthread = \''.addslashes($title).'\' WHERE forumid = '.$FID);
	   $check_previous->free();
	 }
   	 $check_lastpost->free();
	 
	 // Stage 2.3: Subtract 1 from the posters postcount & from forums postcount, also form total postcount
	 new query($SQL, 'UPDATE '.$prefix.'profiles SET posts = (posts - 1) WHERE username = \''.addslashes($query_getinfo->field('poster')).'\'');
	 new query($SQL, 'UPDATE '.$prefix.'forum_display SET postcount = (postcount - 1) WHERE forumid = '.$FID);
	 new query($SQL, 'UPDATE '.$prefix.'configuration SET posts = (posts - 1)');
	 
	 // Stage 2.4: Subtract 1 from the topics reply count and get new lastpost if the post is the last reply
	 new query($SQL, 'UPDATE '.$prefix.'topics SET replies = (replies - 1) WHERE id = \''.$TID.'\'');
	 $query_getlastreply = new query($SQL, 'SELECT '.$prefix.'posts.isstarter as isthread, '.$prefix.'posts.dateline as lpdate, '.$prefix.'posts.poster as lpuser, '.$prefix.'profiles.id as lastposterid FROM '.$prefix.'posts, '.$prefix.'profiles WHERE threadid = '.$TID.' AND '.$prefix.'posts.id != '.$PID.'  AND '.$prefix.'profiles.username = '.$prefix.'posts.poster ORDER BY dateline DESC LIMIT 1');
	 $query_getlastreply->getrow();
	 if ($query_getlastreply->field('isthread')) {
	    new query($SQL, "UPDATE ".$prefix."topics SET lpdate = '', lpuser = '', lastposterid = '' WHERE id = ".$TID);
	} else {
	    new query($SQL, 'UPDATE '.$prefix.'topics SET lpdate = \''.$query_getlastreply->field('lpdate').'\', lpuser = \''.addslashes($query_getlastreply->field('lpuser')).'\', lastposterid = \''.$query_getlastreply->field('lastposterid').'\' WHERE id = '.$TID);
	}
	 $query_getlastreply->free();	
		 
	// Stage 2.5: Remove Post
	new query($SQL, 'DELETE FROM '.$prefix.'posts WHERE id = '.$PID);
	new query($SQL, 'DELETE FROM '.$prefix.'attachments WHERE id = '.$attachid);
   }   
	gen_redirect("Your topic has been removed!","board.php?FID=$FID");
	die();
}
?>

