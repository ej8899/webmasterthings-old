<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Upgrade Script v1.0.5
|   > Script written by 
|   > Date started: 05 March 2003
|
| See docs/license.html for License Information  
+--------------------------------------------------------------------------
*/

/*+------------------------------------------------------------------------------------------------
* The only really change between v1.0.4, and v1.0.5 is the copyright output and change of ownership,
* but it has be done, so here we go, all we need to do is reset the templates!
+------------------------------------------------------------------------------------------------*/
 
/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

/*+--------------------------
* Get the setup_funcs.php file
+--------------------------*/
require "./setup/setup_funcs.php";

/*+--------------------------
* Get the mySQL setuphp file
+--------------------------*/
require "./lib/sqldata.php";
	
/*+--------------------------
* Get the setup array, and assign
* the database type to "$type".
+--------------------------*/
$type = $database_server['type'];

/*+--------------------------
* Get the mySQL driver file!
+--------------------------*/	
require "./lib/database/$type.php";

/*+--------------------------
* Connect to the mySQL database
+--------------------------*/
db_connect();

$DBMS = new db;

/*+------------------------------------------------------------------------------------------------*/

function insert_templates() {

	global $src;

    /*+------------------------------------
    *  Insert new Templates into database
    +------------------------------------*/
	
	tmpl_setup($src[paktmplcb]);

}

/*+------------------------------------------------------------------------------------------------*/

function insert_admin_templates() {

	global $src;

	/*+------------------------------------
    *  Insert new ADMIN Templates into database
    +------------------------------------*/

	tmpl_setup($src[paktmpla], '', 127);
	
}
	
/*+------------------------------------------------------------------------------------------------*/	

function print_pagemiddle($stage) { 
	
    print "<!-- PHP BOT Page Middle Begin -->
    <table width='98%' border='0' align='center' cellpadding='4' cellspacing='1' bgcolor='#234D76'>
	 <tr>
	  <td class='title' bgcolor='#C0CBDB'>
	   <a href='?step=$stage'>Click Here to continue</a>
	  </td>
	 </tr>
	</table>
<!-- PHP BOT Page Middle Begin -->\n";

}	

/*+-----------------------------------------------------------------------------------------------------------------+*/

if (!empty($HTTP_GET_VARS)) {
	
		 foreach ( $HTTP_GET_VARS as $key=>$val ) {
		
		 $actions[$key] = $val;
		 
		 }
		 
		 ###############
		 
		 $allowed_keys = array ( "1" => "1", 
		                         "2" => "2", 
								 "3" => "3",
								 "home" => "home"
							   );
		 
		 /*+-------------------------------------
		 *  We had better check to make sure we can 
		 * do what has been added in the act key
		 +-------------------------------------*/
		 
		 if (! isset($allowed_keys[ $actions['step'] ]) ) {
		 
		 	       /* Do nothing at this current time :P */
				   $actions['step'] = "home";
				   
         }
		 #################
		 
		 }
		 else {
		 if (empty($HTTP_GET_VARS)) {
		 
		  $actions['step'] = "home";
		 
		 }
		 }
		 
/*+-----------------------------------------------------------------------------------------------------------------+*/
		 
if ($actions['step'] == "home") {

print_pageheader("1", "OpenBB v1.0.5 upgrade script", "OpenBB recommend that you take a mySQL backup of your board, and skin templates before continuing.");

print_pagemiddle("1");

print_pagefooter();

}

else {

if ($actions['step'] == "1") {

insert_templates();

print_pageheader("1", "OpenBB v1.0.5 upgrade script", "Stage 2 of upgraded completed!");

print_pagemiddle("2");

print_pagefooter();

}

else {

if ($actions['step'] == "2") {

insert_admin_templates();

print_pageheader("2", "OpenBB v1.0.5 upgrade script", "Stage 3 of upgraded completed!");

print_pagemiddle("3");

print_pagefooter();

}

else {

if ($actions['step'] == "3") {

print_pageheader("3", "OpenBB v1.0.5 upgrade script", "We have finished the upgrade!");

print "<a href='index.php'>Click here to return to your forums!</a>";

print_pagefooter();

}
}
}
}

?>