<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Admin CP Pruning Forums
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

extract($_GET);

function resetcounters() {
	global $SQL;
	new query($SQL, "UPDATE ".$prefix."profiles SET posts = '0'");
	new query($SQL, "UPDATE ".$prefix."forum_display SET postcount = '0', threadcount = '0'");
	new query($SQL, "UPDATE ".$prefix."topics SET replies = '0'");
	$query_posts = new query($SQL, "SELECT id, poster,threadid, forumid FROM ".$prefix."posts");
	while($result = $query_posts->fetch()) {
		new query($SQL, "UPDATE ".$prefix."profiles SET posts = posts + 1 WHERE username = '".$result['poster']."'");
		new query($SQL, "UPDATE ".$prefix."forum_display SET postcount = postcount + 1 WHERE forumid = '".$result['forumid']."'");
		new query($SQL, "UPDATE ".$prefix."topics SET replies = replies + 1 WHERE id = '".$result['threadid']."'");
	}
	$query_posts->free();
	unset($result);
	$query_topics = new query($SQL, "SELECT forumid FROM ".$prefix."topics");
	while($result = $query_topics->fetch()) {
		new query($SQL, "UPDATE ".$prefix."forum_display SET threadcount = threadcount + 1 WHERE forumid = '".$result['forumid']."'");
	}
	$query_topics->free();
	unset($result);
	
	$query_counttopics = new query($SQL, "SELECT COUNT(forumid)-1 as count FROM ".$prefix."topics");
	$topics = $query_counttopics->getrow();
	$query_countposts = new query($SQL, "SELECT COUNT(id)-1 as count FROM ".$prefix."posts");
	$posts = $query_countposts->getrow();
	$query_countusers = new query($SQL, "SELECT COUNT(id)-1 as count FROM ".$prefix."profiles");
	$members = $query_countusers->getrow();
	
	new query($SQL, "UPDATE ".$prefix."configuration SET regmembers = '".$members['count']."', posts = '".$posts['count']."', threads = '".$topics['count']."'");
	
	return;
}

if ($act == 'pruneuser') {
// :: Select user to prune
	$SI['templates'] = '50|52';
   	$SI['ref'] = 'Pruning Control Panel';
  	define('SCRIPTID','cp');
  	require 'base.php';
      check_perm('isadmin',0);
   	eval("\$include = \"".addslashes($TI[52])."\";");
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	print stripslashes($output); flush;
   	exit();
}

elseif($act == 'do_pruneuser') {
	$SI['templates'] = '50|52';
   	$SI['ref'] = 'Pruning Control Panel';
  	define('SCRIPTID','cp');
  	require 'base.php';
	check_perm('isadmin',0);
	
	$query_getid = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$user."' LIMIT 1");
	$result = $query_getid->fetch();
	$prunedid = $result['id'];
	
	if($prunethread) {
		$query_threads = new query($SQL, "SELECT id, pollid FROM ".$prefix."topics WHERE poster = '".$user."'");
		// Delete topics/polls started by user, and remove from all user's favorites
		while($threads = $query_threads->fetch()) {
			new query($SQL, "DELETE FROM ".$prefix."posts WHERE threadid = '".$threads['id']."'");
			new query($SQL, "DELETE FROM ".$prefix."favorites WHERE threadid = '".$threads['id']."'");
			new query($SQL, "DELETE FROM ".$prefix."topics WHERE poster = '".$user."'");
			new query($SQL, "DELETE FROM ".$prefix."polls WHERE id = '".$threads['pollid']."'");
		}
		// Delete posts made by user		
		new query($SQL, "DELETE FROM ".$prefix."posts WHERE poster = '".$user."'");
	} // End pruning posts/topics
	elseif(!$prunethread) {
		new query($SQL, "UPDATE ".$prefix."topics SET poster = '', posterid = '', guest = '1' WHERE poster = '".$user."'");
		new query($SQL, "UPDATE ".$prefix."posts SET poster = '', guest = '1' WHERE poster = '".$user."'");
	}	
	// Delete private messages owned by user
	new query($SQL, "DELETE FROM ".$prefix."pmsg WHERE send = '".$user."' OR accept = '".$user."'");
	// Delete favvorites owned by user
	new query($SQL, "DELETE FROM ".$prefix."favorites WHERE username = '".$user."'");
		
	resetcounters();
	
	if($prunethread) { gen_cpmsg(''.$user.' has been deleted from the forums, and all topics, posts, and polls have been pruned.'); }
	else { gen_cpmsg(''.$user.' has been deleted, and all topics/posts have been reset to guest mode.'); }
}

elseif($act == 'counters') {
	$SI['templates'] = '50';
   	$SI['ref'] = 'Resetting Forum Counters';
  	define('SCRIPTID','cp');
  	require 'base.php';
	check_perm('isadmin',0);
	
	resetcounters();
	gen_cpmsg('Counters have been successfully reset!');
}
?>
