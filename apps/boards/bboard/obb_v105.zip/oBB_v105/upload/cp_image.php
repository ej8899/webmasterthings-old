<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/

$images = 'selected';

if ($do == '') {
   $SI['templates'] = '50|143';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	
	$smileygroups = '<select name="smileygroup">';

	 $query = new query($SQL, "SELECT id, name FROM ".$prefix."smileysets");   
    while ($result = $query->getrow()) {

	$smileygroups .= '<option value="'.$query->field('id').'">'.$query->field('name').'</option>';
   }
	$smileygroups .= '</select>';


	$icons = '<select name="icon">';

	 $query = new query($SQL, "SELECT id, image FROM ".$prefix."topicicons");   
    while ($result = $query->getrow()) {

	$icons .= '<option value="'.$query->field('id').'">'.$query->field('image').'</option>';
   }
	$icons .= '</select>';


	$smileys = '<select name="smiley">';

	 $query = new query($SQL, "SELECT id, smiley, image FROM ".$prefix."smilies");   
    while ($result = $query->getrow()) {

	$smileys .= '<option value="'.$query->field('id').'">'.$query->field('smiley').' -  '.$query->field('image').'</option>';
   }
	$smileys .= '</select>';
   eval("\$include = \"".addslashes(addslashes($TI[143]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} 

elseif ($do == 'addicon') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

  if ($icon_type == 'image/pjpeg' || $icon_type == 'image/jpeg') { $type = '.jpg'; }
   if ($icon_type == 'image/gif') { $type = '.gif'; }
   
   if (!$type) {
      gen_error('Cannot upload the icon','Only GIF and JPG avatars are allowed.'); 
   }


   $query = new query($SQL,"SELECT id FROM ".$prefix."topicicons ORDER BY id DESC LIMIT 1");
   $query->getrow();
   $id = $query->field('id') + 1;

   copy($icon,'images/openbb/icon'.$id.$type);

   new query($SQL, "INSERT INTO ".$prefix."topicicons VALUES ('".$id."','icon".$id.$type."')");
   @my_header("cp_image.php");
}

elseif ($do == 'removeicon') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

   if ($icon != 0) {
   @unlink('images/openbb/icon'.$icon);
 
   new query($SQL, "DELETE FROM ".$prefix."topicicons WHERE id = '".$icon."'");
   new query($SQL, "UPDATE ".$prefix."topics SET icon = 0 WHERE icon = $icon");
   }
   @my_header("cp_image.php");
}


elseif ($do == 'addsmiley') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

  if ($smiley_type == 'image/pjpeg' || $smiley_type == 'image/jpeg') { $type = '.jpg'; }
   if ($smiley_type == 'image/gif') { $type = '.gif'; }
   
   if (!$type) {
      gen_error('Cannot upload the icon','Only GIF and JPG avatars are allowed.'); 
   }


   $query = new query($SQL,"SELECT id FROM ".$prefix."smilies ORDER BY id DESC LIMIT 1");
   $query->getrow();
   $id = $query->field('id') + 1;

   copy($smiley,'images/openbb/smiley/'.$id.$type);

   new query($SQL, "INSERT INTO ".$prefix."smilies VALUES ('".$id."','".$smileychar."','".$id.$type."','".$smileygroup."', '".$clickable."')");
   @my_header("cp_image.php");
}



elseif ($do == 'removesmiley') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

	$query = new query($SQL, "SELECT image FROM ".$prefix."smilies WHERE id = '".$smiley."'");
	$query->getrow();

   @unlink('images/openbb/smiley/'.$query->field('image'));
 
   new query($SQL, "DELETE FROM ".$prefix."smilies WHERE id = '".$smiley."'");
   @my_header("cp_image.php");
}




elseif ($do == 'addgroup') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

   $query = new query($SQL,"SELECT id FROM ".$prefix."smileysets ORDER BY id DESC LIMIT 1");
   $query->getrow();
   $id = $query->field('id') + 1;


   new query($SQL, "INSERT INTO ".$prefix."smileysets VALUES ('".$id."','".$name."')");
   @my_header("cp_image.php");
}

elseif ($do == 'removegroup') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

   new query($SQL, "DELETE FROM ".$prefix."smileysets WHERE id = $smileygroup");
   @my_header("cp_image.php");
}

?>
