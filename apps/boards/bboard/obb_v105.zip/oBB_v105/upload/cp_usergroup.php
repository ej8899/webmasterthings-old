<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/

$usergroup = 'selected';

function write_cache_usergroups ($usergroup = -1) {
	global $SQL, $config, $prefix;
	
	new query($SQL, "DELETE FROM ".$prefix."cache WHERE name LIKE 'forums:gid%'");
	
	if ($usergroups > -1)
	$query_groups = new query($SQL, "SELECT id, forum_cansee FROM ".$prefix."usergroup WHERE id = ".$usergroup." LIMIT 1");
	else
	$query_groups = new query($SQL, "SELECT id, forum_cansee FROM ".$prefix."usergroup");
	
	$query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");
	
	while ($query_groups->getrow()) {
		
		$fcs_p = array();
		$fcs = array();
		$output = '';
		$usergroup = $query_groups->field('id');
		$fcs_default = $query_groups->field('forum_cansee');
		$subcat = '-2';
		
		$query_fcs = new query($SQL, "SELECT forumid, forum_cansee FROM ".$prefix."forum_permissions WHERE uid = ".$usergroup);
		while ($query_fcs->getrow()) {
			$fcs[$query_fcs->field('forumid')] = $query_fcs->field('forum_cansee');
		}
		$query_fcs->free;
		
		
		$query_forums->seek(0);
		
		while ($query_forums->getrow()) {
			$type = $query_forums->field('type');
			if ($type == '1') {
				$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
				
				if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
				$output .= '<option value=""></option><option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$query_forums->field('title').'</option>';
				else
				$fcs_p[] = $query_forums->field('forumid');
				
				
				
				$subcat = '0';
			} elseif ($type == "2") { $stripes = ''; $s = $subcat + 2; while ($s != 0) {
				$stripes .= '-'; $s--;
			}
			
			$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
			if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
			$output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>';
			else
			$fcs_p[] = $query_forums->field('forumid');
			if ($subcat == '0') { $subcat++; }
			$subcat++;
			} else {
				$stripes = ''; $s = $subcat + 2; while ($s != 0) { $stripes .= '-'; $s--; }
				if ($type == '6') { $stripes .= '--'; }
				
				if ($type != 6) {
					$nav = $header . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
					$nestedheader = $nav . '> ';
				} else {
					$nav = $nestedheader . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
				}
				
				$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
				if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
				$output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>';
				else
				$fcs_p[] = $query_forums->field('forumid');
			}
		};
		
		new query($SQL, "INSERT INTO ".$prefix."cache (name, cache) values ('forums:gid$usergroup', '".addslashes($output)."')");
	}
	$query_forums->free;
	$query_groups->free;
}

if ($do == '') {
	$SI['templates'] = '141|50';
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	$query = new query($SQL, "SELECT id, title FROM ".$prefix."usergroup");
	while ($result = $query->getrow()) {
		
		$usergroups .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
	}
	
	eval("\$include = \"".addslashes(addslashes($TI[141]))."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
}
elseif ($do == 'edit') {
	
	$SI['templates'] = '151|50|142';
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	$query = new query($SQL, "SELECT minposts, maxposts, title, image, id FROM ".$prefix."usertitles WHERE usergroup = ".$id);
	while (list($from,$to,$title,$image,$titleid) = $query->getrow()) {
		eval("\$include .= \"".addslashes($TI[151])."\";");
	}
	
	
	$query = new query($SQL, "SELECT * FROM ".$prefix."usergroup WHERE id = ".$id);
	$result = $query->getrow();
	while (list($key,$val) = each($result)) {
		if (!is_numeric($key) && $key != 'id') {
			if ($val == 1) { $val = 'checked'; }
			eval("\$".$key." = \"".$val."\";");
		}
	}
	$action = 'do_edit';
	eval("\$include = \"".addslashes(addslashes($TI[142]))."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
} elseif ($do == 'do_edit') {
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	reset($HTTP_POST_VARS);
	while (list($key,$val) = each($HTTP_POST_VARS)) {
		if ($key != 'do' && $key != 'Submit' && $key != $id && $key != 'Submit_x' && $key != 'Submit_y') {
			$update .= $key.' = \''.$val.'\', ';
		}
	}
	$update = substr($update,0,(strlen($update) - 2));
	new query($SQL, "UPDATE ".$prefix."usergroup SET title = 'Unnamed Group', usertitle = '', isadmin = '0', index_canview = '0', search_cansearch = '0',  forum_canview = '0', forum_cansee = '0', thread_canview = '0', thread_canpost = '0', member_canregister = '0', member_canviewprofile = '0', custom = '0', design_canview = '0', design_canedit = '0', settings_canview = '0', settings_canchange = '0', member_memberlist = '0', member_whosonline = '0', thread_canprint = '0', index_canviewfaq = '0', ismoderator = '0', thread_canmail = '0', forums_canedit = '0', image = '', icon = '', myhome_canaccess = '0', myhome_myprofile = '0', myhome_mysettings = '0', myhome_readmsg = '0', myhome_newmsg = '0', pm_maxday = '0', myhome_delmsg = '0', thread_canreply = '0', avatar_cancustom = '0', myhome_dlmsg = '0', myhome_savemsg = '0', member_canmail = '0', poll_canvote = '0', poll_canstart = '0', flood = '0', myhome_favorites = '0', design_cancreateset = '0', thread_editown = '0', thread_candelete = '0', can_attach = '0',
                     statcolor = '' WHERE id = $id");
	new query($SQL, "UPDATE ".$prefix."usergroup SET $update WHERE id = '$id'");
	
	@header("location: cp_usergroup.php?do=edit&id=$id");
} elseif ($do == 'do_add') {
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	$q = new query($SQL, "SELECT id from ".$prefix."usergroup order by id desc limit 1");
	list($r) = $q->getrow();
	$keys = 'id, ';
	$values = ($r + 1).', ';

	reset($HTTP_POST_VARS);
	while (list($key,$val) = each($HTTP_POST_VARS)) {
		if ($key != 'do' && $key != 'Submit' && $key != $id && $key != 'Submit_x' && $key != 'Submit_y') {
			$keys .= $key.', ';
			$values .= '\''.$val.'\', ';
		}
	}
	$values = substr($values,0,(strlen($values) - 2));
	$keys = substr($keys,0,(strlen($keys) - 2));
	new query($SQL, "INSERT INTO ".$prefix."usergroup ($keys) VALUES ($values)");
	@header("location: cp_usergroup.php");

} elseif ($do == 'remove') {
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	new query($SQL, "DELETE FROM ".$prefix."usergroup WHERE id = '".$UGID."' LIMIT 1");
	new query($SQL, "DELETE FROM ".$prefix."usertitles WHERE usergroup = '".$UGID."'");
	@header("location: cp_usergroup.php");

} elseif ($do == 'add') {
	$SI['templates'] = '50|142';
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	$action = 'do_add';
	eval("\$include = \"".addslashes(addslashes($TI[142]))."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
} elseif ($do == 'forum') {
	$SI['templates'] = '50';
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	$include .= '<br><br><div align="center"><form method="post" action="cp_usergroup.php?do=do_forum&name='.$name.'&id='.$id.'"><font size="1" face="verdana"><b>Editing Userpermissions for forum "'.$name.'"<br><br></b></font><select name="usergroup2">';
	$query = new query($SQL, "SELECT id, title FROM ".$prefix."usergroup");
	while ($query->getrow()) {
		
		$include .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
	}
	$include .= '</select><br><br><input type="submit" value="Ok"></form></div>';
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
} elseif ($do == 'do_forum') {
	
	$SI['templates'] = '50|144';
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	if ($query = new query($SQL, "SELECT * FROM ".$prefix."forum_permissions WHERE uid = '$usergroup2' and forumid = '$id'")) {
		if ($result = $query->getrow()) {
			$action = 'forumedit';
		} else {
			$action = 'forumadd';
		}
		
		if ($result) {
			while (list($key,$val) = each($result)) {
				if (!is_numeric($key) && $key != 'forumid' && $key != 'uid') {
					if ($val == 1) { $val = 'checked'; }
					eval("\$".$key." = \"".$val."\";");
					$status = '(Custom)';
				}
			}
			
		}
		else {
			$query_default = new query($SQL, "SELECT forum_canview, thread_canview, thread_canpost, ismoderator, thread_canprint, thread_canreply, poll_canvote, poll_canstart, forum_cansee, thread_canmail, thread_editown, thread_candelete, can_attach FROM ".$prefix."usergroup WHERE id = '$usergroup2'");
			$result = $query_default->getrow();
			while (list($key,$val) = each($result)) {
				if (!is_numeric($key) && $key != 'id') {
					if ($val == 1) { $val = 'checked'; }
					eval("\$".$key." = \"".$val."\";");
					$status = '(Usergroup Default)';
				}
			}
		}
	}
	eval("\$include = \"".addslashes(addslashes($TI[144]))."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
	
} elseif ($do == 'forumadd') {
	
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	$perms = $HTTP_POST_VARS;
	while (list($key,$val) = each($perms)) {
		if ($key != 'do' && $key != 'Submit' && $key != 'permopts' && $key != 'id' && $key != 'usergroup2' && $key != 'name' && $key != 'imageField_x' && $key != 'imageField_y') {
			$keys .= $key.', ';
			$values .= '\''.$val.'\', ';
		}
	}
	$values = substr($values,0,(strlen($values) - 2));
	$keys = substr($keys,0,(strlen($keys) - 2));
	if ($keys) { $comma = ','; }
	$keys .= $comma.'uid,forumid';
	$values .= $comma.$usergroup2.','.$id;
	new query($SQL, "INSERT INTO ".$prefix."forum_permissions ($keys) VALUES ($values)");
	write_cache_usergroups($usergroup2);
	$name=urlencode($name);
	@my_header("cp_usergroup.php?do=forum&id=$id&name=$name");
	exit();
	
} elseif ($do == 'forumremove') {
	
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "DELETE FROM ".$prefix."forum_permissions WHERE forumid = '$id' and uid = '$usergroup2'");
	write_cache_usergroups($usergroup2);
	$name=urlencode($name);
	@my_header("cp_usergroup.php?do=forum&id=$id&name=$name");
	exit();
	
} elseif ($do == 'forumedit') {
	
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	
	
	while (list($key,$val) = each($HTTP_POST_VARS)) {
		if ($key != 'do' && $key != 'Submit' && $key != 'permopts' && $key != 'id' && $key != 'usergroup2' && $key != 'name' && $key != 'imageField_x' && $key != 'imageField_y') {
			$update .= $key.' = \''.$val.'\', ';
		}
	}
	
	$update = substr($update,0,(strlen($update) - 2));
	new query($SQL, "UPDATE ".$prefix."forum_permissions SET forum_cansee = '0', forum_canview = '0', thread_canview = '0', thread_canpost = '0', ismoderator = '0', thread_canprint = '0', thread_canmail = '0', thread_canreply = '0', poll_canvote = '0', poll_canstart = '0', thread_editown = '0', thread_candelete = '0', can_attach = '0' WHERE forumid = $id and uid = $usergroup2");
	new query($SQL, "UPDATE ".$prefix."forum_permissions SET $update WHERE forumid = '$id' and uid = '$usergroup2'");
	write_cache_usergroups($usergroup2);
	$name=urlencode($name);
	@my_header("cp_usergroup.php?do=forum&id=$id&name=$name");
	exit();
	
}

elseif ($do == 'hideforum') {
	
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	if ($query = new query($SQL, "SELECT * FROM ".$prefix."forum_permissions WHERE uid = '$usergroup2' and forumid = '$id'")) {
		if ($result = $query->getrow()) {
			new query($SQL, "UPDATE ".$prefix."forum_permissions SET forum_cansee = '0', forum_canview = '0', thread_canview = '0', thread_canpost = '0', ismoderator = '0', thread_canprint = '0', thread_canmail = '0', thread_canreply = '0', poll_canvote = '0', poll_canstart = '0', thread_editown = '0', thread_candelete = '0', can_attach = '0' WHERE forumid = '$id' and uid = '$usergroup2'");
		}
		
		elseif(!$result) {
			new query($SQL, "INSERT INTO ".$prefix."forum_permissions (forumid, uid, forum_cansee,forum_canview,thread_canview,thread_canpost,thread_canprint,thread_canmail,thread_canreply,poll_canvote,poll_canstart,thread_editown,thread_candelete,can_attach) VALUES ('$id', '$usergroup2', '0','0','0','0','0','0','0','0','0','0','0','0')");
			
		}
		write_cache_usergroups($usergroup2);
		$name=urlencode($name);
		@my_header("cp_usergroup.php?do=forum&id=$id&name=$name");
		exit();
		
	}
}
elseif ($do == 'readonly') {
	
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	if ($query = new query($SQL, "SELECT * FROM ".$prefix."forum_permissions WHERE uid = '$usergroup2' and forumid = '$id'")) {
		if ($result = $query->getrow()) {
			new query($SQL, "UPDATE ".$prefix."forum_permissions SET forum_cansee = '1', forum_canview = '1', thread_canview = '1', thread_canpost = '0', ismoderator = '0', thread_canprint = '1', thread_canmail = '1', thread_canreply = '0', poll_canvote = '1', poll_canstart = '0', thread_editown = '1', thread_candelete = '1', can_attach = '0' WHERE forumid = '$id' and uid = '$usergroup2'");
		}
		
		elseif(!$result) {
			new query($SQL, "INSERT INTO ".$prefix."forum_permissions (forumid, uid, forum_cansee,forum_canview,thread_canview,thread_canpost,thread_canprint,thread_canmail,thread_canreply,poll_canvote,poll_canstart,thread_editown,thread_candelete,can_attach) VALUES ('$id', '$usergroup2', '1','1','1','0','1','1','0','1','1','0','0','0')");
			
		}
		write_cache_usergroups($usergroup2);
		$name=urlencode($name);
		@my_header("cp_usergroup.php?do=forum&id=$id&name=$name");
		exit();
		
	}
}
elseif ($do == 'replyonly') {
	
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	if ($query = new query($SQL, "SELECT * FROM ".$prefix."forum_permissions WHERE uid = '$usergroup2' and forumid = '$id'")) {
		if ($result = $query->getrow()) {
			new query($SQL, "UPDATE ".$prefix."forum_permissions SET forum_cansee = '1', forum_canview = '1', thread_canview = '1', thread_canpost = '0', ismoderator = '0', thread_canprint = '1', thread_canmail = '1', thread_canreply = '1', poll_canvote = '1', poll_canstart = '0', thread_editown = '1', thread_candelete = '1', can_attach = '1' WHERE forumid = '$id' and uid = '$usergroup2'");
		}
		
		elseif(!$result) {
			new query($SQL, "INSERT INTO ".$prefix."forum_permissions (forumid, uid, forum_cansee,forum_canview,thread_canview,thread_canpost,thread_canprint,thread_canmail,thread_canreply,poll_canvote,poll_canstart,thread_editown,thread_candelete,can_attach) VALUES ('$id', '$usergroup2', '1','1','1','0','1','1','1','1','0','1','1','1')");
			
		}
		write_cache_usergroups($usergroup2);
		$name=urlencode($name);
		@my_header("cp_usergroup.php?do=forum&id=$id&name=$name");
		exit();
	}			
} elseif ($do == 'editrank') {
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "UPDATE ".$prefix."usertitles SET minposts = '$from', maxposts = '$to', title = '$title', image = '$image' WHERE id = $rankid");
	@my_header("cp_usergroup.php?do=edit&id=$id");
} elseif ($do == 'removerank') {
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "DELETE FROM ".$prefix."usertitles WHERE id = '$rankid'");
	@my_header("cp_usergroup.php?do=edit&id=$id");
} elseif ($do == 'newrank') {
	$SI['ref'] = 'Forum Control Panel';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	$q = new query($SQL, "select id from ".$prefix."usertitles order by id desc limit 1");
	$q->getrow();
	$id2 = $q->field('id') + 1;
	new query($SQL, "INSERT INTO ".$prefix."usertitles VALUES ('$id2','$from','$to','$title','$id','$image')");
	@my_header("cp_usergroup.php?do=edit&id=$id");
	}

?>
