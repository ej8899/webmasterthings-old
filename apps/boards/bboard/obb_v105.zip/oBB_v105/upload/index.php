<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

$root_path = "./";
              
/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

if(!isset($_GET))
{

 extract($HTTP_GET_VARS);

}
else {

 extract($_GET);
 
 
 
}
#extract($_GET);

if (!isset($action)) $action = "";

if ($action == 'faq') {
        $SI['ref'] = 'Viewing FAQ';
        $SI['templates'] = '96';
        define('SCRIPTID','index/faq');
        require $root_path . "base.php";

        check_perm('index_canviewfaq',0);

	$nav = '<a href="index.php">'. $config->field('boardname') . '</a> &gt; Frequently Asked Questions';
        eval("\$include = \"".addslashes($TI[96])."\";"); // Forumhome
        $title = 'Reading FAQ';
        eval("\$output = \"".addslashes($TI[0])."\";"); // Base
        lose($output);
}

        $SI['ref'] = 'Viewing Index';
        $SI['settings'] = 'posts, threads, regmembers, newestmember, newestmemberid, maxmembers, maxmemdate,  totalviews';
        $SI['templates'] = '1|2|3|4|73|75|65|67|57|58|59|29|60|66|119|120|121|189|205';
        define('SCRIPTID','index/normal');
        require $root_path . "base.php";

        $include = '';

        check_perm('index_canview',0);

        $frms = explode("|", $HTTP_COOKIE_VARS['forums']);
        $con = 1;
        while (list($key,$val) = each($frms)) {
                $prop = explode("=", $val);
                $cookie_forums[$prop[0]] = $prop[1];
        }

        if ($lastforum = $cookie_forums['lastforum']) {
                $ltime = $cookie_forums['lasttime'];
                $cookie_forums[$lastforum] = $ltime;
                $cookie_forums['lastforum'] = '';
        }

        if ($do == 'markread') {  unset($cookie_forums); }

        if (MEMBER) {
                $username = USERNAME;

                eval("\$welcome_back = \"".addslashes($TI[65])."\";");
                eval("\$login_logout = \"".addslashes($TI[67])."\";");
        } else {
                eval("\$welcome = \"".addslashes($TI[60])."\";");
                eval("\$login_logout = \"".addslashes($TI[66])."\";");
        }

        $nav = '<a href="index.php">'.$config->field('boardname').'</a>';

        // ###############################
        //              Forums
        // ###############################

        if(!isset($CID)) {

        $query_fcs = new query($SQL, "SELECT forumid, forum_cansee FROM ".$prefix."forum_permissions WHERE uid = ".USERGROUP);
        while ($query_fcs->getrow()) {
                $fcs[$query_fcs->field('forumid')] = $query_fcs->field('forum_cansee');
        }
        $query_fcs->free;

        $query_fcs = new query($SQL, "SELECT forum_cansee FROM ".$prefix."usergroup WHERE id = ".USERGROUP." LIMIT 1");
        $query_fcs->getrow();
        $fcs_default = $query_fcs->field('forum_cansee');
        $query_fcs->free;
        $fcs_p = array();

        $query_forums = new query($SQL, "SELECT guest, forumid, lastpost, lastthread, lastposterid, lastposter, lastthreadid, title, description, type, postcount, threadcount, moderators, parent FROM ".$prefix."forum_display WHERE type < 4 ORDER BY displayorder");
        while ($query_forums->getrow()) {

                $fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;

                if ($fcs_f == '1' || ADMIN && !in_array($query_forums->field('parent'), $fcs_p)) {

                        $FID = $query_forums->field('forumid');
                        $lg = $query_forums->field('guest');
                        $forumname = $query_forums->field('title');
                        $description = $query_forums->field('description');

                        if ($cookie_forums[$FID] == '') { $cookie_forums[$FID] = time(); }

                        if ($query_forums->field('type') == 1) {
                                $CID = $FID;
                                eval("\$include .= \"".addslashes($TI[2])."\";"); $cid = $FID;
                        }

                         if ($query_forums->field('type') == 3) {
                $posts = $query_forums->field('postcount');
                $threads = $query_forums->field('threadcount');
                $check[lastpost] = $query_forums->field('lastpost');
                if (!($check[lastvisit] = $cookie_forums[$FID])) { $check[lastvisit] = 0; }

                if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'on.gif'; } else { $icon = 'off.gif'; }

                if ($FID == $lastforum) { $check[lastvisit] = $ltime; }
                unset ($lastpost);
                $lastpost[poster] = $query_forums->field('lastposter');
                $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
                $lastpost[TID] = $query_forums->field('lastthreadid'); // Lastpost threadid
                $lastpost[UID] = $query_forums->field('lastposterid'); // Lastpost Postid
                $lastpost[title] = $query_forums->field('lastthread'); // Lastpost Postid

                if ($lg || $posts == '0') {
                    if($posts == '0') {
                        $posts = '-';
                        $threads = "-";
                        eval("\$lastpost = \"".addslashes($TI[119])."\";"); }
                        else {
                            eval("\$lastpost = \"".addslashes($TI[121])."\";"); }
                } else {
                    eval("\$lastpost = \"".addslashes($TI[120])."\";");
                }

                if ($cid == '') {
                    eval("\$include .= \"".addslashes($TI[73])."\";");  // Forum Template
                } else {
    if ($config->field('quickpost') == '1') {
        eval("\$include .= \"".addslashes($TI[3])."\";");  // Forum Template
     } elseif ($config->field('quickpost') == '0') {
        eval("\$include .= \"".addslashes($TI[189])."\";");  //Forum Template with quickpost
        }
                }
            }
        } else {
            $fcs_p[] = $query_forums->field('forumid');
        }
    }
    $query_forums->free();
 } // end !isset($CID)

 // CATEGORY VIEW

 else {
/* $nav = getnav('forum:'.$CID); */
         // hidden forums
        $query_fcs = new query($SQL, "SELECT forumid, forum_cansee FROM ".$prefix."forum_permissions WHERE uid = ".USERGROUP);
        while ($query_fcs->getrow()) {
                $fcs[$query_fcs->field('forumid')] = $query_fcs->field('forum_cansee');
        }
        $query_fcs->free;

        $query_fcs = new query($SQL, "SELECT forum_cansee FROM ".$prefix."usergroup WHERE id = ".USERGROUP." LIMIT 1");
        $query_fcs->getrow();
        $fcs_default = $query_fcs->field('forum_cansee');
        $query_fcs->free;

        $query_forums = new query($SQL, "SELECT guest, forumid, title, lastthread, lastposter, lastposterid, lastthreadid, lastpost, moderators, description, type, postcount, threadcount FROM ".$prefix."forum_display WHERE parent = $CID ORDER BY displayorder");

        while ($query_forums->getrow()) {

                if (isset($fcs[$query_forums->field('forumid')]))
                $fcs_f = $fcs[$query_forums->field('forumid')];
                else
                $fcs_f = $fcs_default;



                if ($fcs_f == '1') {

                        // General variables (all types)
                        $FID = $query_forums->field('forumid');
                        $forumname = $query_forums->field('title');
                        $description = $query_forums->field('description');
                        $moderators = $query_forums->field('moderators');
                        $lg = $query_forums->field('guest');
                        $posts = $query_forums->field('postcount'); // All posts
                        $threads = $query_forums->field('threadcount'); // All threads
                        $check[lastpost] = $query_forums->field('lastpost'); // Lastpost [unixtime]
                        if (!($check[lastvisit] = $cookie_forums[$FID])) { $check[lastvisit] = 0; }
                        if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'on.gif'; } else { $icon = 'off.gif'; }
                        unset ($lastpost);
                        $lastpost[poster] = $query_forums->field('lastposter');
                        $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
                        $lastpost[TID] = $query_forums->field('lastthreadid'); // Lastpost threadid
                        $lastpost[UID] = $query_forums->field('lastposterid'); // Lastpost Postid
                        $lastpost[title] = $query_forums->field('lastthread'); // Lastpost Postid
                        if ($lg || $posts == '0') {
                                if($posts == '0') {
                                        $posts = "-";
                                        $threads = "-";
                                        eval("\$lastpost = \"".addslashes($TI[119])."\";"); }
                                        else {
                                                eval("\$lastpost = \"".addslashes($TI[121])."\";"); }
                        } else {
                                eval("\$lastpost = \"".addslashes($TI[120])."\";");
                        }
                        eval("\$include .= \"".addslashes($TI[3])."\";");  // Forum Template
                }
        }
        $query_forums->free();
}


        // ###############################
        //           Board Stats
        // ###############################

        if (defined('LASTVISIT')) { $lastvisit = gmdate($timeformat[1], (LASTVISIT + TIMEOFFSET)); } else { $lastvisit = 'Can\'t remember'; }
        $time = gmdate($timeformat[2], (time() + TIMEOFFSET));
        $views = $config->field('totalviews');

        if (ADMIN) { $adminquery = ''; } else { $adminquery = 'AND '.$prefix.'active.invisible = \'0\''; }
        new query($SQL, "DELETE FROM ".$prefix."active WHERE member = '' AND '".time()."' - lastaction > 900");

        $query_countguests = new query($SQL, "SELECT COUNT(DISTINCT ip) AS count FROM ".$prefix."active WHERE member = ''");
        $query_countguests->getrow();
        $activeguests = $query_countguests->field('count');
        $query_countguests->free();

        $query_countmembers = new query($SQL, "SELECT COUNT(record) AS count FROM ".$prefix."active WHERE member != '' AND '".time()."' - lastaction < 900 $adminquery");
        $query_countmembers->getrow();
        $activemembers = $query_countmembers->field('count');
        $query_countmembers->free();

         $totalusers = $activemembers+$activeguests;
     $mosttime = date("h:i m-j-Y");
     if ($totalusers > $mostusers) {
             new query($SQL, "UPDATE ".$prefix."configuration SET mostusers='".$totalusers."', mostuserstime = '".$mosttime."'");
         }

        if ($activemembers != 0 && $activeguests != 0) {
                eval("\$activeusers = \"".addslashes($TI[57])."\";");
        }

        if ($activemembers == 0) {
                eval("\$activeusers = \"".addslashes($TI[59])."\";");
        }

        if ($activeguests == 0) {
                eval("\$activeusers = \"".addslashes($TI[58])."\";");
        }

        // Colored Active Users
        $query_activemembers = new query($SQL, "SELECT ".$prefix."profiles.username as member, ".$prefix."usergroup.statcolor, ".$prefix."profiles.id as memberid FROM ".$prefix."active, ".$prefix."profiles, ".$prefix."usergroup WHERE ".$prefix."usergroup.id = ".$prefix."profiles.usergroup AND ".$prefix."active.member = ".$prefix."profiles.username AND ".$prefix."active.member != '' AND '".time()."' - ".$prefix."active.lastaction < 900 $adminquery ORDER by ".$prefix."profiles.username");
        while($query_activemembers->getrow()) {
                if($query_activemembers->field('statcolor')) {
             $actstatus = '<font color="'.$query_activemembers->field('statcolor').'">'.$query_activemembers->field('member').'</font>';
        }
        else {
             $actstatus = $query_activemembers->field('member');
        }
                  $activememberlist .= '<a href="member'.$php.'?action=profile&UID='.$query_activemembers->field('memberid').'">'. $actstatus . '</a>, ';
        }
        $query_activemembers->free();

        $activememberlist = substr($activememberlist, 0, (strlen($activememberlist) - 2));


// Get today's birthdays

    if($config->field('showbdays')) {
    $bdayoffset = (time()+$offset);
    $today = date("m-d",$bdayoffset);
    $birthdays = new query($SQL, "SELECT username, id, birthdate FROM ".$prefix."profiles WHERE birthdate LIKE('%-$today')");
while ($birthday = $birthdays->getrow()) {
        $bdayuser = $birthdays->field('username');
        $bdayid = $birthdays->field('id');
        $datebits = explode("-", $birthdays->field('birthdate'));
    if($datebits[0] == '0000') { $bdage = '';}
    else{$bdage = date("Y") - $datebits[0]; }
        if ($bdage > 0) { $age = "($bdage)"; }
        else { $age = ''; }

 $bdays .= "<a href=\"member.php?action=profile&UID=$bdayid\">$bdayuser</a> $age, ";
        }
    $tbirthdays = substr($bdays, 0, (strlen($bdays) - 2));
    if($tbirthdays) {
        eval("\$show_bdays = \"".addslashes($TI[205])."\";");
    $birthdays->free();
    }
  }

    $totalthreads = $config->field('threads'); // All threads
        $totalposts = $config->field('posts'); // All posts
        $totalmembers = $config->field('regmembers'); // All members
        $newmember[name] = $config->field('newestmember'); // Newest Member
        $newmember[id] = $config->field('newestmemberid'); // Newest Member's ID

        // ###############################
        //         Private Messaging
        // ###############################
        if (MEMBER) {

                $query_countnewpm = new query($SQL, "SELECT COUNT(id) AS count FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND isread = '0' AND box = 'inbox'");
                $query_countnewpm->getrow();
                $pmnew = $query_countnewpm->field('count');
                $query_countnewpm->free();

                $query_countallpm = new query($SQL, "SELECT COUNT(time) AS count FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND box = 'inbox'");
                $query_countallpm->getrow();
                $pmtotal = $query_countallpm->field('count');
                $query_countallpm->free();

                eval("\$pms = \"".addslashes($TI[29])."\";");
        }


        while (list($key,$val) = each($cookie_forums)) {
                if ($key != '') {
                        if (!eregi(',',$key)) {
                                $cookie .= $key . '='. $val . '|';
                        }
                }
        }
        if($config->field('cookiedomain') != '') {
                setcookie('forums',$cookie,$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
        }
        else {
                setcookie('forums',$cookie,$expire,$config->field('cookiepath'));
        }
        eval("\$include = \"".addslashes($TI[1])."\";"); // Forumhome
        $title = 'OpenBB'; // Set Title
        eval("\$output = \"".addslashes($TI[0])."\";"); // Base
        lose($output);
?>
