<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Setup Functions
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


error_reporting(0);
define('OBB_VER','OpenBB 1.0.5');

$spl[1] = '@18�@';
$spl[2] = '@17�@';
$spl[3] = '@16�@';
$spl[4] = '@15�@';
$spl[5] = '@14�@';

$src = array(

        'pakdbstruct' => 'setup/dbstruct.ob',

        'paktmplcb' => 'setup/tmplset.ob',

        'paktmplcp' => 'setup/tmplsetcp.ob',
        
        'paktmplcg' => 'setup/tmplsetcg.ob',
        
        'paktmpla' => 'setup/tmplset_admin.ob',

        'pakforums' => 'setup/forums.ob',

        'pakusergroups' => 'setup/usergroups.ob',

        'paktitles' => 'setup/titles.ob',

		'paksmilies' => 'setup/smilies.ob'

);

function print_pageheader($step='1',$title='',$desc='') {
echo <<<HTML_BEGIN
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Open Bulletin Board Community Setup -- Step: $step</title>
<meta name="keywords" content="bbs, openbb, forum, board, blazeboard, discussion, bb2">
<meta name="description" content="is a discussion forum powered by OpenBB">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script LANGUAGE="Javascript">
<!--
function redirect(url) {
	window.location.replace(url);
}
//-->
</script>
<style type="text/css">
<!--
a:link {  color: #000000; text-decoration: none}
a:visited {  color: #000000; text-decoration: none}
a:active {  color: #FF3300; text-decoration: none}
a:hover {  color: #FF3300; text-decoration: none}

a.topnav:link {  color: #FFFFFF; text-decoration: none}
a.topnav:visited {  color: #FFFFFF; text-decoration: none}
a.topnav:active {  color: #FF3300; text-decoration: none}
a.topnav:hover {  color: #FF3300; text-decoration: none}

a.headernav:link {  color: #FFFFFF; text-decoration: none}
a.headernav:visited {  color: #FFFFFF; text-decoration: none}
a.headernav:active {  color: #FF3300; text-decoration: none}
a.headernav:hover {  color: #FF3300; text-decoration: none}

.small {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9px; }
TABLE {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
.title {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; font-weight: bold; }
.copyright {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9px; color: #FFFFFF; }

INPUT, SELECT, TEXTAREA		{
	BACKGROUND-COLOR: #FFFFFF;
	COLOR: #000000;
	FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif;
	FONT-SIZE: 12px;
	BORDER-LEFT: #234D76 solid 1px;
	BORDER-RIGHT: #234D76 solid 1px;
	BORDER-TOP: #234D76 solid 1px;
	BORDER-BOTTOM: #234D76 solid 1px;

}

-->
</style>
</head>
<body bgcolor="#56708D" text="#000000" link="#000000" vlink="#000000" alink="#FF3300">

<table width="100%" bgcolor="#56708D" border="0" cellspacing="0" cellpadding="0">
	<tr> 
    	<td width="19%" align="left"> 
      		<a href="index.php"><img src="setup/logo.gif" border="0"></a>
    	</td>
	</tr>
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76" align="center">
	<tr>
		<td bgcolor="#FFFFFF"> 
      		<br>
      		<div align="center">
      			<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76">
  					<tr bgcolor="#F8F8F8">
    					<td>
      				   		<span style="font-size: 12px;"><b>$title</b></span><br>
     						<span class="small">$desc</span>
  						</td>
  					</tr>
				</table>
				<br>
HTML_BEGIN;
}

function print_pagefooter() {

	$copy_year = (date("Y"));

echo <<<HTML_END
</div>
		</td>
	</tr>
</table>
<div align="center">
<br />
<span class="copyright">Powered By Open Bulletin Board <br>Copyright &copy; 2000 - $copy_year by <a class="topnav" href="http://www.openbb.com">the OpenBB Group</a></span>
</div>
</body>
</html>
HTML_END;
}

function fwriteable($file) {
	if (!$config=@fopen($file,"a")) { 
		return 0;
	}
	else {
		@fclose($config);
		return 1;
	}
}

function dbstruct_get_tables($filename) {
global $spl;

	$rarr = array();
	// load the raw structure file first
	$filesize=filesize($filename);
	$fp=fopen($filename,'r');
	$raw=fread($fp,$filesize);
	fclose($fp);
	
	// now extract the real data from the raw
	list($header, $tables) = explode($spl[1], $raw);
	list($desc, $class, $date, $other) = explode($spl[2], $header);
	$tables = explode($spl[2], $tables);

	if ($class != 'OBB_PACK_DBSTRUCT') die('Class mismatch. Please check if the setup source package is correct.'); 	 	for ($i=0; $i<count($tables); $i++) {
		list($tname, $rawfield, $rawindex) = explode($spl[3], $tables[$i]);
		$rarr[] = $tname;
	}
	return $rarr;
}

function dbstruct_setup($filename) {
global $spl, $query, $dbname, $prefix;

	// load the raw structure file first
	$filesize=filesize($filename);
	$fp=fopen($filename,'r');
	$raw=fread($fp,$filesize);
	fclose($fp);
	
	// now extract the real data from the raw
	list($header, $tables) = explode($spl[1], $raw);
	list($desc, $class) = explode($spl[2], $header);
	$tables = explode($spl[2], $tables);

	if ($class != 'OBB_PACK_DBSTRUCT') die('Class mismatch. Please check if the setup source package is correct.'); 	 	$result = query("SHOW TABLES FROM $dbname"); 	print mysql_error(); 	while ($row = fetch($result)) { 		$atableexists[$row[0]] = 1; 	} 	 	for ($i=0; $i<count($tables); $i++) {
		list($tname, $rawfield, $rawindex) = explode($spl[3], $tables[$i]);
		$fields = explode($spl[4], $rawfield);
		$indexes = explode($spl[4], $rawindex);
		
		// setup the deafults
		$tableexists = $atableexists[$prefix.$tname];
		$sqlf = '';
		$sqlf2 = '';
		$sqlfi = '';
		$fieldexists = array();
		$indexexists = array();
        $tname = $prefix.$tname;

				
		// check fields
		// index the fields first
		if ($tableexists) {
			$result = query("SHOW FIELDS FROM `$tname`");
			while($row = fetch($result)) {
				if ($row['Null'])
					$fnotnull = '';
				else
					$fnotnull = 'NOT NULL';
				$dbfstr[$row['Field']] = "$row[Field];$row[Type];$row[Default];$fnotnull";
				if ($row[Extra] != '')
					$dbfextra[$row['Field']] = $row[Extra];
				$fieldexists[$row['Field']] = 1;
			}
		} 		$splitter = '';
		$splitter2 = '';
		for ($ii=0; $ii<count($fields); $ii++) {
			list($fname, $ftype, $fdef, $fnotnull, $fextra) = explode($spl[5], $fields[$ii]);
			
			// make some defaults :p
			if ($fdef != '')
				$fdef2 = "DEFAULT '$fdef'";
			else
				$fdef2 = '';
			
			// alter the table
			if ($tableexists && $fieldexists[$fname]) {
				// check if anything is wrong in the field
				$pkfstr = "$fname;$ftype;$fdef;$fnotnull";
				if (strtolower($dbfstr[$fname]) != strtolower($pkfstr)) {
					// something IS wrong, fix it!
					$sqlf .= $splitter."CHANGE $fname $fname $ftype $fdef2 $fnotnull";
				} else
				if ($dbfextra[$fname] != $fextra) {
					// the extra is wrong, can only change this after indexes are fixed
					$sqlf2 .= $splitter2."CHANGE $fname $fname $ftype $fdef2 $fnotnull $fextra";
				}
			}
			
			// add new field to table that exists
			if ($tableexists && !$fieldexists[$fname]) {
				$sqlf .= $splitter."ADD `$fname` $ftype $fdef2 $fnotnull";
				if ($fextra != '')
					$sqlf2 .= $splitter2."CHANGE $fname $fname $ftype $fdef2 $fnotnull $fextra";
			}
			// add new field to a new table
			if (!$tableexists) {
				$sqlf .= $splitter."$fname $ftype $fdef2 $fnotnull";
				if ($fextra != '')
					$sqlf2 .= $splitter2."CHANGE $fname $fname $ftype $fdef2 $fnotnull $fextra";
			}
			if ($sqlf != '')
				$splitter = ', ';
			if ($sqlf2 != '')
				$splitter2 = ', ';
		}
	
		if (!$tableexists) {
			// CREATE the table
			query("CREATE TABLE $tname ($sqlf)");
		} else
		if ($sqlf != '') {
			// ALTER the table
			query("ALTER TABLE $tname $sqlf");
		}
		
		// check indexes
		// index the fields first
		if ($tableexists) {
			$result = query("SHOW KEYS FROM $tname");
			while($row = fetch($result)) {
				if ($row['Key_name'] != 'PRIMARY')
					$indexexists[$row['Column_name']] = 1;
			}
		}

		$splitter = '';
		if ($rawindex != '')
		for ($ii=0; $ii<count($indexes); $ii++) {
			list($kname, $kfield) = explode($spl[5], $indexes[$ii]); 			// drop the existing primary key and assign this new one
			if ($kname == 'PRIMARY')
				$sqlfi .= $splitter."DROP PRIMARY KEY, ADD PRIMARY KEY($kfield)";
			else {
				// if index exists, destroy it, then create :p
				if ($indexexists[$kname])					
					$sqlfi .= $splitter."DROP INDEX $kname, ADD INDEX($kfield)";
				else
					$sqlfi .= $splitter."ADD INDEX($kfield)";
			}
			if ($sqlfi != '')
				$splitter = ', ';
		}
		if ($sqlfi != '')
			$splitter2.$sqlfi;
		
		$sqlf2 = ''.$sqlfi.$splitter2.$sqlf2;
		
		// for extra properties needed to be done after indexes
		if ($sqlf2 != '') {
			// ALTER the table
			query("ALTER TABLE $tname $sqlf2");
		}
	}

}

function tmpl_setup($filename, $setname,  $gid = 0, $tid = 0, $keepvars = 0, $loadtmpls = array('all')) {
	global $spl, $prefix; 	$fd = fopen($filename, 'r');
	$data = fread ($fd, filesize ($filename));
	fclose($fd);
    unset($keepvars);
	list($header, $tdata, $vdata) = explode($spl[1],$data); 	if (!empty($setname)) {

	query("INSERT INTO ".$prefix."designs VALUES ('".$setname."','".$tid."','".$gid."','".$gid."')");
	}
	
	list($pname, $psig, $pdate, $pother) = explode($spl[2], $header);

	// check header
	if ($psig != 'OBB_USERPACK_TEMPLATESET') {
		print '<B>ERROR:</B> Invalid OBB pack signature ('.$setname.'). Possible reasons maybe the file is corrupted or is not a template pack.';
		exit;
	}

	// now import the data

	$tmpls = explode($spl[2], $tdata);
	$vars = explode($spl[2], $vdata);

	$etmpls = array();
	$evars = array();

	$loadsel = 0;
	if ($loadtmpls[0] != 'all') {
		// cat current templates
		$result = query("SELECT * FROM ".$prefix."templates WHERE groupid=$gid");
		while ($row = fetch($result)) {
			$etmpls[] = $row['id'];
		}
		$lids = implode($loadtmpls);
		$loadsel = 1;
		query("DELETE FROM ".$prefix."templates WHERE id IN ($lids) AND groupid = $gid");
		
	} else {
		query("DELETE FROM ".$prefix."templates WHERE groupid = $gid");
	}

	foreach ($tmpls as $tmpl) {
		list($tid, $rtmpl) = explode($spl[3], $tmpl);
		if ($loadsel) {
			if (in_array($tid, $loadtmpls) || !in_array($tid, $etmpls))
				query("INSERT INTO ".$prefix."templates VALUES ('".$tid."','".addslashes($rtmpl)."','".$gid."')");
		} else {
			query("INSERT INTO ".$prefix."templates VALUES ('".$tid."','".addslashes($rtmpl)."','".$gid."')");
		}
	}

	if (!empty($setname)) {
	if (!$keepvars) {
		query("DELETE FROM ".$prefix."vars WHERE groupid = $gid");
	} else {
		// check for the vars that exists
		$result = query("SELECT * FROM ".$prefix."vars");
		while ($row = fetch($result)) {
			$evars[] = $row['org'];	
		}
	}
	foreach ($vars as $var) {
		list($vorg, $vrep) = explode($spl[3], $var);
		if (($keepvars && !in_array($vorg, $evars)) || !$keepvars)
			query("INSERT INTO ".$prefix."vars VALUES ('".$gid."','".$vorg."','".addslashes($vrep)."')");
			
	}}

}
?>
