<?php

/*+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Global Compliance
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/
# Emulate Register Globals
extract($_GET);
extract($_POST);
extract($_FILES);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);

?>
