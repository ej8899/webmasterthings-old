<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


// +-----------------------------------------------------------+
// | Prompt For Username                                       |
// +-----------------------------------------------------------+


if(!isset($_GET))
{
 
 extract($HTTP_GET_VARS);
 
}
else{

 extract($_GET);
 
}
#extract($_GET);

if ($do == '') {
	//:: Select User In the Dropdown
	$users = 'selected';

	$SI['templates'] = '50|52';
   	$SI['ref'] = 'Forum Control Panel';
  	define('SCRIPTID','cp');
  	require 'base.php';
      check_perm('isadmin',0);
   	eval("\$include = \"".addslashes($TI[52])."\";");
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	print stripslashes($output); flush;
   	exit();
}

// +-----------------------------------------------------------+
// | Open Up User For Editing                                  |
// +-----------------------------------------------------------+

elseif ($do == 'edit') {
	//:: Select User In the Dropdown
	$users = 'selected';

	//:: Declare Base Information
	$SI['templates'] = '50|51';
   	$SI['ref'] = 'Forum Control Panel';
   	define('SCRIPTID','cp');
   	require 'base.php';
      check_perm('isadmin',0);
   
	//:: Set The Username Variable
	if($user != '') {
		 $username = $user; 
	}
         
	//:: Get User Information
	$query = "SELECT id, username, password, email, homepage, note, icq, aim, yahoo, location, note, showemail, usergroup, posts, joindate, timeoffset, timezone, avatar, custom, homepagedesc, occupation, msn, templategroup, vargroup, totalpm, lastpm, invisible, activated, banned, sig, showavatar, showsig, showhistory, ip, lastactive FROM ".$prefix."profiles WHERE username = '$username'";
      $query_users = new query($SQL, $query) or $SQL->error();
      $user = $query_users->getrow();
         
	//:: If There Is No User Give Error
	if ($user['username'] == '') {
      	$include = '<font size="2" face="verdana"><b><center>That user does not exist!</center></b></font>';
            eval("\$output = \"".addslashes($TI[50])."\";");
            print stripslashes($output); flush;
            exit();
      }
	
	//:: Setup Profile Information
	($user['banned'] == "0") ? ($notbanned = "CHECKED") : ($banned = "CHECKED");
      ($user[invisible] == "0") ? ($vis = "CHECKED") : ($invis = "CHECKED");
      ($user[showemail] == "0") ? ($hidemail = "CHECKED") : ($donthidemail = "CHECKED");
      ($user[showavatar] == "0") ? ($dontshowavatar = "CHECKED") : ($showavatar = "CHECKED");
      ($user[showsig] == "0") ? ($dontshowsignature = "CHECKED") : ($showsignature = "CHECKED");
      ($user[showhistory] == "0") ? ($dontshowhistory = "CHECKED") : ($showhistory = "CHECKED");
	  $hostname = gethostbyaddr($user[ip]);
	  $user[ip] = "$user[ip] ($hostname)";
	  $joindate = gmdate($timeformat[3], ($user[joindate]));
      $lastactive = gmdate($timeformat[3], ($user[lastactive]));
       
      //:: Get Group Related Information Of User / Setup Group Dropdown
	$query = new query($SQL, "SELECT id, title FROM ".$prefix."usergroup WHERE id != 0");
      
	while ($result = $query->getrow()) {
      
		if ($user['usergroup'] == $result['id']) {
   			$usergroups .= '<option value="'.$query->field('id').'" selected>'.$query->field('title').'</option>';
        	} 
		else {
        		$usergroups .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
        	}
   	}
	//:: End Usergroup Related

   	//:: Parse The Screen
	eval("\$include = \"".addslashes($TI[51])."\";");
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	print stripslashes($output); flush;
   	exit();
}


// +-----------------------------------------------------------+
// | Edit The User                                             |
// +-----------------------------------------------------------+
 
elseif ($do == 'do_edit') {
	//:: Select User In the Dropdown
	$users = 'selected';

	//:: Declare Base Information
	$SI['templates'] = '50|51';
   	$SI['ref'] = 'Forum Control Panel';
   	define('SCRIPTID','cp');
   	require 'base.php';
      check_perm('isadmin',0);
	
	//:: Declare Rename Information
	if($renamename != '') {
		$rename = $renamename;
		$rename_do = 1;
	}
	else {
		$rename = $username;
		$rename_do = 0;
	}
	//:: End Declaration Of Rename Information

   	//:: Declare New Password Information
	if($newpass != $newpass2) {
      	$include = '<font size="2" face="verdana"><b><center>The passwords you entered do not match!</center></b></font>';
            eval("\$output = \"".addslashes($TI[50])."\";");
            print stripslashes($output); flush;
            exit();
   	}
    
	if((strlen($newpass) > 3)) {
      	$password = $newpass;
       	new query($SQL, "UPDATE ".$prefix."profiles SET password = '".md5($password)."' WHERE username = '".$username."'");
   	}
	//:: End New Password Related Routines

	//-> Process If New Username <-//
	if($rename_do == 1) {
		new query($SQL, "UPDATE ".$prefix."pmsg SET send = '".$rename."' WHERE send = '".$username."'");
		new query($SQL, "UPDATE ".$prefix."pmsg SET accept = '".$rename."' WHERE accept = '".$username."'");
		new query($SQL, "UPDATE ".$prefix."pmsg SET owner = '".$rename."' WHERE owner = '".$username."'");
		new query($SQL, "UPDATE ".$prefix."posts SET poster = '".$rename."' WHERE poster = '".$username."'");
		new query($SQL, "UPDATE ".$prefix."topics SET poster = '".$rename."' WHERE poster = '".$username."'");
		new query($SQL, "UPDATE ".$prefix."active SET member = '".$rename."' WHERE member = '".$username."'");
		new query($SQL, "UPDATE ".$prefix."favorites SET username = '".$rename."' WHERE username = '".$username."'");
	}
	//-> End Process If New Username <-//
       
	//:: Update User Information
	new query($SQL, "UPDATE ".$prefix."profiles SET username = '".$rename."', usergroup = '".$usergroup."', banned = '".$banned."', homepage = '".$homepage."', email = '".$email."', icq = '".$icq."', aim = '".$aim."', yahoo = '".$yahoo."', msn = '".$wm."', posts = '".$posts."', occupation = '".$occupation."', note = '".$personal."', location = '".$location."', sig = '".$sig."', custom = '".$custom."', invisible = '".$invisible."', showsig = '".$showsignature."', showemail = '".$showemail."', showavatar = '".$showavatars."', showhistory = '".$showhistory."', homepage = '".$homepage."', homepagedesc = '".$homepagedesc."' WHERE username = '".$username."'");
      
	//:: Display Successfully Updated
	$include = '<font size="2" face="verdana"><b><center>User modified<br><br><a href="cp_users.php">Click here to return to the user manager</center></b></font>';
      eval("\$output = \"".addslashes($TI[50])."\";");
      print stripslashes($output); flush;
      exit();

	//:: Redirect User Back To cp_users.php
	@my_header("cp_users.php");
}

// +-----------------------------------------------------------+
// | Activate User Routines                                    |
// +-----------------------------------------------------------+

/* This routine has multiple sections to it. The first part here
is displaying the activate list and showing options. Then there
are processes to activate the user or remove the user from the 
system. */

//:: First Process -> Show Activate List
elseif($do == 'activate') {
	

	//:: Declare Base Information
	$SI['templates'] = '50';
   	$SI['ref'] = 'Administration Center';
  	define('SCRIPTID','cp');
  	require 'base.php';
      check_perm('isadmin',0);

	//:: Select The Users
	$query_activate = new query($SQL, "UPDATE ".$prefix."profiles SET activated = '1' WHERE id = '".$UID."'");
if(!$query_activate) {
    $include = '<font size="2" face="verdana"><b><center>An error occurred!<br><br><a href="cp.php">Click Here to Return to the Index</center></b></font>';
      eval("\$output = \"".addslashes($TI[50])."\";");
      print stripslashes($output); flush;
      exit();
    }
    else{ 
     $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
		$query_getadminmail->getrow();
		$admin = $query_getadminmail->field('email');
		$query_getadminmail->free();
     $query_getusermail = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = '".$UID."' LIMIT 1");
		$query_getusermail->getrow();
		$email = $query_getusermail->field('email');
		$query_getusermail->free();
     $query_getconfig = new query($SQL, "SELECT boardurl, actmail, rjctmail FROM ".$prefix."configuration");
        $query_getconfig->getrow();
        $url = $query_getconfig->field('boardurl');
        $actmail = $query_getconfig->field('actmail');
		$rjctmail = $query_getconfig->field('rjctmail');
        $query_getconfig->free();

			$mailheaders = "From: $admin\n";
			$subject = 'Your Account Has Been Activated!';
			eval("\$message = \"".$actmail."\";");
            mail($email, $subject, $message, $mailheaders);
    $include = '<font size="2" face="verdana"><b><center>User has been activated, and a notification has been sent.<br><br><a href="cp.php">Click here to return to administration index</center></b></font>';
      eval("\$output = \"".addslashes($TI[50])."\";");
      print stripslashes($output); flush;
      exit();
    }
	//:: Master Loop To Display Users
	while($query_activate->getrow()) {
		$userid = $query_activate->field('id');
		$username = $query_activate->field('username');
		$activate_stat = $query_activate->field('activated');

   		eval("\$activate_include .= \"".addslashes($TI[cp_activaterow])."\";");
	}
	//:: End Master Loop

	//:: Parse The Screen Display
	eval("\$include = \"".addslashes($TI[cp_activate])."\";");
   	eval("\$output = \"".addslashes($TI[50])."\";");
   	print stripslashes($output); flush;
   	exit();
}
elseif($do == 'remove') {

	//:: Declare Base Information
	$SI['templates'] = '50';
   	$SI['ref'] = 'Administration Center';
  	define('SCRIPTID','cp');
  	require 'base.php';
      check_perm('isadmin',0);
	  
	    $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
		$query_getadminmail->getrow();
		$admin = $query_getadminmail->field('email');
		$query_getadminmail->free();
     $query_getusermail = new query($SQL, "SELECT email, ip FROM ".$prefix."profiles WHERE id = '".$UID."' LIMIT 1");
		$query_getusermail->getrow();
		$email = $query_getusermail->field('email');
		$ip = $query_getusermail->field('ip');
		$query_getusermail->free();
     $query_getconfig = new query($SQL, "SELECT boardurl, actmail, rjctmail FROM ".$prefix."configuration");
        $query_getconfig->getrow();
        $url = $query_getconfig->field('boardurl');
        $actmail = $query_getconfig->field('actmail');
		$rjctmail = $query_getconfig->field('rjctmail');
        $query_getconfig->free();

			$mailheaders = "From: $admin\n";
			$subject = 'Your Activation Has Been Rejected!';
			eval("\$message = \"".$rjctmail."\";");
            mail($email, $subject, $message, $mailheaders);
			
  	  $include = '<font size="2" face="verdana"><b><center>User has been removed & banned and a notification has been sent.<br><br><a href="cp.php">Click here to return to administration index</center></b></font>';

	  new query($SQL, "DELETE FROM ".$prefix."profiles WHERE id = '".$UID."' LIMIT 1");
      new query($SQL, "UPDATE ".$prefix."configuration SET regmembers = regmembers - 1");
      eval("\$output = \"".addslashes($TI[50])."\";");
      print stripslashes($output); flush;
      exit();
   }	
 ?>
