<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_FILES);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/

define('SCRIPTID','search/display');

$SI['config'] = 'slistperpage';
$SI['templates'] = '181|183|184|185|186|187|188|191|192|193';


// 181 - form - main

// 183 - results - main

// 191 - results - topic view header
// 184 - results - topic view topic row
// 185 - results - topic view post row
// 192 - results - post view header
// 193 - results - post view post row

// 186 - results - no result row
// 187 - results - page link
// 188 - results - current page
require 'base.php';

check_perm('search_cansearch',0);
switch ($action) {
case 'display':
	// get the vars
	$q = trim(stripslashes($HTTP_GET_VARS['q']));
	$oq = $q;
	$qauthor = trim($HTTP_GET_VARS['qauthor']);
	$forums =  $HTTP_GET_VARS['forums'];
	$matchsubject =  $HTTP_GET_VARS['matchsubject'];
	$matchmessage =  $HTTP_GET_VARS['matchmessage'];
	$match = $HTTP_GET_VARS['match'];

	$sortby = $HTTP_GET_VARS['sortby'];
	$sort = (strtolower($HTTP_GET_VARS['sort']) == 'asc') ? 'ASC' : 'DESC';
	$page = $HTTP_GET_VARS['page'];		
	$perpage = $HTTP_GET_VARS['perpage'];
	$pages = $HTTP_GET_VARS['pages'];
	
	$viewby = $HTTP_GET_VARS['viewby'];

        // Check if the string is " "

	// check the forums
	if ($forums == '')
		gen_error('Criteria error', 'Please select at least 1 forum');		
	if (!is_array($forums))
		$forums = array($forums);
	
	for($i=0; $i<count($forums); $i++)
		if ($forums[$i] == '')
			unset($forums[$i]);	
	
	$pforums = $forums;

	if ($pforums[0] == 'all') {
		$pforumsall = 1;
		unset($pforums);
	}

	// get forum id/name AND check security
	$query_forums = new query($SQL, "SELECT title, forumid FROM ".$prefix."forum_display ORDER BY displayorder ASC");
	while ($query_forums->fetch()) {
		$aforumname[$query_forums->field('forumid')] = $query_forums->field('title');
		if ($pforumsall == 1)
			$pforums[] = $query_forums->field('forumid');
	}
			
	$query_ug = new query($SQL, "SELECT forum_canview FROM ".$prefix."usergroup WHERE id=".USERGROUP.' LIMIT 1');
	$query_ug->fetch();
	$defcanview = $query_ug->field('forum_canview');
	$query_ug->free;
	
	$query_perm = new query($SQL, "SELECT forum_canview, forumid FROM ".$prefix."forum_permissions WHERE uid=".USERGROUP);
	while ($query_perm->fetch()) {
		$afperm[$query_perm->field('forumid')] = $query_perm->field('forum_canview');
	}
	// remove unauthorized forums from the forum list
	for ($i=0; $i<count($pforums); $i++) {
		if (isset($afperm[$pforums[$i]])) {
			if ($afperm[$pforums[$i]] == 0) {
             	unset($pforums[$i]);}
		} else {
			if ($defcanview == 0)
               unset($pforums[$i]);
		}
	}


	// search queries
	// rm single quotes
    
	$q = eregi_replace("[[:space:]]+", " ", $q);

    if (substr_count($q,"\"") % 2) { gen_error('Query error', 'You have entered an illegal query'); }
	if (substr_count($q,"\" \"")>0) { 	gen_error('Query error', 'You have entered an illegal query'); }	
	if (substr_count($q,"\"\"")>0) { 	gen_error('Query error', 'You have entered an illegal query'); }
    $q = str_replace('\'','',$q);
	$sqs = array();

	if (substr($q, -1) == '"' && substr($q, 0, 1) == '"') {
		// advanced quoted search
		$sqs = split('"[ ]+"', $q);
		$sqs[0] = substr($sqs[0], 1);
		$sqs[count($sqs)-1] = substr($sqs[count($sqs)-1], 0, -1);
	} else {
		// simple search
		$q = str_replace('"','',$q);
		$sqs = explode(" ",$q);
	}

	if ($q == '') {
		$matchmessage = 0;
		$matchsubject = 0;
	}

	if ($matchmessage == 1)
		$msgq = "".$prefix."posts.message LIKE '%$sqs[0]%'";
	if ($matchsubject == 1)
		$subq = "".$prefix."posts.title LIKE '%$sqs[0]%'"; 
	
	$lop = ($match=='all') ? 'AND' : 'OR';
	for($i=1;$i<count($sqs);$i++) {
		if ($matchmessage == 1) $msgq .= " $lop ".$prefix."posts.message LIKE '%$sqs[$i]%'";
		if ($matchsubject == 1) $subq .= " $lop ".$prefix."posts.title LIKE '%$sqs[$i]%'"; 
	}


	// gen the search author query
	if ($qauthor) {
		$quser = "AND ".$prefix."posts.poster LIKE '%$qauthor%'";
	}

	
	// gen the search subjetc/message query
	if ($msgq != '' && $subq != '')
		$qsearch="AND (($msgq) OR ($subq))";
	else if ($msgq == '' && $subq != '')
		$qsearch="AND ($subq)";
	else if ($msgq != '' && $subq == '')
		$qsearch="AND ($msgq)";
	else if ($quser == '')
		gen_error("Criteria error", "You must at least search for text in subject, message or author");
	
	// gen forums query
	$qforums = implode(', ', $pforums);
	$qforums = "AND ".$prefix."topics.forumid IN ($qforums)";
	
	
	// gen the order by query
	if ($viewby == 't')
		$qorder = "ORDER BY ".$prefix."topics.$sortby $sort, ".$prefix."topics.id, ".$prefix."posts.dateline $sort";
	else
		$qorder = "ORDER BY ".$prefix."posts.$sortby $sort";

	// gen the limit query / paging
	if ($pages != '' && $page != '') {
		$start = ($page-1) * $perpage;
		$qlimit = "LIMIT $start,$perpage";
	} else {
		$start = 0;	
	}


// TODO: integrate profiles into this aswell
	$query_search = new query($SQL, "SELECT ".$prefix."posts.threadid AS threadid, ".$prefix."posts.id AS postid, ".$prefix."posts.dateline AS dateline, ".$prefix."topics.dateline AS threaddateline, ".$prefix."posts.title AS title, ".$prefix."topics.title AS threadtitle, ".$prefix."posts.poster as author, ".$prefix."topics.poster as threadauthor, ".$prefix."posts.poster as authorid, ".$prefix."topics.posterid as threadauthorid, ".$prefix."posts.message AS message, ".$prefix."topics.forumid AS forumid FROM ".$prefix."posts, ".$prefix."topics WHERE ".$prefix."topics.id = ".$prefix."posts.threadid $qforums $qsearch $quser $qorder $qlimit");


	if ($pages == '') {
		$resultsnum = mysql_num_rows($query_search->result);
		$pages = ceil($resultsnum/$perpage);
	}
	
	// results range var for tmpl
	$resultsrange = ($start+1).' to '.min($start+$perpage, $resultsnum);

	// url forums
	$urlforums = '';
	foreach ($forums as $urlfi) {
		$urlforums .= '&forums%5B%5D='.$urlfi;
	}
	$urlforums = substr($urlforums, 1);
	
	
	//print $lastquery;
		
	$tmp = $pages;
	if ($page == '') $page=1;
	
	$pagelink = '';
	if ($pages > 1)
	while($tmp != 0) {
		$tmp--;
		$pagenumber = $pages-$tmp;
		$link = "search.php?action=display&pages=$pages&page=$pagenumber&perpage=$perpage&resultsnum=$resultsnum&q=".urlencode($oq)."&qauthor=".urlencode($qauthor)."&$urlforums&matchsubject=$matchsubject&matchmessage=$matchmessage&match=$match&sortby=$sortby&sort=$sort&viewby=$viewby";
		
		if ($page == $pages-$tmp)
			eval("\$pagelink .= \"".addslashes($TI[188])."\";");
		else
			eval("\$pagelink .= \"".addslashes($TI[187])."\";");
	}

	// show topics now!
	if ($viewby == 't')
		eval("\$include = \"".addslashes($TI[191])."\";");
	else
		eval("\$include = \"".addslashes($TI[192])."\";");

	$lasttopic = 0;
	$i=0;
	
	while ($query_search->fetch()) {
        unset($result);
		$i++;
		if ($i > $perpage) break;
		
		
		// TODO: calculate page number?
		$pagenumber=1;
		$TID = $query_search->field('threadid');

		if ($lasttopic != $TID) {
            if ($afperm[$query_search->field('forumid')] != '0') {
			$title = $query_search->field('threadtitle');
			$date = gmdate($timeformat[3], $query_search->field('threaddateline') + offset);
			// TODO: handle for guests
			$poster = $query_search->field('threadauthor');
			$UID = $query_search->field('threadauthorid');
			$FID = $query_search->field('forumid');
			$forumname = $aforumname[$FID];
			eval("\$include .= \"".addslashes($TI[184])."\";");
  			unset($result);
		}
}
		$title = ($query_search->field('title') != '')? $query_search->field('title'): $query_search->field('threadtitle');
		$date = gmdate($timeformat[3], $query_search->field('dateline') + offset);
		$poster = $query_search->field('author');

		$summary = '';
		if (CENSOR){ $message = censor(stripslashes($query_search->field('message'))); }
        else { $message = stripslashes($query_search->field('message')); }

		if (!$summarylen)
			$summarylen = 150;
		$summarylenh = ceil($summarylen / 2);

		if ($q != '') {
			for ($ii = 0; $ii<count($sqs); $ii++) {
				$sumpos = strpos(strtolower($message), strtolower($sqs[$ii]));
				if ($sumpos) break;
			}
		} else {
			$sumpos = 0;
		}
		if ($sumpos == 0) {
			$summary = substr($message, 0, $summarylen);
			
			if (strlen($message) > $summarylen)
				$summary .= '...';
		} else {
			$sums = ($sumpos - $summarylenh < 0) ? 0 : ($sumpos - $summarylenh);
			$suml = ($sumpos + $summarylenh) - $sums;
			$summary = '...'.substr($message, $sums, $suml);
			if (strlen($message) > $summarylen)
				$summary .= '...';
		}
		if (is_array($sqs))
			foreach($sqs as $sqsi)
				$summary = eregi_replace('('.preg_quote($sqsi).')', '<span style="background-color: #CCFFFF">\1</span>', $summary);
		$UID = 0; //$query_search->field('authorid');
		$PID = $query_search->field('postid');
		if($afperm[$query_search->field('forumid')] != '0') {
		eval("\$include .= \"".addslashes($TI[185])."\";");
}		$lasttopic = $TID;
	}
	if ($i == 0) {
		eval("\$include .= \"".addslashes($TI[186])."\";");
	}

	// update active
	new query($SQL, "UPDATE ".$prefix."active SET location = 'Currently \'<a href=\"search.php\">searching</a>\'' WHERE record = '".RECORD."'");

	$title = "Search";
	$nav = '<a href="index.php">'.$boardname.'</a> > <a href="search.php">Community Search</a> > Search Results';
	eval("\$include = \"".addslashes($TI[183])."\";");
	eval("\$output = \"".addslashes($TI[0])."\";");
	lose($output);
	break;
default:

	include('lib/dropdown.php');
	$forumselect = forum_dropdown('search');
	$nav = '<a href="index.php">'.$boardname.'</a> > Community Search';
	eval("\$include = \"".addslashes($TI[181])."\";");
	eval("\$output = \"".addslashes($TI[0])."\";");
	lose($output);
}

?>
