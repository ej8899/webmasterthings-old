<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Download
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

# Emulate Register Globals
extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);

// ###############################
//      DOWNLOAD AN ATTACHMENT
// ###############################

define('SCRIPTID','download');

$SI['templates'] = '';

$SI['ref'] = 'Downloading Attachment '.$AID;
require 'base.php';

if (!isset($AID)) { gen_error('No Attachment Specified!','Go back to the post and try again.'); }

$query_attachment = new query($SQL, "SELECT filename, filesize, filecontent, dateline FROM ".$prefix."attachments WHERE id = ".$AID." LIMIT 1");
$query_attachment->getrow();

if ($query_attachment->field('filename') == '') { gen_error('No Attachment Specified!','Go back and try again.'); }

new query($SQL, "UPDATE ".$prefix."attachments SET downloaded = downloaded + 1 WHERE id = '".$AID."'");
header('Expires: '.gmdate('D, d M Y H:i:s',time()).' GMT');
header('Last-Modified: '.gmdate('D, d M Y H:i:s', $query_attachment->field('dateline')).' GMT');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename='.$query_attachment->field('filename'));
header('Content-Length: '.$query_attachment->field('filesize'));
echo $query_attachment->field('filecontent');
?>
