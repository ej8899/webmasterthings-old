<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


error_reporting(7);
$needscache="true";
# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/

// Avoid warnings
if (!isset($action)) { $action = ''; }
if (!isset($send)) { $send = ''; }


// ###############################
//         MY HOME
// ###############################
if ($action == '' || $action == 'home') {

        $SI['templates'] = '20|80|88|82|21|81|31|47|91';
        $SI['ref'] = 'In his/her Home';
        $SI['settings'] = 'comnews';
        define('SCRIPTID','myhome/home/display');
        require 'base.php';

        check_perm('myhome_canaccess',0);

        $query_getpm = new query($SQL, "SELECT count(id) as totalpm FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND box = 'inbox' AND isread = '1'");
        $query_getpm->getrow();
                $totalpm = $query_getpm->field('totalpm');
        $query_getpm->free();

        $query_getnewpm = new query($SQL, "SELECT count(isread) as unreadpm FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND box = 'inbox' AND isread = '0'");
        $query_getnewpm->getrow();
                $unreadpm = $query_getnewpm->field('unreadpm');
        $query_getnewpm->free();

        $query_getpmlimit = new query($SQL, "SELECT count(pm_maxday) as pmlimit FROM ".$prefix."usergroup");
        $query_getpmlimit->getrow();
                $pmlimit = $query_getpmlimit->field('pmlimit');
        $query_getpmlimit->free();

        $query_user = new query($SQL, "SELECT posts, lastpm, joindate, email FROM ".$prefix."profiles WHERE username = '".USERNAME."'");

        list($totalposts,$lastpm,$joindate,$regemail) = $query_user->fetch();
        $jointime = (time() - $query_user->field('joindate')) / 86400;
        $averagepost = round($totalposts / $jointime);
        $joindate = gmdate($timeformat[3], ($joindate + $offset));
        $lastpm = gmdate($timeformat[3], ($lastpm + $offset));

        $query_user->free();

        $title = 'My Home';
    $nav= '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a>';
        $comnews = $config->field('comnews');
        eval("\$ucpnav = \"".addslashes($TI[21])."\";");
        eval("\$include = \"".addslashes($TI[20])."\";");
        eval("\$output = \"".addslashes($TI[0])."\";");
        lose($output);
}
// ###############################
//         MY PROFILE
// ###############################
if ($action == 'profile') {
        if ($send != 1) {

                $SI['templates'] = '21|22';
                $SI['ref'] = 'Editing his/her profile';
                define('SCRIPTID','myhome/profile/display');
                require 'base.php';

                check_perm('myhome_myprofile',0);

                $query_fetchinfo = new query($SQL, "SELECT email, msn, icq, aim, yahoo, homepagedesc, occupation, location, note, homepage, birthdate, invisible FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
                $query_fetchinfo->getrow();
                $user[email] = stripslashes($query_fetchinfo->field('email'));
                $user[homepage] = stripslashes($query_fetchinfo->field('homepage'));
                $user[icq] = stripslashes($query_fetchinfo->field('icq'));
                $user[aim] = stripslashes($query_fetchinfo->field('aim'));
                $user[yahoo] = stripslashes($query_fetchinfo->field('yahoo'));
                $user[wm] = stripslashes($query_fetchinfo->field('msn'));
                $user[location] = stripslashes($query_fetchinfo->field('location'));
                $user[personal] = stripslashes($query_fetchinfo->field('note'));
                $user[homepagedesc] = stripslashes($query_fetchinfo->field('homepagedesc'));
                $user[occupation] = stripslashes($query_fetchinfo->field('occupation'));
        $birthdate = explode("-",stripslashes($query_fetchinfo->field('birthdate')));
        $day = "day".$birthdate[2]."selected";
        $$day = "selected";
        $month = "month".$birthdate[1]."selected";
        $$month = "selected";
        if(date("Y")>$birthdate[0] && $birthdate[0]!='0000') {
           $year = $birthdate[0];
    }

                $query_fetchinfo->free();

                $title = 'My Home - Change my Profile';
                $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Update Profile';
                eval("\$ucpnav = \"".addslashes($TI[21])."\";");
                eval("\$include = \"".addslashes($TI[22])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        } else {

                $SI['ref'] = 'Changing his/her profile';
                define('SCRIPTID','myhome/profile/insert');
                require 'base.php';

                check_perm('myhome_myprofile',0);

                if(substr($homepage,0,7) != 'http://' && $homepage != '') { $homepage = 'http://' . $homepage; }
        if(!$year) { $year = '0000';}
        if($year < 1910 && $year != '0000' ) {gen_error('Invalid Year','Please check to ensure that you are entering the year in a four digit format.'); }
        if($year > date("Y")) {gen_error('Invalid Year','You have not even been born yet!'); }
        $birthday = $year.'-'.$month.'-'.$day;

                new query($SQL, "UPDATE ".$prefix."profiles SET msn = '".addslashes(strip_tags($wm))."', occupation = '".addslashes(strip_tags($occupation))."', homepagedesc = '".addslashes(strip_tags($homepagedesc))."', email = '".addslashes(strip_tags($email))."', homepage = '".addslashes(strip_tags($homepage))."', icq = '".addslashes(strip_tags($icq))."', aim = '".addslashes(strip_tags($aim))."', yahoo = '".addslashes(strip_tags($yahoo))."', location = '".addslashes(strip_tags($location))."', birthdate = '".addslashes($birthday)."', note = '".addslashes(strip_tags($personal))."', timeoffset = '".$offset."' WHERE username = '".addslashes(USERNAME)."'");
                gen_redirect('Your profile has been updated, redirecting you to your home.','myhome.php');

        }
}


// ###############################
//         MY SETTINGS
// ###############################
if ($action == 'settings') {
        if ($send != 1) {

                $SI['templates'] = '21|104|46|103';
                $SI['ref'] = 'Editing his/her settings';
                define('SCRIPTID','myhome/settings/display');
                require 'base.php';

                check_perm('myhome_mysettings',0);

                $query_fetchinfo = new query($SQL, "SELECT custom, showhistory, censor, sig, avatar, templategroup, vargroup, invisible, homepagedesc, occupation, location, showemail, showavatar, showsig, note, homepage, invisible, timezone, addowntopics, autosubscribe, pmpopup FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
                $query_fetchinfo->getrow();
                $user[invisible] = $query_fetchinfo->field('invisible');
                $user[signature] = $query_fetchinfo->field('sig');

                if (get_perm('custom',0) == 1) {
                        $user[status] = $query_fetchinfo->field('custom');
                        eval("\$status = \"".addslashes($TI[103])."\";");
                }

                if ($query_fetchinfo->field('invisible') == '1') {
                        $invis = 'selected';
                } else {
                        $vis = 'selected';
                }

                if ($query_fetchinfo->field('addowntopics') == '1') {
                        $addowntopics = 'selected';
                } else {
                        $dontaddowntopics = 'selected';
                }

                if ($query_fetchinfo->field('autosubscribe') == '1') {
                        $autosubscribe = 'selected';
                } else {
                        $dontautosubscribe = 'selected';
                }

                if ($query_fetchinfo->field('showemail') == '1') {
                        $showmail = 'selected';
                } else {
                        $hidemail = 'selected';
                }
                if ($query_fetchinfo->field('pmpopup') == '1') {
                        $dopmpop = 'selected';
                } else {
                        $nopmpop = 'selected';
                }
                if ($query_fetchinfo->field('showavatar') == '1') {
                        $showavatar = 'selected';
                } else {
                        $dontshowavatar = 'selected';
                }
                if ($query_fetchinfo->field('censor') == '1') {
                        $censor = 'selected';
                } else {
                        $dontcensor = 'selected';
                }
                if ($query_fetchinfo->field('showsig') == '1') {
                        $showsignature = 'selected';
                } else {
                        $dontshowsignature = 'selected';
                }
                if ($query_fetchinfo->field('showhistory') == '1') {
                        $showhistory = 'selected';
                } else {
                        $dontshowhistory = 'selected';
                }
                if ($query_fetchinfo->field('timezone') != 0) {
                        $tz = $query_fetchinfo->field('timezone');
                        $tz = str_replace('.', '', $tz);
                        $tz = str_replace('-', 'm', $tz);
                        if (substr($tz, 0,1) != 'm') { $tz = 'p'.$tz; }
                        $timezone = '';
                        $timezone[$tz] = 'selected';
                } else {
                        $timezone = '';
                        $timezone[0] = 'selected';
                }

                eval("\$timezoneselector = \"".addslashes($TI[46])."\";");

                $designselector = '<select name="design">';
                $q = new query($SQL, "SELECT title, v, id FROM ".$prefix."designs");
                while ($q->getrow()) {
                        if($q->field('v') == $query_fetchinfo->field('vargroup')) {
                                $designselector .= '<option value="'.$q->field('id').'" selected>'.$q->field('title').'</option>';
                        } else {
                                $designselector .= '<option value="'.$q->field('id').'">'.$q->field('title').'</option>';
                        }
                }
                $q->free();
                $designselector .= '</select>';
                $timezoneselector = stripslashes($timezoneselector);
                $avatarselector = '<select name="avatar" onchange="showavatar();">';
                if (strtolower(substr($query_fetchinfo->field('avatar'),0,7)) == 'http://')
                $avatarselector .= '<option value="URL" selected>Custom URL linked avatar</option>';
                $query_avatars = new query($SQL, "SELECT name, url FROM ".$prefix."avatar WHERE owner = '".addslashes(USERNAME)."' OR owner = ''");
                while($query_avatars->getrow()) {
                        $av = $query_avatars->field('url');
                        if (!isset($avatarimg)) { $avatarimg = 'avatars/'.$av; }
                        if ($av == $query_fetchinfo->field('avatar')) {
                                $avatarselector .= '<option value="'.$av.'" selected>'.$query_avatars->field('name').'</option>';
                                $avatarimg = 'avatars/'.$av;
                        } else {
                                $avatarselector .= '<option value="'.$av.'">'.$query_avatars->field('name').'</option>';
                        }
                }
                $query_fetchinfo->free();
                $query_avatars->free();

                $avatarselector .= '</select>';
                $title = 'My Home - Change my Settings';
                $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Update Settings';
                eval("\$ucpnav = \"".addslashes($TI[21])."\";");
                eval("\$include = \"".addslashes($TI[104])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        } else {

                $SI['ref'] = 'Changing his/her settings';
                define('SCRIPTID','myhome/settings/insert');
                require 'base.php';

                check_perm('myhome_mysettings',0);

                if(substr($homepage,0,7) != 'http://' && $homepage != '') { $homepage = 'http://' . $homepage; }
                $getoffset[1] = ((substr($timeoffset, 1) * 3600) + 3600);
                $getoffset[2] = substr($timeoffset, 0,1);
                $offset = $getoffset[2] . $getoffset[1];

                $q = new query($SQL, "SELECT v,t FROM ".$prefix."designs WHERE id = $design");
                $q->getrow();

                if ($avatar == 'URL') {
                   $avatar = '';
                } else {
           $query_avatars = new query($SQL, "SELECT name FROM ".$prefix."avatar WHERE url = '$avatar' AND (owner = '".addslashes(USERNAME)."' OR owner = '')");
           $query_avatars->getrow();
           if ($query_avatars->field('name')=='') { gen_error('Invalid Avatar','The avatar you have chosen has not been listed'); }
                   $avatar = "avatar = '".$avatar."',";
        }

                if (isset($status) && get_perm('custom',0) == 1) {
                        $custom = "custom = '".htmlspecialchars($status)."',";
                } else {
                        $custom = '';
                }
                new query($SQL, "UPDATE ".$prefix."profiles SET $custom showhistory = '".$showhistory."', sig = '".htmlspecialchars($signature)."', showemail = '".$showmail."', censor = '".$censor."' ,showsig = '".$showsignature."', showavatar = '".$showavatars."', templategroup = '".$q->field('t')."', vargroup = '".$q->field('v')."', $avatar timeoffset = '".$offset."', timezone = '".$timeoffset."', invisible = '".$invisible."', pmpopup = '".$pmpopup."', addowntopics = '".$addowntopics."', autosubscribe = '".$autosubscribe."' WHERE username = '".addslashes(USERNAME)."'");
                new query($SQL, "UPDATE ".$prefix."active SET invisible = '".$invisible."' WHERE record = '".RECORD."'");
                $q->free();
                gen_redirect('Your profile has been updated, redirecting you to your home.','myhome.php');

        }
}



// ###############################
//         MY AVATAR
// ###############################
if ($action == "avatar") {

        if ($send != 1 ) {

                $SI['templates'] = '21|112';
                $SI['settings'] = 'avsize, avw, avh';
                $SI['ref'] = 'Uploading an Avatar';
                define('SCRIPTID','myhome/avatar/display');
                require 'base.php';

                $types = 'GIF & JPEG';
                $size = $config->field('avsize');
                $max_width = $config->field('avw');
                $max_height = $config->field('avh');
                check_perm('avatar_cancustom',0);

                $query_fetchinfo = new query($SQL, "SELECT avatar FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
                $query_fetchinfo->fetch();
                $myav = $query_fetchinfo->field('avatar');
                $myavheight = $query_fetchinfo->field('avh');
                $myavwidth = $query_fetchinfo->field('avw');

                if (strtolower(substr($myav,0,7)) == 'http://')
                $avurl = $myav;

                $title = 'My Home - Upload Custom Avatar';
                $nav = '<a href="myhome.php">UserCP</a> > Custom Avatar';
                eval("\$ucpnav = \"".addslashes($TI[21])."\";");
                eval("\$include = \"".addslashes($TI[112])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        } else {

                $SI['settings'] = 'avsize,avw,avh';
                $SI['ref'] = 'Uploading an Avatar';
                define('SCRIPTID','myhome/avatar/insert');
                require 'base.php';

                $uploaded = is_uploaded_file($avatar);

                if ($uploaded) {
                        $size = $config->field('avsize');
                        check_perm('avatar_cancustom',0);
                        if ($avatar_size  > $size) { gen_error('Cannot upload your Avatar','The maxium size of the avatar is '.$size.' bytes.'); }

                        if ($avatar_type == 'image/pjpeg' || $avatar_type == 'image/jpeg') { $type = '.jpg'; }
                        if ($avatar_type == 'image/gif') { $type = '.gif'; }

                        if (!$type) {
                                gen_error('Cannot upload your Avatar','Only GIF and JPG avatars are allowed.');
                        }

                        if (file_exists('avatars/'.getavatar(USERNAME).'.gif')) { unlink('avatars/'.getavatar(USERNAME).'.gif');   }
                        if (file_exists('avatars/'.getavatar(USERNAME).'.jpg')) { unlink('avatars/'.getavatar(USERNAME).'.jpg');   }
                        if (!copy($avatar, 'avatars/'.getavatar(USERNAME).$type))
                        gen_error('Error', 'This server does not support uploading, please contact the administrator for more info');

                        list($width, $height) = GetImageSize('avatars/'.getavatar(USERNAME).$type);
                } else {
                        if (!$avurl)
                        gen_error('Error', 'Please either upload or specify a URL');
						
                        if (strtolower(substr($avurl,0,7))!='http://')
                        gen_error('Error', 'URL must begin with http://');
						
						
						if ( preg_match('/\?/', $avurl ) ) { 
						
						gen_error('Error', "URL's are not allowed to contain question mark's");
						
						}                        					
						
                        if (substr($avurl, -4) == '.jpg') { $type = '.jpg'; }
                        if (substr($avurl, -4) == '.gif') { $type = '.gif'; }

                        if (!$type) {
                                gen_error('Cannot upload your Avatar','Only GIF and JPG avatars are allowed.');
                        }

                        list($width, $height) = GetImageSize($avurl);
                }


                if (($height > $config->field('avh')) || ($width > $config->field('avw'))) {
                        if ($uploaded) @unlink($avatar, 'avatars/'.getavatar(USERNAME).$type);
                        gen_error('Cannot upload/link your Avatar','Your avatar can only be '.$config->field('avw').' by '.$config->field('avh')." big. (Detected: $width X $height)");
                }

                if ($uploaded) {
                        new query($SQL, "DELETE FROM ".$prefix."avatar WHERE owner = '".addslashes(USERNAME)."'");
                        $query = new query($SQL,"SELECT id FROM ".$prefix."avatar ORDER BY id DESC LIMIT 1");
                        $query->getrow();
                        $id = $query->field('id') + 1;
                        $query->free();
                        new query($SQL, "INSERT INTO ".$prefix."avatar VALUES ('".$id."','My Avatar','".addslashes(getavatar(USERNAME)).$type."','".addslashes(USERNAME)."')");
                        new query($SQL, "UPDATE ".$prefix."profiles SET avatar = '".addslashes(getavatar(USERNAME)).$type."' WHERE username = '".addslashes(USERNAME)."'");
                } else {
                        new query($SQL, "UPDATE ".$prefix."profiles SET avatar = '".$avurl."' WHERE username = '".addslashes(USERNAME)."'");

                }

                gen_redirect('Your new avatar is uploaded and set as your default avatar','myhome.php?action=settings');
        }
}

// ###############################
//         MY MESSAGES
// ###############################
if ($action == 'messages') {

        $SI['templates'] = '21|30|31|107';
        $SI['ref'] = 'Viewing his/her messages';
        define('SCRIPTID','myhome/messages/display');
        require 'base.php';

        check_perm('myhome_readmsg',0);

        if (!isset($box)) { $box = 'inbox'; }

        $box = htmlentities($box);

        $rbg = '0';
        $count = 0;

        $query_getpm = new query($SQL, "SELECT send, accept, subject, id, time, userid, isread FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND box = '".$box."' ORDER BY time DESC");


        while ($query_getpm->getrow()) {

                if ($rbg == 0) {
                        $rowbg = '{primary}';
                        $rbg = 1;
                } else {
                        $rowbg = '{secondary}';
                        $rbg = 0;
                }

                $count++;

                if ($query_getpm->field('isread')) { $icon = 'msg-off.gif'; } else { $icon = 'msg-on.gif'; }

                $id = $query_getpm->field('id');
                $UID = $query_getpm->field('userid');

                $sender = $query_getpm->field('send');
                if ($sender == USERNAME) {
                        $sender = stripslashes($query_getpm->field('accept'));
                }



                $isread = $query_getpm->field('isread');
                $subject = stripslashes($query_getpm->field('subject'));
                $time = $query_getpm->field('time');
                eval("\$include .= \"".addslashes($TI[31])."\";");
        }

        $query_getpm->free();

        if ($count == 0) { eval("\$include = \"".addslashes($TI[107])."\";");   }

        $title = 'My Home - Viewing Messages: '.$box;
        $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Viewing Messages: '.$box;
        eval("\$ucpnav = \"".addslashes($TI[21])."\";");
        eval("\$include = \"".addslashes($TI[30])."\";");
        eval("\$output = \"".addslashes($TI[0])."\";");
        lose($output);

}



// ###############################
//         MY MESSAGES ( READ MSG )
// ###############################
if ($action == 'readmsg') {

        $SI['templates'] = '21|71';
        $SI['ref'] = 'Viewing his/her messages';
        define('SCRIPTID','myhome/readmsg/display');
        require 'base.php';



        check_perm('myhome_readmsg',0);


        $query_fetchpm = new query($SQL, "SELECT accept, box, send, message, time, subject FROM ".$prefix."pmsg WHERE id = '".$id."' AND owner = '".addslashes(USERNAME)."'");
        $query_fetchpm->getrow();
        new query($SQL, "UPDATE ".$prefix."pmsg SET isread = '1' WHERE id = '".$id."' AND (accept = '".addslashes(USERNAME)."' OR send = '".addslashes(USERNAME)."')");


        $sender = $query_fetchpm->field('send');

        if ($query_fetchpm->field('box') == 'inbox') {
                new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'sent items' WHERE id = (".$id." + 1) AND send = '".$sender."'");
        }

        $time = $query_fetchpm->field('time');
        $date = gmdate($timeformat[1], ($query_fetchpm->field('time') + $offset));
        $subject = stripslashes(format($query_fetchpm->field('subject')));
        require 'lib/codeparse.php';
           $message = codeparse(stripslashes(format($query_fetchpm->field('message'))), '1', '0', $sender);

        $title = 'My Home - Viewing Private Message \''.$subject.'\'';
        $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Reading Message: '.$subject;
        $query_fetchpm->free();

        eval("\$ucpnav = \"".addslashes($TI[21])."\";");
        eval("\$include = \"".addslashes($TI[71])."\";");
        eval("\$output = \"".addslashes($TI[0])."\";");
        lose($output);

}


// ###############################
//         MY MESSAGES ( NEW MSG )
// ###############################
if ($action == 'newmsg') {

        if ($send != 1 || isset($preview)) {

                $SI['templates'] = '21|69|94|122';
                $SI['ref'] = 'Writing a new message';
                $SI['settings'] = 'parseurl, dsmiley';
                define('SCRIPTID','myhome/newmsg/display');
                require 'base.php';



                check_perm('myhome_newmsg',0);

                if (isset($replyto)) {
                        $query_fetchpm = new query($SQL, "SELECT accept, box, send, message, subject FROM ".$prefix."pmsg WHERE id = '".$replyto."' AND owner = '".addslashes(USERNAME)."'");
                        $query_fetchpm->getrow();
                        $to = $query_fetchpm->field('send');

                        if (strtoupper(substr($query_fetchpm->field('subject'),0,4)) != 'RE: ')
                        $subject = 'RE: ' . $query_fetchpm->field('subject');
                        else
                        $subject = $query_fetchpm->field('subject');

                        $message = '[quote]'. stripslashes($query_fetchpm->field('message')) .'[/quote]';
                        $query_fetchpm->free();
                }

                if (isset($PID)) {
                        $query_fetchpost = new query($SQL, "SELECT message, poster, threadid FROM ".$prefix."posts WHERE id = '".$PID."'");
                        $query_fetchpost->getrow();
                        $to = $query_fetchpost->field('send');

                        $subject = 'RE: '.$config->field('boardurl').'/read.php?TID='.$query_fetchpost->field('threadid').'#'.$PID;


                        $message = '[quote]'. $query_fetchpost->field('message') .'[/quote]';
                        $to = $query_fetchpost->field('poster');
                        $query_fetchpost->free();
                }


                if (isset($forward)) {
                        $query_fetchpm = new query($SQL, "SELECT accept, box, message, send, time, subject FROM ".$prefix."pmsg WHERE id = '".$forward."' AND owner = '".addslashes(USERNAME)."'");
                        $query_fetchpm->getrow();

                        if (strtoupper(substr($query_fetchpm->field('subject'),0,4)) != 'FW: ')
                        $subject = 'FW: ' . $query_fetchpm->field('subject');
                        else
                        $subject = $query_fetchpm->field('subject');


                        $message = '[quote]';
                        $message .= '[i]Received from '.$query_fetchpm->field('send').' at '.gmdate($timeformat[1], ($query_fetchpm->field('time') + $offset)).'[/i]';
                        $message .= $query_fetchpm->field('message') .'[/quote]';
                        $query_fetchpm->free();
                }

                if (isset($preview)) {
                        $to = $reciever;
                        $oldmsg = $message;
                        if ($parseurl == 'CHECKED') { $a = 1; } else { $a = 0; }
                        if ($disablesmilies == 'CHECKED') { $b = 1; } else { $b = 0; }
                        include 'lib/codeparse.php';
            $message = stripslashes($message);
                        $message = codeparse($message, $a, $b, USERNAME);
                        eval("\$preview = \"".addslashes($TI[122])."\";");
                        $message  = $oldmsg;
                }

                $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
                while ($query_getsmileyset->getrow()) {
                        $smileyset[id] = $query_getsmileyset->field('id');
                        $smileyset[name] = $query_getsmileyset->field('name');
                        eval("\$smilies .= \"".addslashes($TI[94])."\";");
                }
                $query_getsmileyset->free();

                if ($config->field('parseurl')) { $parseurl = 'CHECKED'; }
                if ($config->field('dsmiley')) { $disablesmilies = 'CHECKED'; }
                if ($parseurl == 'yes' && $preview == 1) { $parseurl = 'CHECKED'; } elseif ($preview == 1) { $parseurl = ''; }
                if ($disablesmilies == 'yes' && $preview == 1) { $disablesmilies = 'CHECKED'; } elseif ($preview == 1) { $disablesmilies = ''; }

                $title = 'My Home - Writing Private Message';
                $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Composing Message';
                eval("\$ucpnav = \"".addslashes($TI[21])."\";");
                eval("\$include = \"".addslashes($TI[69])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        } else {

                // ## SEND IT!

                $SI['ref'] = 'Sending a new message';
                define('SCRIPTID','myhome/newmsg/insert');
                require 'base.php';

                if ($reciever == '') {
                        gen_error("An error occured while sending the message","You must specify a reciever that will recieve your message, go back and correct this.");
                }

                if ($message == '') {
                        gen_error("An error occured while sending the message","You must specify a message that will be send to the reciever(s), go back and correct this.");
                }

                if ($subject == '') {
                        gen_error("An error occured while sending the message","You must specify a subject for your message, go back and correct this.");
                }

                $q = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$reciever."'");
                if (!$q->getrow()) {
                        gen_error("An error occured while sending the message","The reciever doesn't exists, go back and correct this.");
                }
                $uid = $q->field('id');


                $qr = new query($SQL, "SELECT lastpm, totalpm FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
                $qr->getrow();

                $q = new query($SQL, "SELECT pm_maxday FROM ".$prefix."usergroup WHERE id = '".USERGROUP."'");
                $q->getrow();

                if ($q->field('pm_maxday') == '-1') { $max = '9999'; } else { $max = $q->field('pm_maxday'); }

                $days_since_last_pm = (time() - $qr->field('lastpm')) / 86400;
                $expire = gmdate($timeformat[1], ($qr->field('lastpm') + OFFSET + 86400));
                if ($qr->field('totalpm') > $max && $days_since_last_pm < 1) {
                        gen_error("An error occured while sending the message","You have reached your maximum message limit for today, please wait untill $expire.");
                }

                new query($SQL, "UPDATE ".$prefix."profiles SET lastpm = '".time()."', totalpm = (totalpm + 1) WHERE username = '".addslashes(USERNAME)."'");
                $qr->free();

                send_pm($reciever, USERNAME, $subject, $message, 0, USERID, $uid);
                gen_redirect('Your message has been sent.','myhome.php?action=messages');

        }

}



// ###############################
//         MY MESSAGES ( DELETE MSG )
// ###############################
if ($action == 'delmsg') {

        $SI['ref'] = 'Deleting his/her messages';
        define('SCRIPTID','myhome/delmsg/insert');
        require 'base.php';



        check_perm('myhome_delmsg',0);


        if ($id == 'all' && $box != 'recycle bin') {
                new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'recycle bin' WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."'");
        } elseif ($id == 'all' && $box == 'recycle bin') {
                new query($SQL, "DELETE FROM ".$prefix."pmsg WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."'");
        } elseif ($box != 'recycle bin') {
                new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'recycle bin' WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."' AND id = '".$id."'");
        } elseif ($box == 'recycle bin') {
                new query($SQL, "DELETE FROM ".$prefix."pmsg WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."' AND id = '".$id."'");
        }


        gen_redirect('The message(s) is/are deleted. Redirecting you to the Message Box','myhome.php?action=messages&box='.$box);

}



// ###############################
//         MY MESSAGES ( DOWNLOAD MSG )
// ###############################
if ($action == 'downloadmsg') {

        $SI['ref'] = 'Downloading one of his/her messages';
        $SI['templates'] = '115';
        define('SCRIPTID','myhome/downloadmsg/display');
        require 'base.php';



        check_perm('myhome_dlmsg',0);

        @header('Content-Type: text/plain');

        $query_fetchpm = new query($SQL, "SELECT accept, box, send, message, time, subject FROM ".$prefix."pmsg WHERE id = '".$id."' AND owner = '".addslashes(USERNAME)."'");
        $query_fetchpm->getrow();
        $from = $query_fetchpm->field('send');

        $time = $query_fetchpm->field('time');
        $date = gmdate($timeformat[1], ($time + $offset));
        $subject = $query_fetchpm->field('subject');
        require 'lib/codeparse.php';
        $message = $query_fetchpm->field('message');

        $query_fetchpm->free();

        eval("\$result = \"".addslashes($TI[115])."\";");
        print stripslashes($result);
}


// ###############################
//         MY MESSAGES ( SAVE MSG )
// ###############################
if ($action == 'savemsg') {

        $SI['ref'] = 'Saving one of his/her messages';
        define('SCRIPTID','myhome/savemsg/display');
        require 'base.php';



        check_perm('myhome_savemsg',0);


        new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'saved items' WHERE id = '".$id."' AND owner = '".addslashes(USERNAME)."'");


        gen_redirect('Your message has been saved - redirecting you','myhome.php?action=messages&box=saved items');
}



// ###############################
//         FAVORITES
// ###############################
if ($action == 'favorites') {

        $SI['ref'] = 'Viewing his/her favorites';
        $SI['templates'] = '21|80|82|47|91|88';
        define('SCRIPTID','myhome/favorites/display');
        require 'base.php';



        check_perm('myhome_favorites',0);

        $frms = explode("|", $HTTP_COOKIE_VARS['forums']);
        $con = 1;
        while (list($key,$val) = each($frms)) {
                $prop = explode("=", $val);
                $cookie_forums[$prop[0]] = $prop[1];
        }


        $query_getfavorites = new query($SQL, "SELECT ".$prefix."topicicons.image as icon, ".$prefix."topics.lastposterid, ".$prefix."favorites.email as subscribed, ".$prefix."topics.dateline as dateline, ".$prefix."topics.forumid, ".$prefix."topics.id, ".$prefix."topics.title, ".$prefix."topics.smode, ".$prefix."topics.mode, ".$prefix."topics.lastposterid, ".$prefix."topics.poster, ".$prefix."topics.replies, ".$prefix."topics.views, ".$prefix."topics.lpdate, ".$prefix."topics.posterid, ".$prefix."topics.lpuser FROM ".$prefix."favorites, ".$prefix."topics, ".$prefix."topicicons WHERE ".$prefix."favorites.threadid = ".$prefix."topics.id
   AND ".$prefix."favorites.username = '".addslashes(USERNAME)."' AND ".$prefix."topics.icon = ".$prefix."topicicons.id ORDER BY ".$prefix."topics.lpdate DESC");
        while ($query_getfavorites->getrow()) {
                $dostatus = 1;

                $TID = $query_getfavorites->field('id');
                $replies = $query_getfavorites->field('replies');
                $views = $query_getfavorites->field('views');
                $topicicon = $query_getfavorites->field('icon');
                $starter = $query_getfavorites->field('poster');
                $UID = $query_getfavorites->field('posterid');
                $lastpost[UID] = $query_getfavorites->field('lastposterid');
                $FID = $query_getfavorites->field('forumid');
                $date = gmdate($timeformat[3], ($query_getfavorites->field('dateline') + $offset));


                if ($cookie_forums[$FID.','.$TID]) {
                        $check[lastvisit] = $cookie_forums[$FID.','.$TID];
                } else {
                        $check[lastvisit] = $cookie_forums[$FID];
                }


                if ($query_getfavorites->field('subscribed')) {
                        $subscribe = '<a href="myhome.php?action=unsubscribe&TID='.$TID.'">Unsubscribe</a>';
                } else {
                        $subscribe = '<a href="myhome.php?action=subscribe&TID='.$TID.'">Subscribe</a>';
                }

                $check[lastpost] = $query_getfavorites->field('lpdate');
                if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'topic-on.gif'; } else { $icon = 'topic-off.gif'; }

                if ($query_getfavorites->field('lpuser') != '') {
                        unset($lastpost);
                        $lastpost[UID] = $query_getfavorites->field('lastposterid');
                        $lastpost[poster] = $query_getfavorites->field('lpuser');
                        $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
                        eval("\$lastpost = \"".addslashes($TI[47])."\";");
                } else {
                        unset($lastpost);
                        $lastpost[UID] = $UID;
                        $lastpost[date] = $date;
                        $lastpost[poster] = $starter;
                        eval("\$lastpost = \"".addslashes($TI[91])."\";");
                }

                $dostatus = 1;
                $mode = $query_getfavorites->field('smode');

                if ($query_getfavorites->field('locked') == '1') {
                        $icon = 'lock.gif';
                } else { }

                if ($mode == 0) {
                        $title = $query_getfavorites->field('title');
                        $mode = '';
                } else {
                        $title = $query_getfavorites->field('title');
                        $mode = $query_getfavorites->field('mode') . ': ';
                }

                $count++;
                eval("\$include .= \"".addslashes($TI[80])."\";");
        }
        if ($count == 0) { eval("\$include = \"".addslashes($TI[82])."\";"); }
        $title = 'My Favorites';
        $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Favorites';
        eval("\$ucpnav = \"".addslashes($TI[21])."\";");
        eval("\$include = \"".addslashes($TI[88])."\";");
        eval("\$output = \"".addslashes($TI[0])."\";");
        lose($output);

} elseif ($action == 'unsubscribe') {

        $SI['ref'] = 'Unsubscribing from a Topic';
        define('SCRIPTID','myhome/favorites/unsubscribe');
        require 'base.php';



        check_perm('myhome_favorites',0);

        if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }

        new query($SQL, "UPDATE ".$prefix."favorites SET email = '0' WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
        gen_redirect('You are now unsubscribed from this topic, redirecting you to your favorites','myhome.php?action=favorites');
} elseif ($action == 'subscribe') {

        $SI['ref'] = 'Subscribing to a Topic';
        define('SCRIPTID','myhome/favorites/subscribe');
        require 'base.php';



        check_perm('myhome_favorites',0);

        if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }

        $query_check  = new query($SQL, "SELECT email FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
        if (!$query_check->getrow()) {
                gen_error('You can only Subscribe to Topics wich are in your favorites.','To add this topic to your favorites, <a href="myhome.php?action=createfavorite&TID='.$TID.'">click here</a>');
        }
        $query_check->free();
        new query($SQL, "UPDATE ".$prefix."favorites SET email = '1' WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
        gen_redirect('You are now Subscribed to this topic, redirecting you to your favorites','myhome.php?action=favorites');


} elseif ($action == 'createfavorite') {



        $SI['ref'] = 'Adding a Topic to his/her favorites';
        define('SCRIPTID','myhome/favorites/create');
        require 'base.php';



        check_perm('myhome_favorites',0);

        if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }

        $query_check  = new query($SQL, "SELECT email FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
        if ($query_check->getrow()) {
                gen_error('This topic already exists in your favorites.','To remove this topic from your favorites, <a href="myhome.php?action=deletefavorite&TID='.$TID.'">click here</a>');
        }

        $query_check  = new query($SQL, "SELECT forumid FROM ".$prefix."topics WHERE id = '".$TID."'");
        if (!$query_check->getrow()) {
                gen_error('This topic does not exist.','Go back and try again');
        }
        $FID = $query_check->field('forumid');
        $query_check->free();

        if (AUTOSUBSCRIBE) { $email = 1; } else { $email = 0; }
        /*$checkfav = check_perm('thread_canview',1);

        if($checkfav) {
                gen_error('Access Denied','You do not have permission to add this topic to your favorites');
        }*/
	check_perm('thread_canview',1,USERGROUP);
        new query($SQL, "INSERT INTO ".$prefix."favorites VALUES('".addslashes(USERNAME)."','".$FID."','".$TID."','".$email."','1')");
        gen_redirect('This topic is now added to your favorites, redirecting you to your favorites','myhome.php?action=favorites');



} elseif ($action == 'deletefavorite') {

        $SI['ref'] = 'Removing a Topic from his/her favorites';
        define('SCRIPTID','myhome/favorites/delete');
        require 'base.php';



        check_perm('myhome_favorites',0);

        if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }

        $query_check  = new query($SQL, "SELECT email FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
        if (!$query_check->getrow()) {
                gen_error('This topic does not exists in your favorites.','To add this topic to your favorites, <a href="myhome.php?action=createfavorite&TID='.$TID.'">click here</a>');
        }

        $query_check->free();

        new query($SQL, "DELETE FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
        gen_redirect('This topic has been deleted from your favorites, redirecting you to your favorites','myhome.php?action=favorites');

} elseif ($action == 'chpass') {
        $SI['templates'] = '21|150';
        $SI['ref'] = 'Changing his/her pass';
        define('SCRIPTID','myhome/chpass');
        require 'base.php';



        check_perm('myhome_mysettings',0);

        $nav = '<a href="index.php">'.$boardname.'</a> > <a href="myhome.php">UserCP</a> > Change Password';
        eval("\$ucpnav = \"".addslashes($TI[21])."\";");
         eval("\$include = \"".addslashes($TI[150])."\";");
        eval("\$output = \"".addslashes($TI[0])."\";");
        lose($output);



} elseif ($action == 'do_chpass') {
        $SI['ref'] = 'Changing his/her pass';
        define('SCRIPTID','myhome/chpass/send');
        require 'base.php';

        check_perm('myhome_mysettings',0);
        if ($conf != $new) { gen_error('Cannot change Password','Both passwords does not match'); }
        new query($SQL,"UPDATE ".$prefix."profiles SET password = '".md5($new)."' WHERE username = '".addslashes(USERNAME)."'");
        gen_redirect('Password has been changed, redirecting to My Settings','myhome.php?action=settings');



}
?>
