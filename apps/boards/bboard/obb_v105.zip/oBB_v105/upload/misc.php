<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Misc
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

error_reporting(0);

  // ###############################
	//           Active Topics
	// ###############################
	
# Emulate Register Globals
extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);

if($action == 'latest') {
	$SI['ref'] = 'Active Topics';
	$SI['templates'] = '48|49';
	define('SCRIPTID','index/latest');
	require 'base.php';
	check_perm('index_canview',0);
	
	$ctime = time()-86400;
	$query_forums = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display");
	while ($query_forums->fetch()) {		
		$pforums[] = $query_forums->field('forumid');
	}
			
	$query_ug = new query($SQL, "SELECT thread_canview FROM ".$prefix."usergroup WHERE id=".USERGROUP.' LIMIT 1');
	$query_ug->fetch();
	$defcanview = $query_ug->field('thread_canview');
	$query_ug->free;
	
	$query_perm = new query($SQL, "SELECT thread_canview, forumid FROM ".$prefix."forum_permissions WHERE uid=".USERGROUP);
	while ($query_perm->getrow()) {
		$afperm[$query_perm->field('forumid')] = $query_perm->field('thread_canview');
		
	}

	for ($i=0; $i<count($pforums); $i++) {
		if (isset($afperm[$pforums[$i]])) {
			if ($afperm[$pforums[$i]] == 0) {
             	unset($pforums[$i]);}
		} else {
			if ($defcanview == 0)
               unset($pforums[$i]);
		}
	}
	
	$query_topics = new query($SQL, "SELECT forumid, title, poster, id, lpuser, lpdate, lastposterid FROM ".$prefix."topics WHERE lpdate > $ctime ORDER BY lpdate DESC LIMIT 15");
	while($query_topics->getrow()) {
			$title = $query_topics->field('title');
			$author = $query_topics->field('poster');
			$tid = $query_topics->field('id');
			$lastpost = $query_topics->field('lpdate');
			if($query_topics->field('lpuser') == '') {
				$lpuser = $query_topics->field('poster'); }
			else {
				$lpuser = $query_topics->field('lpuser');
			}
			$lastposterid = $query_topics->field('lastposterid');
			$lpdate = gmdate($timeformat[3], ($query_topics->field('lpdate') + $offset));
			if($afperm[$query_topics->field('forumid')] == '0') {
				$topicrow .= '';
			}
			else {
				eval("\$topicrow .= \"".addslashes($TI[49])."\";");
			}
	}
	$query_topics->free();
	eval("\$output = \"".addslashes($TI[48])."\";");
	lose($output);
	
}


    // ###############################
	//         Community Team
	// ###############################

if($action == 'team') {
	$SI['ref'] = 'Community Team Members';
	$SI['templates'] = '209|210|211';
	define('SCRIPTID','base/team');
	require 'base.php';
	
	$query_forums = new query($SQL, "SELECT forumid, moderators FROM ".$prefix."forum_display");
	while ($query_forums->fetch()) {		
		$pforums[] = $query_forums->field('forumid');
	}
	$query_ug = new query($SQL, "SELECT forum_cansee FROM ".$prefix."usergroup WHERE id=".USERGROUP.' LIMIT 1');
	$query_ug->fetch();
	$defcanview = $query_ug->field('forum_cansee');
	$query_ug->free;
	
	$query_perm = new query($SQL, "SELECT forum_cansee, forumid FROM ".$prefix."forum_permissions WHERE uid=".USERGROUP);
	while ($query_perm->getrow()) {
		$afperm[$query_perm->field('forumid')] = $query_perm->field('forum_cansee');		
	}

	for ($i=0; $i<count($pforums); $i++) {
		if (isset($afperm[$pforums[$i]])) {
			if ($afperm[$pforums[$i]] == 0) {
             	unset($pforums[$i]);}
		} else {
			if ($defcanview == 0)
               unset($pforums[$i]);
		}
	}
	
	$qforums = implode(', ', $pforums);
			
	$query_mods = new query($SQL, "SELECT ".$prefix."moderators.modid, ".$prefix."forum_display.title, ".$prefix."moderators.forumid, ".$prefix."profiles.username FROM ".$prefix."moderators, ".$prefix."profiles, ".$prefix."forum_display WHERE ".$prefix."moderators.modid = ".$prefix."profiles.id AND ".$prefix."moderators.forumid = ".$prefix."forum_display.forumid ORDER BY ".$prefix."moderators.modid");
	while($query_mods->fetch()) {
		$forumid = $query_mods->field('forumid');
		$forumtitle = $query_mods->field('title');
		$mod_forums[$query_mods->field('modid')] .= "<a href=\"board.php?FID=$forumid\">$forumtitle</a>, ";
		$mod_id[] = $query_mods->field('modid');
	}
	$query_mods->free();
	
	$modid = implode(', ',$mod_id);
	if(!$modid) { $modid = 'null'; }
		
	$query_users = new query($SQL, "SELECT ".$prefix."profiles.id, ".$prefix."profiles.username, ".$prefix."usergroup.isadmin, ".$prefix."usergroup.ismoderator, ".$prefix."profiles.joindate, ".$prefix."profiles.location FROM ".$prefix."profiles, ".$prefix."usergroup WHERE ".$prefix."profiles.usergroup = ".$prefix."usergroup.id ORDER BY username");
	while($query_users->fetch()) {
	
		$isadmin = $query_users->field('isadmin');
		$isglobalmod = $query_users->field('ismoderator');
		$name = $query_users->field('username');
		$uid = $query_users->field('id');
		$location = $query_users->field('location');
		$joindate = gmdate($timeformat[3], ($query_users->field('joindate') + $offset));

		if(in_array($uid,$mod_id)) {
			$forumlist = substr($mod_forums[$uid], 0, (strlen($mod_forums[$uid]) - 2));
			eval("\$forummodrow .= \"".addslashes($TI[211])."\";"); 
		}
		if($isadmin) { 
			eval("\$adminrow .= \"".addslashes($TI[210])."\";"); 
		}
		elseif($isglobalmod) {
			eval("\$globalmodrow .= \"".addslashes($TI[210])."\";"); 
		}	
		
		unset($isadmin);
		unset($isglobalmod);
		unset($isforummod);
	}
	$nav = "<a href=\"index.php\">$boardname</a> > Community Team";
	eval("\$include = \"".addslashes($TI[209])."\";"); 
	eval("\$output = \"".addslashes($TI[0])."\";"); 
	lose($output);
}
    // ###############################
	//            PM Popup
	// ###############################

if($action == 'pmpop') {
	$SI['ref'] = 'Private Messaging - Popup';
	$SI['templates'] = '220';
	define('SCRIPTID','base/pmpopup');
	require 'base.php';
	
	eval("\$output = \"".addslashes($TI[220])."\";"); 
	lose($output);
}
