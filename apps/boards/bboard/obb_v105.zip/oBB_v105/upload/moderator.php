<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}
/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/

// ###############################
//              LOCK TOPIC
// ###############################

if ($action == 'lock') {
	
	$SI['templates'] = '19|56';
	$SI['ref'] = 'Viewing profile ('.$UID.')';
	define('SCRIPTID','moderator/lock');
	require 'base.php';
		
	$query_getforum = new query($SQL, "SELECT forumid, locked FROM ".$prefix."topics WHERE id = '".$TID."'");
	if (!$query_getforum->getrow()) { gen_error('Invalid TopicID','Go back and try again.'); }
	$FID = $query_getforum->field('forumid');
	$status = $query_getforum->field('locked');
	$query_getforum->free();
	
	if($user_mod[$FID]) { define('MODERATOR',1); $ismod = 1; }
		else { $ismod = 0; }
	
	if (!$ismod) {
		if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
	}
	
	if (!MODERATOR) { gen_error('No Access!','This part of the boards is for moderators only.'); }
	
	
	if ($status == 1) {
		new query($SQL, "UPDATE ".$prefix."topics SET locked = '0' WHERE id = '".$TID."'");
		gen_redirect('The topic is now unlocked, redirecting you.','board.php?FID='.$FID);
	} else {
		new query($SQL, "UPDATE ".$prefix."topics SET locked = '1' WHERE id = '".$TID."'");
		gen_redirect('The topic is now locked, redirecting you.','board.php?FID='.$FID);
	}
	
}


// ###############################
//              MAKE TOPIC STICKY
// ###############################

if ($action == 'sticky') {
	
	$SI['templates'] = '19|56';
	$SI['ref'] = 'Viewing profile ('.$UID.')';
	define('SCRIPTID','moderator/sticky');
	require 'base.php';
	
	$query_getforum = new query($SQL, "SELECT forumid, smode FROM ".$prefix."topics WHERE id = '".$TID."'");
	if (!$query_getforum->getrow()) { gen_error('Invalid TopicID','Go back and try again.'); }
	$FID = $query_getforum->field('forumid');
	$status = $query_getforum->field('smode');
	$query_getforum->free();
	
	if($user_mod[$FID]) { define('MODERATOR',1); $ismod = 1; }
		else { $ismod = 0; }
		
	if (!$ismod) {
		if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
	}
	
	if (!MODERATOR) { gen_error('No Access!','This part of the boards is for moderators only.'); }
	
	if ($status == 1) {
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '0', mode = '' WHERE id = '".$TID."'");
		gen_redirect('The topic is now marked as normal, redirecting you.','board.php?FID='.$FID);
	} else {
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '1', mode = 'Sticky' WHERE id = '".$TID."'");
		gen_redirect('The topic is now made sticky, redirecting you.','board.php?FID='.$FID);
	}
	
}

// ###############################
//              MAKE TOPIC IMPORTANT
// ###############################

if ($action == 'important') {
	
	$SI['templates'] = '19|56';
	$SI['ref'] = 'Viewing profile ('.$UID.')';
	define('SCRIPTID','moderator/important');
	require 'base.php';
		
	$query_getforum = new query($SQL, "SELECT forumid, smode FROM ".$prefix."topics WHERE id = '".$TID."'");
	if (!$query_getforum->getrow()) { gen_error('Invalid TopicID','Go back and try again.'); }
	$FID = $query_getforum->field('forumid');
	$status = $query_getforum->field('smode');
	$query_getforum->free();
	
	if($user_mod[$FID]) { define('MODERATOR',1); $ismod = 1; }
		else { $ismod = 0; }
		
	if (!$ismod) {
		if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
	}
	
	if (!MODERATOR) { gen_error('No Access!','This part of the boards is for moderators only.'); }
	
	if ($status == 1 || $status == 2) {
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '0', mode = '' WHERE id = '".$TID."'");
		gen_redirect('The topic is now marked as normal, redirecting you.','board.php?FID='.$FID);
	} else {
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '1', mode = 'Sticky' WHERE smode = '2'");
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '2', mode = 'Important' WHERE id = '".$TID."'");
		gen_redirect('The topic is now made sticky, redirecting you.','board.php?FID='.$FID);
	}
	
}

// ###############################
//      MAKE ANNOUNCEMENT
// ###############################

if ($action == 'announce') {
	
	$SI['templates'] = '19|56';
	$SI['ref'] = 'Viewing profile ('.$UID.')';
	define('SCRIPTID','moderator/important');
	require 'base.php';
	
	$query_getforum = new query($SQL, "SELECT forumid, smode FROM ".$prefix."topics WHERE id = '".$TID."'");
	if (!$query_getforum->getrow()) { gen_error('Invalid TopicID','Go back and try again.'); }
	$FID = $query_getforum->field('forumid');
	$status = $query_getforum->field('smode');
	$query_getforum->free();
	
	if(!ADMIN) { gen_error('No Access!','Only Administrators May Make Announcements'); }
	
	if ($status == 1 || $status == 2 || $status == 3) {
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '0', mode = '' WHERE id = '".$TID."'");
		new query($SQL, "UPDATE ".$prefix."topics SET locked = '0' WHERE id = '".$TID."'");
		gen_redirect('The topic is now marked as normal and is unlocked, redirecting you.','board.php?FID='.$FID);
	} else {
		new query($SQL, "UPDATE ".$prefix."topics SET smode = '3', mode = 'Announcement' WHERE id = '".$TID."'");
		new query($SQL, "UPDATE ".$prefix."topics SET locked = '1' WHERE id = '".$TID."'");
		gen_redirect('The topic is now an announcement and locked, redirecting you.','board.php?FID='.$FID);
	}
	
}


// ###############################
//              MOVE TOPIC
// ###############################

if ($action == 'move') {
	if ($send == 1) {
		
		$SI['ref'] = 'Moving Topic';
		$SI['templates'] = '28';
		define('SCRIPTID','moderator/move/insert');
		require 'base.php';
		
		$query_getforum = new query($SQL, "SELECT forumid FROM ".$prefix."topics WHERE id = '".$TID."'");
		if (!$query_getforum->getrow()) { gen_error('Invalid Topic ID','Go back and try again.'); }
		$FID_old = $query_getforum->field('forumid');
		$query_getforum->free();
		
		if ($FID_old == $FID) { gen_error('Cannot move thread!','The target forum cannot be the same as the current forum'); }
		
		if($user_mod[$FID] || ADMIN) {$ismod = 1; }
		else { $ismod = 0; }
			
		if (!$ismod) {
			if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); $ismod = 1; } else { define('MODERATOR',0); $ismod = 0;}
		}
		
		if (!$ismod) { gen_error('No Access!','This part of the boards is for moderators only.'); }
		
		if($user_mod[$FID_old] || ADMIN) { $ismodold = 1; }
		else { $ismodold = 0; }
		
		if(!$ismodold) {
			if (get_forumperm('ismoderator',$FID_old)) { $ismodold = 1; } else { $ismodold = 0;}
        }
        if(!$ismodold) { gen_error('No Access!','You must be moderator in both forums!'); }
					
		$query_lastpost_old = new query($SQL, "SELECT lastpost FROM ".$prefix."forum_display WHERE forumid = '".$FID_old."'");
		$query_lastpost_old->getrow();
		$lastpost_old = $query_lastpost_old->field('lastpost');
		$query_lastpost_old->free();
		
		$query_lastpost_new = new query($SQL, "SELECT lastpost FROM ".$prefix."forum_display WHERE forumid = '".$FID."'");
		$query_lastpost_new->getrow();
		$lastpost_new = $query_lastpost_new->field('lastpost');
		$query_lastpost_new->free();
		
		$move = new query($SQL, "SELECT forumid, title, dateline, poster, lpdate, lpuser, replies, smode, mode, toforumid, totopic, views, lastposterid, locked, icon, posterid, lastguest, pollid, moved FROM ".$prefix."topics WHERE id='".$TID."'");
		$move->getrow();
		
		$lastpost_topic = $move->field('lpdate');
		if ($lastpost_old = $lastpost_topic) {
			$query_lastpost_old2 = new query($SQL, "SELECT id FROM ".$prefix."topics WHERE forumid = '".$FID_old."' AND id !='".$TID."'  ORDER by lpdate DESC LIMIT 1");
			$query_lastpost_old2->getrow();
			$sec_lastpost = $query_lastpost_old2->field('id');
			$query_lastpost_old2->free();
			
			$query_lastpost_old3 = new query($SQL, "SELECT id, dateline, title, poster FROM ".$prefix."posts WHERE threadid ='".$sec_lastpost."'  ORDER by dateline ASC LIMIT 1");
			$query_lastpost_old3->getrow();
			$third_lastpost = $query_lastpost_old3->field('id');
			
			new query($SQL, "UPDATE ".$prefix."forum_display SET lastpost='".$query_lastpost_old3->field('dateline')."', lastposter='".addslashes($query_lastpost_old3->field('poster'))."', lastthreadid='".$sec_lastpost."', lastthread='".addslashes($query_lastpost_old3->field('title'))."' WHERE forumid='".$FID_old."'");
			$query_lastpost_old3->free();
		}
		if ($lastpost_topic > $lastpost_new) {
			new query($SQL, "UPDATE ".$prefix."forum_display SET lastpost= '".$move->field('dateline')."', lastposter = '".addslashes($move->field('poster'))."', lastthreadid = '".$TID."', lastposterid='".$move->field('lastposterid')."', lastthread = '".addslashes($move->field('title'))."' WHERE forumid = '".$FID."'");
		}
		
		new query($SQL, "UPDATE ".$prefix."topics SET forumid='".$FID."', moved = '1' WHERE id = '".$TID."'");
		new query($SQL, "UPDATE ".$prefix."posts SET forumid='".$FID."' WHERE threadid='".$TID."'");
		$post_num = $move->field('replies') + 1;
		new query($SQL, "UPDATE ".$prefix."forum_display SET postcount=postcount-$post_num, threadcount=threadcount-1 WHERE forumid='".$FID_old."'");
		new query($SQL, "UPDATE ".$prefix."forum_display SET postcount=postcount+$post_num, threadcount=threadcount+1 WHERE forumid='".$FID."'");
		$move->free();
		$myquery = new query($SQL, "SELECT title FROM ".$prefix."forum_display WHERE forumid = '".$FID."' LIMIT 1");
		while ($myquery->getrow()) {
			$forumname = $myquery->field('title');
		}
		gen_redirect("Thread Moved to $forumname!","read.php?TID=$TID");
		
	} else {
		
		
		$SI['ref'] = 'Moving Topic';
		$SI['templates'] = '28';
		define('SCRIPTID','moderator/move/screen');
		require 'base.php';
		require 'lib/dropdown.php';
		$title = 'Moving Topic';
		$selectbox = forum_dropdown('FID');
		eval("\$include = \"".addslashes($TI[28])."\";");
		eval("\$output = \"".addslashes($TI[0])."\";");
		lose($output);
	}
}

?>
