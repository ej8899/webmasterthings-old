<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


$avatars = 'selected';

# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/


if ($do == '') {
   $SI['templates'] = '50|145';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	
   $avatarselector = '<select name="avatar" onchange="showavatar();">';
   $query_avatars = new query($SQL, "SELECT name, url FROM ".$prefix."avatar WHERE owner = '' AND name != 'none'");
   while($query_avatars->getrow()) {
      $av = $query_avatars->field('url');
      if (!isset($avatarimg)) { $avatarimg = 'avatars/'.$av; }
         $avatarselector .= '<option value="'.$av.'">'.$query_avatars->field('name').'</option>'; 
   }
	
   eval("\$include = \"".addslashes($TI[145])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} 
elseif ($do == 'add') {
   $SI['templates'] = '50|146';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	
	
   eval("\$include = \"".addslashes(addslashes($TI[146]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} 
elseif ($do == 'do_add') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

  
   if (is_uploaded_file($avatar)) {
   
   if ($avatar_type == 'image/pjpeg' || $avatar_type == 'image/jpeg') { $type = '.jpg'; }
   if ($avatar_type == 'image/gif') { $type = '.gif'; }
   
   if (!$type) {
      gen_error('Cannot upload your Avatar','Only GIF and JPG avatars are allowed.');
   }


   $file = time();

   if (!copy($avatar, 'avatars/'.$file.$type)) {
		gen_error('Add avatar error','Uploading the avatar has failed. This is probably due to permission restrictions on the server.');
   }
   $fname = $file.$type;
   
   } else {
	$fname = $avfilename;
   }

	if ($fname == '')
		gen_error('Add avatar error','Please provide either a file or filename for an uploaded avatar.');
   $query = new query($SQL,'SELECT id FROM '.$prefix.'avatar ORDER BY id DESC LIMIT 1');
   $query->getrow();
   $id = $query->field('id') + 1;
   $query->free();
   new query($SQL, "INSERT INTO ".$prefix."avatar VALUES ('".$id."','".$name."','".$fname."','')");

@my_header('cp_avatars.php');

}

elseif ($do == 'remove') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);


   unlink('avatars/'.$avatar);
   new query($SQL, "DELETE FROM ".$prefix."avatar WHERE url = '".$avatar."'");


@my_header('cp_avatars.php');

}


?>
