<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

$ipbanning = "selected";

    /*+--------------------------------
	* Added MP 16-APR-2003
	+--------------------------------*/

    if ( ! isset ( $action ) ) {
	
	     $action = "";
	}
	
	/*+-----------------------------+*/

if ( $action == "" ) {

	$SI['templates'] = '50|195|196|198';
	$SI['ref'] = 'IP Banning Administration';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	
	$query = new query($SQL, "SELECT * from ".$prefix."ipban");
	
		 while ($query->getrow()) {
			
			  $ipid = $query->field('ipid');
			  $ip   = $query->field('number');
			  
			  #eval("\$include .= \"".addslashes($TI[196])."\";");
			  
			  
			  /* Changed by MP 16-APR-2003 */
			  
			  /* Template 196 is no longer used. */
			  $include .= "IP: $ip <a href='cp_ipbans.php?action=do_delip&ipid=$ipid' onClick=\"return(window.confirm('Are You Sure You Want to Delete the IP address $ip?'));\"><img src='images/cp/remove.gif' border='0'></a> <a href='cp_ipbans.php?action=edit&ipid=$ipid'><img src='images/cp/edit.gif' border='0'></a> <br />";
			  
			  #eval ("\$include .= \"IP: $ip <a href='cp_ipbans.php?action=do_delip&ipid=$ipid' onClick=\"return(window.confirm('are you sure?'));\"><img src='images/cp/remove.gif' border='0'></a> <a href='cp_ipbans.php?action=edit&ipid=$ipid'><img src='images/cp/edit.gif' border='0'></a> <br />\";");
			 
			  
		 }
		 
	if(!isset($ip)) {  eval("\$include .= \"".addslashes($TI[198])."\";");  }
	
	$addbutton = "<a href='cp_ipbans.php?action=add'><img src='images/cp/add-new.gif' border='0' alt='Add New IP Address'></a>";
	
	eval("\$include = \"".addslashes($TI[195])."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
}

// +-----------------------------------------------------------+
// | Open Up IP For Editing                                    |
// +-----------------------------------------------------------+

elseif ($action == 'edit') {
	$SI['templates'] = '50|195|197';
	$SI['ref'] = 'IP Banning Administration';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	$act = 'do_editip&ipid=$ipid';
	$addbutton = " <input type='image' border='0' name='imageField' src='images/cp/ok.gif'> ";
	//:: Get IP Information
	$query = "SELECT number FROM ".$prefix."ipban WHERE ipid = '$ipid'";
	$query_ipbans = new query($SQL, $query) or $SQL->error();
	$ipbans = $query_ipbans->getrow();
	$ip = $query_ipbans->field('number');
	eval("\$include = \"".addslashes($TI[197])."\";");
	
	//:: Parse The Screen
	eval("\$include = \"".addslashes($TI[195])."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
}

// +-----------------------------------------------------------+
// | Edit The IP                                               |
// +-----------------------------------------------------------+

elseif ($action == 'do_editip') {
	//:: Declare Base Information
	$SI['templates'] = '50|195';
	$SI['ref'] = 'IP Banning Administration';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "UPDATE ".$prefix."ipban SET number = '".$ip."' WHERE ipid = '".$ipid."'");
	//:: Redirect User Back To cp_ipbans.php
	@my_header("cp_ipbans.php");
}

// +-----------------------------------------------------------+
// | Add IP Ban                                                |
// +-----------------------------------------------------------+
elseif( $action == "add" ) {
	//:: Declare Base Information
	$SI['templates'] = '50|195|197';
	$SI['ref'] = 'IP Banning Administration';
	define('SCRIPTID','cp');
	$act = 'do_addip';
	require 'base.php';
	check_perm('isadmin',0);
	$addbutton = "<input type='image' border='0' name='imageField' src='images/cp/ok.gif'>";
	
	eval("\$include = \"".addslashes($TI[197])."\";");
	//:: Parse The Screen Display
	eval("\$include = \"".addslashes($TI[195])."\";");
	eval("\$output = \"".addslashes($TI[50])."\";");
	print stripslashes($output); flush;
	exit();
}

// +-----------------------------------------------------------+
// | Add IP to DB                                              |
// +-----------------------------------------------------------+

elseif ($action == 'do_addip') {
	//:: Declare Base Information
	$SI['templates'] = '50|195';
	$SI['ref'] = 'IP Banning Administration';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "INSERT INTO ".$prefix."ipban (number) VALUES ('".$ip."')");
	//:: Redirect User Back To cp_users.php
	@my_header("cp_ipbans.php");
}

// +-----------------------------------------------------------+
// | Delete IP from DB                                         |
// +-----------------------------------------------------------+

elseif ($action == 'do_delip') {
	//:: Declare Base Information
	$SI['templates'] = '50|195';
	$SI['ref'] = 'IP Banning Administration';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "DELETE FROM ".$prefix."ipban WHERE ipid LIKE '" .$ipid. "'");
	//:: Redirect User Back To cp_users.php
	@my_header("cp_ipbans.php");
}

?>
