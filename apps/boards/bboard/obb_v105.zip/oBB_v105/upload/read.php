<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


// ###############################
//              READ A TOPIC
// ###############################
error_reporting(7);

// register_globals twaddle

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}
/*extract($_ENV);
extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);*/


define('SCRIPTID','read/display');

if ($action != 'print') {
	$SI['templates'] = '9|10|35|36|83|102|116|125|126|130|131|137|138';
} 
else {
	$SI['templates'] = '25|26';
}

$SI['settings'] = 'modimg, plistperpage';
$SI['ref'] = 'Loading Topic <a href="read.php?TID='.$TID.'">'. $TID.'</a>';
require 'base.php';


// get rid the stupid #bookmarks
$TID=floor($TID);
$page=floor($page);

if ($bgcolor == $tempvars[primary]) {
	$bgcolor = $tempvars[secondary];
}
else {
	$bgcolor = $tempvars[primary];
}



function get_procent ($x,$y) {

	$r = ((100 / $y) * $x);
	return round($r,0);
}

function get_bar ($x) {
	return round((2.5*$x));
}



$frms = explode("|", $HTTP_COOKIE_VARS['forums']);

while (list($key,$val) = each($frms)) {
	$prop = explode("=", $val);
	$cookie_forums[$prop[0]] = $prop[1];
}
$cookie_forums['lasttime'] = time();

$query_getforum = new query($SQL, "SELECT forumid, pollid, description, locked FROM ".$prefix."topics WHERE id = $TID");
$query_getforum->getrow();
	$FID = $query_getforum->field('forumid');
	$poll = $query_getforum->field('pollid');
	$topiclock = $query_getforum->field('locked');
	$topicdesc = $query_getforum->field('description');
$query_getforum->free();

inforum($FID);

if ($action != 'print') {
	check_perm('thread_canview',1);
} 
else {
	check_perm('thread_canprint',1);
}

if ($topiclock) { $replybutton = 'newreply-locked.gif'; } else { $replybutton = 'newreply.gif'; }


if ($action != 'print') {

	if ($action == 'lastpost') {

		if (!isset($TID)) { gen_error('No Thread specified!','Go back to the forum page and try again.'); }
		
		$query_getinfo = new query($SQL, "SELECT replies, forumid FROM ".$prefix."topics WHERE id = $TID");
		$query_getinfo->getrow();
		
		$query_getlastpost = new query($SQL, "SELECT id FROM ".$prefix."posts WHERE threadid = '".$TID."' ORDER BY id DESC LIMIT 1");
		$query_getlastpost->getrow();
		$PID = $query_getlastpost->field('id');
		$query_getlastpost->free();

		if ($query_getinfo->field('replies') < $config->field('plistperpage')) { 
			@my_header('read.php?TID='.$TID.'#'.$PID); 
		}
		else {
			$pages = ceil(($query_getinfo->field('replies') + 1) / $config->field('plistperpage'));
			@my_header('read.php?TID='.$TID.'&page='.$pages.'#'.$PID);
		}

		$query_getinfo->free();
		exit();
	}

	if ($action == 'newest') {
	
		if (!isset($TID)) { gen_error('No Thread specified!','Go back to the forum page and try again.'); }
		
		$query_getinfo = new query($SQL, "SELECT replies FROM ".$prefix."topics WHERE id = $TID");
		$query_getinfo->getrow();
		
		$query_getlastpost = new query($SQL, "SELECT id, dateline FROM ".$prefix."posts WHERE threadid = '".$TID."' ORDER BY id ASC");
		$i = 0;
		while ($query_getlastpost->getrow()) {
			$i++;
			$PID = $query_getlastpost->field('id');
			if ($query_getlastpost->field('dateline') > $cookie_forums[$FID]) {
				$PID = $query_getlastpost->field('id');
				$query_getlastpost->free();
				break;
			}
		}
		if ($query_getinfo->field('replies') < $config->field('plistperpage')) { 
			@my_header('read.php?TID='.$TID.'#'.$PID); 
		}
		else {
			$pages = ceil($i / $config->field('plistperpage'));
			@my_header('read.php?TID='.$TID.'&page='.$pages.'#'.$PID);
		}
		$query_getinfo->free();
		exit();
	}

	function get_group($group, $user) {
		global $SQL, $pusericon, $pusergroup, $prefix;
		$query_getgroup = new query($SQL, "SELECT title, icon FROM ".$prefix."usergroup WHERE id = '$group'");
		$query_getgroup->getrow();
		$pusergroup[$user] = $query_getgroup->field('title');
		$pusericon[$user] = $query_getgroup->field('icon');
		$query_getgroup->free();
		return;
	}
	
	function get_usertitle($posts,$group, $user = '') {
		global $SQL, $FID, $mods, $puserimage, $pusertitle, $config, $prefix;
	
		// get from custom user titles
		$query_gettitle = new query($SQL, "SELECT custom AS usertitle FROM ".$prefix."profiles WHERE username = '$user' LIMIT 1");
		$query_gettitle->getrow();
		if ($title = $query_gettitle->field('usertitle')) {
			$pusertitle[$user] = $tagl.$title;
			$query_gettitle = new query($SQL, "SELECT image FROM ".$prefix."usergroup WHERE id = '$group' LIMIT 1");
			$query_gettitle->getrow();
			if ($query_gettitle->field('image') == '') {
				$query_gettitle = new query($SQL, "SELECT title AS usertitle, image FROM ".$prefix."usertitles WHERE (minposts - 1) < $posts AND (maxposts + 1) > $posts AND usergroup = '$group'");
				$query_gettitle->getrow();
			}
			$puserimage[$user] = $query_gettitle->field('image');
			return;
		}
	
		// get from custom forum usergroup titles
		$query_gettitle = new query($SQL, "SELECT usertitle FROM ".$prefix."forum_permissions WHERE forumid = '".$FID."' AND uid = '".$group."' LIMIT 1");
		$query_gettitle->getrow();
		if ($title = $query_gettitle->field('usertitle')) {
			$pusertitle[$user] = $tagl.$title;
			$query_gettitle = new query($SQL, "SELECT image FROM ".$prefix."usergroup WHERE id = '$group' LIMIT 1");
			$query_gettitle->getrow();
			if ($query_gettitle->field('image') == '') {
				$query_gettitle = new query($SQL, "SELECT title AS usertitle, image FROM ".$prefix."usertitles WHERE (minposts - 1) < $posts AND (maxposts + 1) > $posts AND usergroup = '$group'");
				$query_gettitle->getrow();
			}
			$puserimage[$user] = $query_gettitle->field('image');
			return;		
		}
		// get from custom usergroup titles
		$query_gettitle = new query($SQL, "SELECT usertitle, custom, image, isadmin, ismoderator FROM ".$prefix."usergroup WHERE id = '$group' LIMIT 1");
		$query_gettitle->getrow();
		if ($title = $query_gettitle->field('usertitle')) {
			$pusertitle[$user] = $tagl.$title;
			$puserimage[$user] = $query_gettitle->field('image');
			return;
		}
		$query_gettitle = new query($SQL, "SELECT title AS usertitle, image FROM ".$prefix."usertitles WHERE (minposts - 1) < $posts AND (maxposts + 1) > $posts AND usergroup = '$group'");
		$query_gettitle->getrow();
		
		$pusertitle[$user] = $tagl.$query_gettitle->field('usertitle');
		$puserimage[$user] = $query_gettitle->field('image');
		$query_gettitle->free();
		}
	}

	include 'lib/codeparse.php';
	
	$include = '';
	if (!isset($TID)) {
		gen_error('No Topic specified!','Go back to the forum page and try again.');
	}
	if (!isset($FID)) {
		gen_error('No Forum specified!','Go back and try again.');
	}
	
	new query($SQL, "UPDATE ".$prefix."favorites SET visit = '1' WHERE threadid = $TID AND username = '".addslashes(USERNAME)."'");
	$cookie_forums[$FID.','.$TID] = time();
	
	if ($action != 'print') {
	if($user_mod[$FID]) { define('MODERATOR',1); $ismod = 1; } else { $ismod = 0; }
	
	if (!$ismod) {
		if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
	}
	new query($SQL, "UPDATE ".$prefix."favorites set visit = '1'  WHERE threadid = '$TID' AND username = '".addslashes(USERNAME)."'");
	
	
	$query_getinfo = new query($SQL, "SELECT title, replies FROM ".$prefix."topics WHERE id = '$TID'");
	$query_getinfo->getrow();
	new query($SQL, "UPDATE ".$prefix."topics SET views = (views + 1) WHERE id = $TID");
	new query($SQL, "UPDATE ".$prefix."configuration SET totalviews = (totalviews + 1)");
	new query($SQL, "UPDATE ".$prefix."active SET location = 'Reading Topic <a href=\"read.php?TID=$TID&FID=$FID\">".addslashes($query_getinfo->field('title'))."</a>' WHERE record = '".RECORD."'");
	
	$maxpostsperpage=$config->field('plistperpage');;
	
	if ($query_getinfo->field('replies') >= $maxpostsperpage) {
		$count = (($query_getinfo->field('replies')+1) / $maxpostsperpage);
		$pages = ceil($count);
		if ($page == '') { $page = 1; }
		
		$pagelink = '';
		
		if ($pages > $page + 2 && $pages > 5) {
			$tmp = max($page + 2, 5);
		}
		else {
			$tmp = $pages;
		}
		
		if ($page > 2 && $pages > 5) {
			$pagenumber = min($page - 3, $pages - 5);
		}
		else {
			$pagenumber = 0;
		}
		
		for ($i=0; $i<5 && $tmp != 0 && $pagenumber <= $pages; $i++) {
			$pagenumber++;
			$tmp--;
			if ($pagenumber == $page) {
				if ($page == 1) {
					$prevlast = 1;
				}
				else {
				$previouspage = $page - 1;
				}	
				eval("\$pagelink .= \"".addslashes($TI[138])."\";");
				$getnext = 1;
			}
			else {
				if ($getnext) {
					$getnext = 0;
					$nextpage = $pagenumber;
				}
				eval("\$pagelink .= \"".addslashes($TI[137])."\";");
			}
		}
	
		if ($prevlast) {
			$prevlast = 0;
			$previouspage = $pages;
		}
	
		if ($getnext) {
			$getnext = 0;
			$nextpage = 1;
		}
	} 
	else {
		$page = 1;
		$pagenumber = 1;
		$previouspage = 1;
		$nextpage = 1;
		eval("\$pagelink = \"".addslashes($TI[138])."\";");
		$pages = 1;
	}
	if ($page > $pages) { gen_error("Page not found", "Sorry, this page does not exist."); }
	
	$start = (($page - 1)*$maxpostsperpage);
	if (($pages * $maxpostsperpage) == ($query_getinfo->field('replies') + 1)) { $final = $pages + 1; } else { $final = $pages; }
	$query_getinfo->free();
	
	$nav = getnav('forum:'.$FID);
	if ($page != 1) {
		$thread = $query_getinfo->field('title');
		$nav .= ' > '. $thread;
	}
	//attachments - added posts.attachid to select statement as attachid
	$query_threads = new query($SQL, "SELECT ".$prefix."posts.guest as isguest, ".$prefix."profiles.yahoo as yahoo, ".$prefix."usergroup.statcolor, ".$prefix."profiles.lastactive as lastact, ".$prefix."profiles.invisible as invis, ".$prefix."profiles.icq as icq, ".$prefix."profiles.aim as aim, ".$prefix."profiles.msn as msn, ".$prefix."profiles.homepage as homepage, ".$prefix."profiles.joindate as joindate, ".$prefix."profiles.id as userid, ".$prefix."profiles.usergroup as usergroup, ".$prefix."profiles.avatar as avatar, ".$prefix."profiles.sig as sig, ".$prefix."profiles.location as location, ".$prefix."profiles.posts as posts, ".$prefix."posts.id as id, ".$prefix."posts.ip as ip, ".$prefix."posts.parseurl as parseurl, ".$prefix."posts.dsmiley as dsmiley, ".$prefix."posts.dsig as dsig, ".$prefix."posts.poster as poster,". $prefix."posts.message as message, ".$prefix."posts.title as title, ".$prefix."posts.dateline as dateline, ".$prefix."posts.lastupdate as lastupdate, ".$prefix."posts.isstarter as isstarter,
	".$prefix."posts.lastupdateby as lastupdateby, ".$prefix."posts.attachid as attachid FROM ".$prefix."posts, ".$prefix."profiles, ".$prefix."usergroup WHERE ".$prefix."posts.poster = ".$prefix."profiles.username AND ".$prefix."posts.threadid = '$TID' AND ".$prefix."profiles.usergroup = ".$prefix."usergroup.id ORDER BY ".$prefix."posts.id LIMIT $start,$maxpostsperpage");
} 
else {
	//attachments - added posts.attachid to select statement as attachid
	$query_threads = new query($SQL, "SELECT ".$prefix."posts.guest as isguest, ".$prefix."profiles.yahoo as yahoo, ".$prefix."usergroup.statcolor, ".$prefix."profiles.lastactive as lastact, ".$prefix."profiles.invisible as invis, ".$prefix."profiles.icq as icq, ".$prefix."profiles.aim as aim, ".$prefix."profiles.msn as msn, ".$prefix."profiles.homepage as homepage,  ".$prefix."profiles.id as userid, ".$prefix."posts.id as id, ".$prefix."posts.poster as poster, ".$prefix."posts.message as message, ".$prefix."posts.title as title, ".$prefix."posts.dateline as dateline, ".$prefix."posts.lastupdate as lastupdate, ".$prefix."posts.isstarter as isstarter, ".$prefix."posts.lastupdateby as lastupdateby, ".$prefix."posts.attachid as attachid FROM ".$prefix."posts, ".$prefix."profiles, ".$prefix."usergroup WHERE ".$prefix."posts.poster = ".$prefix."profiles.username AND ".$prefix."posts.threadid = '$TID' AND ".$prefix."profiles.usergroup = ".$prefix."usergroup.id ORDER BY ".$prefix."posts.id");
}
$col = '1';
$query_threads->getrow();

// Set Thread Title
if ($page == 1 && $action != 'print') { 
	$title = strip_tags($thread = $query_threads->field('title')); $nav .= ' > '. $title; 
} 
else{ 
	$title = $thread = $query_threads->field('title');
}

// Set the ID of the Firstpost + the ID of this post (the first one)
$id = $firstpostid = $query_threads->field('id');

// Get Users IP
if (MODERATOR || ADMIN && $action != 'print') { 
	$ip = 'IP: <a href="member.php?action=getdns&uid='.$query_threads->field('userid').'&pip='.$query_threads->field('ip').'">'.$query_threads->field('ip').'</a>'; 
} 
else { 
	$ip = "";#""'IP: Hidden'; 
}


// Last Update: Edit
// <----------
$lastupdate = $query_threads->field('lastupdate');
$lastupdateby = $query_threads->field('lastupdateby');

if ($lastupdate) {
	$lastupdate = 'Last updated at '. gmdate($timeformat[3], ($query_threads->field('lastupdate') + $offset));

	if ($lastupdateby != '') {
	$lastupdate .= ' by '.$lastupdateby;
	}
} 
else {
	$lastupdate = '';
}

if ($lastupdate != '') {
	
	$lastedited = ' Last edited by: ' .$lastupdateby .' on '.gmdate($timeformat[3], ($query_threads->field('lastupdate') + $offset));
	$posttime = gmdate($timeformat[3], ($query_threads->field('dateline') + $offset));
} 
else {
	$posttime = gmdate($timeformat[3], ($query_threads->field('dateline') + $offset));
	$lastedited = '';
}
// -------->





$gp = $query_threads->field('isguest');

if (!$gp) {
	$username = $query_threads->field('poster');
	$UID = $query_threads->field('userid');
}	
$PID = $query_threads->field('id');

if ($action != 'print') {
$post = preg_replace("/([^\n\r ?&\.\/<>\"\\-]{60})/i"," \\1<br>",$query_threads->field('message'));
	$post = codeparse($post, $query_threads->field('parseurl'), $query_threads->field('dsmiley'), $username);
	if(CENSOR) {
		$post = censor($post);
	}
	
	if ($col == 1) {
		$col = 2;
		$rowbg = '{primary}';
	} 
	else {
		$col = 1;
		$rowbg = '{secondary}';
	}
	//attachments - set attachment variables if this post has an attachment
	if ($query_threads->field('attachid') != 0) {
	$query_attachment = new query($SQL, "SELECT filename, filesize, downloaded FROM ".$prefix."attachments WHERE id = ".$query_threads->field('attachid'));
		$query_attachment->getrow();
		$attachdl = $query_attachment->field('downloaded');
		$attachment = "<a href=download.php?AID=".$query_threads->field('attachid').">".$query_attachment->field('filename')."</a>&nbsp;&nbsp;(".$query_attachment->field('filesize')." bytes)<br>Downloaded: $attachdl time(s)<br>";
	} 
	else {
		$attachment = '';
	}
	//end attachments

	if (!$gp) {
	
		$user[groupid] = $query_threads->field('usergroup');
		$user[title] = $pusertitle[$username];
		$user[location] = $query_threads->field('location');
		$user[posts] = $query_threads->field('posts');
		
		$user[icq] = $query_threads->field('icq');
		$user[wm] = $query_threads->field('msn');
		$user[aim] = $query_threads->field('aim');
		$user[yahoo] = $query_threads->field('yahoo');
		
		$user[homepage] = $query_threads->field('homepage');
		$user[joindate] = gmdate("F j, Y", ($query_threads->field('joindate') + offset));
		
		if($query_threads->field('statcolor')) { $fcolor = $query_threads->field('statcolor'); } else { $fcolor = $tempvars['bodytext']; }
		
		if (!isset($pusertitle[$username])) {
			$pusergroup[$username] = '';
			$pusericon[$username] = '';
			get_group($user[groupid], $username);
			$puser[group][$username] = $pusergroup[$username];
			$pusertitle[$username] = '';
			$puserimage[$username] = '';
			get_usertitle($user[posts],$user[groupid],$username);
		}
	
	// Online / Offline
	if(!ADMIN && $query_threads->field('invis')) {  $iapprove = 0; } else { $iapprove = 1; }
	if((time() - $query_threads->field('lastact')) < 600 && isapprove) {
		$puserstat = "online.gif"; }
	else {
		$puserstat = "offline.gif"; }
	}
	
	$user[title] = $pusertitle[$username];
	$user[image] = $puserimage[$username];
	$user[group] = $puser[group][$username];
	$user[onlinestat] = $puserstat[$username];
	
	if ($pusericon[$username]) {
		$user[icon] = $pusericon[$username];
		eval("\$user[icon] = \"".addslashes($TI[102])."\";");
	}

	if (SHOWAVATAR) {
		if($query_threads->field('avatar') != '') {
			if (strtolower(substr($query_threads->field('avatar'),0,7)) == 'http://') {
				$user[avatar] = '<img src="'.$query_threads->field('avatar').'" border="0">';
			}
			else {
				$user[avatar] = '<img src="avatars/'.$query_threads->field('avatar').'" border="0">';
			}
		}
		else { 
			$user[avatar] = ''; 
		}
	}

		if(SHOWSIG && $query_threads->field('sig') && !$query_threads->field('dsig') )
		{
			$signature = codeparse($query_threads->field('sig'),1,0,$username);
			eval('$user[signature] = "'. addslashes($TI[83]) .'";');
		}
		else
		{
			$signature = '';
			$user['signature'] = '';
		}

	if (!$gp) {
		eval("\$include .= \"".addslashes($TI[10])."\";");
	} 
	else {
		eval("\$include .= \"".addslashes($TI[116])."\";");
	}

	unset($user[signature]);
	unset($user[avatar]);
} 
else {
	$post = nl2br($query_threads->field('message'));
	if(CENSOR) {
		$post = censor($post);
	}
	eval("\$include .= \"".addslashes($TI[26])."\";");
}

// <!-- Seperator -->

while ($query_threads->getrow()) {

	$gp = $query_threads->field('isguest');
	$title = $query_threads->field('title');
	$id = $query_threads->field('id');

	// Last Update: edit
	// <----------
	
	if ($bgcolor == $tempvars[primary]) {
		$bgcolor = $tempvars[secondary];
	}
	else {
		$bgcolor = $tempvars[primary];
	}
	$lastupdate = $query_threads->field('lastupdate');

	// Moderator: IP
	if (MODERATOR || ADMIN && $action != 'print') { 
		$ip = 'IP: <a href="member.php?action=getdns&uid='.$query_threads->field('userid').'&pip='.$query_threads->field('ip').'">'.$query_threads->field('ip').'</a>'; 
	} 
	else { 
		$ip = ""; #'IP: Hidden'; 
	}
	
	$lastupdateby = $query_threads->field('lastupdateby');
	
	if ($lastupdate) {	
		$lastupdate = 'Last updated at '. gmdate($timeformat[3], ($query_threads->field('lastupdate') + $offset));
	
		if ($lastupdateby != '') {
			$lastupdate .= " by <a href=profile.php?nid=$lastupdateby>$lastupdateby</a>";
		}		
	} 
	else {
		$lastupdate = "";
	}
	
	if ( $lastupdate != "" ) {
	
		$lastedited = ' Last edited by: ' .$lastupdateby .' on '.gmdate($timeformat[3], ($query_threads->field('lastupdate') + $offset));
		$posttime = gmdate($timeformat[3], ($query_threads->field('dateline') + $offset));
	} 
	else {
		$posttime = gmdate($timeformat[3], ($query_threads->field('dateline') + $offset));
		$lastedited = "";
	}
	// -------->

	if (!$gp) {
		$username = $query_threads->field('poster');
		$UID = $query_threads->field('userid');
	}		
		$PID = $query_threads->field('id');
		
	if ($action != 'print') {
		$post = preg_replace("/([^\n\r ?&\.\/<>\"\\-]{60})/i"," \\1<br>",$query_threads->field('message'));
		$post = codeparse($post, $query_threads->field('parseurl'), $query_threads->field('dsmiley'), $username);
		if(CENSOR) {
			$post = censor($post);
		}
		
		if ($col == 1) {
			$col = 2;
			$rowbg = '{primary}';
		} 
		else {
			$col = 1;
			$rowbg = '{secondary}';
		}

		//attachments - set attachment variables if this post has an attachment
		if ($query_threads->field('attachid') != 0) {
			$query_attachment = new query($SQL, "SELECT filename, filesize FROM ".$prefix."attachments WHERE id = ".$query_threads->field('attachid'));
			$query_attachment->getrow();
			$attachment = "<font size=-2>$username attached this file:</font><br><a href=download.php?AID=".$query_threads->field('attachid').">".$query_attachment->field('filename')."</a>&nbsp;&nbsp;(".$query_attachment->field('filesize')." bytes)<br>";
		} 
		else {
			$attachment = '';
		}
		//end attachments

		if (!$gp) {
			$user[groupid] = $query_threads->field('usergroup');
			$user[title] = $pusertitle[$username];
			$user[image] = $puserimage[$username];
			$user[location] = $query_threads->field('location');
			$user[posts] = $query_threads->field('posts');
			$user[joindate] = gmdate($timeformat[1], ($query_threads->field('joindate') + offset));
		
		// Online / Offline
		if(!ADMIN && $query_threads->field('invis')) {  $iapprove = 0; } else { $iapprove = 1; }
		if((time() - $query_threads->field('lastact')) < 600 && isapprove) {
			$puserstat = "online.gif"; }
		else {
			$puserstat = "offline.gif"; }
		}
				
		if($query_threads->field('statcolor')) { $fcolor = $query_threads->field('statcolor'); } else { $fcolor = $tempvars['bodytext']; }
		
		if (!isset($pusertitle[$username])) {
			$pusergroup[$username] = '';
			$pusericon[$username] = '';
			get_group($user[groupid], $username);
			$puser[group][$username] = $pusergroup[$username];
			$pusertitle[$username] = '';
			$puserimage[$username] = '';
			get_usertitle($user[posts],$user[groupid],$username);
		}

		$user[title] = $pusertitle[$username];
		$user[image] = $puserimage[$username];
		$user[group] = $puser[group][$username];

		if ($pusericon[$username]) {
			$user[icon] = $pusericon[$username];
			eval("\$user[icon] = \"".addslashes($TI[102])."\";");
		} 
		else { 
			$user[icon] = ''; 
		}

		if (SHOWAVATAR) {
			 if($query_threads->field('avatar') != '') {
				if (strtolower(substr($query_threads->field('avatar'),0,7)) == 'http://') {
					$user[avatar] = '<img src="'.$query_threads->field('avatar').'" border="0">';
				}
				else {
					$user[avatar] = '<img src="avatars/'.$query_threads->field('avatar').'" border="0">';
				}
			 }
			 else { $user[avatar] = ''; }
		}


		if(SHOWSIG && $query_threads->field('sig') && !$query_threads->field('dsig') )
		{
			$signature = codeparse($query_threads->field('sig'),1,0,$username);
			eval('$user[signature] = "'. addslashes($TI[83]) .'";');
		}
		else
		{
			$signature = '';
			$user['signature'] = '';
		}
	
		if (!$gp) {
			eval("\$include .= \"".addslashes($TI[10])."\";");
		} 
		else {
			eval("\$include .= \"".addslashes($TI[116])."\";");
		}
		unset($user[signature]);
		unset($user[avatar]);
	} 
	else {
		$post = $query_threads->field('message');
		if(CENSOR) {
			$post = censor($post);
		}
		eval("\$include .= \"".addslashes($TI[26])."\";");
	}
}
$cookie_forums['lastforum'] = $FID;

while (list($key,$val) = each($cookie_forums)) {
	if ($key != '') {
		$cookie .= $key . '='. $val . '|';
	}
}

if($config->field('cookiedomain') != '') {
	setcookie('forums',$cookie,$expire,$config->field('cookiepath'),$config->field('cookiedomain'));
}
else {
	setcookie('forums',$cookie,$expire,$config->field('cookiepath'));
}
$query_threads->free();

if ($action != 'print') {
	if (MODERATOR || ADMIN) { eval("\$adminfunctions = \"".addslashes($TI[35])."\";");  }

	require 'lib/dropdown.php';
	$fs[$FID] = 'selected';

	eval("\$selectbox = \"".addslashes(forum_dropdown('forumid'))."\";");
	eval("\$forumnav = \"".addslashes($TI[36])."\";");

	$page = $final;

	if ($poll) {
		
		$query_poll = new query($SQL, "SELECT total, option1, option2, option3, option4, option5, option6, option7, option8, option9, option10, answer1, answer2, answer3, answer4, answer5, answer6, answer7, answer8, answer9, answer10 FROM ".$prefix."polls WHERE id = '".$poll."'");
		
		while($query_poll->getrow()) {

			$voters = explode(',',$query_poll->field('total'));
			if (in_array(USERNAME,$voters)) { $gotvote = 1; }
			
			if ($topiclock || $gotvote || !MEMBER) {
				$polltemplate = addslashes($TI[131]);
			} 
			else {
				$polltemplate = addslashes($TI[125]);
			}
			$total = count($voters);
			if ($choice = $query_poll->field('option1')) {
				$choiceid = 1;
				$votes = $query_poll->field('answer1');
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}
			
			if ($choice = $query_poll->field('option2')) {
				$votes = $query_poll->field('answer2');
				$choiceid = 2;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}

			if ($choice = $query_poll->field('option3')) {
				$votes = $query_poll->field('answer3');
				$choiceid = 3;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}
			
			if ($choice = $query_poll->field('option4')) {
				$votes = $query_poll->field('answer4');
				$choiceid = 4;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}
			
			if ($choice = $query_poll->field('option5')) {
				$votes = $query_poll->field('answer5');
				$choiceid = 5;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}


			if ($choice = $query_poll->field('option6')) {
				$votes = $query_poll->field('answer6');
				$choiceid = 6;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}
			
			if ($choice = $query_poll->field('option7')) {
				$votes = $query_poll->field('answer7');
				$choiceid = 7;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}
			
			if ($choice = $query_poll->field('option8')) {
				$votes = $query_poll->field('answer8');
				$choiceid = 8;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}
			
			if ($choice = $query_poll->field('option9')) {
				$votes = $query_poll->field('answer9');
				$procent = get_procent($votes, $total);
				$choiceid = 9;
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}

			if ($choice = $query_poll->field('option10')) {
				$votes = $query_poll->field('answer10');
				$choiceid = 10;
				$procent = get_procent($votes, $total);
				$barwidth = get_bar($procent);
				eval("\$choices .= \"".$polltemplate."\";");
			}			
		}
		$query_poll->free();
		$question = $thread;
		if ($topiclock || $gotvote || !MEMBER) {
			eval("\$includepoll = \"".addslashes($TI[130])."\";");
		} 
		else {
			eval("\$includepoll = \"".addslashes($TI[126])."\";");
		}
	}

	$thread = str_replace('<','&lt;',$thread);
	$title = 'Reading Topic: '.$thread.'';
	eval("\$include = \"".addslashes($TI[9])."\";");
	eval("\$output = \"".addslashes($TI[0])."\";");
} 
else {
	$url = $config->field('boardurl') . '/read.php?TID='.$TID;
	$boardname = $config->field('boardname');
	$title = 'Preparing to Print Topic \''.$thread.'\'';
	eval("\$output = \"".addslashes($TI[25])."\";");
}

lose($output);
?>


