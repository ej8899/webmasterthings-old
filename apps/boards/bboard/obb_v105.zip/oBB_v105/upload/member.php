<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Open Bulletin Board - Moderate Script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/


error_reporting(7);
$needscache="true";

# Emulate Register Globals

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

/*extract($_GET);
extract($_POST);
extract($_COOKIE);
extract($_SERVER);
extract($_ENV);*/


// ###############################
//              VIEW PROFILE
// ###############################

if ($action == 'profile') {

        $SI['templates'] = '19|56';
        $SI['ref'] = 'Viewing profile ('.$UID.')';
        define('SCRIPTID','member/profile/display');
        require 'base.php';

        check_perm('member_canviewprofile',0);
        check_perm('member_canviewprofile',0);
        function get_usertitle($posts,$group,$user) {
                global $SQL, $prefix;

                $query_usertitle = new query($SQL, "SELECT custom FROM ".$prefix."profiles WHERE id = '".$user."'");
                        $query_usertitle->getrow();
                        $u = $query_usertitle->field('custom');
                        if(trim($query_usertitle->field('custom')) != '') { return $u; }
                $query_usertitle->free();

                $query_usertitle = new query($SQL, "SELECT usertitle, custom FROM ".$prefix."usergroup WHERE id = $group");
                $query_usertitle->getrow();
                if ($query_usertitle->field('custom') == '1') {
                        $o = $query_usertitle->field('usertitle');
                        if ($query_usertitle->field('usertitle') == '') { $query_usertitle->free(); return $o; }
                }

                if ($query_usertitle->field('usertitle') == '') {
                        $query_usertitle = new query($SQL, "SELECT title AS usertitle FROM ".$prefix."usertitles WHERE (minposts - 1) < $posts AND (maxposts + 1) > $posts AND usergroup = $group");
                        $query_usertitle->getrow();
                }
                $result = $query_usertitle->field('usertitle');
                $query_usertitle->free();
                return $result;
        }

        function get_group($group) {
                global $SQL, $prefix;
                $q = new query($SQL, "SELECT title FROM ".$prefix."usergroup WHERE id = $group");
                $q->getrow();
                return $q->field('title');
        }
        $query_users = new query($SQL, "SELECT username, showemail, homepagedesc, msn, occupation, avatar, email, homepage, posts, joindate, icq, aim, yahoo, location, note, birthdate, usergroup FROM ".$prefix."profiles WHERE id = '".$UID."'");
        if (!$query_users->getrow()) { gen_error('An invalid profile was requested.',''); }
        $user[name] = $query_users->field('username');

        if ($query_users->field('showemail')) {
                $user[email] = $query_users->field('email');
        } else {
                $user[email] = 'Send an E-mail';
        }

        $user[homepage] = $query_users->field('homepage');
        $user[posts] = $query_users->field('posts');
        $user[icq] = $query_users->field('icq');
        $user[aim] = $query_users->field('aim');
        $user[yim] = $query_users->field('yahoo');
        $user[wm] = $query_users->field('msn');
        $user[jointime] = (time() - $query_users->field('joindate')) / 86400;
        if ($user[jointime] < 1) {
                $user[pratio] = $user[posts];
        } else {
                $rat = explode('.', ($user[posts] / $user[jointime]));
                $user[pratio] = $rat[0] .'.'. substr($rat[1],0,2);
        }
        if (ADMIN) { eval("\$adminopt = \"".addslashes($TI[56])."\";"); }
        $user[location] = stripslashes($query_users->field('location'));
        $user[notes] = stripslashes($query_users->field('note'));
        $user[homepagedesc] = stripslashes($query_users->field('homepagedesc'));
        $user[occupation] = stripslashes($query_users->field('occupation'));
        $user[groupid] = $query_users->field('usergroup');
        $user[group] = get_group($user[groupid]);
        $user[joindate] = gmdate($timeformat[1], ($query_users->field('joindate') + $offset));
        if($query_users->field('avatar') != '') {
if (strtolower(substr($query_users->field('avatar'),0,7)) == 'http://')
$avatar = '<img src="'.$query_users->field('avatar').'">';
else
$avatar = '<img src="avatars/'.htmlentities($query_users->field('avatar')).'">';
} else { $avatar = ''; }
        $user[status] = get_usertitle($user[posts],$user[groupid],$UID);
    $bconvert =  strtotime($query_users->field('birthdate'));
    $birthdate = explode("-",stripslashes($query_users->field('birthdate')));

           if($birthdate[0] == '0000' && !$birthdate[1] || $birthdate[1] == '00') {
                $birthday = '';
        }
        else {
            if($birthdate[0] == '0000') {
                    $birthday = date("F jS", $bconvert);
            }
            else {
                        $birthday = date("F jS, Y", $bconvert);
            }
        }

    $query_users->free();
        $nav = getnav('profile') .' > '. $user[name];
        $title = 'Viewing Profile of '. $user[name];
        eval("\$include = \"".addslashes($TI[19])."\";");
        eval("\$output = \"".addslashes($TI[0])."\";");
        lose($output);

}
// ###############################
//              LOGIN
// ###############################
if ($action == 'login') {
        // ### 'Log in' Screen
        if (!$send) {
                $SI['ref'] = 'Logging In';
                $SI['templates'] = '16';
                define('SCRIPTID','member/login/display');
                require 'base.php';

                if (MEMBER) { gen_error('Already logged in!',''); }

                $title = 'Logging In';
                eval("\$include = \"".addslashes($TI[16])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);

        }

        // ### Set User to logged in
        elseif ($send) {
                $redirect =  str_replace('|','&',$redirect);
                $SI['ref'] = 'Logging In';
                define('SCRIPTID','member/login/insert');
                require 'base.php';

                unset($loginerror);
                if (MEMBER) {
                        if($site) { @header("location: $siteurl/index.php?act=loginredir&loginerror=loggedin"); die();}

                else { gen_error('Already logged in!',''); }
                }

                if ($username == '' ||  $password == '') {
                        if($site) { @header("location: $siteurl/index.php?act=loginredir&loginerror=missing"); die();}
                    else { gen_error('Fill in all fields please!','Required information is missing.'); }
                }
                $query_checkdata = new query($SQL, "SELECT password, invisible, username FROM ".$prefix."profiles WHERE username = '".trim($username)."'");
                if (!$query_checkdata->getrow()) {

                        if($site) { @header("location: $siteurl/index.php?act=loginredir&loginerror=baduser"); die();}
                        else { gen_error('Username ('.$username.') does not exist!','Please check for typing mistakes. To register click <a href="member.php?action=register">here</a>.'); }
                }
                if ($query_checkdata->field('password') != md5($password)) {

                        if($site) { @header("location: $siteurl/index.php?act=loginredir&loginerror=badpass"); die();}
                        else { gen_error('Wrong Password!','If you lost your password click <a href="member.php?action=forgotpasswd">here</a>.'); }
                }
                $username = htmlspecialchars($query_checkdata->field('username'));
                new query($SQL, "DELETE FROM ".$prefix."active WHERE member = '".addslashes($username)."'");
                new query($SQL, "UPDATE ".$prefix."active SET invisible = '".$query_checkdata->field('invisible')."', member = '".addslashes($username)."', lastaction = '".time()."' WHERE record = '".RECORD."'");

                setcookie('record',RECORD,$expire,$config->field('cookiepath'),$config->field('cookiedomain'),0);
                $query_checkdata->free();

                if($site) {        @header("location: $siteurl/index.php?act=loginredir"); die();        }

                if ($redirect) {
                        gen_redirect('You are now logged in, redirecting you.', $redirect);
                } else {
                        gen_redirect('You are now logged in, redirecting you to mainpage.', 'index.php');
                }

        }
}

// ###############################
//              LOGOUT
// ###############################
if ($action == 'logout') {
        $SI['ref'] = 'Logging Out';
        define('SCRIPTID','member/logout');
        include 'base.php';

        if (!MEMBER) { gen_error('Not Logged In!','You can\'t logout if you aren\'t logged in!'); }

        setcookie('record',RECORD,$expire,$config->field('cookiepath'),$config->field('cookiedomain'),0);
        new query($SQL, "UPDATE ".$prefix."active SET member = '' WHERE record = '".RECORD."'");
        gen_redirect('Succesfully logged out, we are taking you back to the mainpage.','index.php');
}
// ###############################
//              REGISTER
// ###############################


if ($action == 'register') {


// ### Get User Information
        if (!$send) {
                $SI['ref'] = 'Registering a new Account';
                $SI['templates'] = '15|46|203';
                $nav = 'Registration';

                define('SCRIPTID','member/register/display');
                include 'base.php';

                $q_conf = new query($SQL, "SELECT defaulttimezone FROM ".$prefix."configuration LIMIT 1");
                $q_conf->getrow();
                check_perm('member_canregister',0);

                $vis = 'checked';
                $hidemail = 'checked';

                if (SHOWAVATAR) {
                        $showavatar = 'checked';
                } else {
                        $dontshowavatar = 'checked';
                }
                if (SHOWSIG) {
                        $showsignature = 'checked';
                } else {
                        $dontshowsignature = 'checked';
                }
                if (SHOWHISTORY) {
                        $showhistory = 'checked';
                } else {
                        $dontshowhistory = 'checked';
                }

                $avatarselector = '<select name="avatar" onchange="showavatar();">';
                $query_avatars = new query($SQL, "SELECT name, url, owner FROM ".$prefix."avatar");
                while($query_avatars->getrow()) {
                        $av = $query_avatars->field('url');
                        if (!isset($avatarimg)) { $avatarimg = 'avatars/'.$av; }
                        if ($query_avatars->field('owner') == '') {
                                $avatarselector .= '<option value="'.$av.'">'.$query_avatars->field('name').'</option>';
                        }
                }
                $query_avatars->free();



                $designselector = '<select name="design">';
                $query_designs = new query($SQL, "SELECT title, t, id FROM ".$prefix."designs");
                while ($query_designs->getrow()) {
                        if($query_designs->field('t') == TEMPLATEGROUP) {
                                $designselector .= '<option value="'.$query_designs->field('id').'" selected>'.$query_designs->field('title').'</option>';
                        } else {
                                $designselector .= '<option value="'.$query_designs->field('id').'">'.$query_designs->field('title').'</option>';
                        }
                }
                $query_designs->free();
                $designselector .= '</select>';
                $title = 'Registering new user';
                $tmz = $q_conf->field('defaulttimezone');
                $q_conf->free;
                if ($tmz < 0)
                $tmz = str_replace('-', 'm', $tmz);
                else if ($tmz > 0)
                $tmz = 'p'.$tmz;
                unset ($timezone);
                $timezone[$tmz] = 'selected';

               eval("\$timezoneselector = \"".addslashes($TI[46])."\";");
            eval("\$eula = \"".addslashes($TI[203])."\";");
                eval("\$include = \"".addslashes($TI[15])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);
    }


        // ### Interprete User Information
        elseif ($send) {
                $SI['ref'] = 'Registering a new Account';
                $SI['settings'] = 'vmail, pmail, regtype, regpm, pmauthor';

                define('SCRIPTID','member/register/insert');
                include 'base.php';

                check_perm('member_canregister',0);

                if($regagree != '1') { gen_error('Registration Failed', 'You must agree to the terms and conditions before your registration may be processed!');}

            if(!$year) { $year = '0000';}
        if($year < 1910 && $year != '0000' ) {gen_error('Invalid Year','Please check to ensure that you are entering the year in a four digit format.'); }
        if($year > date("Y")) {gen_error('Invalid Year','You have not even been born yet!'); }
        $birthday = $year.'-'.$month.'-'.$day;
                $username = trim($username);
                $username = stripslashes($username);
        $username = ereg_replace("'","",$username);
                if ($pass == '' || $username == '' || $email == '' || $pass2 == '' || $email2 == '') {
                        gen_error('Please fill in all required fields!','Press back and try again.');
                }

                if ($pass != $pass2) {
                        gen_error('The passwords you entered do not match. Please press back, and try again.');
                }
                if ($email != $email2) {
                        gen_error('The email addresses you entered do not match. Please press back, and try again.');
                }
                $query_checkexists = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$username."' OR username = '".getavatar_undo($username)."'");
                if ($query_checkexists->getrow()) {
                        gen_error('That username already exists!','Go back and try another.');
                }
                $query_checkexists->free();
                $email = trim($email);
                $query_checkexists = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE email = '".$email."'");
                if ($query_checkexists->getrow()) {
                        gen_error('The e-mail address you entered already exists','You may only register once on these forums.');
                }
                $query_checkexists->free();

                if ($timeoffset) {
                        $getoffset[1] = ((substr($timeoffset, 1) * 3600) + 3600);
                        $getoffset[2] = substr($timeoffset, 0,1);
                        $offset = $getoffset[2] . $getoffset[1];
                }

                $type = $config->field('regtype');
                if ($type == 0 || $type == 3) { $activated = 0; } else { $activated = 1; }
                if ($type == 1) { $pass = substr(md5(uniqid(microtime())),0,5); }

                $query_checkdesign = new query($SQL, "SELECT v, t FROM ".$prefix."designs WHERE id = $design");
                $query_checkdesign->getrow();
                $vargroup = $query_checkdesign->field('v');
                $templategroup = $query_checkdesign->field('t');
                $query_checkdesign->free();

                if($homepage && substr($homepage,0,7) != 'http://') { $homepage = 'http://' . $homepage; }

                $query_countmembers = new query($SQL, "SELECT id FROM ".$prefix."profiles ORDER BY id DESC LIMIT 1");
                $query_countmembers ->getrow();
                $totalmembers = $UID = $query_countmembers ->field('id') + 1;

                // Subtract: our Guest Dummy
                $totalmembers--;

                new query($SQL, "UPDATE ".$prefix."configuration SET regmembers = '".$totalmembers."', newestmember = '".$username."', newestmemberid = '".$UID."'");
                $query_countmembers->free();

                new query($SQL, "INSERT into ".$prefix."profiles (id, sig, avatar, msn, username, password, email, homepage, icq, aim, yahoo, location, note, showemail, occupation, homepagedesc, joindate, usergroup, timeoffset, timezone, templategroup, vargroup, invisible, activated, banned, showavatar, showsig, showhistory, pmpopup, birthdate, ip) VALUES ('".$UID."', '" . strip_tags($signature) . "', '" . htmlspecialchars($avatar) . "', '" . strip_tags($wm) . "', '" . htmlspecialchars($username) . "', '" . md5($pass) . "', '" . strip_tags($email) . "', '" . strip_tags($homepage) . "', '" . strip_tags($icq) . "', '" . strip_tags($aim) . "', '" . htmlspecialchars($yahoo) . "', '" . strip_tags($location) . "', '" . strip_tags($personal) . "', '".htmlspecialchars($showmail)."', '".strip_tags($occupation)."', '".strip_tags($homepagedesc)."', '".time()."', '1', '".$offset."', '".$timeoffset."','".$templategroup."','".$vargroup."', '".htmlspecialchars($invisible)."','".$activated."','0', '".$showavatars."', '".htmlspecialchars($showsignature)."', '".htmlspecialchars($showhistory)."', '".htmlspecialchars($pmpopup)."', '".htmlspecialchars($birthday)."', '".$REMOTE_ADDR."')");


                if ($config->field('sendpm') == 1) { send_pm($username, $config->field('pmauthor'), 'Welcome!', $config->field('regpm')); }
                $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
                $query_getadminmail->getrow();
                $admin = $query_getadminmail->field('email');
                $query_getadminmail->free();

                if ($type == 0) {
                        $mailheaders = "From: $admin\n";
                        $subject = 'Activation Mail';
                        $url = $config->field('boardurl') . '/member.php?action=activate&s=' . md5(time()) . '&UID='.$UID;
                        eval("\$message = \"".$config->field('vmail')."\";");
                        mail($email, $subject, $message, $mailheaders);
                        gen_msg('An email has been send with an activation link.','Please wait for further instructions.');
                }

                if ($type == 1) {
                        $mailheaders = "From: $admin\n";
                        $subject = 'Your Password';
                        eval("\$message = \"".$config->field('pmail')."\";");
                        mail($email, $subject, $message, $mailheaders);
                        gen_msg('An email has been sent with your password.','Please wait for further instructions.');
                }

                if ($type == 2) {  gen_redirect('You are now registered, we are returning you to the mainpage.','index.php');  }
        }

        if ($type == 3) {  gen_msg('Registration Successful.','You will receive an e-mail shortly when the forum administrator accepts your registration.');
                }
}


// +-----------------------------------------------------------+
// | Password Reset                                            |
// +-----------------------------------------------------------+

//:: Step 1 - Forgot Password Validation
if($action == 'forgotpasswd') {

        if (!$send) {
                $SI['ref'] = 'Password Reset Procedure';
                $SI['templates'] = '194';

                define('SCRIPTID','member/forgotpasswd/display');
                include 'base.php';

                eval("\$include = \"".addslashes($TI[194])."\";");
                eval("\$output = \"".addslashes($TI[0])."\";");
                lose($output);
        }

        elseif($send) {
                $SI['ref'] = 'Password Reset Procedure';

                define('SCRIPTID','member/forgotpasswd/process');
                include 'base.php';

                if ($username == '') {
                        gen_error('Fill in all fields please!','Required information is missing.');
                }

                if ($act == "") {
                        $query_check_username = new query($SQL, "SELECT email, id, username FROM ".$prefix."profiles WHERE username = '".trim($username)."'");

                        if (!$query_check_username->getrow()) {
                                gen_error('Username ('.$username.') does not exist!','Please check for typing mistakes. To retry click <a href="member.php?action=forgotpasswd">here</a>.');
                        }

                        $id = $query_check_username->field('id');
                        $email = $query_check_username->field('email');
                        $query_check_username->free();

                        $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
                        $query_getadminmail->getrow();
                        $admin = $query_getadminmail->field('email');
                        $query_getadminmail->free();

                        $resetid = crypt(time());
                        $resetid = md5($resetid);

                        new query($SQL, "UPDATE ".$prefix."profiles SET resetid = '".$resetid."' WHERE id = '".$id."'");

                        $url = $config->field('boardurl') . '/member.php?action=passwdsend&resetid='.$resetid.'&id='.$id;
                        $mailheaders = "From: $admin\n";
                        $subject = 'Validation For Password Reset';
                        $message = "A request to generate a new password for " . $config->field('boardurl') . " has been recieved. To validate this request please click on the following link.\n\n" . $url . "\n\n If you did NOT request this please disregard this email and DO NOT click the above link.";
                        mail($email, $subject, $message, $mailheaders);
                        gen_redirect('An email has been sent to validate this request.',$config->field('boardurl').'/');
                }
        }
}

//:: Step 2 - Make Security Checks and Reset Password
if ($action == 'passwdsend') {

        include 'base.php';

        if (!$resetid) {
                gen_error('Sorry, no ResetID Was Specified!','Please make sure it is inserted into the URL.');
        }

        if (!$id) {
                gen_error('Sorry, no UserID Was Specified!','Please make sure it is inserted into the URL.');
        }

        $query_getresetid = new query($SQL, "SELECT resetid FROM ".$prefix."profiles WHERE id = $id ");
        $query_getresetid->getrow();
        $theresetid = $query_getresetid->field('resetid');
        $query_getresetid->free();

        if (!$theresetid) {
                gen_error('Sorry, a ResetID was never filed in the database.','Please make sure you use the password reset form.');
        }

        if($theresetid != $resetid || $resetid != $theresetid) {
                gen_error('Sorry, the ResetID does not match the ResetID in the database.','Please try password reset again.');
        }

        $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
        $query_getadminmail->getrow();
        $admin = $query_getadminmail->field('email');
        $query_getadminmail->free();

        $newpasswd = genpassword(8);


        new query($SQL, "UPDATE ".$prefix."profiles SET password='".md5($newpasswd)."' WHERE id = '".$id."'");

        new query($SQL, "UPDATE ".$prefix."profiles SET resetid = '' WHERE id = '".$id."'");

        $query_user_email = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = '".$id."'");
        $query_user_email->getrow();
        $email = $query_user_email->field('email');
        $query_user_email->free();

        $mailheaders = "From: $admin\n";
        $subject = "New Password For: ".$config->field('boardname');
        $message = "Hello.\n\n Your new password is $newpasswd You can now login again!";
        mail($email, $subject, $message, $mailheaders);

        if ($adminreq == 'true' && ADMIN) {
                gen_redirect('An email has been sent to the user with his/her new password','cp_users.php');
        }

        else {
                gen_redirect('An email has been sent with your new password.',$config->field('boardurl').'/');
        }

}



// ###############################
//              LIST MEMBERS
// ###############################

if ($action == 'list') {

        $SI['ref'] = 'Viewing Member List';
        $SI['settings'] = 'mlistperpage';
        $SI['templates'] = '17|18';
        define('SCRIPTID','member/list');
    include 'base.php';

        check_perm('member_memberlist',0);

        if ($sortorder == '') { $sortorder = 'username'; }
        if ($perpage == '') { $perpage = $config->field('mlistperpage'); }
        if ($reverse == 1) { $orderquery = 'DESC'; } else { $orderquery = 'ASC'; }

        $nav = getnav('memberlist');
        $prequery = 'SELECT p.username, p.email, p.homepage, p.posts, p.id, u.statcolor FROM '.$prefix.'profiles p, '.$prefix.'usergroup u WHERE p.usergroup = u.id AND '.$sortorder.' != \'\' ORDER BY '.$sortorder.' '.$orderquery;

        $query_count = new query($SQL, 'SELECT COUNT(username) AS count FROM '.$prefix.'profiles WHERE \''.$sortorder.'\' != \'\'');
        $query_count->getrow();
        $totalrecords = $query_count->field('count');
        $query_count->free();

        $count = ($totalrecords / $perpage);
        $tmp2 = explode(".", $count);
        $pages = $tmp2[0];
        if (substr($tmp2[1],0,1) > 0) { $pages++; }
        if ($page == '') { $page = 1; }

        if ($page > 1) { $i = $page - 1; $pagelink .= '<a href="member.php?action=list&page='.$i.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&lt;</a> &nbsp;&nbsp; '; $pagelink .= '&nbsp;&nbsp; <a href="member.php?action=list&page=1&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&lt;&lt;</a> &nbsp;&nbsp; '; } else { $pagelink .= '&lt; &nbsp;&nbsp; '; $pagelink .= '&nbsp;&nbsp; &lt;&lt; &nbsp;&nbsp; '; }
        if ($page > 2) { $i = $page - 1; } else { $i = 0; }
        $tmp = 3;

        while ($tmp != 0) {
                $i++;
                $tmp--;
                if ($i <= $pages) {
                        if ($i == $page) { $pagelink .= $i . '  &nbsp; '; } else { $pagelink .= '<a href="member.php?action=list&page='.$i.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">'.$i.'</a> &nbsp; ';}
                }
        }

        $i = $page + 1;

        if ($count > 1 && $page != $pages) { $pagelink .= '&nbsp;&nbsp; <a href="member.php?action=list&page='.$pages.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&gt;&gt;</a> &nbsp;&nbsp; '; } else { $pagelink .= '&nbsp;&nbsp; &gt;&gt; &nbsp;&nbsp; '; }
        if ($count > 1 && $page != $pages && $i <= $pages) { $pagelink .= '&nbsp;&nbsp; <a href="member.php?action=list&page='.$i.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&gt;</a> '; } else { $pagelink .= '&nbsp;&nbsp; &gt; '; }
        $start = (($page - 1)*$perpage);
        $page = $pages;
        if (($page * $perpage) == $count) { $page++; }

        $prequery .= ' LIMIT '.$start.','.$perpage;
        $query_getmembers = new query($SQL, $prequery);
        while ($query_getmembers->getrow()) {
        if($query_getmembers->field('statcolor')) {
                     $user[name] = '<font color="'.$query_getmembers->field('statcolor').'">'.$query_getmembers->field('username').'</font>';
        }
        else {
             $user[name] = $query_getmembers->field('username');
    }
                $user[id] = $query_getmembers->field('id');
                $user[email] = $query_getmembers->field('email');
                $user[homepage] = $query_getmembers->field('homepage');

                if ($user[homepage]) {
                        $user[homepage] = '<a href="'.$user[homepage].'" target="_blank">Homepage</a>';
                }

                if ($user[email]) {
                        $user[email] = '<a href="member.php?action=mail&UID='.$user[id].'">Send E-Mail</a>';
                }

                $user[posts] = $query_getmembers->field('posts');
                $user[joindate] = $query_getmembers->field('joindate');
                $user[joindate] = date("F d, Y",$user[joindate]+($timeoffset*3600));
                eval("\$include .= \"".addslashes($TI['17'])."\";");
        }

        $query_getmembers->free();

        $option_sortorder[$sortorder] = 'selected';
        $option_perpage[$perpage] = 'selected';
        $option_reverse[$reverse] = 'selected';

        $title = 'Viewing Member List';
        eval("\$include = \"".addslashes($TI['18'])."\";");
        eval("\$output = \"".addslashes($TI['0'])."\";");
        lose($output);

}

// ########################
//          Activation Code
// ########################
if ($action == 'activate') {
        require 'base.php';
        $q = new query($SQL, "SELECT activated, joindate FROM ".$prefix."profiles WHERE id = '".$UID."'");
        if (!$q->getrow()) { gen_error('Invalid activation URL!','Check the URL for typing mistakes.'); }
        if (md5($q->field('joindate')) != $s) { gen_error('Invalid activation URL!','Check the URL for typing mistakes.'); }
        if ($q->field('activated') == 1) { gen_error('This account has already been activated!',''); }
        new query($SQL, "UPDATE ".$prefix."profiles SET activated = '1' WHERE id = '".$UID."'");
        gen_redirect('Your account has been activated, you can now login!','member.php?action=login');
}


// ###############################
//             LIST ONLINE MEMBERS
// ###############################

if ($action == 'online') {

        $SI['ref'] = 'Viewing Online Member List';
        $SI['templates'] = '33|34|132';
        define('SCRIPTID','member/online/display');
        include 'base.php';

        check_perm('member_whosonline',0);

        if ($sortorder == '') { $sortorder = 'member'; }
        if ($reverse == 1) { $orderquery = 'DESC'; } else { $orderquery = 'ASC'; }
        if (ADMIN) { $adminquery = ''; } else { $adminquery = 'AND '.$prefix.'active.invisible = \'0\''; }

        $nav = getnav('online');
        $prequery = 'SELECT '.$prefix.'active.member as member, '.$prefix.'active.lastaction as lastaction, '.$prefix.'active.ip as ip, '.$prefix.'active.location as location, '.$prefix.'active.invisible as invisible, '.$prefix.'active.inforum as inforum, '.$prefix.'profiles.id as id FROM '.$prefix.'active, '.$prefix.'profiles WHERE \''.time().'\' - lastaction < 900 '.$adminquery.' AND '.$prefix.'active.member = '.$prefix.'profiles.username ORDER BY '.$sortorder.' '.$orderquery;

        /////////


        $query_forums = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display");
        while ($query_forums->fetch()) {

                $pforums[] = $query_forums->field('forumid');
        }

        $query_ug = new query($SQL, "SELECT thread_canview FROM ".$prefix."usergroup WHERE id=".USERGROUP.' LIMIT 1');
        $query_ug->fetch();
        $defcanview = $query_ug->field('thread_canview');
        $query_ug->free;

        $query_perm = new query($SQL, "SELECT thread_canview, forumid FROM ".$prefix."forum_permissions WHERE uid=".USERGROUP);
        while ($query_perm->getrow()) {
                $afperm[$query_perm->field('forumid')] = $query_perm->field('thread_canview');

        }

        for ($i=0; $i<count($pforums); $i++) {
                if (isset($afperm[$pforums[$i]])) {
                        if ($afperm[$pforums[$i]] == 0) {
                     unset($pforums[$i]);}
                } else {
                        if ($defcanview == 0)
               unset($pforums[$i]);
                }
        }


        $query_getmembers = new query($SQL, $prequery);
        while ($query_getmembers->getrow()) {
                $userid = $query_getmembers->field('id');
                if (ADMIN) {
               $uip = $query_getmembers->field('ip');
                   $ip = "<a href=\"member.php?action=getdns&ip=$uip&uid=$userid\">$uip</a>";
                 } else { $ip = '-------'; }


                $member = $query_getmembers->field('member');
                if($member) {
                        $member = "<a href=\"member.php?action=profile&UID=$userid\">$member</a>";
                }
                else {
                        $member = 'Visitor';
                }
                if ($query_getmembers->field('invisible')) { $invisible = $TI['132']; } else { $invisible = ''; }

                $location = $query_getmembers->field('location');

                if($afperm[$query_getmembers->field('inforum')] == '0') {
                        $location = 'Restricted';
                }

                $lastaction = gmdate($timeformat[1], ($query_getmembers->field('lastaction') + $offset));
                                eval("\$include .= \"".addslashes($TI['34'])."\";");
        }

        $query_getmembers->free();

        $option_sortorder[$sortorder] = 'selected';
        $option_perpage[$perpage] = 'selected';
        $option_reverse[$reverse] = 'selected';

        $title = 'Viewing Member List';
        eval("\$include = \"".addslashes($TI['33'])."\";");
        eval("\$output = \"".addslashes($TI['0'])."\";");
        lose($output);

}
// +-----------------------------------------------------------+
// | View DNS Information                                      |
// +-----------------------------------------------------------+
if($action == 'getdns') {
        $nav = 'View DNS Information';
        $SI['ref'] = 'Viewing DNS Information';
        $SI['templates'] = '200';
        define('SCRIPTID','member/getdns');
        require('base.php');
        check_perm('isadmin',0);

        $query_getdns = new query($SQL, "SELECT username, ip, lastactive FROM ".$prefix."profiles WHERE id = ".$uid."");
        $query_getdns->getrow();
        if($query_getdns->field('username') != '') {
        $userip = $query_getdns->field('ip');
    if(!$userip) { $userip = '0.0.0.0'; }
        $username = $query_getdns->field('username');
        $lastseen = date("F d, Y",$query_getdns->field('lastactive')+($timeoffset*3600));
        $query_getdns->free();
   }

        else {
        $userip = $ip;
        $username = 'Unregistered User';
        $lastseen = 'N/A';
        }

        $hostname = gethostbyaddr($userip);
        if(!$hostname) { $hostname = 'Unresolved'; }

        if($do == 'banip') {
                new query($SQL, "INSERT INTO ".$prefix."ipban (number) VALUES ('".$userip."')");
                gen_redirect('IP Address '.$userip.' has been banned','member.php?action=getdns&uid='.$uid.'&pip='.$pip.'');
        }
        elseif($do == 'banall') {
                new query($SQL, "INSERT INTO ".$prefix."ipban (number) VALUES ('".$userip."')");

                $query_chkguest = new query($SQL, "SELECT username FROM ".$prefix."profiles WHERE id = '".$uid."'");
                        $query_chkguest->getrow();
                        if($query_chkguest->field('username') == '') {
                                gen_error('Illegal Action','You may not ban the guest account!');
                        $query_chkguest->free();
                }
                new query($SQL, "UPDATE ".$prefix."profiles SET banned = '1' WHERE username = '".$username."'");
                gen_redirect('User '.$username.' and IP address '.$userip.' have been banned','member.php?action=getdns&uid='.$uid.'&pip='.$pip.'');
        }
$title = 'View DNS Information';
        eval("\$include = \"".addslashes($TI['200'])."\";");
        eval("\$output = \"".addslashes($TI['0'])."\";");
        lose($output);

}

// +-----------------------------------------------------------+
// | eMail User To User                                        |
// +-----------------------------------------------------------+


if ($action == 'mail') {

        //:: If Ready To Send We Use This Process
        if ($send == 1) {
                //:: Define Basic Info and Check Perms
                $SI['ref'] = 'Sending a topic';
                define('SCRIPTID','member/mail/insert');
                require 'base.php';
                check_perm('member_canmail',0);

                //:: If The User Would Like We Can Display Their eMail vs. The Admins In From
                if($showmine == '1') {
                        $query_getsenderemail = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = '".USERID."' LIMIT 1");
                        $query_getsenderemail->getrow();
                        $sendermail = $query_getsenderemail->field('email');
                        $query_getsenderemail->free();
                }
                //:: If The User Doesn't Want Their eMail Revealed We Use The Admins
                else {
                        $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
                        $query_getadminmail->getrow();
                        $sendermail = $query_getadminmail->field('email');
                        $query_getadminmail->free();
                }

                //:: Get The eMail Address Of Who We Are Sending Too
                $query_getuser = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = '".$UID."' LIMIT 1");
                $query_getuser->getrow();
                $email = $query_getuser->field('email');
                $query_getuser->free();

                //:: Now Lets Send The eMail
                $mailheaders = "From: $sendermail";
                $sender = USERNAME;
                $syssubject = "A message from: $sender - ";
                mail($email, stripslashes($syssubject.$subject), stripslashes($message), $mailheaders);
                gen_redirect('Thank You - The Message Has Been Sent','index.php');

        }
        //:: If Not Ready To Send... Display Form
        else {
                //:: Define Basic Info and Check Perms
                $SI['ref'] = 'Sending an E-Mail';
                $SI['templates'] = '123';
                define('SCRIPTID','member/mail/display');
                include 'base.php';
                check_perm('member_canmail',0);

                //:: If No UserID Specified... We Can't Get A To eMail... So... Request It
                if(!$UID) {
                        gen_error('No UID Specified!','Please make sure it is included in the URL.');
                }
                //:: If Not Logged In Parse An Error
                elseif (!USERNAME) {
                        gen_error('You must be logged in to perform this function.','<a href=member.php?action=login>Click here to login</a>.');
                }
                //:: Otherwise Give Them The Form
                else {
                        $title = 'Send an eMail';
                        eval("\$include = \"".addslashes($TI['123'])."\";");
                        eval("\$output = \"".addslashes($TI['0'])."\";");
                }
                lose($output);
        }
}



?>
