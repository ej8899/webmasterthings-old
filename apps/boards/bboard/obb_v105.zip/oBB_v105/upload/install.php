<?php

/*
+--------------------------------------------------------------------------
|   Open Bulletin Board - Community Forum Software v1.0.*
|   ========================================
|   by 
|   Copyright (C) 2002 The OpenBB Group 
|   http://www.openbb.com
|   ========================================
|   Web: http://www.openbb.com
|   Email: licence@linark.co.uk
+---------------------------------------------------------------------------
|
|   > Installation script
|   > Script written by 
|   > Date started: 
|
| See docs/license.txt for License Information  
+--------------------------------------------------------------------------
*/

/*+----------------------------------------------------------------------------------------------------------------+*/
/*                              NO USER EDITABLE SECTIONS BELOW THIS LINE                                           */
/*+----------------------------------------------------------------------------------------------------------------+*/

$SETUPSCRIPT = 1;

if(file_exists('lib/sqldata.php')) {
	include 'lib/sqldata.php';

	if(isset($database_server['type'])) {
		$type2 = $database_server['type'];
	}
	else {
		$type2 = "";
	}
	
if(isset($database_server['setup_reopenpass'])) {
		$reopenkey_file = $database_server['setup_reopenpass'];
	}
	else {
		$reopenkey_file = "";
	}
}
else {

$type2 = "";
$reopenkey_file = "";

} 

if(!isset($_POST))
{
 extract($HTTP_POST_VARS);
 extract($HTTP_GET_VARS);
 extract($HTTP_COOKIE_VARS);
 extract($HTTP_ENV_VARS);
 extract($HTTP_SERVER_VARS);
}
else{
 extract($_POST);
 extract($_GET);
 extract($_COOKIE);
 extract($_ENV);
 extract($_SERVER);
}

if ($reopenkey_file != "" && md5($rk) != $database_server['setup_reopenpass']) {
	include "./setup/setup_funcs.php";

	print_pageheader('Setup Locked','Setup Locked',"Setup has deteted a reopen key is in place. Please enter this key, or delete sqldata.php.");

	echo <<<TYPE_CHOOSE
				<form action="install.php" method="POST">
				
      <table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
        <tr>
						
          <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Setup 
            Locked </font></td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Setup has been either run before, or someone set a reopen key in sqldata.php. In order to proceed you will need to enter in this password or delete sqldata.php.<br /><br />
							<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76">
								
              <tr bgcolor="#C0CBDB"> 
                <td colspan="2" align="left" valign="middle" class="title"> <font color="#647082">Unlock... 
                  </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#e9e9e9">
										Reopen Key
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="password" name="rk">
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#e9e9e9">
										<input type="submit" value="Continue ->">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				</form>
TYPE_CHOOSE;

	print_pagefooter();
}
else {

if($mode == "" && !$code) { # Added MP 04032003
/*if($mode == 'clean_sql' && $code == '') {*/
	include './setup/setup_funcs.php';

	print_pageheader(1,'OpenBB Installation: Step 1','Welcome to the OpenBB Installation Script. <br> Please enter your database information in to the table below :');
	
	echo <<<TYPE_CHOOSE
				<form action="install.php" action="POST">
				<input type="hidden" name="mode" value="clean_do_sql">
				<input type="hidden" name="code" value="2">
				<input type="hidden" name="rk" value="$rk">
				
<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
    <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
      1: OpenBB Database Information </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please provide all the information on the database where you are installing OpenBB.<br /><br />
							<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76" align="center">
								<tr>
									<td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB">
										<font color="#647082">Database Information</font>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Database Server Software
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<select name="type">
											<option value="mysql" selected>MySQL</option>
											</select>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Host
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="server" size="20" value="localhost">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Username
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="user" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Password
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="password" name="pass" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Database Name
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="db" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Database Prefix (Example: obb_)
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="prefix" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Reopen Key
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="password" name="unlockpass" size="20">
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->">
									</td>
								</tr>
							</table>
						
					
				</table>
				</form>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'clean_do_sql') {
	include './setup/setup_funcs.php';

	print_pageheader(2,'Step 2: Writing SQL Information / Testing Connection','Currently we are writing the SQL information to the file, and testing the database connection.');

	include "lib/database/$type.php";

      if (!$sqlerror = testdbconn($db, $server, $user, $pass)) {
		$conf = '<'.'?'.'php '.'
        	$database_server[\'type\'] = \''.$type.'\';
        	$database_server[\'hostname\'] = \''.$server.'\';
        	$database_server[\'username\'] = \''.$user.'\';
        	$database_server[\'password\'] = \''.$pass.'\';
        	$database_server[\'database\'] = \''.$db.'\';
		    $database_server[\'prefix\'] = \''.$prefix.'\';
        	$database_server[\'setup_$versionsion\'] = \''.OBB_VER.'\';
        	$database_server[\'setup_reopenpass\'] = \''.md5($unlockpass).'\';
            $prefix = $database_server[\'prefix\'];
        	'.'?'.'>';

		$rk = $unlockpass;

        	if (fwriteable('lib/sqldata.php')) {
            	$fp=fopen('lib/sqldata.php','w');
                	fwrite($fp,$conf);
                	fclose($fp);
                	print 'Database connection was successful and information written to the file.<br /><input type="submit" value="Continue ->" onclick="redirect(\'install.php?rk='.$rk.'&mode=clean_dbstruct&prefix='.$prefix.'&type='.$type.'\')">';
		}
		else {
			echo 'There was an error when writing to sqldata.php. Most likely it was not chmoded to 777. Please copy and paste the following code into sqldata.php, overwriting any text already in there.<br /><textarea cols="72" rows="9">'.$conf.'</textarea><br /> After you have
 completed that you may click the \'Continue ->\' button below.<br /><br /><input type="submit" value="Continue ->" onclick="redirect(\'install.php?rk='.$rk.'&mode=clean_dbstruct&type='.$type.'\')">';
		}
	}
	else {
		echo 'An error occured while trying to connect to the DB. ('.$sqlerror.') Please verify your setup configurations by clicking <a href="install.php?rk=$rk&mode=clean_sql"><b>here</b></a>.';
	}

	print_pagefooter();
}

if($mode == 'clean_dbstruct' && !$code) {
	include './setup/setup_funcs.php';
	include "lib/database/$type.php";
	include 'lib/sqldata.php';

	db_connect();

	$DBMS = new db;
    
	print_pageheader(3,'Step 3: Creating Database Structure','We are now creating the database structure.');

      $tables = dbstruct_get_tables($src[pakdbstruct]);

      for ($i=0; $i<count($tables); $i++) {

      	if ($i == 0) {
			$deltables = $prefix.$tables[$i];
	}
		else {
			$deltables .= ', '.$prefix.$tables[$i];
		}
	}
        
    	$sql = "DROP TABLE IF EXISTS $deltables";

	query($sql);

	dbstruct_setup($src[pakdbstruct]);

	echo <<<TYPE_CHOOSE
			<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          3: Database Structure Creation </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we create the database structure.<br /><br />
							<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76">
								<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Database Structure Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Delete Existing Tables
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Setting Up New Tables
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=clean_temps&type=$type&prefix=$prefix')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'clean_temps' && !$code) {
	include './setup/setup_funcs.php';
	include "lib/database/$type.php";
	include 'lib/sqldata.php';

	db_connect();

	$DBMS = new db;

	print_pageheader(4,'Step 4: Populate Database -- Templates','We are now populating the database with template information.');

      $loadtmpls[] = 'all';

	for($i=0; $i<count($loadtmpls); $i++) {
      	
		if ($loadtmpls[$i] == '-' || empty($loadtmpls[$i])) {
            	unset($loadtmpls[$i]);
		}
	}
	
	tmpl_setup($src[paktmplcb], 'OpenBB', 0, 0, $loadtmpls);
	tmpl_setup($src[paktmpla], '', 127);

	echo <<<TYPE_CHOOSE
				<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          4: Populate Database -- Templates </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we import the latest templates.<br /><br />
							<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76">
								<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Template Import Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										All Base Templates Imported
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										All Admin Templates Imported
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=clean_data&type=$type&prefix=$prefix')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'clean_data' && $code == '') {
	include './setup/setup_funcs.php';
    $cpath = substr($_SERVER['SCRIPT_NAME'],0, - 10);
    if($cpath == '') { $cpath = '/';}
    $bpath = $SERVER_NAME.$cpath;   
   	print_pageheader(5,'Step 5: Community / Administrator Information','Please enter your community and administrator account information in below.');

    
	echo <<<TYPE_CHOOSE
								<form action="install.php" action="POST">
				<input type="hidden" name="mode" value="clean_do_data">
				<input type="hidden" name="rk" value="$rk">
				<input type="hidden" name="type" value="$type">
                <input type="hidden" name="prefix" value="$prefix">
				<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          5: Gather Community / Administrator Information </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please provide me information on the your community and administrator.<br /><br />
							<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76" align="center">
								<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Community Information </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>Community Name</b>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="cname">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>URL To Community</b><br />
										<span class="small">Please include the http://</span>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="curl" size="20" value="http://$bpath">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>Cookiepath</b><br />
										<span class="small">If you don't know, please leave as is.</span>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="ccpath" value="$cpath" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>Cookie Domain</b><br />
										<span class="small">If your unsure, leave this blank.</span>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="cdomain" size="20">
									</td>
								</tr>
								<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Administrator Information </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>Username</b>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="auser" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>Password</b>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="password" name="apass" size="20">
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										<b>E-Mail</b>
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="text" name="aemail" size="30">
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				</form>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'clean_do_data' && !$code) {
	include './setup/setup_funcs.php';
	include "lib/database/$type.php";
	include_once 'lib/sqldata.php';

	db_connect();

	print_pageheader(6,'Step 6: Populate Database -- Final Information','We are now populating the database with community, user, and other information.');

      if (empty($cname) || empty($curl) || empty($ccpath) || empty($auser) || empty($apass) || empty($aemail)) {
      	print "Please fill in all fields.<br /><input type=\"submit\" value=\"<- Go Back\" onclick=\"redirect('install.php?rk=$rk&$mode=clean_data&prefix=$prefix')\">";
            print_pagefooter();
		exit;
      }

      query("INSERT INTO ".$prefix."configuration (boardname, cookiepath, boardurl, regmembers, posts, threads, newestmember, mlistperpage, time1, time2, time3, maxmemdate, maxmembers, comnews, redirect, usegzip, gzlevel, regtype, sendpm, pmauthor, regpm, vmail, pmail, templategroup, vargroup, showsig, showavatar, showhistory, parseurl, dsmiley, lastadd, locked, newestmemberid, modimg, lockedreason, redirtype, avsize, avw, avh, totalviews, defaulttimezone, defaulttimeoffset, tlistperpage, plistperpage,lgthsubj,lgthdesc,smilies,censor,actmail,showbdays,maxuploadsize,uploadextensions,rjctmail,cookiedomain)
	VALUES ('".addslashes($cname)."','".$ccpath."','".$curl."', '1', '0', '0', '".addslashes($auser)."', '25', 'F j Y, H:i', 'H:i', 'd-m-y H:i:s', 0, 0, 'We are now running OpenBB 1.0.3!', 1,'0',1,'2','0','".addslashes($auser)."', 'Welcome to my board!',' Hello, to continue the registration process visit: \$url','Hello, your password is \$pass You can now login!',0,0,'1','1','1','1','0','0','0','1','stars4.gif','','0','5000','75','75','0','0','0', '20', '10', '20', '40', '8', 'piss,shit,fuck,asshole,cocksucker,pussy','The forum administrator has approved your request for registration! Please visit \$url to login','1','5000','.bmp,.jpg,.txt,.doc', 'The administrator of: \$url has rejected your application to the community.','".$cdomain."')");
	
	 query("INSERT INTO ".$prefix."smileysets VALUES ('1','Default Smilies')");

      query("INSERT INTO ".$prefix."avatar VALUES (0, 'none', 'blank.gif', '')");

      query("INSERT INTO ".$prefix."cache VALUES ('forums','<option value=\"\"></option><option value=\"1\" \$fs[1]>Category</option><option value=\"2\" \$fs[2]>-- General Chat</option>','')");

      query("INSERT INTO ".$prefix."navigations VALUES ( 'profile', '<a href=\"index.php\">".$cname."</a> > Profiles')");
      query("INSERT INTO ".$prefix."navigations VALUES ( 'memberlist', '<a href=\"index.php\">".$cname."</a> > Memberlist')");
      query("INSERT INTO ".$prefix."navigations VALUES ( 'online', '<a href=\"index.php\">".$cname."</a> > Who is online?')");
      query("INSERT INTO ".$prefix."navigations VALUES ( 'usercp', '<a href=\"index.php\">".$cname."</a> > My Home')");

      $fp3=fopen($src[pakforums],'r');
      $rawforums=fread($fp3,filesize($src[pakforums]));
      fclose($fp3);
      $forums = explode("@18�@", $rawforums);
      $id = 0;
        
	while (list($key,$val) = each($forums)) {
      	$prop = explode("@17�@", $val);
            $id++;
            query("INSERT INTO ".$prefix."forum_display VALUES ( '".$id."', '".$prop[0]."', '".$prop[1]."', '".$prop[2]."', '".$prop[3]."', '".$prop[4]."', '".$prop[5]."', '".$prop[6]."', '".$prop[7]."', '".$prop[8]."', '".$prop[9]."', '".$prop[10]."', '".$prop[11]."', '".$prop[12]."','0',$id,'0')");
            query("INSERT INTO ".$prefix."navigations VALUES ( 'forum:".$id."', '<a href=\"index.php\">".$cname."</a> > ".$prop[14]."')");
      }

	query("INSERT INTO ".$prefix."profiles VALUES ( '1', '".$auser."', '".md5($apass)."', '".$aemail."', '".$curl."', '', '', '', '', '', '0', '3', '', '".time()."', '0', '0', 'blank.gif', 'Admin', 'An OpenBB Powered Site', 'Forum Administrator', '', '0', '0', '0', '0', '0', '1','0','','1','1','1','1','1','','1', '', '', '','1')");
	query("INSERT INTO ".$prefix."profiles VALUES ( '', '', '', '', '', '', '', '', '', '', '', '0', '-5', '0', '0', '0', '', '', '', '', '', '0', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '0', '', '', '','1')");

	
	$fp5=fopen($src['paksmilies'],'r');
	$rawsmilies=fread($fp5,filesize($src['paksmilies']));
	fclose($fp5);
	$smilies = explode("@18�@", $rawsmilies);
	$id = 0;
        
	while (list($key,$val) = each($smilies)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO ".$prefix."smilies VALUES ( '".$id."', '".$prop[0]."', '".$prop[1]."', '1', '1')");
	}

	$fp7=fopen($src['pakusergroups'],'r');
	$rawgroups=fread($fp7,filesize($src['pakusergroups']));
	fclose($fp7);
	$groups = explode("@18�@", $rawgroups);
	$id = 0;
        
	while (list($key,$val) = each($groups)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO ".$prefix."usergroup VALUES ( '".($id - 1)."', '".$prop[0]."', '".$prop[1]."', '".$prop[2]."', '".$prop[3]."', '".$prop[4]."', '".$prop[5]."', '".$prop[6]."', '".$prop[7]."', '".$prop[8]."', '".$prop[9]."', '".$prop[10]."', '".$prop[11]."', '".$prop[12]."', '".$prop[13]."', '".$prop[14]."', '".$prop[15]."', '".$prop[16]."', '".$prop[17]."', '".$prop[18]."', '".$prop[19]."', '".$prop[20]."', '".$prop[21]."', '".$prop[22]."', '".$prop[23]."', '".$prop[24]."', '".$prop[25]."', '".$prop[26]."', '".$prop[27]."', '".$prop[28]."', '".$prop[29]."', '".$prop[30]."', '".$prop[31]."', '".$prop[32]."', '".$prop[33]."', '".$prop[34]."', '".$prop[35]."', '".$prop[36]."', '".$prop[37]."', '".$prop[38]."', '".$prop[39]."', '".$prop[40]."', '".$prop[41]."', '".$prop[42]."', '".$prop[43]."', '".$prop[44]."', '".$prop[45]."')");
        query("UPDATE ".$prefix."usergroup SET statcolor = '#BF031E' WHERE id = '3'");
        query("UPDATE ".$prefix."usergroup SET statcolor = '#6D8FDE' WHERE id = '2'");
	}

	$fp8=fopen($src['paktitles'],'r');
	$rawtitles=fread($fp8,filesize($src['paktitles']));
	fclose($fp8);
	$titles = explode("@18�@", $rawtitles);
	$id = '-1';
        
	while (list($key,$val) = each($titles)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO ".$prefix."usertitles VALUES ('".$id."','".$prop[0]."', '".$prop[1]."', '".$prop[2]."', '".$prop[3]."', '".$prop[4]."')");
	}

	query("INSERT INTO ".$prefix."topicicons VALUES ('0','icon0.gif')");

	echo <<<TYPE_CHOOSE
					<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          6: Populate Database -- Final Information </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we import the latest templates.<br /><br />
							<table width="98%" border="0" cellspacing="1" cellpadding="4" bgcolor="#234D76">
								<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Information Import Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Configuration
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Smilies
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Navigation
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Cache
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Demo Forums / Categories
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Usergroups / Titles
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									
              <td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6"> 
                Administrator Information </td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=clean_final&curl=$curl')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'clean_final' && !$code) {
	include './setup/setup_funcs.php';

	print_pageheader(7,'Step 7: OpenBB Setup Complete','You have now finished the Installation of OpenBB.');

	echo <<<LICENSE_AREA
						<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          7: OpenBB Setup Complete </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Thank you once again for choosing the Open Bulletin Board community software. You may now visit your community.<br />
							<div align="center">
								<input type="submit" value="Goto Community ->" onclick="redirect('$curl')">
							</div>
						</td>
					</tr>
				</table>
LICENSE_AREA;

	print_pagefooter();
}

/*if($mode == 'upg_type' && !$code) {
	include './setup/setup_funcs.php';

	print_pageheader(3,'Step 3: Select Upgrade Type','Please choose the upgrade type.');


	echo <<<TYPE_CHOOSE
						<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          3: Setup Upgrade Type </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please choose if the setup will proceed as an upgrade from <b>1.0.0 or better</b> / <b>RC 2 or better</b> / <b>previous to RC 2</b>.<br /><br />
							<b>1.0.0 or Later:</b> An upgrade from any version 1.0.0 or later.<br />
							<input type="submit" value="1.0.0+" onclick="redirect('install.php?rk=$rk&mode=upg_100')"><br /><br />							
							<b>Release Canidate 2 or Later:</b> An upgrade from any version RC 2 or later.<br />
							<input type="submit" value="RC 2+" onclick="redirect('install.php?rk=$rk&mode=upg_dbstruct&upg_type=rc2')"><br /><br />
							<b>Previous To RC 2:</b> An upgrade from any version previous to RC 2.<br />
							<input type="submit" value="Pre-RC 2" onclick="redirect('install.php?rk=$rk&mode=upg_dbstruct&upg_type=prc2')">
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
}*/

/*if($mode == 'upg_dbstruct' && !$code) {

	switch($upg_type) {
	case 'rc2':

	include './setup/setup_funcs.php';
	include_once 'lib/sqldata.php';
	include "lib/database/$type2.php";
	db_connect();

	print_pageheader(4,'Step 4: Upgrading Database(From RC 2)','We are now upgrading the database from RC 2.');

	dbstruct_setup($src[pakdbstruct]);
    query("UPDATE ".$prefix."usergroup SET statcolor = '#BF031E' WHERE id = '3'");
    query("UPDATE ".$prefix."usergroup SET statcolor = '#6D8FDE' WHERE id = '2'");
    query("UPDATE ".$prefix."configuration SET actmail = 'The forum administrator has approved your request for registration! Please visit \$url to login', rjctmail = 'The administrator of: \$url has rejected your application to the community.', censor = 'fuck,piss,shit,cocksucker,cunt,asshole,dickhead,bitch', maxuploadsize = '5000', uploadextensions = '.bmp,.jpg,.txt,.doc', smilies = '8'");

	echo <<<TYPE_CHOOSE
						<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          4: Upgrading Database</font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we import the latest templates.<br /><br />
							<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Information Import Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Updating Tables
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=upg_temps')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();

	break;
	case 'prc2':

	include './setup/setup_funcs.php';
	include_once 'lib/sqldata.php';
	include "lib/database/$type2.php";
	db_connect();

	print_pageheader(4,'Step 4: Upgrading Database(From Pre-RC 2)','We are now upgrading the database from Pre-RC 2.');

		// get the highest ID
                $result = query('SELECT id FROM posts ORDER BY id DESC LIMIT 1');
                $row = fetch($result);
                $newid = $row['id'] + 1;

                // now search and replace
                $lastid = -1;
                $post_found = 0;
                $result = query('SELECT id, poster FROM posts ORDER BY id ASC');
                while($row = fetch($result)) {
                        if ($lastid == $row['id']) {
                                // needs new ID
                                query("UPDATE posts SET id = $newid WHERE id=$row[id] AND poster='".addslashes($row[poster])."' LIMIT 1");
                                $newid++;
                                $post_found++;
                        }
                        $lastid = $row['id'];
                }


                // get the highest ID
                $result = query('SELECT id FROM topics ORDER BY id DESC LIMIT 1');
                $row = fetch($result);
                $newid = $row['id'] + 1;

                // now search and replace
                $lastid = -1;
                $topic_found = 0;
                $result = query('SELECT id, poster FROM topics ORDER BY id ASC');
                while($row = fetch($result)) {
                        if ($lastid == $row['id']) {
                                // needs new ID
                                query("UPDATE topics SET id = $newid WHERE id=$row[id] AND poster='".addslashes($row[poster])."' LIMIT 1");
                                $newid++;
                                $topic_found++;
                        }
                        $lastid = $row['id'];
                }

                // get the highest ID
                $result = query('SELECT id FROM polls ORDER BY id DESC LIMIT 1');
                $row = fetch($result);
                $newid = $row['id'] + 1;

                // now search and replace
                $lastid = -1;
                $poll_found = 0;
                $result = query('SELECT id, total FROM polls ORDER BY id ASC');
                while($row = fetch($result)) {
                        if ($lastid == $row['id']) {
                                // needs new ID
                                query("UPDATE polls SET id = $newid WHERE id=$row[id] AND total='".addslashes($row[total])."' LIMIT 1");
                                $newid++;
                                $poll_found++;
                        }
                        $lastid = $row['id'];
                }


                dbstruct_setup($src[pakdbstruct]);

                // strip slashes for templates
                        $result = query('SELECT * FROM templates');
                        while($row = fetch($result)) {
                                // brute force deslashing
                                $tmpl = str_replace('\\', '', $row['template']);
                                query("UPDATE templates SET template = '".addslashes($tmpl)."' WHERE id=$row[id] AND groupid=$row[groupid]");
                        }

                        // query("UPDATE templates SET groupid = 127 WHERE id IN (50, 38, 39, 100, 42, 101, 140, 52, 51, 89, 61, 62, 63, 64, 76, 77, 78, 90, 127, 128, 79, 141, 142, 151, 144, 145, 146, 143)");
                        query("DELETE FROM templates WHERE (groupid = 127) OR (id IN (50, 38, 39, 100, 42, 101, 140, 52, 51, 89, 61, 62, 63, 64, 76, 77, 78, 90, 127, 128, 79, 141, 142, 151, 144, 145, 146, 143))");
                        tmpl_setup($src[paktmpla], '', 127);

                        query("DELETE FROM templates WHERE id IN (23, 37, 40, 41, 48, 49, 54, 147, 148, 149)");

                $lastid = -1;
                $lastgid = -1;
                $tmp_found = 0;
                $result = query('SELECT id, template, groupid FROM templates ORDER BY groupid ASC, id ASC');
                while($row = fetch($result)) {
                        if ($lastid == $row['id'] && $lastgid == $row['groupid']) {
                                // needs new ID
                                query("DELETE FROM templates WHERE id=$row[id] AND template='".addslashes($row[template])."' AND groupid=$row[groupid] LIMIT 1");
                                $tmp_found++;
                        }
                        $lastid = $row['id'];
                        $lastgid = $row['groupid'];
                }
	


	echo <<<TYPE_CHOOSE
				<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          4: Upgrading Database </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we import the latest templates.<br /><br />
							<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Information Import Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Search / Fix Duplicate ID's (Posts)
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done ($post_found found)</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Search / Fix Duplicate ID's (Topics)
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done ($topic_found found)</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Search / Fix Duplicate ID's (Polls)
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done ($poll_found found)</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Updating Tables
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Striping Slashes
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Updating Admin Templates
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Removing Obsolete Templates
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Removing Duplicate Templates
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done ($tmp_found found)</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=upg_temps')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
break;
}
}*/

/*if($mode == 'upg_100' && !$code) {
	include './setup/setup_funcs.php';
	include_once 'lib/sqldata.php';
	include "lib/database/".$database_server['type'].".php";
	db_connect();

	$q = query("SELECT template FROM ".$prefix."templates WHERE id = '0' AND groupid = '0'");
	$data = fetch($q);
	$base = stripslashes($data['template']);

	$base1 = str_replace('1.0.0', '$obbver', $base);
	$base2 = str_replace('1.0.1', '$obbver', $base1);
	$base3 = str_replace('Images, Logo\'s and Design are � 2002', '', $base2);
 	$base4 = str_replace('<a href="http://www.impartmedia.com">impart</a>media Studios.', '', $base3);
	$base5 = str_replace('All rights reserved.', '', $base4);

    query("ALTER TABLE ".$prefix."usergroup ADD statcolor VARCHAR(7) NOT NULL");
    query("UPDATE ".$prefix."usergroup SET statcolor = '#BF031E' WHERE id = '3'");
    query("UPDATE ".$prefix."usergroup SET statcolor = '#6D8FDE' WHERE id = '2'");
    
	query("UPDATE ".$prefix."templates SET template = '".addslashes($base5)."' WHERE id = '0' AND groupid = '0'") or die(mysql_error());
    query("DELETE FROM ".$prefix."vars WHERE org = 'admincolor' OR org = 'modcolor'");

	tmpl_setup($src[paktmpla], '', 127);	

	print_pageheader(4,'Step 4: Upgrade Tasks From 1.0.0 Or Later','We are now upgrading your board from 1.0.0 or later.');

	echo <<<TYPE_CHOOSE
				<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          4: Upgrade Tasks From 1.0.0 Or Later </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we upgrade your board.<br /><br />
							<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Upgrade Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Changing Version Number
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Altering Base Template
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Upgrading Admin Templates
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=upg_rk')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
}*/

if($mode == 'upg_temps' && !$code) {
	include './setup/setup_funcs.php';
	include_once 'lib/sqldata.php';
	include "lib/database/$type2.php";
	db_connect();

	print_pageheader(5,'Step 5: Populate Database -- Templates','We are now populating the database with template information.');

      $loadtmpls[] = 'all';

	for($i=0; $i<count($loadtmpls); $i++) {
      	
		if ($loadtmpls[$i] == '-' || empty($loadtmpls[$i])) {
            	unset($loadtmpls[$i]);
		}
	}

	tmpl_setup($src[paktmplcb], 'OpenBB', 0, 0, $loadtmpls);
	tmpl_setup($src[paktmpla], '', 127);

	echo <<<TYPE_CHOOSE
				<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          5: Populate Database -- Templates </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Please wait while we import the latest templates.<br /><br />
							<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
									
              <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                <font color="#647082">Template Import Process </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										All Base Templates Imported
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										All Admin Templates Imported
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<b>Done</b>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->" onclick="redirect('install.php?rk=$rk&mode=upg_rk')">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'upg_rk' && !$code) {
	include './setup/setup_funcs.php';
	include_once 'lib/sqldata.php';
	include "lib/database/$type2.php";
	db_connect();

	print_pageheader(6,'Step 6: Lock Setup','Please choose a password so that the setup script can be locked..');

	echo <<<TYPE_CHOOSE
				<form action="install.php" method="POST">
				<input type="hidden" name="mode" value="upg_do_rk">
				<input type="hidden" name="rk" value="$rk">
				
      <table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
          <td height="23" align="left" valign="middle" bgcolor="#C0CBDB" class="title"> 
            <font color="#647082">Step 6: Lock Setup </font></td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Now we must lock up the setup script.<br /><br />
							<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
									
                <td colspan="2" class="title" align="left" valign="middle" bgcolor="#C0CBDB"> 
                  <font color="#647082">Lock... </font> </td>
								</tr>
								<tr>
									<td  width="50%" align="center" valign="middle" bgcolor="#f6f6f6">
										Choose Reopen Key
									</td>
									<td  width="50%" align="center" valign="middle" bgcolor="#ffffff">
										<input type="password" size="20" name="unlockpass">
									</td>
								</tr>
								<tr>
									<td colspan="2" align="left" valign="middle" bgcolor="#f6f6f6">
										<input type="submit" value="Continue ->">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				</form>
TYPE_CHOOSE;

	print_pagefooter();
}

if($mode == 'upg_do_rk') {
	include './setup/setup_funcs.php';
	include_once 'lib/sqldata.php';

	print_pageheader(7,'Step 7: Writing Setup Lock','Currently we are writing the setup lock so that setup can not be run again without the password.');

	include "lib/database/$type2.php";

	$conf = '<'.'?'.'php '.'
      $database_server[\'type\'] = \''.$database_server['type'].'\';
      $database_server[\'hostname\'] = \''.$database_server['hostname'].'\';
      $database_server[\'username\'] = \''.$database_server['username'].'\';
      $database_server[\'password\'] = \''.$database_server['password'].'\';
      $database_server[\'database\'] = \''.$database_server['database'].'\';
	$database_server[\'prefix\'] = \''.$database_server['prefix'].'\';
      $database_server[\'setup_$versionsion\'] = \''.OBB_VER.'\';
      $database_server[\'setup_reopenpass\'] = \''.md5($unlockpass).'\';
      $prefix = $database_server[\'prefix\'];
      '.'?'.'>';

	$rk = $unlockpass;

        	if (fwriteable('lib/sqldata.php')) {
            	$fp=fopen('lib/sqldata.php','w');
                	fwrite($fp,$conf);
                	fclose($fp);
                	print 'sqldata.php is now up to date.<br /><input type="submit" value="Continue ->" onclick="redirect(\'install.php?rk='.$rk.'&mode=upg_final\')">';
		}
		else {
			echo 'There was an error when writing to sqldata.php. Most likely it was not chmoded to 777. Please copy and paste the following code into sqldata.php, overwriting any text already in there.<br /><textarea cols="72" rows="9">'.$conf.'</textarea><br /> After you have
 completed that you may click the \'Continue ->\' button below.<br /><br /><input type="submit" value="Continue ->" onclick="redirect(\'install.php?rk='.$rk.'&mode=upg_final\')">';
		}


	print_pagefooter();
}

/*if($mode == 'upg_final' && !$code) {
	include './setup/setup_funcs.php';
	include 'base.php';

	print_pageheader(5,'Step 5: OpenBB Upgrade Complete','You have now finished the upgrade wizard.');

	$curl = $config->field('boardurl');

	echo <<<LICENSE_AREA
										
<table width="98%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#234D76">
<tr>
						
        <td class="title" align="left" valign="middle" bgcolor="#C0CBDB"> <font color="#647082">Step 
          5: OpenBB Upgrade Complete </font> </td>
					</tr>
					<tr>
						<td align="left" valign="middle" bgcolor="#ffffff">
							Thank you once again for choosing the Open Bulletin Board community software. You may now visit your community.<br />
							<div align="center">
								<input type="submit" value="Goto Community ->" onclick="redirect('$curl')">
							</div>
						</td>
					</tr>
				</table>
LICENSE_AREA;

	print_pagefooter();
}*/



}



?>
