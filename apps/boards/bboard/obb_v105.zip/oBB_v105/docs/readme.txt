---------------------------------------
Open Bulletin Board - 1.0.4
---------------------------------------
---------------------------------------
Installation Instructions
---------------------------------------

* Clean Install *
- Upload/Extract all files to the chosen directory on your webhosting space
- Rename lib/sqldata.php.dist to lib/sqldata.php (Important: CHMOD 666 or 777 lib/sqldata.php)
- CHMOD 666 or 777 the following directories: avatars/, images/themes/openbb/*, images/openbb
- From your web browser, run setup.php
- Follow the instructions given by the setup wizard

* Upgrade From Previous Release *
- Upload/Extract all files to the chosen directory on your webhosting space, making sure to overwrite ALL base files
- Ensure that the following directories are CHMOD 666 or 777: avatars/, images/themes/openbb/*, images/openbb
- From your web browser, run setup.php (Note: You will be asked to enter an "unlock" password. If you do not remember this password,
  simply edit lib/sqldata.php and remove the setup reopen pass line)
- Follow the instructions given by the setup wizard


---------------------------------------
New In 1.0.4 / 1.0.0 Series
---------------------------------------

1.0.0 Series
---------------
- Templates are now W3C strict compliant
- More bug and browser incompatibility fixes
- Completed and working version of active topics
- User option to enable or disable censored words
- The ability to drop a user group from the Admin CP
- A "Team support" page for and listing of your moderators and administrators

1.0.2 Build
---------------
- We are now register_globals Off compliant :D
- Custom usergroup coloring in who's online
- Custom usergroup coloring in members list
- Deleting template sets now removes vars
- Some template fixes
- And more!

1.0.3 Build
---------------
- We really *are* register_globals Off compliant ;)
- We are error_reporting(E_ALL) compliant
- MSIE Template bug fixed
- Avatar security bug stomped
- Plenty of BBcode security bugs stomped
- Posts no longer disappear if posted by a user called Guest
- Other stuff I can't remember

1.0.4 Build
---------------
- Various problems with various packages of 1.0.3 fixed (bbcode parsing, corrupt files, errors when quoting etc.)
- You can now post without uploading an attachment in Konqueror!
- Decent error message if tmp directory is not CHMOD 777 (no asdf-of-death)
- Uhm... changelog updated :D

---------------------------------------
Credits
---------------------------------------

A very special thanks goes out to Lindy Throgmartin (Ace)
For all of his work and sleepless nights he put into this project.
Without him OpenBB would have never have gotten as far as it did.
Another special thank you goes out to Lino (Takerfan) for teaching Lindy the basics of PHP and helping him along our journey.
Lastly we would like to thank YOU!
Thank you for your on going support, patience and help.




All files are Copyright � 2003 The OpenBB Group
                 http://www.openBB.com/

See docs/license.html for license information.
