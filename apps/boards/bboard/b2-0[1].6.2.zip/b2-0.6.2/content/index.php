<? header("Location: ../index.php"); ?>
