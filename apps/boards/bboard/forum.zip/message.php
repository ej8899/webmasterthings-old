<?
$ok = 0;
if($HTTP_POST_VARS["submit"]) {
	require("conf.php");
	$ok = 1;
	if(empty($onderwerp))
		$err[] = "You've forgotten your subject!";

	if(empty($naam))
		$err[] = "You've forgotten your name!";

	if(empty($bericht))
		$err[] = "You've forgotten your message!";
	
	for($i=0;$i<sizeof($bad_words);$i++)
		if(ereg($bad_words[$i], $naam) || ereg($bad_words[$i], $onderwerp) || ereg($bad_words[$i], $bericht))
			$err[] = "We like to keep our forum desent. Please use some normal language!";

	if(sizeof($err) > 0) {
		?>
<html>

<head>
<title>Forum</title>
<link rel="stylesheet" type="text/css" href="./stylez.css">
</head>

<body>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr><td class="MainTD">
<table width="100%" border=0 cellspacing=1 cellpadding=3>
  <tr>
    <td class="HeaderText">The message:</td>
  </tr>
  <tr>
   <td valign="top" align="left" class="NormalText">
     <form method="POST" action="<?=$PHP_SELF?>">
     <input type="hidden" name="onderwerp" value="<?=$onderwerp?>">
     <input type="hidden" name="naam" value="<?=$naam?>">
     <input type="hidden" name="bericht" value="<?=$bericht?>">
     <input type="hidden" name="reply" value="<?=$reply?>">
     Error,<br><br>
     Something went wrong. Please take attention to the errors below.<br><br>
		<?
		for($i=0;$i<=sizeof($err);$i++)
			echo "\n\t<font class=\"Error\">".$err[$i]."</font><br>";
		?>
     <input type="submit" value="Back">
     </form>
   </td>
  </tr>
 </table>
</td></tr>
</table>
</body>
</html>
		<?
	} else {

		mysql_connect($host,$user,$pass);
		mysql_select_db($db);

		$date=(date("d-m-Y"));
		$time=(date("H:i:d")); 
		$op = $date." ".$time;

		$sql = "INSERT INTO forum (id, onderwerp, naam, bericht, optijd, op, replyop) VALUES ('', '$onderwerp', '$naam', '$bericht', '".time()."', '".$op."', '".$reply."')";
		mysql_query($sql) or die("<h1>Something went wrong</h1><hr>".mysql_error());

		if($reply <> 0) {
			$sql = "UPDATE forum SET replys = replys+1 WHERE id = '$reply'";
			mysql_query($sql) or die("<h1>Something went wrong</h1><hr>".mysql_error());
		}

		if($reply == 0)
			header("Location: ./index.php"); 
		else
			header("Location: ./read.php?id=$reply");
	}
} else {
	if(!isset($reply))
		$reply = 0;
	?>
<html>

<head>
<title>Forum</title>
<link rel="stylesheet" type="text/css" href="./stylez.css">
<script language="JavaScript">
<!--
function SubmitOnce(theform) {
	// if IE 4+ or NS 6+
	if (document.all || document.getElementById) {
		// hunt down "submit" and "reset"
		for (i=0;i<theform.length;i++) {
			var tempobj=theform.elements[i];
			if(tempobj.type.toLowerCase()=="submit"||tempobj.type.toLowerCase()=="reset") {
				//disable it
				tempobj.disabled=true;
			}
		}
	}
}
//-->
</script>
</head>

<body>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr><td class="MainTD">
<table width="100%" border=0 cellspacing=1 cellpadding=3>
  <tr>
    <td class="HeaderText">The message:</td>
  </tr>
  <tr>
   <td valign="top" align="left" class="NormalText">
     <form name="postform" onsubmit="SubmitOnce(this);" method="POST" action="<?=$PHP_SELF?>">
       What's your name:<br>
       <input type="text" name="naam" value="<?=$naam?>"><br>
       What's the subject:<br>
       <input type="text" name="onderwerp" value="<?=$onderwerp?>"><br>
       What's your message:<br>
       <textarea name="bericht" rows="8" cols="40"><?=$bericht?></textarea><br>
       <input type="hidden" name="reply" value="<?=$reply?>">
       <input type="hidden" name="submit" value="true">
       <input type="submit" value="Submit">
       <input type="reset" value="Reset">
     </form>
<?
}
?>
   </td>
  </tr>
 </table>
</td></tr>
</table>
</body>
</html>