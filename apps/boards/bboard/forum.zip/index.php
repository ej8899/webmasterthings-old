<?
require("./conf.php");
include("./functions.php");

mysql_connect($host,$user,$pass);
mysql_select_db($db);

if (!isset($page))
	$page = 0;

$aantal_per_page = $messages_per_page;

$x = $page * $aantal_per_page;

$sql = "SELECT * FROM forum WHERE replyop = 0 ORDER BY optijd DESC LIMIT $x, $aantal_per_page";
$res = mysql_query($sql) or die(mysql_error());

$que1 = "SELECT * FROM forum WHERE replyop = 0";
$out1 = mysql_query($que1) or die(mysql_error());

$num = mysql_num_rows($out1);
?>
<html>

<head>
<title>Forum</title>
<link rel="stylesheet" type="text/css" href="./stylez.css">
</head>

<body>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr>
	<td height="20" align="right">
		<a href="message.php">Add a message</a> | 
<? 
if ($page > 0) {
	echo "<a href=\"./index.php?page=" . ($page - 1) . "\">Next $aantal_per_page messages</a> | ";
}
else {
	echo "Next $aantal_per_page messages | ";
}
$bla = 10 + 10 * $page;
if ($num > $bla) {
	echo "<a href=\"./index.php?page=" . ($page + 1) . "\">Past $aantal_per_page messages</a>";
}
else {
	echo "Past $aantal_per_page messages";
}
?>
</td>
</tr>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=1>
<tr><td class="MainTD">
<table width="100%" border=0 cellspacing=0 cellpadding=3>
<tr>
	<td height="20" class="HeaderText">Subject:</td>
	<td height="20" class="HeaderText">By:</td>
	<td height="20" class="HeaderText">Reply's:</td>
</tr>
<?
while($row = mysql_fetch_object($res)){
?>
<tr>
	<td width="65%" height="20" nowrap><a href="./read.php?id=<?=$row->id?>"> <?=(strlen($row->onderwerp) > $max_length) ? substr(htmlspecialchars($row->onderwerp),0,$max_length)."..." : htmlspecialchars($row->onderwerp)?></td>
	<td width="30%" height="20" nowrap><?=(strlen($row->naam) > $max_length) ? substr(htmlspecialchars($row->naam),0,$max_length)."..." : htmlspecialchars($row->naam)?></td>
	<td height="20" nowrap><?=$row->replys?></td>
</tr>
<?
}
?>
</table>
</td>
</tr>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr>
	<td height="20" align="right">
		<a href="./message.php">Add a message</a> | &copy; <a href="http://www.monstar.nl" target="_blank">Monstar.nl</a>
	</td>
</tr>
</table>
</body>
</html>