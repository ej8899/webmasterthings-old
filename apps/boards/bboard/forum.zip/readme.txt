Hello,

A couple of days ago I was borred so I wrote my self a forum...

This forum is totaly crap... a least I think... For the begginner is 
it a good way to start php+mysql...

To install:
- Modify conf.php to your needs
- Upload everything
- Run forum.sql in PhpMyAdmin or trough the command line or something
- Open your browser and go to the dir. where the script is located...
- ready...

Everything under this line may not be removed
--------------------------------------------------
Original downloaded from http://www.monstar.nl

If you want to put this project on your website so
other people can download it you first have to
inform me about it.

For non-commercial use only. If you want to use
this project in a commercial project please contact 
a.bontjer@x-interactive.nl