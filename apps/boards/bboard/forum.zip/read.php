<?
if(isset($id)){
?>
<html>

<head>
<title>Forum</title>
<link rel="stylesheet" type="text/css" href="./stylez.css">
</head>

<body>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr><td class="MainTD">
<table width="100%" border=0 cellspacing=1 cellpadding=3>
  <tr>
    <td class="HeaderText">The message:</td>
  </tr>
<?
	require("conf.php");
	include("functions.php");
	$server = mysql_connect($host,$user,$pass);
	mysql_select_db($db,$server);
	$sql = "SELECT * FROM forum WHERE id = $id ORDER BY optijd DESC";
	$res = mysql_query($sql);	
	$row = mysql_fetch_array($res);
	echo "<tr  bgcolor=\"FFFFFF\">\n";
	echo "<td valign=top align=left class=\"NormalText\">\n";
	echo "<b>Subject:</b> ".htmlspecialchars($row["onderwerp"])."<br>\n"; 
	echo "<b>By:</b> ".htmlspecialchars($row["naam"])."<br>\n";
	echo "<b>Written on:</b> ".$row["op"]."<br>\n";
	echo "<b>Message:</b><br>".MaakOp($row["bericht"])."</td>\n";
	echo "</tr>\n";
?>
</table>
</td></tr>
</table><br>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr><td class="MainTD">
<table width="100%" border=0 cellspacing=1 cellpadding=3>
  <tr>
    <td class="HeaderText">Reply's</td>
  </tr>
<?
	$ond = $row["onderwerp"];    
	$sql = "SELECT * FROM forum WHERE replyop = $id ORDER BY optijd DESC";
	$res = mysql_query($sql);
	if(mysql_num_rows($res) == 0){
		echo "<tr  bgcolor=\"FFFFFF\">\n";
		echo "<td valign=top align=left class=\"NormalText\">\n";
		echo "No reply's\n"; 
		echo "</tr>\n";
	} else {
		while($row = mysql_fetch_object($res)){
			echo "<tr  bgcolor=\"FFFFFF\">\n";
			echo "<td valign=top align=left class=\"NormalText\">\n";
			echo "<b>Subject:</b> ".htmlspecialchars($row->onderwerp)."<br>\n"; 
			echo "<b>By:</b> ".htmlspecialchars($row->naam)."<br>\n";
			echo "<b>Written on:</b> $row->op<br>\n";
			echo "<b>Message:</b><br> ".MaakOp($row->bericht)."</td>\n";
			echo "</tr>\n";
		}
	}
?>
</table>
</td></tr>
</table>
<table width="580" border=0 cellspacing=0 cellpadding=0>
<tr>
	<td height="20" align="right">
		<a href="./index.php">Back to the index</a> | <a href="./message.php?reply=<?=$id?>">Reply on this message</a> | &copy; <a href="http://www.monstar.nl" target="_blank">Monstar.nl</a>
	</td>
</tr>
</table>
<?
}
else {
	header("Location: ./index.php");
}
?>
</body>
</html>