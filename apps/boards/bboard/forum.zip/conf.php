<?
// Where is your MySQL server located? (localhost is most common)
$host = "localhost";
// The user name to access the database
$user = "root";
// If needed, fill in the password
$pass = "";
// Name of the database
$db = "Easy_Forum";
// Number of messages per page
$messages_per_page = 20;
// Number of characters after the subject or name needs to be cut off
// in the index
$max_length = 40;
// Users may use html? (true/false)
$html=true;
// Here you can add some 'bad' words
$bad_words = array("fuck","cunt","dick","motherfucker","asshole");
?>