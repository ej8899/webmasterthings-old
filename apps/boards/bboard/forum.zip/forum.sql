CREATE TABLE forum (
   id mediumint(9) NOT NULL auto_increment,
   onderwerp varchar(100) NOT NULL,
   naam varchar(100) NOT NULL,
   bericht text NOT NULL,
   optijd int(11) DEFAULT '0' NOT NULL,
   op varchar(12) NOT NULL,
   replyop mediumint(9) DEFAULT '0' NOT NULL,
   replys int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   UNIQUE id (id)
);
