<?php
/*****************************************************************************/
/* Install.php                                                               */
/*****************************************************************************/
/* YaBB: Yet another Bulletin Board                                          */
/* Open-Source Project started by Zef Hemel (zef@zefnet.com)                 */
/* Software Version: YaBB SE                                                 */
/* ========================================================================= */
/* Software Distributed by:    http://www.yabbse.org                         */
/* Support, News, Updates at:  http://www.yabbse.org/community               */
/*                             http://www.yabbforum.com/community            */
/* ========================================================================= */
/* Copyright (c) 2001-2002 The YaBB SE Development Team                      */
/* Software by: The YaBB SE Development Team                                 */
/*****************************************************************************/
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General */
/* Public License for more details.                                          */
/*                                                                           */
/* The GNU GPL can be found in gpl.txt in this directory                     */
/*****************************************************************************/

define('YSE_VERSION', 'yse153');
define('YSE_PHP_VERSION', '4.1.0');
define('YSE_MYSQL_VERSION', '3.22.0');

error_reporting(E_ALL);

if (!isset($HTTP_GET_VARS['step']))
	$step = 0;
else
	$step = (int) $HTTP_GET_VARS['step'];

$self = &$HTTP_SERVER_VARS['PHP_SELF'];

$mydir = substr(__FILE__, 0, strrpos(__FILE__, (strpos(__FILE__, '/') === false ? '\\' : '/')));
$mydir = str_replace('//', '/', $mydir);
$mydir = str_replace('\\', '/', $mydir);

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title>YaBB SE Installer</title>
	<style>
	<!--
		body {
			font-family: Verdana;
			font-size: 10pt;
		}
		td {
			font-size: 10pt;
		}
	-->
	</style>
	</head>
	<body bgcolor="#FFFFFF">
		<center><table border="0" cellspacing="1" cellpadding="4" bgcolor="#000000" width="90%">
			<tr>
				<th bgcolor="#34699E"><font color="#FFFFFF">YaBB SE Installer</font></th>
			</tr>
			<tr>
				<td bgcolor="#f0f0f0" align="left">';

$func = 'doStep' . $step;
if (function_exists($func))
	$func();

echo '
				</td>
			</tr>
		</table></center>
	</body>
</html>';

// Step zero: Finding out how and where to install.
function doStep0()
{
	global $self, $mydir, $HTTP_GET_VARS, $HTTP_POST_VARS;

	// Check the PHP version.
	if (!php_version_check(YSE_PHP_VERSION) && !isset($HTTP_GET_VARS['overphp']))
	{
		echo '
	<font color="red">
		<br />
		Warning!  You do not appear to have a version of PHP installed on your webserver that meets YaBB SE' . "'" . 's minimum installations requirements.<br />
		<br />
		If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.<br />
	</font><br />
	<a href="' . $self . '?step=0&overphp=true">Click here</a> to try anyway, noting that this is <i>strongly</i> discouraged.<br />
	<br />';
		return false;
	}

	// They want to extract the ya file.
	if (file_exists($mydir . '/' . YSE_VERSION . '.ya'))
	{
		// However, they are in safe mode... tsk, tsk, tsk.
		if (ini_get('safe_mode') && !isset($HTTP_GET_VARS['override']))
			echo '
	<font color="red">
		<br />
		Warning! It appears that safe mode is enabled.<br />
		<br />
		Your PHP seems to be in safe mode.  Please delete ' . YSE_VERSION . '.ya, and then upload all the files from the safe mode package.<br />
		<br />
		If you know for a fact that safe mode is NOT enabled you may continue, although this is strongly discouraged.<br />
	</font><br />
	<a href="' . $self . '?step=0&override=true">Click here</a> to try anyway, noting that this is <i>strongly</i> discouraged.<br />
	<br />';
		// Alright, that's a go for getting the installation directory.
		else
			echo '
	This program will install YaBB SE on your webserver.<br />
	<form action="' . $self . '?step=1" method="post">
		<table border="0" cellspacing="0" cellpadding="3">
			<tr>
				<td valign="top"><b>Install to directory:</b></td>
				<td><input type="text" name="installdir" id="installdir" value="' . $mydir . '" size="65" /><br />
				<font size="1">Please create this directory first, then chmod it to 777!</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Overwrite newer files:</b></td>
				<td><input type="checkbox" name="overwrite" id="overwrite" value="1" /></td>
			</tr>
		</table>
		<center>
			<input type="submit" value="Start installation &gt;" />
		</center>
	</form>';
	}
	// Looks like the didn't upload the .ya file...?
	else
	{
		// Make sure they uploaded all the files.
		$ftest = @file_exists($mydir . '/index.php')
			&& @file_exists($mydir . '/' . YSE_VERSION . '.sql');
		if (!$ftest)
		{
			echo '
	<font color="red">
		<br />
		Unable to find crucial installation files in this script' . "'" . 's directory.<br />
		<br />
		Please make sure you uploaded the entire package, and then try again.<br />
	</font>';
			return false;
		}
		// Let's move on to step 2 now.
		$HTTP_POST_VARS['installdir'] = $mydir;
		doStep2();
	}

	return true;
}

// Step one: Extracting the ya file. (not in safe mode!)
function doStep1()
{
	global $self, $mydir, $HTTP_POST_VARS, $HTTP_GET_VARS;

	$HTTP_POST_VARS['overwrite'] = isset($HTTP_POST_VARS['overwrite']) ? $HTTP_POST_VARS['overwrite'] : 0;
	$HTTP_POST_VARS['installdir'] = str_replace('\\\\', '/', $HTTP_POST_VARS['installdir']);
	$HTTP_POST_VARS['installdir'] = str_replace('//', '/', $HTTP_POST_VARS['installdir']);
	$HTTP_POST_VARS['installdir'] = str_replace('\\', '/', $HTTP_POST_VARS['installdir']);

	// Check if it actually exists.
	if (!is_dir($HTTP_POST_VARS['installdir']) && !isset($HTTP_GET_VARS['override']))
	{
		echo '
	<font color="red">
		<br />
		The directory you entered was reported as NOT being a directory.<br />
		Please check the path!<br />
	</font><br />
	<form action="' . $self . '?step=1&override=true" method="post">
		<input type="hidden" name="installdir" id="installdir" value="' . $HTTP_POST_VARS['installdir'] . '" />
		<input type="hidden" name="overwrite" id="overwrite" value="' . $HTTP_POST_VARS['overwrite'] . '" />
		<center>
			<input type="submit" value="Proceed Anyway &gt;">
		<center>
	</form>';
		return false;
	}

	// It's time to extract the files.
	echo '
		Starting installation of files, please wait...<br />';
	$ya = fopen(YSE_VERSION . '.ya', 'rb');
	while (!feof($ya))
	{
		$data = explode('|^|', chop(fgets($ya, 4086)));
		if (!isset($data[1]))
			$data[1] = '';
		$filename = $HTTP_POST_VARS['installdir'] . '/' . $data[1];

		if ($data[0] == 'dir' && !file_exists($filename) && $data[1] != '.')
		{
			mkdir($filename, 0777);
			chmod($filename, 0777);
		}
		elseif($data[0] == 'file')
		{
			if (file_exists($filename) && filemtime($filename) >= $data[3] && !$HTTP_POST_VARS['overwrite'])
			{
				$buffer = fread($ya, $data[2]);
				echo '
		Skipping <i>' . $filename . '</i>, because it' . "'" . 's newer or of the same age.<br />';
			}
			else
			{
				if (in_array(substr($filename, -4), array('.php', '.lng', '.txt')))
					$fp = fopen($filename, 'w');
				else
					$fp = fopen($filename, 'wb');
				fputs($fp, fread($ya, $data[2]), $data[2]);
				fclose($fp);

				chmod($filename, 0666);
				touch($filename, $data[3]);
				echo '
		Wrote <i>' . $filename . '</i> successfully.<br />';
			}
		}
	}
	fclose($ya);

	// Change the permissions on some inportant files.
	@chmod($HTTP_POST_VARS['installdir'] . '/yabbinfo.xml', 0777);
	@chmod($HTTP_POST_VARS['installdir'] . '/Settings_bak.php', 0777);
	@chmod($HTTP_POST_VARS['installdir'] . '/Packages/installed.list', 0777);
	@chmod($HTTP_POST_VARS['installdir'] . '/Packages/server.list', 0777);

	echo '
	<form action="' . $self . '?step=2" method="post">
		<input type="hidden" name="installdir" id="installdir" value="' . $HTTP_POST_VARS['installdir'] . '" />
		<input type="submit" value="Proceed &gt;" />
	</form>';

	return true;
}

function doStep2()
{
	global $self, $HTTP_POST_VARS;

	// Set up the defaults.
	$db_server = @ini_get('mysql.default_host') or $db_server = 'localhost';
	$db_user = @ini_get('mysql.default_user');
	$db_passwd = @ini_get('mysql.default_password');

	// Should we use a non standard port?
	$db_port = @ini_get('mysql.default_port');
	if (!empty($db_port))
		$db_server .= ':' . $db_port;

	echo '
	There are just a few settings to set up... (:/)
	<form action="' . $self . '?step=3" method="post">
		<table border="0" cellspacing="0" cellpadding="3">
			<tr>
				<td valign="top"><b>MySQL server name:</b></td>
				<td>
					<input type="text" name="db_server" id="db_server" value="' . $db_server . '" /><br />
					<font size="1">
						This is nearly always localhost, so if you don' . "'" . 't know use localhost.<br />
					</font>
				</td>
			</tr>
			<tr>
				<td valign="top"><b>MySQL username:</b></td>
				<td>
					<input type="text" name="db_user" id="db_user" value="' . $db_user . '" /><br />
					<font size="1">
						Fill in the username you need to connect to your MySQL database, if you don' . "'" . 't know, try the username of your ftp account, most of the times those two are equal.<br />
					</font>
				</td>
			</tr>
			<tr>
				<td valign="top"><b>MySQL password:</b></td>
				<td>
					<input type="password" name="db_passwd" id="db_passwd" value="' . $db_passwd . '" /><br />
					<font size="1">
						Fill in the password you need to connect to your MySQL database, if you don' . "'" . 't know, try the password of your ftp account, most of the times they' . "'" . 're the same.<br />
					</font>
				</td>
			</tr>
				<tr>
				<td valign="top"><b>MySQL Database name:</b></td>
				<td>
					<input type="text" name="db_name" value="' . (empty($db_user) ? 'yabbse' : $db_user) . '" /><br />
					<font size="1">
						Fill in the name of the database you want to use to let YaBB SE store it' . "'" . 's data in, <b>make sure it is empty or at least doesn' . "'" . 't contain important info using the prefix below, it is very likely that it will be destroyed!<br />
						If this database does not exist, we will try to create it.</b>
					</font>
				</td>
			</tr>
				<tr>
				<td valign="top"><b>MySQL Database prefix:</b></td>
				<td>
					<input type="text" name="db_prefix" value="yabbse_" /><br />
					<font size="1">
						Fill in the prefix you would like to use on all your table names.  You may leave this blank.  This value will be prepended to all table names to allow for multiple YaBB SE installations in a single database.
					</font>
				</td>
			</tr>
		</table>
		<center>
			<input type="hidden" name="installdir" id="installdir" value="' . $HTTP_POST_VARS['installdir'] . '" />
			<input type="submit" value="Proceed &gt;" /> (Only proceed if successful!)
		</center>
	</form>';

	return true;
}

// Step three: Do the SQL thang.
function doStep3()
{
	global $self, $HTTP_POST_VARS;

	$db_vars = array('name', 'user', 'passwd', 'server', 'prefix');

	// Set the variables up so I can type a *little* less.
	foreach ($db_vars as $db_var)
		${'db_' . $db_var} = isset($HTTP_POST_VARS['db_' . $db_var]) ? $HTTP_POST_VARS['db_' . $db_var] : '';

	// Modify Settings.php
	$settingsArray = file($HTTP_POST_VARS['installdir'] . '/Settings.php');
	for ($i = 0; $i < count($settingsArray); $i++)
	{
		$settingsArray[$i] = trim($settingsArray[$i]);
		if (strncasecmp($settingsArray[$i], '$db_', 4) == 0)
		{
			foreach ($db_vars as $db_var)
				if (strncasecmp($settingsArray[$i], '$db_' . $db_var, 4 + strlen($db_var)) == 0)
					$settingsArray[$i] = '$db_' . $db_var . ' = "' . addslashes(${'db_' . $db_var}) . '";';
		}
	}
	$fp = fopen($HTTP_POST_VARS['installdir'] . '/Settings.php', 'w');
	foreach($settingsArray as $line)
		fputs($fp, $line . "\n");

	// Attempt a connection.
	$linkid = mysql_connect($db_server, $db_user, $db_passwd);
	if(!$linkid)
	{
		echo '
	<font color="red">
		<br />
		Cannot connect to database server with given data!<br />
		<br />
		Please check the information you provided, and then try again.<br />
		<br />
	</font><br />';
		return false;
	}

	// Do they meet the install requirements?
	if (!mysql_version_check(YSE_MYSQL_VERSION))
	{
		echo '
	<font color="red">
		<br />
		Your MySQL Version does not meet the minimum requirements of YaBB SE.<br />
		<br />
		Please ask your host to upgrade.<br />
		<br />
	</font><br />';
		return false;
	}

	// Let's try that database on for size...
	mysql_query("
		CREATE DATABASE IF NOT EXISTS $db_name");
	if (!mysql_select_db($db_name, $linkid))
	{
		echo '
	<font color="red">
		<br />
		Unable to use the provided database, ' . $db_name . '!<br />
		<br />
		Please double check this information, and try again.  Remember, some hosts add a prefix to your database name.<br />
		<br />
	</font><br />';
		return false;
	}

	// Read in the SQL.
	$sql_lines = file($HTTP_POST_VARS['installdir'] . '/' . YSE_VERSION . '.sql', 'r');
	$sql_lines = str_replace('{$db_prefix}', $db_prefix, $sql_lines);

	// Execute the SQL.
	$current = '';
	$count = 0;
	$sql_count = 0;
	$db_messed = false;
	foreach ($sql_lines as $line)
	{
		$line = rtrim($line);		

		// No comments allowed!
		if(!ereg('^#', $line))
			$current .= $line;

		// Is this the end of the query string?
		if (!empty($current) && (ereg(";\n?$", $line) || $count == count($sql_lines)))
		{
			$sql_count++;
			echo '
	<i>
		Executing package #' . $sql_count . '... ';

			if (!mysql_query($current))
			{
				echo ' <b>unsuccessful!</b><br />
		Error: ' . mysql_error() . '<br />
		In ' . $current . '
	</i><br />';
				$db_messed = true;
			}
			else
				echo ' successful.<br />';
			$current = '';

			// Gimme a little more time! *sweat*
			if ($sql_count % 200 == 0)
				@set_time_limit(240);
		}

		$count++;
	}

	// Let's optimize those new tables.
	$tables = mysql_list_tables($db_name);
	while(list ($table) = mysql_fetch_row($tables))
		mysql_query("
			OPTIMIZE TABLE $table") or $db_messed = true;

	if ($db_messed)
		echo '
		<font color="red">
			<br />
			Warning: Some of the queries failed!!<br />
			Your installation may not work correctly!<br />
		</font><br />';

	echo '
	<form action="' . $self . '?step=4" method="post">
		<center>
			<input type="hidden" name="installdir" value="' . $HTTP_POST_VARS['installdir'] . '" />
			<input type="submit" value="Proceed ' . ($db_messed ? 'Anyway ' : '') . '&gt;" />
		</center>
	</form>';

	return true;
}

// Step four: Fetch the important addresses.
function doStep4()
{
	global $self, $HTTP_POST_VARS, $HTTP_SERVER_VARS;

	// What host are we on?
	$host = getenv('HTTP_HOST');
	if (empty($host))
		$host = $HTTP_SERVER_VARS['SERVER_NAME'];
	if (empty($host))
		$host = 'www.myserver.com';

	// What port?
	$port = $HTTP_SERVER_VARS['SERVER_PORT'];
	if (empty($port) || $port == '80')
		$port = '';
	else
		$port = ':' . $port;

	// And how about the path?
	$path = substr($self, 0, strrpos($self, '/'));
	if (empty($path))
		$path = '/yabbse';

	// Now, to put what we've learned together...
	$url = 'http://' . $host . $port . $path;

	echo '
	<script>
	<!--
		function updateFields()
		{
			if (document.layers || document.all || document.getElementById)
			{
				pForm = document.step4form;
				pForm.imagesdir.value = pForm.boardurl.value + "/YaBBImages";
				pForm.facesurl.value = pForm.boardurl.value + "/YaBBImages/avatars";
				pForm.attachurl.value = pForm.boardurl.value + "/attachments";
			}
		}
	-->
	</script>
	Please provide a few URLs and paths to allow your forum to work properly.<br />
	You can most likely leave these at their defaults.
	<form action="' . $self . '?step=5" method="post" name="step4form">
		<table border="0" cellspacing="0" cellpadding="3">
			<tr>
				<td valign="top"><b>Board URL:</b></td>
				<td><input type="text" name="boardurl" value="' . $url . '" size="65" onChange="updateFields();" /><br />
				<font size="1">This is the url of your site <u>without the trailing \'/\'</u>.</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Images URL:</b></td>
				<td><input type="text" name="imagesdir" value="' . $url . '/YaBBImages" size="65" /><br />
				<font size="1">This is the location of your yabb images including the buttons, icons etc.</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Faces URL:</b></td>
				<td><input type="text" name="facesurl" value="' . $url . '/YaBBImages/avatars" size="65" /><br />
				<font size="1">This is the URL of the avatars.  It is, by default, the avatars sub-folder under your images folder.</font></td>
			</tr>

			<tr>
				<td valign="top"><b>Attachments URL:</b></td>
				<td><input type="text" name="attachurl" value="' . $url . '/attachments" size="65" /><br />
				<font size="1">This is the URL of attachments, after upload.  It is, by default, the attachments sub-folder under your YaBB SE forum directory.</font></td>
			</tr>
			<tr><td colspan="2">&nbsp;</td></tr>
		</table>
		<center>
			<input type="hidden" name="installdir" value="' . $HTTP_POST_VARS['installdir'] . '">
			<input type="submit" value="Proceed &gt;" />
		</center>
	</form>';

	return true;
}

// Step five: Actually store those important addresses.
function doStep5()
{
	global $self, $HTTP_POST_VARS;

	// Take care of these vars.
	$vars = array(
	// URLs...
		'boardurl' => $HTTP_POST_VARS['boardurl'],
		'facesurl' => $HTTP_POST_VARS['facesurl'],
		'imagesdir' => $HTTP_POST_VARS['imagesdir'],
		'helpfile' => $HTTP_POST_VARS['boardurl'] . '/YaBBHelp/index.html',
		'ubbcjspath' => $HTTP_POST_VARS['boardurl'] . '/ubbc.js',
		'faderpath' => $HTTP_POST_VARS['boardurl'] . '/fader.js',
	// Directories...
		'boarddir' => $HTTP_POST_VARS['installdir'],
		'sourcedir' => $HTTP_POST_VARS['installdir'] . '/Sources',
		'facesdir' => $HTTP_POST_VARS['installdir'] . '/YaBBImages/avatars',
	);

	// Modify Settings.php
	$settingsArray = file($HTTP_POST_VARS['installdir'] . '/Settings.php');
	for ($i = 0; $i < count($settingsArray); $i++)
	{
		$settingsArray[$i] = trim($settingsArray[$i]);
		foreach ($vars as $var => $val)
			if (strncasecmp($settingsArray[$i], '$' . $var, 1 + strlen($var)) == 0)
			{
				$comment = "\t" . strstr($settingsArray[$i], '#');
				$settingsArray[$i] = '$' . $var . ' = "' . addslashes($val) . '";' . $comment;
			}
	}
	$fp = fopen($HTTP_POST_VARS['installdir'] . '/Settings.php', 'w');
	foreach($settingsArray as $line)
		fputs($fp, $line . "\n");
	fclose($fp);

	// Update the attachment directory and URL.
	require_once($HTTP_POST_VARS['installdir'] . '/Settings.php');
	$linkid = mysql_connect($db_server, $db_user, $db_passwd);
	mysql_select_db($db_name, $linkid);
	mysql_query("
		UPDATE {$db_prefix}settings
		SET value='$HTTP_POST_VARS[installdir]/attachments'
		WHERE variable='attachmentUploadDir'");
	mysql_query("
		UPDATE {$db_prefix}settings
		SET value='$HTTP_POST_VARS[attachurl]'
		WHERE variable='attachmentUrl'");

	// Set defaults.
	$HTTP_POST_VARS['username'] = 'admin';
	$HTTP_POST_VARS['email'] = '';

	return doStep5a();
}

// Step five A: Ask for the administrator login information.
function doStep5a()
{
	global $self, $HTTP_POST_VARS;

	echo '
	The installer can now create an administrator account for you.<br />
	<form action="' . $self . '?step=6" method="post">
		<table border="0" cellspacing="0" cellpadding="3">
			<tr>
				<td valign="top"><b>Your username:</b></td>
				<td><input type="text" name="username" id="username" value="' . $HTTP_POST_VARS['username'] . '" /><br />
				<font size="1">Choose the user name you would like to have, this account will automatically receive admin rights</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Password:</b></td>
				<td><input type="password" name="password1" id="password1" /><br />
				<font size="1">Fill in your prefered password here, remember it well!</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Password again:</b></td>
				<td><input type="password" name="password2" id="password2" /><br />
				<font size="1">Just for verification</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Database Password:</b></td>
				<td><input type="password" name="password3" id="password3" /><br />
				<font size="1">This one is for security.</font></td>
			</tr>
			<tr>
				<td valign="top"><b>E-Mail:</b></td>
				<td><input type="text" name="email" id="email" size="20" value="' . $HTTP_POST_VARS['email'] . '" /><br />
				<font size="1">Provide an email address as well, or you might not be able to lgoin.</font></td>
			</tr>
			<tr>
				<td valign="top"><b>Skip this:</b></td>
				<td><input type="checkbox" name="skip" id="skip" value="1" /><font size="1">Only check this if you DO NOT want to set up an admin account.  Most likely this will only happen if you intend to continue and convert an existing Y1G board.  <b>This is not recommended!</b></font></td>
			</tr>
		</table>
		<center>
			<input type="hidden" name="installdir" value="' . $HTTP_POST_VARS['installdir'] . '" />
			<input type="submit" value="Proceed &gt;" />
		</center>
	</form>';

	return true;
}

// Step six: Create the administrator, and finish.
function doStep6()
{
	global $HTTP_POST_VARS;
	global $db_prefix;

	// Load the SQL server login information.
	require_once($HTTP_POST_VARS['installdir'] . '/Settings.php');

	if (!isset($HTTP_POST_VARS['skip']))
	{
		$linkid = mysql_connect($db_server, $db_user, $HTTP_POST_VARS['password3']);
		if (!$linkid)
		{
			echo '
		<font color="red">
			Unable to connect to the MySQL server.  Check your password and try again.<br />
		</font>';
			return false;
		}
		if (!mysql_select_db($db_name, $linkid))
		{
			echo '
		<font color="red">
			Unable to connect to the database.  Check that the user is allowed to access that database.<br />
		</font>';
			return false;
		}

		// Let them try again...
		if($HTTP_POST_VARS['password1'] != $HTTP_POST_VARS['password2'])
		{
			echo '
	<font color="red">
		Passwords didn' . "'" . 't match!!!<br />
	</font>';
			return doStep5a();
		}

		// This will have to change obviously ;)
		$queryPasswdPart = md5_hmac($HTTP_POST_VARS['password1'], strtolower($HTTP_POST_VARS['username']));
		$result = mysql_query("
			INSERT INTO {$db_prefix}members
				(memberName, realName, passwd, emailAddress, memberGroup, posts, personalText, avatar, dateRegistered, hideEmail)
			VALUES ('" . addslashes($HTTP_POST_VARS['username']) . "', '" . addslashes($HTTP_POST_VARS['username']) . "', '$queryPasswdPart', '$HTTP_POST_VARS[email]', 'Administrator', '0', '', 'blank.gif', '" . time() . "', '0')");
		if(!$result)
		{
			// Crud!
			echo '
	<font color="red">
		An error occurred while creating an Administrator: ' . mysql_error() . '
	</font><br />';
		}
		else
			echo '
	An administrator account has been created, you can now proceed to your newly created board.<br />
	<b>Please remember to delete install.php or rename it so it can' . "'" . 't be executed, and to chmod your installation dir to something other than 777</b><br />';
	}
	else
	{
		$linkid = mysql_connect($db_server, $db_user, $db_passwd);
		if (!mysql_select_db($db_name, $linkid))
		{
			echo '
		<font color="red">
			Unable to connect to the database.  Check that the user is allowed to access that database.<br />
		</font>';
			return false;
		}
	}

	chdir($HTTP_POST_VARS['installdir']);
	include_once($sourcedir . '/Subs.php');
	updateStats('member');
	updateStats('message');
	updateStats('topic');

	echo '
	Congratulations, the installation is complete!
	<p><blockquote><a href="' . $boardurl . '/index.php">Go to your board</a><br /></p>
	<p>
		Good luck!<br />
		The YaBB SE team.
	</p>';

	return true;
}

function php_version_check($reqver)
{
	$minver = explode('.', $reqver);
	$curver = explode('.', PHP_VERSION);
	if (($curver[0] <= $minver[0]) && ($curver[1] <= $minver[1]) && ($curver[1] <= $minver[1]) && ($curver[2][0] < $minver[2][0]))
		return false;
	else
		return true;
}

function mysql_version_check($reqver)
{
	$minver = explode('.', $reqver);
	$curver = mysql_get_server_info() < mysql_get_client_info() ? mysql_get_server_info() : mysql_get_client_info();
	if (strpos($curver, '-') !== false)
		$curver = substr($curver, 0, strpos($curver, '-'));
	$curver = explode('.', $curver);
	if (($curver[0] <= $minver[0]) && ($curver[1] <= $minver[1]) && ($curver[1] <= $minver[1]) && ($curver[2] < $minver[2]))
		return false;
	else
		return true;
}

// MD5 Encryption
function md5_hmac($data, $key)
{
	if (strlen($key) > 64)
		$key = pack('H*', md5($key));
	$key  = str_pad($key, 64, chr(0x00));

	$k_ipad = $key ^ str_repeat(chr(0x36), 64);
	$k_opad = $key ^ str_repeat(chr(0x5c), 64);

	return md5($k_opad . pack('H*', md5($k_ipad . $data)));
}

?>
