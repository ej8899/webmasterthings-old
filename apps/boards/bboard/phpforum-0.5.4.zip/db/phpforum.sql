CREATE TABLE phpforum(
  phpforum_id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  parent_id int(11) DEFAULT '0' NOT NULL,
  forum_id int(4) NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  date timestamp,
  poster_name text,
  poster_email text,
  mail_followup set('false','true'),
  INDEX idx_parent_id (parent_id),
  INDEX idx_forum_id (forum_id),
  INDEX idx_date (date)
);