<?php
$sys_dbhost="localhost";
$sys_dbname="myforum";
$sys_dbuser="root";
$sys_dbpassword="password";

function db_connect() {
	global $sys_dbhost,$sys_dbuser,$sys_dbpassword;
	return @mysql_pconnect($sys_dbhost,$sys_dbuser,$sys_dbpassword);
}

function db_query($qstring,$print=0) {
	if ($print) print "<br>Query is: $qstring<br>";
	global $sys_dbname;
	$db_qhandle = mysql($sys_dbname,$qstring);
	return $db_qhandle;
}

function db_num_rows($qhandle) {
	if ($qhandle) {
		return mysql_numrows($qhandle);
	} else {
		return 0;
	}
}

function db_fetch_array($qhandle = 0) {
	if ($qhandle) {
		return @mysql_fetch_array($qhandle);
	} else {
		return 0;
	}
}

function db_insert_id() {
	return mysql_insert_id();
}

?>