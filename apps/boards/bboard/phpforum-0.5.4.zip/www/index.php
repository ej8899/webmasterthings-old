<?php
	include("include/template.php");
	include("include/database.php");
	include("phpforum/phpforum.php");

	db_connect();

	$myForum = new PHPForum('phpforum', '1', '20', 'Site Title', 'http://site.url/', 'Forum Title');

	switch($HTTP_GET_VARS[action]) {
		case 'index':
			$myForum->index($HTTP_GET_VARS[page]);
		break;

		case 'message':
			$myForum->message($HTTP_GET_VARS[phpforum_id]);
		break;

		case 'add_post':
			if(!$myForum->add_post($HTTP_POST_VARS[parent_id], $HTTP_POST_VARS[form_subject], 
					$HTTP_POST_VARS[form_body], $HTTP_POST_VARS[form_name], $HTTP_POST_VARS[form_email], 
					$HTTP_POST_VARS[form_mail_followup])) print "Error: failed to insert record!";
			$myForum->index($HTTP_GET_VARS[page]);
			break;

		case 'new_thread':
			$myForum->submit_form(0, "");
			$myForum->t->parse("forum_body", "file_forum_submit", true);
			$myForum->t->parse("forum_body", "forum_function_back.ihtml", true);
		break;

		default:
			$HTTP_GET_VARS[page] = 1;
			$myForum->index($HTTP_GET_VARS[page]);
		break;
	}

	$myForum->t->pparse("output", "file_site");
?>