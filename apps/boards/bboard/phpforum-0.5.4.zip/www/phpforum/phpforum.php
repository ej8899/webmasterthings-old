<?php
class PHPForum {
	var $forum_table, $forum_id, $max_rows;
	var $site_title, $site_url, $forum_title;

	// Class Constructor
	function PHPForum($forum_table, $forum_id, $max_rows, $site_title, $site_url, $forum_title) {
		$this->forum_table = $forum_table;
		$this->forum_id = $forum_id;
		$this->max_rows = $max_rows;
		$this->site_title = $site_title;
		$this->site_url = $site_url;
		$this->forum_title = $forum_title;

		$this->t = new Template("templates");
		$this->t->set_file("file_site", "forum_index.ihtml");
		$this->t->set_file("forum_error", "forum_error.ihtml");
		$this->t->set_var ("site_title", $site_title);
		$this->t->set_var ("forum_title", $this->forum_title);
	}

	// Display index over all messages
	function index($page=1) {
		global $PHP_SELF;
		$cur_page = 1; // Displayed index page.
		$color = "";
		$this->t->set_file("file_index_table", "forum_table.ihtml");
		$this->t->set_file("file_index_table_data", "forum_table_body.ihtml");
		$this->t->set_var("current_page", $page);
		$this->t->set_var("total_pages", $this->get_num_pages());

		$this->index_header();

		$result = db_query("SELECT parent_id, phpforum_id, subject, poster_name, poster_email,
                                 concat(substring(date,5,2),'.',substring(date,7,2),'-',
                                 substring(date,1,4), ' ', substring(date,9,2),':',
                                 substring(date,11,2),':',substring(date,13,2)) as formated_date
                            FROM $this->forum_table
                           WHERE forum_id='$this->forum_id' AND parent_id='0'
                           ORDER BY date DESC");

		while($row = db_fetch_array($result)) {
			if($page == $cur_page) {
				$color ? $color = "" : $color = "bgcolor=#F2F8FF";
				if($row[poster_email] != "") $poster_name = "<a href=mailto:" . $row[poster_email] . ">" . $row[poster_name] . "</a>";
				else $poster_name = $row[poster_name];

				$subject = "<a href=" . basename($PHP_SELF) . "?action=message&parent_id=$row[phpforum_id]&phpforum_id=$row[phpforum_id]&page=$page>" . $row[subject] . "</a>";

				$this->t->set_var("forum_subject", $subject);
				$this->t->set_var("forum_poster_name", "by " . $poster_name);
				$this->t->set_var("forum_datetime", $row[formated_date]);
				$this->t->set_var("forum_table_bg_color", $color);
				$this->t->parse("forum_table_body", "file_index_table_data", true);
			}

			$displayed_messages++;
			$result2 = db_query("SELECT parent_id, phpforum_id, subject, poster_name, poster_email,
                                       concat(substring(date,5,2),'.',substring(date,7,2),'-',
                                       substring(date,1,4), ' ',substring(date,9,2),':',
                                       substring(date,11,2),':',substring(date,13,2)) as formated_date
                                 FROM $this->forum_table
                                WHERE parent_id='$row[phpforum_id]'
                                ORDER BY date DESC");

			while($row2 = db_fetch_array($result2)) {
				if($page == $cur_page) {
					$color ? $color = "" : $color = "bgcolor=#F2F8FF";
					if($row2[poster_email] != "") $poster_name = "<a href=mailto:" . $row2[poster_email] . ">" . $row2[poster_name] . "</a>";
					else $poster_name = $row2[poster_name];

					$subject = "<a href=" . basename($PHP_SELF) . "?action=message&parent_id=$row[phpforum_id]&phpforum_id=$row2[phpforum_id]&page=$page>" . $row2[subject] . "</a>";

					$this->t->set_var("forum_subject", "&#133;" . $subject);
					$this->t->set_var("forum_poster_name", "by " . $poster_name);
					$this->t->set_var("forum_datetime", $row2[formated_date]);
					$this->t->set_var("forum_table_bg_color", $color);
					$this->t->parse("forum_table_body", "file_index_table_data", true);
				}
				$displayed_messages++;
			}
			if($this->max_rows <= $displayed_messages) {
				$displayed_messages = 0;
				$cur_page++;
			}
		}

		if($this->get_num_pages() < $page || db_num_rows($result) < 1) {
			$this->t->set_var("forum_subject", "There are no posted messages!");
			$this->t->set_var("forum_poster_name", "");
			$this->t->set_var("forum_datetime", "");
			$this->t->set_var("forum_table_bg_color", "");
			$this->t->parse("forum_table_body", "file_index_table_data", true);
		}
		$this->t->parse("forum_body", "file_index_table", true);
	}

	// Displays post
	function message($msg_id) {
		global $PHP_SELF, $HTTP_GET_VARS;
		$back = "<a href=".basename($PHP_SELF)."?action=index&page=".$HTTP_GET_VARS[page].">Back</a>";

		$this->t->set_file("file_forum_message", "forum_read.ihtml");
		$this->t->set_var("forum_menu_back", $back);

		$result = db_query("SELECT subject, body, poster_name,
                                 concat(substring(date,9,2),':',
                                 substring(date,11,2),':',substring(date,13,2), ' ',
                                 substring(date,5,2),'.',substring(date,7,2),'-',
                                 substring(date,1,4)) as date
                            FROM $this->forum_table WHERE phpforum_id='$msg_id'");
		if($row = db_fetch_array($result)) {
			$this->t->set_var("forum_msg_subject", $row[subject]);
			$this->t->set_var("forum_msg_datetime", $row[date]);
			$this->t->set_var("forum_msg_body", $row[body]);
			$this->t->set_var("forum_msg_poster_name", $row[poster_name]);
			$this->t->parse("forum_body", "file_forum_message", true);

			$this->submit_form($HTTP_GET_VARS[parent_id], $row[subject]);
			$this->t->parse("forum_submit_form", "file_forum_submit", true);
		}
	}

	// Displays submit form
	function submit_form($parent_id=0, $subject) {
		global $PHP_SELF, $HTTP_GET_VARS;
		$index = "<a href=" . basename($PHP_SELF) . "?action=index&page=".$HTTP_GET_VARS[page].">Index</a>";
		$submit_url = basename($PHP_SELF)."?action=add_post&page=".$HTTP_GET_VARS[page];
		$this->t->set_file( "file_forum_submit", "forum_submit.ihtml");
		$this->t->set_var("forum_menu_index", $index);
		$this->t->set_var("forum_submit_url", $submit_url);
		$this->t->set_var("forum_submit_parent_id", $parent_id);
		if($subject) $subject = "Re: " . $subject;
		$this->t->set_var("forum_submit_topic", $subject);

		$this->back_button();
	}

	function back_button() {
		global $PHP_SELF, $HTTP_GET_VARS;
		$back_url = basename($PHP_SELF) . "?action=index&page=".$HTTP_GET_VARS[page];
		$this->t->set_file("forum_function_back.ihtml", "forum_function_back.ihtml");
		$this->t->set_var("forum_back_url", $back_url);
	}

	// Inserts data into the database + email stuff
	function add_post($parent_id, $subject, $body, $poster_name,
        	              $poster_email, $mail_followup) {
		global $PHP_SELF;
		if(!$this->unique_message($subject, $body, $poster_name)) return FALSE;

		if(!$this->validate_email($poster_email)) $poster_email = "";
		if($mail_followup != "true") $mail_followup="false";
		if($poster_email == "") $mail_followup="false";

		// All backslashes stripped off
		$mail_body = stripslashes($body);
		$mail_subject = stripslashes($subject);

		// Convert all applicable characters to HTML entities
		$body = htmlentities($body);
		$subject = htmlentities($subject);

		// Re-enables the code tag(htmlentities() kills it).
		$body = str_replace ("&lt;code&gt;", "<code>", $body);
		$body = str_replace ("&lt;/code&gt;", "</code>", $body);

		// Strip away all html entities
		$poster_name = strip_tags($poster_name);
		$poster_email = strip_tags($poster_email);

		// Makes all words starting with http:// clickable
		$body = $this->urls_clickable($body);

		// Convert newline to html tags
		$body = nl2br($body);

		if(strlen($subject) < 1) {
			$this->error('subject');
			return FALSE;
		}

		if(strlen($poster_name) < 1) {
			$this->error('poster_name');
			return FALSE;
		}

		$result = db_query("INSERT INTO $this->forum_table
                            (parent_id, forum_id, subject, body, poster_name, poster_email,
                             mail_followup)
                          VALUES('$parent_id', '$this->forum_id', '$subject', '$body', '$poster_name',
                                 '$poster_email', '$mail_followup')");

		$insert_msg_id = db_insert_id();

		if($parent_id) {
			$result = db_query("SELECT DISTINCT poster_email FROM $this->forum_table
						WHERE parent_id='$parent_id' AND mail_followup='true' AND poster_email != '$poster_email'
						OR phpforum_id='$parent_id' AND mail_followup='true' AND poster_email != '$poster_email'");

			while($row = db_fetch_array($result)) {
				$mail_header = $poster_name . " has commented your message at $this->site_title( $this->site_url )\n\n<-Message--->\n\n";
				$mail_footer = "\n\n<----Message end->\n\nYou can respond by visiting:\n$this->site_url". basename($PHP_SELF) ."?action=message&parent_id=". $parent_id ."&phpforum_id=". $insert_msg_id ."\n\nSubmit a new message on:\n$this->site_url". basename($PHP_SELF) ."?action=new_thread";
				mail($row[poster_email], "[$this->forum_title] " . $mail_subject, $mail_header . $mail_body . $mail_footer, "From: noreply\nReply-To: noreplay\nX-Mailer: freeScene PHPForum");
			}
		}
		return TRUE;
	}

	// Return total amount of messages in the current forum
	function get_num_posts() {
		global $forum_id;
      		$result = db_query("SELECT 1 FROM $this->forum_table
		                           WHERE forum_id='$this->forum_id'");
		return db_num_rows($result);
	}

	// Returns the total amount of pages
	function get_num_pages() {
		$current_page = 1;
		$result = db_query("SELECT * FROM $this->forum_table
                			WHERE forum_id='$this->forum_id'
                                        AND parent_id='0' ORDER BY date DESC");
		while($row = db_fetch_array($result)) {
			if($this->max_rows <= $comments_on_screen) {
				$comments_on_screen = 0;
				$current_page++;
			}
			$comments_on_screen++;
			$result2 = db_query("SELECT * FROM $this->forum_table
                        			WHERE parent_id=$row[phpforum_id]
                                   		ORDER BY date DESC");
			while(($row2 = db_fetch_array($result2))) {
				$comments_on_screen++;
			}
		}
		return $current_page;
	}

	// Returns the total amount of forums
	function get_num_forums() {
		$result = db_query("SELECT DISTINCT forum_id FROM '$this->forum_table'");
		return db_num_rows($result);
	}

	function index_header() {
		global $PHP_SELF, $HTTP_GET_VARS;

		$new_thread = "<a href=". basename($PHP_SELF)."?action=new_thread&page=".$HTTP_GET_VARS[page].">New thread</a>";

		if($HTTP_GET_VARS[page]!=1) $first = "<a href=". basename($PHP_SELF). "?action=index&page=1>First</a>";
		else $first = "First";
		if($HTTP_GET_VARS[page]>1) $next = "<a href=". basename($PHP_SELF). "?action=index&page=".($HTTP_GET_VARS[page]-1).">Next</a>";
		else $next = "Previous";
		if($HTTP_GET_VARS[page]<$this->get_num_pages()) $previous= "<a href=". basename($PHP_SELF). "?action=index&page=".($HTTP_GET_VARS[page]+1).">Previous</a>";
		else $previous= "Next";
		if($HTTP_GET_VARS[page]!=$this->get_num_pages()) $last= "<a href=". basename($PHP_SELF). "?action=index&page=".$this->get_num_pages().">Last</a>";
		else $last= "Last";

		$this->t->set_var("forum_menu_new_thread", $new_thread);
		$this->t->set_var("forum_menu_first", $first);
		$this->t->set_var("forum_menu_next", $next);
		$this->t->set_var("forum_menu_previous", $previous);
		$this->t->set_var("forum_menu_last", $last);
	}

	// Validates e-mail address
	function validate_email($email) {
		if(eregi("([a-z0-9\.]+)\@([a-z0-9\.]+)\.([a-z]{2,3})", $email)) return TRUE;
		return FALSE;
	}

	// Makes all words starting with http:// clickable
	function urls_clickable($string) {
		for($n=0; $n < strlen($string); $n++)
		{
			if(strtolower($string[$n]) == 'h') {
				if(!strcmp("http://", strtolower($string[$n]) . strtolower($string[$n+1]) . strtolower($string[$n+2]) . strtolower($string[$n+3]) . $string[$n+4] . $string[$n+5] . $string[$n+6])) {
					$startpos = $n;
					while($n < strlen($string) && eregi("[a-z0-9\.\:\?\/\~\-\_\&\=\%\+\'\"]", $string[$n])) $n++;
					if(!eregi("[a-z0-9]", $string[$n-1])) $n--;
					$link = substr($string, $startpos, ($n-$startpos));
					$link = $link;
					$string_tmp = $string;
					$string = substr($string_tmp, 0, $startpos);
					$string .= "<a href=\"$link\">$link</a>";
					$string .= substr($string_tmp, $n, strlen($string_tmp));
					$n = $n + 15;
				}
			}
		}
		return $string;
	}

	// Runs a check against the database for a duplicate
	function unique_message($subject, $body, $poster_name) {
		$res = db_query("SELECT 1 FROM $this->forum_table
			WHERE subject='$subject'
			AND body='$body'
			AND poster_name='$poster_name'");

		if(db_fetch_array($res)) return FALSE;
		else return TRUE;
	}

	function error($err_msg) {
		switch($err_msg) {
			case 'subject':
				$err_msg = "Please enter a subject!";
			break;
			case 'poster_name':
				$err_msg = "Please enter your name or an alias!";
			break;
		}
		$this->t->set_var("forum_error_message", $err_msg);
		$this->t->parse("forum_body", "forum_error", true);
	}
}
?>