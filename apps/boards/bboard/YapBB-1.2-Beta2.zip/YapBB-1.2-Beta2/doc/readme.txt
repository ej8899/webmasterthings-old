Please read the section 'upgrading' in the YapBB manual when you are going
to upgrade your existing YapBB 1.x to YapBB 1.2.

The YapBB Crew