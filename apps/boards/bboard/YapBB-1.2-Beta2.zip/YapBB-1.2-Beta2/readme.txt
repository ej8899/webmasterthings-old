Contents:
---------

database/ - This directory contains scripts and such for creating and
            upgrading YapBB tables.
doc/      - This directory contains documentation concerning YapBB.
tools/    - This directory contains YapBB-related tools.
YapBB/    - This directory contains the actual YapBB scripts which are to
            be placed somewhere inside the webserver's document root.

Please read the manual for information on installation, configuration, etc.
