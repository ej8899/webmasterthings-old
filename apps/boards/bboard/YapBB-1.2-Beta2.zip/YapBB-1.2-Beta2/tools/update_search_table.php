<?php chdir('/home/httpd/html/yapbb/');
// on Windows something like this: "c:/Program Files/Apache/htdocs/yapbb/confic.inc.php"
// on Linux something like this: "/home/httpd/html/yapbb/config.inc.php"

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//=====================================================================================================================
// Description: this file is to be executed by a cron job to automatically update the search index (pherhaps nightly)
//              this file should not be placed inside the document root of the webserver
//              make sure the complete path to your YapBB's "config.inc.php" is correct (see line 1)
//=====================================================================================================================

		require("config.inc.php");
		$searcher = new Searcher();
		$query = new MySQL();
		$res = $query->select("SELECT text, id FROM " . $cfgDatabase['post']);
		for ($i = 0; $i < $query->rows; $i++)
			$searcher->update_post(stripslashes($res[$i]['text']), $res[$i]['id']);

?>