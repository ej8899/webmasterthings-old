This directory contains YapBB-related tools. Currently only a script for
automatic updating of the search index is available. Read the comments in
this file for instructions.
