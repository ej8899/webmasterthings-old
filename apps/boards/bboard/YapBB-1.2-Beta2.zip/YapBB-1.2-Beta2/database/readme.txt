This directory contains files for creating and upgrading your existing
YapBB tables.

You use 'setup.sql' for creating tables when installing YapBB for the first
time. See the 'installation' section in the manual for more information.


The the PHP script files are required when upgrading your existing YapBB
installation to the latest version.

Currently an upgrade script for 1.0x --> 1.1 and one for 1.1 --> 1.2 are
provided. Please read the 'upgrading' section in the manual closely before
proceding with the upgrade.
