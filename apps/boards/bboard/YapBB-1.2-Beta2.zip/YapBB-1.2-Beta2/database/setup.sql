# phpMyAdmin MySQL-Dump
# http://phpwizard.net/phpMyAdmin/
#
# Host: localhost Database : yapbb
#
# Table names have 'forum_' prefix. Modify if required.

# --------------------------------------------------------
#
# Table structure for table 'forum_announcement'
#

CREATE TABLE forum_announcement (
   topicid int(10) unsigned DEFAULT '0' NOT NULL,
   sticky tinyint(4) DEFAULT '0' NOT NULL,
   PRIMARY KEY (topicid),
   KEY topicid (topicid),
   UNIQUE topicid_2 (topicid)
);

#
# Dumping data for table 'forum_announcement'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_avatar'
#

CREATE TABLE forum_avatar (
   id smallint(6) DEFAULT '0' NOT NULL,
   url text,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_avatar'
#

INSERT INTO forum_avatar (id, url) VALUES ( '1', '');
INSERT INTO forum_avatar (id, url) VALUES ( '2', 'jester.jpg');
INSERT INTO forum_avatar (id, url) VALUES ( '3', 'menm.jpg');
INSERT INTO forum_avatar (id, url) VALUES ( '4', 'usericon.gif');

# --------------------------------------------------------
#
# Table structure for table 'forum_bannedemail'
#

CREATE TABLE forum_bannedemail (
   id mediumint(9) NOT NULL auto_increment,
   host tinytext NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_bannedemail'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_category'
#

CREATE TABLE forum_category (
   id smallint(9) NOT NULL auto_increment,
   description mediumtext NOT NULL,
   position smallint(9) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY ID (id),
   UNIQUE ID_2 (id)
);

#
# Dumping data for table 'forum_category'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_forum'
#

CREATE TABLE forum_forum (
   id mediumint(11) unsigned NOT NULL auto_increment,
   name tinytext NOT NULL,
   description text NOT NULL,
   category smallint(11) unsigned DEFAULT '0' NOT NULL,
   password tinyint(4) unsigned DEFAULT '1' NOT NULL,
   usehtml tinyint(4) unsigned DEFAULT '1' NOT NULL,
   useybb tinyint(4) unsigned DEFAULT '1' NOT NULL,
   position mediumint(11) unsigned DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_forum'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_ipban'
#

CREATE TABLE forum_ipban (
   id mediumint(20) unsigned NOT NULL auto_increment,
   ip tinytext NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_ipban'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_moderator'
#

CREATE TABLE forum_moderator (
   forumid mediumint(20) DEFAULT '0' NOT NULL,
   userid int(20) DEFAULT '0' NOT NULL
);

#
# Dumping data for table 'forum_moderator'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_post'
#

CREATE TABLE forum_post (
   id bigint(20) unsigned NOT NULL auto_increment,
   text longtext NOT NULL,
   topicid int(20) unsigned DEFAULT '0' NOT NULL,
   posterid int(20) DEFAULT '0' NOT NULL,
   date bigint(20) DEFAULT '0' NOT NULL,
   ip tinytext,
   iconid tinyint(4) DEFAULT '0' NOT NULL,
   editorid int(20) unsigned DEFAULT '0' NOT NULL,
   editdate bigint(20) DEFAULT '0' NOT NULL,
   reactionto bigint(20) DEFAULT '0' NOT NULL,
   usesmilies tinyint(4) DEFAULT '1' NOT NULL,
   usehtml tinyint(4) DEFAULT '1' NOT NULL,
   useybb tinyint(4) DEFAULT '1' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_post'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_search_index'
#

CREATE TABLE forum_search_index (
   word VARCHAR(50), 
   qid INT
);

#
# Dumping data for table 'forum_search_index'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_session'
#

CREATE TABLE forum_session (
   id char(32) NOT NULL,
   lastAction datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   ip char(15) NOT NULL,
   userID mediumint(9),
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_session'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_status'
#

CREATE TABLE forum_status (
   id smallint(11) unsigned NOT NULL auto_increment,
   description text NOT NULL,
   requirements mediumint(20) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_status'
#

INSERT INTO forum_status (id, description, requirements) VALUES ( '1', 'Junior member', '0');
INSERT INTO forum_status (id, description, requirements) VALUES ( '2', 'Member', '100');
INSERT INTO forum_status (id, description, requirements) VALUES ( '3', 'Senior member', '1000');
INSERT INTO forum_status (id, description, requirements) VALUES ( '4', 'Very senior member', '10000');
INSERT INTO forum_status (id, description, requirements) VALUES ( '5', 'Spammer', '-999999');

# --------------------------------------------------------
#
# Table structure for table 'forum_subscription'
#

CREATE TABLE forum_subscription (
   userid bigint(20) DEFAULT '0' NOT NULL,
   topicid bigint(20) DEFAULT '0' NOT NULL,
   PRIMARY KEY (userid, topicid)
);

#
# Dumping data for table 'forum_subscription'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_topic'
#

CREATE TABLE forum_topic (
   id bigint(20) unsigned NOT NULL auto_increment,
   description text NOT NULL,
   postid bigint(20) DEFAULT '0' NOT NULL,
   views bigint(20) DEFAULT '0' NOT NULL,
   active tinyint(4) DEFAULT '1' NOT NULL,
   forumid mediumint(20) unsigned DEFAULT '0' NOT NULL,
   lastpostid bigint(20) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_topic'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_user'
#

CREATE TABLE forum_user (
   id int(11) NOT NULL auto_increment,
   nickname tinytext NOT NULL,
   password tinytext NOT NULL,
   icq int(20) unsigned DEFAULT '0' NOT NULL,
   email tinytext NOT NULL,
   showemail tinyint(4) DEFAULT '1' NOT NULL,
   homepage text NOT NULL,
   wherefrom text NOT NULL,
   bio text NOT NULL,
   registerdate bigint(20) DEFAULT '0' NOT NULL,
   posts mediumint(20) unsigned DEFAULT '0' NOT NULL,
   active tinyint(4) DEFAULT '1' NOT NULL,
   notes text NOT NULL,
   signature tinytext NOT NULL,
   groupid tinyint(4) DEFAULT '1' NOT NULL,
   displayprofile tinyint(4) DEFAULT '1' NOT NULL,
   activated tinyint(4) DEFAULT '0' NOT NULL,
   activationkey tinytext NOT NULL,
   avatarurl text NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Dumping data for table 'forum_user'
#

INSERT INTO forum_user (nickname, password, icq, email, showemail, homepage, wherefrom, bio, registerdate, posts, active, notes, signature, groupid, displayprofile, activated, activationkey, avatarurl) VALUES ( 'Admin23', '11111111', '0', 'root@localhost', '1', '', '', '', '0', '0', '1', 'The administrator account', '', '4', '1', '1', '', '');
INSERT INTO forum_user (nickname, password, icq, email, showemail, homepage, wherefrom, bio, registerdate, posts, active, notes, signature, groupid, displayprofile, activated, activationkey, avatarurl) VALUES ( 'Guest', '', '0', '', '0', '', '', '', '0', '0', '1', 'Anonymous user account; it has no password', 'Want your own account? [url=register.php]Register![/url]', '1', '0', '1', '', '');

# --------------------------------------------------------
#
# Table structure for table 'forum_user_vars'
#

CREATE TABLE forum_user_vars (
   name varchar(30) NOT NULL,
   session varchar(32) NOT NULL,
   intval int(10) unsigned,
   strval varchar(100),
   id mediumint(8) unsigned NOT NULL auto_increment,
   PRIMARY KEY (id),
   KEY sessionID (session),
   UNIQUE id (id)
);

#
# Dumping data for table 'forum_user_vars'
#


# --------------------------------------------------------
#
# Table structure for table 'forum_useronline'
#

CREATE TABLE forum_useronline (
   userid int(20) unsigned DEFAULT '0' NOT NULL,
   date bigint(20) DEFAULT '0' NOT NULL,
   ip text NOT NULL
);

#
# Dumping data for table 'forum_useronline'
#

