<?php $NODB = array("notfalse"); require("./config.inc.php");

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//=====================================================================================================================
// Description: retrieves the style sheet associated with the current template
//=====================================================================================================================

header("Content-type: text/css");

$file = "";
if (!file_exists($file = "$cfgTemplateDirectory$cookieTemplateName/style.php"))
	if (!file_exists($file = $cfgTemplateDirectory . "Default/style.php"))
		$file = "";


//=====================================================================================================================
// Return default style sheet
//=====================================================================================================================
if ($file == "")
	echo "
	X.inp { font: Tahoma; font-size: 8pt; border-width:1; border-color:000000; border-style:solid; }
	
	.thtcolor {
	  COLOR: #FFFFFF;
	}
	#all A:active {
	  COLOR: $cfgActiveLinkColor ;
	}
	#all A:visited {
	  COLOR: $cfgVisitedLinkColor ;
	}
	#all A:hover {
	  COLOR: $cfgHoverLinkColor;
	}
	#all A:link {
	  COLOR: $cfgLinkColor;
	}
	
	#cat A:active {
	  COLOR: #000000;
	  text-decoration: none
	}
	#cat A:visited {
	  COLOR: #000000 ;
	  text-decoration: none
	}
	#cat A:hover {
	  COLOR: #000000 ;
	  text-decoration: underline
	}
	#cat A:link {
	  COLOR: #000000 ;
	  text-decoration: none
	}
	";
else
//=====================================================================================================================
// Return selected style sheet
//=====================================================================================================================
	include($file);

require($cfgIncludeDirectory . "cleanup.php");
?>
