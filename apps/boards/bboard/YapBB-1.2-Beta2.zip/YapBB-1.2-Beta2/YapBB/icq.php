<?php include("./config.inc.php");

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
	modified by Sven Vintges (templates)
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//=====================================================================================================================
// Description: full featured ICQ pager
//=====================================================================================================================

require($cfgIncludeDirectory . "class_Snoopy.php");


//=====================================================================================================================
// Preliminary checks
//=====================================================================================================================
if (isset($HTTP_POST_VARS['from'])) $from = $HTTP_POST_VARS['from']; else unset($from);
if (isset($HTTP_POST_VARS['to'])) $to = $HTTP_POST_VARS['to']; else unset($to);
if (isset($HTTP_POST_VARS['subject'])) $subject = $HTTP_POST_VARS['subject']; else unset($subject);
if (isset($HTTP_POST_VARS['fromemail'])) $fromemail = $HTTP_POST_VARS['fromemail']; else unset($fromemail);
if (isset($HTTP_POST_VARS['body'])) $body = $HTTP_POST_VARS['body']; else unset($body);
if (isset($HTTP_GET_VARS['UIN'])) $UIN = $HTTP_GET_VARS['UIN']; else unset($UIN);

if ((!isset($UIN) || empty($UIN) || $UIN == 0 || $UIN == "") && (!isset($to) || $to == "" || empty($to)))
	sendError("ue: wrong UIN");

if ($submitted = isset($from) && isset($to) && isset($subject) && isset($fromemail) && isset($body))
{
//=====================================================================================================================
// User has submitted message
//=====================================================================================================================
	//$submit_url = "http://wwp.mirabilis.com/scripts/WWPMsg.dll";
	$submit_url = "http://wwp.icq.com/scripts/WWPMsg.dll";

	$snoopy = new Snoopy;
	$snoopy->agent = "(compatible; MSIE 4.01; MSN 2.5; AOL 4.0; Windows 98)";
	$success = FALSE;
	if ($snoopy->fetchtext($submit_url . "?from=" . urlencode($from) . "&to=" . urlencode($to) . "&subject=" . urlencode($subject) . "&fromemail=" . urlencode($fromemail) . "&body=" . urlencode($body)))
		$success = !eregi("An Error Has Occurred", $snoopy->results);
	$body = urlencode($body);
}
else	// the input form is about to show again
{
	$UIN = htmlspecialchars($UIN);
	$to = htmlspecialchars($tp);
	$from = htmlspecialchars($from);
	$fromemail = htmlspecialchars($fromemail);
	$body = htmlspecialchars($body);
}


//=====================================================================================================================
// Template stuff
//=====================================================================================================================
if (!$template->load_file($templateHandler, "$cfgTemplateDirectory$cookieTemplateName/icq.ybt"))
	if (!$template->load_file($templateHandler, $cfgTemplateDirectory . "Default/icq.ybt"))
		sendError("pe: Could not load template (icq.ybt)!");

$template->register($templateHandler, "UIN, sessionUser, sessionUserEmail, body, subject, to, from, fromemail");
echo $template->pget($templateHandler);

require($cfgIncludeDirectory . "cleanup.php");
?>
