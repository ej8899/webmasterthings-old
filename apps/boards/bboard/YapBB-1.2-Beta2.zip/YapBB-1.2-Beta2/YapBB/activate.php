<?php require("./config.inc.php");

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


//=====================================================================================================================
// Activate a new account (from an URL sent by registration e-mail)
//=====================================================================================================================
$query = new MySQL;
$res = $query->select("SELECT * FROM " . $cfgDatabase['user'] . " WHERE activated = 0 AND activationkey = '" . addslashes(ROT13($key)) . "'");
$msg = "";
$success = false;
if ($success = $query->rows == 1)
	$query->query("UPDATE " . $cfgDatabase['user'] . " SET activated = 1 WHERE activated = 0 AND activationkey = '" . addslashes(ROT13($key)) . "'");
else if ($query->rows > 1)
	$msg = "Database fault while activating account";
else if ($query->rows == 0)
	$msg = "Invalid activation key";

if (!$template->load_file($templateHandler, "$cfgTemplateDirectory$cookieTemplateName/activate.ybt"))
	if (!$template->load_file($templateHandler, $cfgTemplateDirectory . "Default/activate.ybt"))
		sendError("pe: Could not load template (activate.ybt)!");

$template->register($templateHandler, "msg");
$template->pprint($templateHandler);

require($cfgIncludeDirectory . "cleanup.php");
?>
