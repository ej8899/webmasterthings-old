<?php if (!$GLOBALS['includeBit']) exit();

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

function render_time()
{
	$times = explode(" ", $GLOBALS['templateStartTime']);
	$begin = $times[1] + $times[0];
	$times = explode(" ", microtime());
	$end = $times[1] + $times[0];
	$dif = round(($end - $begin) * 1000) / 1000;
	$parts = explode(".", $dif);
	while (strlen($parts[1]) < 3) $parts[1] .= "0";
	$dif = $parts[0] . "." . $parts[1];
	echo "\n\n <center><i>Rendered by PHP in: $dif sec</i></center>\n\n";
}

// Enable the following to display how long it took to render each page:
render_time();

if ($cfgUseCompression) gzdocout();

?>