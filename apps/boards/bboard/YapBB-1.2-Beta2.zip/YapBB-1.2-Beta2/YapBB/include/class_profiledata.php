<?php

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

// Small data carying class (a struct actually :))

class ProfileData
{
	var $classname = "ProfileData";	/* for serialize */
	var $userPass1;
	var $userPass2;
	var $userName;
	var $email;
	var $ICQ;
	var $homepage;
	var $showProfile;
	var $location;
	var $bio;
	var $signature;
	var $avatarurl;
}
?>