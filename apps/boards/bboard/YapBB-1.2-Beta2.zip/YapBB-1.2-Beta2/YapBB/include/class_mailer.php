<?php
/**
* Modified classes phpmailer and smtp to fit into YapBB
* and to be PHP3 compatible
*
* http://yapbb.sourceforge.net/
*/


////////////////////////////////////////////////////
// phpmailer - PHP email class
//
// Version 1.15, Created 06/15/2001
//
// Class for sending email using either
// sendmail, PHP mail(), or SMTP.	Methods are
// based upon the standard AspEmail(tm) classes.
//
// Author: Brent R. Matzelle <bmatzelle@yahoo.com>
//
// License: LGPL, see LICENSE
////////////////////////////////////////////////////

/**
 * phpmailer - PHP email transport class
 * @author Brent R. Matzelle
 */
class phpmailer
{
	/////////////////////////////////////////////////
	// PUBLIC VARIABLES
	/////////////////////////////////////////////////

	/**
	* Email priority (1 = High, 3 = Normal, 5 = low). Default value is 3.
	* @public
	* @type int
	*/
	var $Priority					= 3;

	/**
	* Sets the CharSet of the message. Default value is "iso-8859-1".
	* @public
	* @type string
	*/
	var $CharSet					= "iso-8859-1";

	/**
	* Sets the Content-type of the message. Default value is "text/plain".
	* @public
	* @type string
	*/
	var $ContentType			= "text/plain";

	/**
	* Sets the Encoding of the message. Default value is "8bit".
	* @public
	* @type string
	*/
	var $Encoding					= "8bit";

	/**
	* Sets the From email of the message. Default value is "root@localhost".
	* @public
	* @type string
	*/
	var $From							= "root@localhost";

	/**
	* Sets the From name of the message. Default value is "root".
	* @public
	* @type string
	*/
	var $FromName					= "root";

	/**
	* Sets the Sender email of the message. If not empty, will be sent via -f to sendmail
	* or as 'MAIL FROM' in smtp mode. Default value is "".
	* @public
	* @type string
	*/
	var $Sender						= "";

	/**
	* Sets the Subject of the message. Default value is "".
	* @public
	* @type string
	*/
	var $Subject					= "";

	/**
	* Sets the Body of the message. Default value is "".
	* @public
	* @type string
	*/
	var $Body							= "";

	/**
	* Sets word wrapping on the message. Default value is false (off).
	* @public
	* @type string
	*/
	var $WordWrap					= false;

	/**
	* Method to send mail: ("mail", "sendmail", or "smtp").
	* Default value is "mail".
	* @public
	* @type string
	*/
	var $Mailer						= "mail";

	/**
	* Sets the path of the sendmail program. Default value is
	* "/usr/sbin/sendmail".
	* @public
	* @type string
	*/
	var $Sendmail					= "/usr/sbin/sendmail";

	/**
	*	Turns phpmailer debugging on or off. Default value is false (off).
	*	@public
	*	@type bool
	*/
	var $MailerDebug			= false;

	/**
	*	Turns Microsoft mail client headers on and off. Default value is false (off).
	*	@public
	*	@type bool
	*/
	var $UseMSMailHeaders = false;


	/////////////////////////////////////////////////
	// SMTP VARIABLES
	/////////////////////////////////////////////////

	/**
	*	Sets the SMTP host. Default value is "localhost".
	*	@public
	*	@type string
	*/
	var $Host				= "localhost";

	/**
	*	Sets the SMTP server port. Default value is 25.
	*	@public
	*	@type int
	*/
	var $Port				= 25;

	/**
	*	Sets the CharSet of the message. Default value is "localhost.localdomain".
	*	@public
	*	@type string
	*/
	var $Helo				= "localhost.localdomain";

	/**
	*	Sets the SMTP server timeout. Default value is 10.
	*	@public
	*	@type int
	*/
	var $Timeout			= 10; // Socket timeout in sec.

	/**
	*	Sets SMTP class debugging on or off. Default value is false (off).
	*	@public
	*	@type bool
	*/
	var $SMTPDebug		= false;


	/////////////////////////////////////////////////
	// PRIVATE VARIABLES
	/////////////////////////////////////////////////

	/**
	*	Holds phpmailer version.
	*	@type string
	*/
	var $Version				= "phpmailer [version 1.15]";

	/**
	*	Holds all "To" addresses.
	*	@type array
	*/
	var $to						= array();

	/**
	*	Holds all "CC" addresses.
	*	@type array
	*/
	var $cc						= array();

	/**
	*	Holds all "BCC" addresses.
	*	@type array
	*/
	var $bcc						= array();

	/**
	*	Holds all "Reply-To" addresses.
	*	@type array
	*/
	var $ReplyTo				= array();

	/**
	*	Holds all attachments.
	*	@type array
	*/
	var $attachment		= array();

	/**
	*	Holds all custom headers.
	*	@type array
	*/
	var $CustomHeader	= array();

	/**
	*	Holds the message boundary.
	*	@type string
	*/
	var $boundary			= false;

	/////////////////////////////////////////////////
	// CONSTRUCTOR
	/////////////////////////////////////////////////

	/**
	* phpmailer constructor does nothing but is required by PHP3.	Returns void.
	* @public
	* @returns void
	*/
	function phpmailer() {
		// do nothing
	}

	/////////////////////////////////////////////////
	// VARIABLE METHODS
	/////////////////////////////////////////////////

	/**
	* IsHTML method sets message type to HTML.	Returns void.
	* @public
	* @returns void
	*/
	function IsHTML($bool) {
		if($bool == true)
			$this->ContentType = "text/html";
		else
			$this->ContentType = "text/plain";
	}

	/**
	* IsSMTP method sets Mailer to use SMTP.	Returns void.
	* @public
	* @returns void
	*/
	function IsSMTP() {
		$this->Mailer = "smtp";
	}

	/**
	* IsMail method sets Mailer to use PHP mail() function.	Returns void.
	* @public
	* @returns void
	*/
	function IsMail() {
		$this->Mailer = "mail";
	}

	/**
	* IsSendmail method sets Mailer to use $Sendmail program.	Returns void.
	* @public
	* @returns void
	*/
	function IsSendmail() {
		$this->Mailer = "sendmail";
	}

	/**
	* IsQmail method sets Mailer to use qmail MTA.	Returns void.
	* @public
	* @returns void
	*/
	function IsQmail() {
		//$this->Sendmail = "/var/qmail/bin/qmail-inject";
		$this->Sendmail = "/var/qmail/bin/sendmail";
		$this->Mailer = "sendmail";
	}


	/////////////////////////////////////////////////
	// RECIPIENT METHODS
	/////////////////////////////////////////////////

	/**
	* AddAddress method adds a "to" address.	Returns void.
	* @public
	* @returns void
	*/
	function AddAddress($address, $name = "") {
		$cur = count($this->to);
		$this->to[$cur][0] = trim($address);
		$this->to[$cur][1] = $name;
	}

	/**
	* AddCC method adds a "cc" address.	Returns void.
	* @public
	* @returns void
	*/
	function AddCC($address, $name = "") {
		$cur = count($this->cc);
		$this->cc[$cur][0] = trim($address);
		$this->cc[$cur][1] = $name;
	}

	/**
	* AddBCC method adds a "bcc" address.	Returns void.
	* @public
	* @returns void
	*/
	function AddBCC($address, $name = "") {
		$cur = count($this->bcc);
		$this->bcc[$cur][0] = trim($address);
		$this->bcc[$cur][1] = $name;
	}

	/**
	* AddReplyTo method adds a "Reply-to" address.	Returns void.
	* @public
	* @returns void
	*/
	function AddReplyTo($address, $name = "") {
		$cur = count($this->ReplyTo);
		$this->ReplyTo[$cur][0] = trim($address);
		$this->ReplyTo[$cur][1] = $name;
	}


	/////////////////////////////////////////////////
	// MAIL SENDING METHODS
	/////////////////////////////////////////////////

	/**
	* Send method creates message and assigns Mailer.	Returns bool.
	* @public
	* @returns bool
	*/
	function Send() {
		if(count($this->to) < 1)
		{
			$this->error_handler("You must provide at least one recipient email address");
			return false;
		}

		$header = $this->create_header();
		if(!$body = $this->create_body())
			return false;

	// Choose the mailer
		if($this->Mailer == "sendmail")
		{
			if(!$this->sendmail_send($header, $body))
			return false;
		}
		elseif($this->Mailer == "mail")
		{
			if(!$this->mail_send($header, $body))
			return false;
		}
		elseif($this->Mailer == "smtp")
		{
			if(!$this->smtp_send($header, $body))
			return false;
		}
		else
		{
			$this->error_handler(sprintf("%s mailer is not supported", $this->Mailer));
			return false;
		}

		return true;
		}

	/**
	* sendmail_send method sends mail using the $Sendmail program.	Returns bool.
	* @private
	* @returns bool
	*/
	function sendmail_send($header, $body) {
		if ($this->Sender != "")
			$sendmail = sprintf("%s -f %s -t", $this->Sendmail, $this->Sender);
		else
			$sendmail = sprintf("%s -t", $this->Sendmail);

		if(!@$mail = popen($sendmail, "w"))
		{
			$this->error_handler(sprintf("Could not execute %s", $this->Sendmail));
			return false;
		}

		fputs($mail, $header);
		fputs($mail, $body);
		pclose($mail);

		return true;
	}

	/**
	* mail_send method sends mail using the PHP mail() function.	Returns bool.
	* @private
	* @returns bool
	*/
	function mail_send($header, $body) {
	// Create mail recipient list
		$to = $this->to[0][0]; // no extra comma
		for($i = 1; $i < count($this->to); $i++)
			$to .= sprintf(",%s", $this->to[$i][0]);
		for($i = 0; $i < count($this->cc); $i++)
			$to .= sprintf(",%s", $this->cc[$i][0]);
		for($i = 0; $i < count($this->bcc); $i++)
			$to .= sprintf(",%s", $this->bcc[$i][0]);

		if ($this->Sender != "")
			$params = sprintf("-f %s", $this->Sender);
		else
			$params = "";

		if(!@mail($to, $this->Subject, $body, $header, $params))
		{
			$this->error_handler("Could not instantiate mail()");
			return false;
		}

		return true;
	}

	/**
	* smtp_send method sends mail via SMTP using PhpSMTP (Author:
	* Chris Ryan).	Returns bool.
	* @private
	* @returns bool
	*/
	function smtp_send($header, $body) {
	// Include SMTP class code, but not twice
//			include_once("class.smtp.php"); // Load code only if asked

		$smtp = new SMTP;
		$smtp->do_debug = $this->SMTPDebug;

	// Try to connect to all SMTP servers
		$hosts = explode(";", $this->Host);
		$index = 0;
		$connection = false;

	// Retry while there is no connection
		while($index < count($hosts) && $connection == false)
		{
			if($smtp->Connect($hosts[$index], $this->Port, $this->Timeout))
				$connection = true;
			//printf("%s host could not connect<br>", $hosts[$index]); //debug only
			$index++;
		}
		if(!$connection)
		{
			$this->error_handler("SMTP Error: could not connect to SMTP host server(s)");
			return false;
		}

		$smtp->Hello($this->Helo);
		if ($this->Sender == "")
			$smtp->Mail(sprintf("<%s>", $this->From));
		else
			$smtp->Mail(sprintf("<%s>", $this->Sender));

		for($i = 0; $i < count($this->to); $i++)
			$smtp->Recipient(sprintf("<%s>", $this->to[$i][0]));
		for($i = 0; $i < count($this->cc); $i++)
			$smtp->Recipient(sprintf("<%s>", $this->cc[$i][0]));
		for($i = 0; $i < count($this->bcc); $i++)
			$smtp->Recipient(sprintf("<%s>", $this->bcc[$i][0]));

		if(!$smtp->Data(sprintf("%s%s", $header, $body)))
		{
			$this->error_handler("SMTP Error: Data not accepted");
			return false;
		}
		$smtp->Quit();

		return true;
	}


	/////////////////////////////////////////////////
	// MESSAGE CREATION METHODS
	/////////////////////////////////////////////////

	/**
	* addr_append method creates recipient headers.	Returns string.
	* @private
	* @returns string
	*/
	function addr_append($type, $addr) {
		$addr_str = "";
		$addr_str .= sprintf("%s: %s <%s>", $type, $addr[0][1], $addr[0][0]);
		if(count($addr) > 1)
		{
			for($i = 1; $i < count($addr); $i++)
			{
				$addr_str .= sprintf(", %s <%s>", $addr[$i][1], $addr[$i][0]);
			}
			$addr_str .= "\r\n";
		}
		else
			$addr_str .= "\r\n";

		return($addr_str);
	}

	/**
	* wordwrap wraps message for use with mailers that don't
	* automatically perform wrapping.	Written by philippe.	Returns string.
	* @private
	* @returns string
	*/
	function wordwrap($message, $length) {
		$line = explode("\n", $message);
		$message = "";
		for ($i=0 ;$i < count($line); $i++)
		{
			$line_part = explode(" ", trim($line[$i]));
			$buf = "";
			for ($e = 0; $e<count($line_part); $e++)
			{
			$buf_o = $buf;
			if ($e == 0)
					$buf .= $line_part[$e];
			else
					$buf .= " " . $line_part[$e];
			if (strlen($buf) > $length and $buf_o != "")
			{
					$message .= $buf_o . "\r\n";
					$buf = $line_part[$e];
			}
			}
			$message .= $buf . "\r\n";
		}

		return ($message);
	}

	/**
	* create_header assembles message header.	Returns a string if sucessful
	* or false if unsucessful.
	* @private
	* @returns string
	*/
	function create_header() {
		$header = array();
		$header[] = sprintf("Date: %s\r\n", date("D, j M Y H:i:s T"));
		$header[] = $this->addr_append("To", $this->to);
		$header[] = sprintf("From: %s <%s>\r\n", $this->FromName, trim($this->From));
		if(count($this->cc) > 0)
			$header[] = $this->addr_append("Cc", $this->cc);
		if(($this->Mailer == "sendmail") && (count($this->bcc) > 0))
			$header[] = $this->addr_append("Bcc", $this->bcc);
		if(count($this->ReplyTo) > 0)
			$header[] = $this->addr_append("Reply-to", $this->ReplyTo);
		$header[] = sprintf("Subject: %s\r\n", trim($this->Subject));
		$header[] = sprintf("X-Priority: %d\r\n", $this->Priority);
		$header[] = sprintf("X-Mailer: %s\r\n", $this->Version);
		$header[] = sprintf("Return-Path: %s\r\n", trim($this->From));

	// Add custom headers
		for($index = 0; $index < count($this->CustomHeader); $index++)
			$header[] = sprintf("%s\r\n", $this->CustomHeader[$index]);

		if($this->UseMSMailHeaders)
			$header[] = $this->AddMSMailHeaders();

	// Add all attachments
		if(count($this->attachment) > 0)
		{
		// Set message boundary
			$this->boundary = "_b" . md5(uniqid(time()));

			$header[] = sprintf("Content-Type: Multipart/Mixed; charset = \"%s\";\r\n", $this->CharSet);
			$header[] = sprintf(" boundary=\"Boundary-=%s\"\r\n", $this->boundary);
		}
		else
		{
			$header[] = sprintf("Content-Transfer-Encoding: %s\r\n", $this->Encoding);
			$header[] = sprintf("Content-Type: %s; charset = \"%s\";\r\n", $this->ContentType, $this->CharSet);
		}

		$header[] = "MIME-Version: 1.0\r\n";

		return(join("", $header));
	}

	/**
	* create_body assembles the message body.	Returns a string if sucessful
	* or false if unsucessful.
	* @private
	* @returns string
	*/
	function create_body() {
	// wordwrap the message body if set
		if($this->WordWrap)
			$this->Body = $this->wordwrap($this->Body, $this->WordWrap);

		$this->Body = $this->encode_string($this->Body, $this->Encoding);

		if(count($this->attachment) > 0)
		{
			if(!$body = $this->attach_all())
			return false;
		}
		else
			$body = $this->Body;

		if (empty($body))
			$this->error_handler("No text!");

		return($body);
	}


	/////////////////////////////////////////////////
	// ATTACHMENT METHODS
	/////////////////////////////////////////////////

	/**
	* AddAttachment check if attachment is valid and add to list.
	* Returns false if the file was not found.
	* @public
	* @returns bool
	*/
	function AddAttachment($path, $name = "", $encoding = "base64", $type = "application/octet-stream") {
		if(!@is_file($path))
		{
			$this->error_handler(sprintf("Could not find %s file on filesystem", $path));
			return false;
		}

		$filename = basename($path);
		if($name == "")
			$name = $filename;

	// Append to $attachment array
		$cur = count($this->attachment);
		$this->attachment[$cur][0] = $path;
		$this->attachment[$cur][1] = $filename;
		$this->attachment[$cur][2] = $name;
		$this->attachment[$cur][3] = $encoding;
		$this->attachment[$cur][4] = $type;

		return true;
	}

	/**
	* attach_all attach text and binary attachments to body.	Returns a
	* string if sucessful or false if unsucessful.
	* @private
	* @returns string
	*/
	function attach_all() {
	// Return text of body
		$mime = array();
		$mime[] = "This is a MIME message. If you are reading this text, you\r\n";
		$mime[] = "might want to consider changing to a mail reader that\r\n";
		$mime[] = "understands how to properly display MIME multipart messages.\r\n\r\n";
		$mime[] = sprintf("--Boundary-=%s\r\n", $this->boundary);
		$mime[] = sprintf("Content-Type: %s; charset = \"%s\";\r\n", $this->ContentType, $this->CharSet);
		$mime[] = sprintf("Content-Transfer-Encoding: %s\r\n\r\n", $this->Encoding);
		$mime[] = sprintf("%s\r\n", $this->Body);

	// Add all attachments
		for($i = 0; $i < count($this->attachment); $i++)
		{
			$path = $this->attachment[$i][0];
			$filename = $this->attachment[$i][1];
			$name = $this->attachment[$i][2];
			$encoding = $this->attachment[$i][3];
			$type = $this->attachment[$i][4];
			$mime[] = sprintf("--Boundary-=%s\r\n", $this->boundary);
			$mime[] = sprintf("Content-Type: %s;\r\n", $type);
			$mime[] = sprintf("name=\"%s\"\r\n", $name);
			$mime[] = sprintf("Content-Transfer-Encoding: %s\r\n", $encoding);
			$mime[] = sprintf("Content-Disposition: attachment; filename=\"%s\"\r\n\r\n", $name);
			if(!$mime[] = sprintf("%s\r\n\r\n", $this->encode_file($path, $encoding)))
			return false;
		}
		$mime[] = sprintf("\r\n--Boundary-=%s--\r\n", $this->boundary);

		return(join("", $mime));
	}

	/**
	* encode_file encode attachment in requested format.	Returns a
	* string if sucessful or false if unsucessful.
	* @private
	* @returns string
	*/
	function encode_file ($path, $encoding = "base64") {
		if(!@$fd = fopen($path, "r"))
		{
			$this->error_handler("File Error: Could not open file %s", $path);
			return false;
		}
		$file = fread($fd, filesize($path));
		$encoded = $this->encode_string($file, $encoding);
		fclose($fd);

		return($encoded);
	}

	/**
	* encode_string encode string to requested format.	Returns a
	* string if sucessful or false if unsucessful.
	* @private
	* @returns string
	*/
	function encode_string ($str, $encoding = "base64") {
		switch(strtolower($encoding)) {
			case "base64":
	// chunk_split is found in PHP >= 3.0.6
				$encoded = chunk_split(base64_encode($str));
			break;

			case "7bit":
			case "8bit":
			case "binary":
				$encoded = $str;
				break;

			case "quoted-printable":
		// Not yet available
			default:
				$this->error_handler("Unknown encoding: %s", $encoding);
				return false;
		}
		return($encoded);
	}

	/////////////////////////////////////////////////
	// MESSAGE RESET METHODS
	/////////////////////////////////////////////////

	/**
	* ClearAddresses clears all recipients assigned in the TO array.	Returns void.
	* @public
	* @returns void
	*/
	function ClearAddresses() {
		$this->to = array();
	}

	/**
	* ClearCCs clears all recipients assigned in the CC array.	Returns void.
	* @public
	* @returns void
	*/
	function ClearCCs() {
		$this->cc = array();
	}

	/**
	* ClearBCCs clears all recipients assigned in the BCC array.	Returns void.
	* @public
	* @returns void
	*/
	function ClearBCCs() {
		$this->bcc = array();
	}

	/**
	* ClearReplyTos clears all recipients assigned in the ReplyTo array.	Returns void.
	* @public
	* @returns void
	*/
	function ClearReplyTos() {
		$this->ReplyTo = array();
	}

	/**
	* ClearAllRecipients clears all recipients assigned in the TO, CC and BCC
	* array.	Returns void.
	* @public
	* @returns void
	*/
	function ClearAllRecipients() {
		$this->to = array();
		$this->cc = array();
		$this->bcc = array();
	}

	/**
	* ClearAddresses clears all previously set attachments.	Returns void.
	* @public
	* @returns void
	*/
	function ClearAttachments() {
		$this->attachment = array();
	}

	/**
	* ClearCustomHeaders clears all custom headers.	Returns void.
	* @public
	* @returns void
	*/
	function ClearCustomHeaders() {
		$this->CustomHeader = array();
	}


	/////////////////////////////////////////////////
	// MISCELLANEOUS METHODS
	/////////////////////////////////////////////////

	/**
	* error_handler prints out structured errors.	Returns void.
	* @private
	* @returns void
	*/
	function error_handler($msg) {
		if($this->MailerDebug == true)
		{
			print("<h3>Mailer Error</h3>");
			print("Description:<br>");
			printf("<font color=\"FF0000\">%s</font>", $msg);
		}
	}

	/**
	* AddCustomHeader adds a custom header.	Returns void.
	* @public
	* @returns void
	*/
	function AddCustomHeader($custom_header) {
		$this->CustomHeader[] = $custom_header;
	}

	/**
	* UseMSMailHeaders adds all the Microsoft message headers.	Returns string.
	* @public
	* @returns string
	*/
	function UseMSMailHeaders() {
		$MSHeader = "";
		if($this->Priority == 1)
			$MSPriority = "High";
		elseif($this->Priority == 5)
			$MSPriority = "Low";
		else
			$MSPriority = "Medium";

		$MSHeader .= sprintf("X-MSMail-Priority: %s\r\n", $MSPriority);
		$MSHeader .= sprintf("Importance: %s\r\n", $MSPriority);

		return($MSHeader);
	}

	/**
	* PrintVersion prints out the version number of phpmailer.	Returns void.
	* @public
	* @returns void
	*/
	function PrintVersion() {
		//printf("<h5><a href=\"http://phpmailer.sourceforge.net\">%s</a></h5>", $this->Version);
		printf("%s", $this->Version);
	}

}
// End of class

/*
 * File: smtp.php
 *
 * Description: Define an SMTP class that can be used to connect
 *							and communicate with any SMTP server. It implements
 *							all the SMTP functions defined in RFC821 except TURN.
 *
 * Creator: Chris Ryan <chris@greatbridge.com>
 * Created: 03/26/2001
 *
 * TODO:
 *			- Move all the duplicate code to a utility function
 *						Most of the functions have the first lines of
 *						code do the same processing. If this can be moved
 *						into a utility function then it would reduce the
 *						overall size of the code significantly.
 */

/*
 * STMP is rfc 821 compliant and implements all the rfc 821 SMTP
 * commands except TURN which will always return a not implemented
 * error. SMTP also provides some utility methods for sending mail
 * to an SMTP server.
 */
class SMTP {
	var $SMTP_PORT = 25; # the default SMTP PORT
	var $CRLF = "\r\n";	# CRLF pair

	var $smtp_conn;			# the socket to the server
	var $error;					# error if any on the last call
	var $helo_rply;			# the reply the server sent to us for HELO

	var $do_debug;				# the level of debug to perform

	/*
	* SMTP()
	*
	* Initialize the class so that the data is in a known state.
	*/
	function SMTP() {
		$this->smtp_conn = 0;
		$this->error = null;
		$this->helo_rply = null;

		$this->do_debug = 0;
	}

	/************************************************************
	 *                  CONNECTION FUNCTIONS                    *
	 ***********************************************************/

	/*
	* Connect($host, $port=0, $tval=30)
	*
	* Connect to the server specified on the port specified.
	* If the port is not specified use the default SMTP_PORT.
	* If tval is specified then a connection will try and be
	* established with the server for that number of seconds.
	* If tval is not specified the default is 30 seconds to
	* try on the connection.
	*
	* SMTP CODE SUCCESS: 220
	* SMTP CODE FAILURE: 421
	*/
	function Connect($host,$port=0,$tval=30) {
		# set the error val to null so there is no confusion
		$this->error = null;

		# make sure we are __not__ connected
		if($this->connected()) {
			# ok we are connected! what should we do?
			# for now we will just give an error saying we
			# are already connected
			$this->error =
				array("error" => "Already connected to a server");
			return false;
		}

		if(empty($port)) {
			$port = $this->SMTP_PORT;
		}

		#connect to the smtp server
		$this->smtp_conn = fsockopen($host,		# the host of the server
										$port,		# the port to use
										$errno,		# error number if any
										$errstr,	# error message if any
										$tval);		# give up after ? secs
		# verify we connected properly
		if(empty($this->smtp_conn)) {
			$this->error = array("error" => "Failed to connect to server",
									"errno" => $errno,
									"errstr" => $errstr);
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": $errstr ($errno)" . $this->CRLF;
			}
			return false;
		}

		# sometimes the SMTP server takes a little longer to respond
		# so we will give it a longer timeout for the first read
		//if(function_exists("socket_set_timeout"))
		//		socket_set_timeout($this->smtp_conn, 1, 0);

		# get any announcement stuff
		$announce = $this->get_lines();

		# set the timeout	of any socket functions at 1/10 of a second
		//if(function_exists("socket_set_timeout"))
		//		socket_set_timeout($this->smtp_conn, 0, 100000);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $announce;
		}

		return true;
	}

	/*
	* Connected()
	*
	* Returns true if connected to a server otherwise false
	*/
	function Connected() {
		if(!empty($this->smtp_conn)) {
			$sock_status = socket_get_status($this->smtp_conn);
			if($sock_status["eof"]) {
				# hmm this is an odd situation... the socket is
				# valid but we aren't connected anymore
				if($this->do_debug >= 1) {
					echo "SMTP -> NOTICE:" . $this->CRLF .
							"EOF caught while checking if connected";
				}
				$this->Close();
				return false;
			}
			return true; # everything looks good
		} 
		return false;
	}

	/*
	* Close()
	*
	* Closes the socket and cleans up the state of the class.
	* It is not considered good to use this function without
	* first trying to use QUIT.
	*/
	function Close() {
		$this->error = null; # so there is no confusion
		$this->helo_rply = null;
		if(!empty($this->smtp_conn)) { 
			# close the connection and cleanup
			fclose($this->smtp_conn);
			$this->smtp_conn = 0;
		}
	}


	/**************************************************************
		*												SMTP COMMANDS												*
		*************************************************************/

	/*
	* Data($msg_data)
	*
	* Issues a data command and sends the msg_data to the server
	* finializing the mail transaction. $msg_data is the message
	* that is to be send with the headers. Each header needs to be
	* on a single line followed by a <CRLF> with the message headers
	* and the message body being seperated by and additional <CRLF>.
	*
	* Implements rfc 821: DATA <CRLF>
	*
	* SMTP CODE INTERMEDIATE: 354
	*			[data]
	*			<CRLF>.<CRLF>
	*			SMTP CODE SUCCESS: 250
	*			SMTP CODE FAILURE: 552,554,451,452
	* SMTP CODE FAILURE: 451,554
	* SMTP CODE ERROR	: 500,501,503,421
	*/
	function Data($msg_data) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Data() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"DATA" . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 354) {
			$this->error =
				array("error" => "DATA command not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}

		# the server is ready to accept data!
		# according to rfc 821 we should not send more than 1000
		# including the CRLF
		# characters on a single line so we will break the data up
		# into lines by \r and/or \n then if needed we will break
		# each of those into smaller lines to fit within the limit.
		# in addition we will be looking for lines that start with
		# a period '.' and append and additional period '.' to that
		# line. NOTE: this does not count towards are limit.

		# normalize the line breaks so we know the explode works
		$msg_data = str_replace("\r\n","\n",$msg_data);
		$msg_data = str_replace("\r","\n",$msg_data);
		$lines = explode("\n",$msg_data);

		# we need to find a good way to determine is headers are
		# in the msg_data or if it is a straight msg body
		# currently I'm assuming rfc 822 definitions of msg headers
		# and if the first field of the first line (':' sperated)
		# does not contain a space then it _should_ be a header
		# and we can process all lines before a blank "" line as
		# headers.
		$field = substr($lines[0],0,strpos($lines[0],":"));
		$in_headers = false;
		if(!empty($field) && !strstr($field," ")) {
			$in_headers = true;
		}

		$max_line_length = 998; # used below; set here for ease in change

		while(list(,$line) = @each($lines)) {
			$lines_out = null;
			if($line == "" && $in_headers) {
				$in_headers = false;
			}
			# ok we need to break this line up into several
			# smaller lines
			while(strlen($line) > $max_line_length) {
				$pos = strrpos(substr($line,0,$max_line_length)," ");
				$lines_out[] = substr($line,0,$pos);
				$line = substr($line,$pos + 1);
				# if we are processing headers we need to
				# add a LWSP-char to the front of the new line
				# rfc 822 on long msg headers
				if($in_headers) {
					$line = "\t" . $line;
				}
			}
			$lines_out[] = $line;

			# now send the lines to the server
			while(list(,$line_out) = @each($lines_out)) {
				if($line_out[0] == ".") {
					$line_out = "." . $line_out;
				}
				fputs($this->smtp_conn,$line_out . $this->CRLF);
			}
		}

		# ok all the message data has been sent so lets get this
		# over with aleady
		fputs($this->smtp_conn, $this->CRLF . "." . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "DATA not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* Expand($name)
	*
	* Expand takes the name and asks the server to list all the
	* people who are members of the _list_. Expand will return
	* back and array of the result or false if an error occurs.
	* Each value in the array returned has the format of:
	*			[ <full-name> <sp> ] <path>
	* The definition of <path> is defined in rfc 821
	*
	* Implements rfc 821: EXPN <SP> <string> <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE FAILURE: 550
	* SMTP CODE ERROR	: 500,501,502,504,421
	*/
	function Expand($name) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Expand() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"EXPN " . $name . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "EXPN not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}

		# parse the reply and place in our array to return to user
		$entries = explode($this->CRLF,$rply);
		while(list(,$l) = @each($entries)) {
			$list[] = substr($l,4);
		}

		return $rval;
	}

	/*
	* Hello($host="")
	*
	* Sends the HELO command to the smtp server.
	* This makes sure that we and the server are in
	* the same known state.
	*
	* Implements from rfc 821: HELO <SP> <domain> <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE ERROR	: 500, 501, 504, 421
	*/
	function Hello($host="") {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Hello() without being connected");
			return false;
		}

		# if a hostname for the HELO wasn't specified determine
		# a suitable one to send
		if(empty($host)) {
			# we need to determine some sort of appopiate default
			# to send to the server
			$host = "localhost";
		}

		fputs($this->smtp_conn,"HELO " . $host . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "HELO not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}

		$this->helo_rply = $rply;

		return true;
	}

	/*
	* Help($keyword="")
	*
	* Gets help information on the keyword specified. If the keyword
	* is not specified then returns generic help, ussually contianing
	* A list of keywords that help is available on. This function
	* returns the results back to the user. It is up to the user to
	* handle the returned data. If an error occurs then false is
	* returned with $this->error set appropiately.
	*
	* Implements rfc 821: HELP [ <SP> <string> ] <CRLF>
	*
	* SMTP CODE SUCCESS: 211,214
	* SMTP CODE ERROR	: 500,501,502,504,421
	*/
	function Help($keyword="") {
		$this->error = null; # to avoid confusion

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Help() without being connected");
			return false;
		}

		$extra = "";
		if(!empty($keyword)) {
			$extra = " " . $keyword;
		}

		fputs($this->smtp_conn,"HELP" . $extra . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 211 && $code != 214) {
			$this->error =
				array("error" => "HELP not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}

		return $rply;
	}

	/*
	* Mail($from)
	*
	* Starts a mail transaction from the email address specified in
	* $from. Returns true if successful or false otherwise. If True
	* the mail transaction is started and then one or more Recipient
	* commands may be called followed by a Data command.
	*
	* Implements rfc 821: MAIL <SP> FROM:<reverse-path> <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE SUCCESS: 552,451,452
	* SMTP CODE SUCCESS: 500,501,421
	*/
	function Mail($from) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Mail() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"MAIL FROM:" . $from . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "MAIL not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* Noop()
	*
	* Sends the command NOOP to the SMTP server.
	*
	* Implements from rfc 821: NOOP <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE ERROR	: 500, 421
	*/
	function Noop() {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Noop() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"NOOP" . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "NOOP not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* Quit($close_on_error=true)
	*
	* Sends the quit command to the server and then closes the socket
	* if there is no error or the $close_on_error argument is true.
	*
	* Implements from rfc 821: QUIT <CRLF>
	*
	* SMTP CODE SUCCESS: 221
	* SMTP CODE ERROR	: 500
	*/
	function Quit($close_on_error=true) {
		$this->error = null; # so there is no confusion

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Quit() without being connected");
			return false;
		}

		# send the quit command to the server
		fputs($this->smtp_conn,"quit" . $this->CRLF);

		# get any good-bye messages
		$byemsg = $this->get_lines();

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $byemsg;
		}

		$rval = true;
		$e = null;

		$code = substr($byemsg,0,3);
		if($code != 221) {
			# use e as a tmp var cause Close will overwrite $this->error
			$e = array("error" => "SMTP server rejected quit command",
							"smtp_code" => $code,
							"smtp_rply" => substr($byemsg,4));
			$rval = false;
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $e["error"] . ": " .
							$byemsg . $this->CRLF;
			}
		}

		if(empty($e) || $close_on_error) {
			$this->Close();
		}

		return $rval;
	}

	/*
	* Recipient($to)
	*
	* Sends the command RCPT to the SMTP server with the TO: argument of $to.
	* Returns true if the recipient was accepted false if it was rejected.
	*
	* Implements from rfc 821: RCPT <SP> TO:<forward-path> <CRLF>
	*
	* SMTP CODE SUCCESS: 250,251
	* SMTP CODE FAILURE: 550,551,552,553,450,451,452
	* SMTP CODE ERROR	: 500,501,503,421
	*/
	function Recipient($to) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Recipient() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"RCPT TO:" . $to . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250 && $code != 251) {
			$this->error =
				array("error" => "RCPT not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* Reset()
	*
	* Sends the RSET command to abort and transaction that is
	* currently in progress. Returns true if successful false
	* otherwise.
	*
	* Implements rfc 821: RSET <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE ERROR	: 500,501,504,421
	*/
	function Reset() {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Reset() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"RSET" . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "RSET failed",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}

		return true;
	}

	/*
	* Send($from)
	*
	* Starts a mail transaction from the email address specified in
	* $from. Returns true if successful or false otherwise. If True
	* the mail transaction is started and then one or more Recipient
	* commands may be called followed by a Data command. This command
	* will send the message to the users terminal if they are logged
	* in.
	*
	* Implements rfc 821: SEND <SP> FROM:<reverse-path> <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE SUCCESS: 552,451,452
	* SMTP CODE SUCCESS: 500,501,502,421
	*/
	function Send($from) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Send() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"SEND FROM:" . $from . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "SEND not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* SendAndMail($from)
	*
	* Starts a mail transaction from the email address specified in
	* $from. Returns true if successful or false otherwise. If True
	* the mail transaction is started and then one or more Recipient
	* commands may be called followed by a Data command. This command
	* will send the message to the users terminal if they are logged
	* in and send them an email.
	*
	* Implements rfc 821: SAML <SP> FROM:<reverse-path> <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE SUCCESS: 552,451,452
	* SMTP CODE SUCCESS: 500,501,502,421
	*/
	function SendAndMail($from) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
				"error" => "Called SendAndMail() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"SAML FROM:" . $from . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "SAML not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* SendOrMail($from)
	*
	* Starts a mail transaction from the email address specified in
	* $from. Returns true if successful or false otherwise. If True
	* the mail transaction is started and then one or more Recipient
	* commands may be called followed by a Data command. This command
	* will send the message to the users terminal if they are logged
	* in or mail it to them if they are not.
	*
	* Implements rfc 821: SOML <SP> FROM:<reverse-path> <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE SUCCESS: 552,451,452
	* SMTP CODE SUCCESS: 500,501,502,421
	*/
	function SendOrMail($from) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
				"error" => "Called SendOrMail() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"SOML FROM:" . $from . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250) {
			$this->error =
				array("error" => "SOML not accepted from server",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return true;
	}

	/*
	* Turn()
	*
	* This is an optional command for SMTP that this class does not
	* support. This method is here to make the RFC821 Definition
	* complete for this class and __may__ be implimented in the future
	*
	* Implements from rfc 821: TURN <CRLF>
	*
	* SMTP CODE SUCCESS: 250
	* SMTP CODE FAILURE: 502
	* SMTP CODE ERROR	: 500, 503
	*/
	function Turn() {
		$this->error = array("error" => "This method, TURN, of the SMTP ".
										"is not implemented");
		if($this->do_debug >= 1) {
			echo "SMTP -> NOTICE: " . $this->error["error"] . $this->CRLF;
		}
		return false;
	}

	/*
	* Verify($name)
	*
	* Verifies that the name is recognized by the server.
	* Returns false if the name could not be verified otherwise
	* the response from the server is returned.
	*
	* Implements rfc 821: VRFY <SP> <string> <CRLF>
	*
	* SMTP CODE SUCCESS: 250,251
	* SMTP CODE FAILURE: 550,551,553
	* SMTP CODE ERROR	: 500,501,502,421
	*/
	function Verify($name) {
		$this->error = null; # so no confusion is caused

		if(!$this->connected()) {
			$this->error = array(
					"error" => "Called Verify() without being connected");
			return false;
		}

		fputs($this->smtp_conn,"VRFY " . $name . $this->CRLF);

		$rply = $this->get_lines();
		$code = substr($rply,0,3);

		if($this->do_debug >= 2) {
			echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply;
		}

		if($code != 250 && $code != 251) {
			$this->error =
				array("error" => "VRFY failed on name '$name'",
						"smtp_code" => $code,
						"smtp_msg" => substr($rply,4));
			if($this->do_debug >= 1) {
				echo "SMTP -> ERROR: " . $this->error["error"] .
							": " . $rply . $this->CRLF;
			}
			return false;
		}
		return $rply;
	}

	/******************************************************************
		*												INTERNAL FUNCTIONS												*
		******************************************************************/

	/*
	* get_lines()
	*
	* __internal_use_only__: read in as many lines as possible
	* either before eof or socket timeout occurs on the operation.
	* With SMTP we can tell if we have more lines to read if the
	* 4th character is '-' symbol. If it is a space then we don't
	* need to read anything else.
	*/
	function get_lines() {
		$data = "";
		while($str = fgets($this->smtp_conn,515)) {
			if($this->do_debug >= 4) {
				echo "SMTP -> get_lines(): \$data was \"$data\"" .
							$this->CRLF;
				echo "SMTP -> get_lines(): \$str is \"$str\"" .
							$this->CRLF;
			}
			$data .= $str;
			if($this->do_debug >= 4) {
				echo "SMTP -> get_lines(): \$data is \"$data\"" . $this->CRLF;
			}
			# if the 4th character is a space then we are done reading
			# so just break the loop
			if(substr($str,3,1) == " ") { break; }
		}
		return $data;
	}

}


?>