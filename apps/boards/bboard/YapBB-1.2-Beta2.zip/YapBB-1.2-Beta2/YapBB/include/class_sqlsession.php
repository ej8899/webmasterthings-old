<?php
/*							sqlsession

a MySQL based session management and variable registration system
joshua macadam, 2000
josh@onestop.net

Modified by Arno van der Kolk for YapBB, 2001
http://yapbb.sourceforge.net/

Now in class form and dependant on YapBB's MySQL class

*/

class SqlSession
{
	var $MAX_UNAUTH_IDLE = 42300;	//How long may an unauthorized user be idle (just to clean up out session table!)
	var $MAX_AUTH_IDLE = 600;		//If you are logged in, how long for?
	var $DB_T_SESSION;
	var $DB_T_USER_VARS;
	var $sql;
	var $session;
	var $name = "PHPSESSID";
	var $module;
	var $cookie_lifetime = 0;
	var $cookie_path = "";
	var $cookie_domain = "";
	var $started = FALSE;

	function SqlSession($session_table, $user_vars_table)
	{
		$this->sql = new MySQL();
		$this->DB_T_SESSION = $session_table;
		$this->DB_T_USER_VARS = $user_vars_table;
	}

	function s_killold()
	{
		//$debug = 1;

		// figure out who all we're about to delete for being too old!
		$Query = "SELECT vars.id FROM " . $this->DB_T_SESSION . " AS sess, " . $this->DB_T_USER_VARS . " AS vars WHERE sess.id = vars.session AND LastAction < '";
		$Query .= date("Y-m-d H:i:s", (time() - $this->MAX_UNAUTH_IDLE));
		$Query .= "'";

		$res = $this->sql->select($Query);
		$tmp = "";
		if (($c = $this->sql->rows) > 0)
		{
			for ($i = 0; $i < $c; $i++)
				$tmp .= $res[$i][0] . ", ";
	
			$tmp = substr($tmp, 0, -2);
			$this->sql->query("DELETE FROM " . $this->DB_T_USER_VARS . " WHERE id IN ($tmp)");
		}


		// kill IDs after 12 hours for the sake of resources!
		$Query = "DELETE FROM " . $this->DB_T_SESSION . " WHERE LastAction < '";
		$Query .= date("Y-m-d H:i:s", (time() - $this->MAX_UNAUTH_IDLE));
		$Query .= "'";
		$this->sql->query($Query);

		if ($debug) printf("Query=%s.<br>", $Query);

		// log users out if idle for 5 minutes
		// time problems resolved but
		// was noting ocassionally: 5 increments per second?

		$Query = "UPDATE " . $this->DB_T_SESSION . " SET userID = NULL WHERE LastAction < '";
		$Query .= date("Y-m-d H:i:s", (time() - $this->MAX_AUTH_IDLE));
		$Query .= "'";
		$this->sql->query($Query);

		if ($debug) printf("Query=%s.<br>", $Query);
		if ($debug) printf("Current Time=%s.<br>",date("Y-m-d H:i:s"));
	}

	function s_touch($sess)
	{
		//$debug = 1;
		$Query = "UPDATE " . $this->DB_T_SESSION . " SET LastAction = now() WHERE id = '$sess'";
		$this->sql->query($Query);

		if ($debug) printf("Query=%s.<br>", $Query);
	}

	function s_valid_session($sess)
	{
		//$debug = 1;

		$this->s_killold();

		if ($debug) printf("VALID: Recieved session=%s.<br>", $sess);

		if (!$sess)
			return 0;

		$Query = "SELECT * FROM " . $this->DB_T_SESSION . " WHERE id = '$sess'";
		if ($debug) printf("Query=%s.(validsess)<br>", $Query);

		$res = $this->sql->select($Query);
		$status = $res[0];

		return $status;
	}

	function s_get_var($varname)
	{
		//$debug = 1;

		$Query = "SELECT * FROM " . $this->DB_T_USER_VARS . " WHERE session = '" . $this->session . "' AND name = '$varname'";
		if ($debug) printf("Query=%s.(reg var)<br>", $Query);

		$result = $this->sql->select($Query);
		if ($this->sql->rows == 0) return 0;

		if (!$result[0]['intval'])
			return $result[0]['strval'];
		else
			return $result[0]['intval'];
	}

	function s_is_registered($varname)
	{
		// $debug=1;

		$Query = "SELECT * FROM " . $this->DB_T_USER_VARS . " WHERE session = '" . $this->session . "' AND name = '$varname'";
		if ($debug) printf("Query=%s.(is regged)<br>", $Query);

		$this->sql->select($Query);
		return $this->sql->rows;
	}

	function s_register($varname)
	{
		if (!$this->started)
			$this->s_start();
		//$debug = 1;

		$Query = "SELECT name FROM " . $this->DB_T_USER_VARS . " WHERE session = '" . $this->session . "' AND name = '$varname'";
		if ($debug) printf("Query=%s.(is regged)<br>", $Query);
		$this->sql->select($Query);

		$value = $GLOBALS[$varname];
		if (is_int($value))
		{
			$intval = $value;
			$strval = "NULL";
		}
		else
		{
			$intval = "NULL";
			$strval = $value;
		}

		if ($this->sql->rows)
			$Query = "UPDATE " . $this->DB_T_USER_VARS . " SET intval = $intval, strval = '$strval' WHERE session = '" . $this->session . "' AND name = '$varname'";
		else
			$Query = "INSERT INTO " . $this->DB_T_USER_VARS . " values('$varname', '" . $this->session . "', $intval, '$strval', NULL)";

		$this->sql->query($Query);
		if ($debug) printf("Query=%s.(set var)<br>", $Query);

		return true;
	}

	//lookey lookey! persistant DATA!!!!!
	function s_loadvars($session)
	{
		$Query = "SELECT * FROM " . $this->DB_T_USER_VARS . " WHERE session = '$session'";

		global $HTTP_SESSION_VARS;
		if (!is_array($HTTP_SESSION_VARS))
			$HTTP_SESSION_VARS = array();

		$res = $this->sql->select($Query);
		for ($i = 0; $i < $this->sql->rows; $i++)
		{
			if ($res[$i]['intval'])
			{
				$HTTP_SESSION_VARS[$res[$i]['name']] = $res[$i]['intval'];
				$GLOBALS[$res[$i]['name']] = $res[$i]['intval'];
			}
			else
			{
				$HTTP_SESSION_VARS[$res[$i]['name']] = $res[$i]['strval'];
				$GLOBALS[$res[$i]['name']] = $res[$i]['strval'];
			}
		}
	}

	function s_start()
	{
		if ($this->started)
			return false;

		global $HTTP_COOKIE_VARS;
		$this->session = $HTTP_COOKIE_VARS[$this->name];
		//$debug = 1;

		if ($debug) printf("Recieved session=%s<br>", $this->session);

		if (!$this->s_valid_session($this->session))
		{
			$this->session = $this->s_begin_session();
		}
		else
		{
			$this->s_loadvars($this->session);
		}

		define("SID", $this->name . "=" . $this->session);
		$this->s_touch($this->session);
		$this->started = TRUE;

		return true;
	}

	function s_login($userID)
	{
		//$debug = 1;
		$this->s_start();

		$Query= "UPDATE " . $this->DB_T_SESSION . " SET userID = '$userID' WHERE id = '" . $this->session . "'";
		$this->sql->query($Query);

		if ($debug) printf("Query=%s.(s_login)<br>", $Query);
	}

	function s_gencode()
	{
		$session_code_length = 32;	// PHP4's session system uses MD5 hashes, which are 32 bytes long

		$this->s_killold();

		srand(time());

		$Puddle = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		for($index = 0; $index < $session_code_length; $index++){
			$sid .= substr($Puddle, (rand()%(strlen($Puddle))), 1);
		}

		//If by some miracle this id exists, return 0. It will not pass
		//when it is checked next.
		if ($this->s_valid_session($sid)) $sid = 0;

		return $sid;
	}

	function s_begin_session()
	{
		global $REMOTE_ADDR;

		if (empty($REMOTE_ADDR))
			$REMOTE_ADDR = getenv("REMOTE_ADDR");

		//$debug = 1;

		while (!($sesscode = $this->s_gencode()));
		if ($debug) printf("Codemade=%s<br>", $sesscode);

		$Query = "INSERT INTO " . $this->DB_T_SESSION . " VALUES ('$sesscode', now(), '$REMOTE_ADDR', NULL)";

		if ($debug) printf("Query=%s.<br>", $Query);

		$this->sql->query($Query);

		setcookie($this->name, $sesscode, $this->cookie_lifetime, $this->cookie_path, $this->cookie_domain);

		return $sesscode;
	}

	function s_return_var($variable)
	{
		$Query = "SELECT $variable FROM " . $this->DB_T_SESSION . " WHERE id = '" . $this->session . "'";

		if ($debug) printf("Query=%s.<br>", $Query);

		$result = $this->sql->select($Query);
		return $result[0][0];
	}

	//Checks to see if user is logged in and if so returns userID
	//----------------------------------------------------------------------------------
	function s_logged_in()
	{
		$this->s_killold();

		$this->s_start();

		$Query = "SELECT userID FROM " . $this->DB_T_SESSION . " WHERE id = '" . $this->session . "'";

		$result = $this->sql->select($Query);
		return $result[0][0];
	}

	function s_destroy()
	{
		$this->s_unset();
		setcookie($this->name);
		return true;
	}

	function s_unregister($varname)
	{
		$Query = "DELETE FROM " . $this->DB_T_USER_VARS . " WHERE session = '" . $this->session . "' AND name = '$varname'";
		if ($debug) printf("Query=%s.(reg var)<br>", $Query);

		$this->sql->query($Query);

		return true;
	}

	function s_unset()
	{
		$Query = "DELETE FROM " . $this->DB_T_USER_VARS . " WHERE session = '" . $this->session . "'";
		if ($debug) printf("Query=%s.(reg var)<br>", $Query);

		$this->sql->query($Query);

		return true;
	}

	function s_get_cookie_params()
	{
		return array(
			0 => $this->cookie_lifetime,
			1 => $this->cookie_path,
			2 => $this->cookie_domain,
			"lifetime" => $this->cookie_lifetime,
			"path" => $this->cookie_path,
			"domain" => $this->cookie_domain
		);
	}

	function s_set_cookie_params($lifeint, $path, $domain)
	{
		$this->cookie_path = $path;
		$this->cookie_lifetime = $lifeint;
		$this->cookie_domain = $domain;
		return 1;
	}

	function s_encode()
	{
		$Query = "SELECT name, strval, intval FROM " . $this->DB_T_USER_VARS . " WHERE session = '" . $this->session . "'";
		$res = $this->sql->select($Query);

		$text = "";
//		$text .= str_replace(";", "/;", $this->name) . ";";
//		$text .= str_replace(";", "/;", $this->session) . ";";
		for ($k = 0; $k < $this->sql->rows; $k++)
		{
			$text .= str_replace(";", "/;", str_replace("/", "//", $res[$k]['name'])) . ";";
			$text .= str_replace(";", "/;", str_replace("/", "//", $res[$k]['strval'])) . ";";
			$text .= str_replace(";", "/;", str_replace("/", "//", $res[$k]['intval'])) . ";";
		}
		return substr($text, 0, -1);
	}

	function s_decode($data)
	{
		$buffer = $char = $prevChar = "";
		$values = array();
		$escape = $count = 0;
		if ($len = strlen($data))
			$values[0] = " ";

		for ($i = 0; $i < $len; $i++)
		{
			$prevChar = $char;
			$char = substr($data, $i, 1);

			if ($char == "/")
			{
				if ($escape == $i && $escape > 0)
				{
					$values[$count] .= $char;
				}
				else
				{
					$escape = $i + 1;
				}
			}
			else if ($char == ";")
			{
				if ($escape == $i && $escape > 0)
				{
					$values[$count] .= $char;
				}
				else
				{
					$count++;
					$values[$count] .= " ";
				}
			}
			else
			{
				if ($escape == $i && $escape > 0)
				{
					$values[$count] .= $prevChar . $char;
				}
				else
				{
					$values[$count] .= $char;
				}
			}
		}

//		$this->s_destroy();
//		$this->s_name($values[0]);
//		$this->s_id($values[1]);
//		$s = 2;
		$s = 0;

		$count = sizeof($values);
		for ($i = $s; $i < $count; $i += 3)
		{
			$name = substr($values[$i], 1);
			$strval = substr($values[$i + 1], 1);
			$intval = substr($values[$i + 2], 1);

			if ($strval == "NULL")
				$val = (int)$intval;
			else
				$val = (string)$strval;

			$this->s_register($name, $val);
		}

		return TRUE;
	}

	function s_name($name = "\0")
	{
		$tmp = $this->name;
		if ($name != "\0" && trim($name) != "") $this->name = $name;
		return $tmp;
	}

	function s_module_name($module = "\0")
	{
		$tmp = $this->module;
		if ($module != "\0") $this->module = $module;
		return $tmp;
	}

	function s_id($id = "\0")
	{
		$tmp = $this->session;
		if ($id != "\0") $this->session = $id;
		return $tmp;
	}
}
?>