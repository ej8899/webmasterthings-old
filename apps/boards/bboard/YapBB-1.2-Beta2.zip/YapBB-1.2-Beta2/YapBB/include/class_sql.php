<?php   

/*
MySQL Class
by breker@multimedialesdesign.de
http://www.phpsearch.de/   
V1.0 - No newer Versions will be aviable

Modified by Arno van der Kolk
for use in YapBB
http://yapbb.sourceforge.net/
*/   

if (!(							// static 'initializer'
	extension_loaded("mysql")	// on PHP4 this first check will suffice, but on PHP3 (Win32), it might not
	|| function_exists("mysql_pconnect")
	|| function_exists("mysql_select_db")
	|| function_exists("mysql_error")
	|| function_exists("mysql_query")
	|| function_exists("mysql_insert_id")
	|| function_exists("mysql_fetch_array")
	|| function_exists("mysql_free_result")
))
	sendError("No support for MySQL found on this host!");

$sql_conn = FALSE;				// static link to database for some optimization in constructor :)

class MySQL{         

	var $classname = "MySQL";	/* for serialize */
	var $CONNECTION;
	var $DATABASE = "main";
	var $USERNAME = "root";
	var $PASSWORD = "";
	var $SERVER = "127.0.0.1";
	var $rows = 0;				// easy hack to obtain rows of last select query

	function MySQL()
	{
		global $cfgServerUser, $cfgServerPassword, $cfgServerHost, $cfgServerPort, $lang, $cfgDatabase, $sql_conn;

		$user = $this->USERNAME = $cfgServerUser;
		$pass = $this->PASSWORD = $cfgServerPassword;
		$server = $this->SERVER = $cfgServerHost . ($cfgServerPort != "" ? ":" . $cfgServerPort : "");
		$dbase = $this->DATABASE = $cfgDatabase['database'];

		if (!$sql_conn)			// because of the global nature of $sql_conn, this will only be executed once
		{
			if ($sp = @fsockopen($cfgServerHost, !empty($cfgServerPort) ? $cfgServerPort : 3306, $errNo, $errStr, 10))
				fclose($sp);
			else
				die ("<h1>" . $lang['errorNoConnection'] . "</h1><P>Description: '$errStr ($errNo)'<P>\n");

			$sql_conn = mysql_pconnect($server, $user, $pass);
			if(!$sql_conn || !mysql_select_db($dbase, $sql_conn))
				die ("<h1>" . $lang['errorNoConnection'] . "</h1><P>MySQL said: '" . mysql_error() . "'<P>\n");
		}
		$this->CONNECTION = $sql_conn;
	}

	function insert ($sql, $debug = false)
	{
		$this->rows = 0;
		if(empty($sql)) { return false; }
		if(!eregi("^insert",$sql))
		{
			return false;
		}
		if(empty($this->CONNECTION)) return false;
		$conn = $this->CONNECTION;
		if ($debug) echo "$sql<br>\n";
		@$results = mysql_query($sql,$conn)
			or $this->error($sql, mysql_error());
		if(!$results) return false;
		$result = mysql_insert_id();
		return $result;
	}

	function select ($sql, $debug = false)
	{
		if(empty($sql)) return false;
		if(!eregi("^select",$sql))
		{
			return false;
		}
		if(empty($this->CONNECTION)) return false;
		$conn = $this->CONNECTION;
		if ($debug) echo "$sql<br>\n";
		@$results = mysql_query($sql,$conn)
			or $this->error($sql, mysql_error());
		if( (!$results) or (empty($results)) ) return false;
		$c = 0;
		$data = array();
		while ( $row = mysql_fetch_array($results))
		{
			$data[$c] = $row;
			$c++;
		}
		mysql_free_result($results);
		$this->rows = sizeof($data);
		return $data;
	}

	function update($sql, $debug = false)
	{
		$this->rows = 0;
		if(empty($sql)) return false;
		if(!eregi("^update",$sql)) return false;
		if(empty($this->CONNECTION)) return false;
		$conn = $this->CONNECTION;
		if ($debug) echo "$sql<br>\n";
		@$results = mysql_query($sql,$conn)
			or $this->error($sql, mysql_error());
		if(!$results) return false;
		return true;
	}

	function delete($sql, $debug = false)
	{
		$this->rows = 0;
		if(empty($sql)) return false;
		if(!eregi("^delete",$sql)) return false;
		if(empty($this->CONNECTION)) return false;
		$conn = $this->CONNECTION;
		if ($debug) echo "$sql<br>\n";
		@$results = mysql_query($sql,$conn)
			or $this->error($sql, mysql_error());
		if(!$results) return false;
		return true;
	}

	function query($sql, $debug = false)
	{
		$this->rows = 0;
	 	if(empty($sql)) return false;
		if(empty($this->CONNECTION)) return false;
		$conn = $this->CONNECTION;
		if ($debug) echo "$sql<br>\n";
		@$results = mysql_query($sql,$conn)
			or $this->error($sql, mysql_error());
		if(!$results) return false;
		return true;
	}

	function error($sql, $msg)
	{
		global $cfgShowMySQLFalseErrors;
		if (!empty($msg))
			die  ("<P>\n\nInvalid SQL-query:\n\n<P><PRE>$sql</PRE>\n\n<P>MySQL said: '<b>$msg</b>'<P>\n");
		else if ($cfgShowMySQLFalseErrors)
			print("<P>\n\nInvalid SQL-query:\n\n<P><PRE>$sql</PRE>\n\n<P>MySQL reported <b>nothing</b> back!<P>\n");
		else
			;	// false alarm
	}
}        
?>