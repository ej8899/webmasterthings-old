<?php if (!$GLOBALS['includeBit']) exit();

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//=====================================================================================================================
// Warning: It is NOT advised to alter anything in this file!
//=====================================================================================================================

define("YAPBB_HOME_URL", "http://yapbb.sourceforge.net/");			// home page of YapBB
define("YAPBB_VERSION", "1.2-02-Beta 2, 15 July 2001");				// hard coded version of this release (format is: [version-patch-comment])
																		// version is: major.minor
																		// patch is: integer indicating patch number for this version
																		// comment is: free text
define("YAPBB_VERSION_URL", YAPBB_HOME_URL . "yapbb_version.php");	// URL which contains update info


?>