<?php if (!$GLOBALS['includeBit']) exit();

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//
// LIST THE SMILIES HERE
//
// TIP: Make sure the ones with HTML elements (<, >, ", &) in the 'code'
//      are frontmost, and the ones whose code starts with ; are last.
//
// You can select 1 icon that will not be usable IN posts. By specifying
// "" (empty) as key, that icon will still be selectable as identifyer.
// Typically a 'paper' or other kind of 'general indicator' is used.
//

$smilies = array(
	""			=> $cfgSmiliesURL . "posticon.gif",
	"}>"		=> $cfgSmiliesURL . "devil.gif",
	":party:"	=> $cfgSmiliesURL . "party.gif",
	"|("		=> $cfgSmiliesURL . "frown.gif",
	":("		=> $cfgSmiliesURL . "sad.gif",
	":'("		=> $cfgSmiliesURL . "cry.gif",
	":O="		=> $cfgSmiliesURL . "shout.gif",
	":~"		=> $cfgSmiliesURL . "kwijl.gif",
	":r"		=> $cfgSmiliesURL . "pukey.gif",
	":7"		=> $cfgSmiliesURL . "loveit.gif",
	":D"		=> $cfgSmiliesURL . "biggrin.gif",
	":+"		=> $cfgSmiliesURL . "clown.gif",
	":)"		=> $cfgSmiliesURL . "smile.gif",
	":9"		=> $cfgSmiliesURL . "yummie.gif",
	":P"		=> $cfgSmiliesURL . "puh2.gif",
	"8)7"		=> $cfgSmiliesURL . "bonk.gif",
	":o"		=> $cfgSmiliesURL . "redface.gif",
	":*"		=> $cfgSmiliesURL . "puh.gif",
	":?"		=> $cfgSmiliesURL . "confused.gif",
	"8D"		=> $cfgSmiliesURL . "veryhappy.gif",
	":')"		=> $cfgSmiliesURL . "crysmile.gif",
	"}:O"		=> $cfgSmiliesURL . "koe.gif",
	"B)"		=> $cfgSmiliesURL . "coool.gif",
	"|o"		=> $cfgSmiliesURL . "frusty.gif",
	":!)"		=> $cfgSmiliesURL . "idea.gif",
	";)"		=> $cfgSmiliesURL . "wink.gif"
);

/*
$smilies[0][0]	= $cfgSmiliesURL . "posticon.gif";
$smilies[1][0]	= $cfgSmiliesURL . "devil.gif";			// }>
$smilies[2][0]	= $cfgSmiliesURL . "party.gif";			// :party:
$smilies[3][0]	= $cfgSmiliesURL . "frown.gif";			// |(
$smilies[4][0]	= $cfgSmiliesURL . "sad.gif";			// :(
$smilies[5][0]	= $cfgSmiliesURL . "cry.gif";			// :'(
$smilies[6][0]	= $cfgSmiliesURL . "shout.gif";			// :O=
$smilies[7][0]	= $cfgSmiliesURL . "kwijl.gif";			// :~
$smilies[8][0]	= $cfgSmiliesURL . "pukey.gif";			// :r
$smilies[9][0]	= $cfgSmiliesURL . "loveit.gif";		// :7
$smilies[10][0]	= $cfgSmiliesURL . "biggrin.gif";		// :D
$smilies[11][0]	= $cfgSmiliesURL . "clown.gif";			// :+
$smilies[12][0]	= $cfgSmiliesURL . "smile.gif";			// :)
$smilies[13][0]	= $cfgSmiliesURL . "yummie.gif";		// :9
$smilies[14][0]	= $cfgSmiliesURL . "puh2.gif";			// :P
$smilies[15][0]	= $cfgSmiliesURL . "bonk.gif";			// 8)7
$smilies[16][0]	= $cfgSmiliesURL . "wink.gif";			// ;)
$smilies[17][0]	= $cfgSmiliesURL . "redface.gif";		// :o
$smilies[18][0]	= $cfgSmiliesURL . "puh.gif";			// :*
$smilies[19][0]	= $cfgSmiliesURL . "confused.gif";		// :?
$smilies[20][0]	= $cfgSmiliesURL . "veryhappy.gif";		// 8D
$smilies[21][0]	= $cfgSmiliesURL . "crysmile.gif";		// :')
$smilies[22][0]	= $cfgSmiliesURL . "koe.gif";			// }:O
$smilies[23][0]	= $cfgSmiliesURL . "coool.gif";			// B)
$smilies[24][0]	= $cfgSmiliesURL . "frusty.gif";		// |o
$smilies[25][0]	= $cfgSmiliesURL . "idea.gif";			// :!)

// LIST THE KEYCODES FOR THE SMILIES HERE
// LEAVE THE STRING EMPTY TO ONLY BE ABLE TO SELECT IT FOR THE POSTS

$smilies[0][1]	= "";
$smilies[1][1]	= "}>";
$smilies[2][1]	= ":party:";
$smilies[3][1]	= "|(";
$smilies[4][1]	= ":(";
$smilies[5][1]	= ":'(";
$smilies[6][1]	= ":O=";
$smilies[7][1]	= ":~";
$smilies[8][1]	= ":r";
$smilies[9][1]	= ":7";
$smilies[10][1]	= ":D";
$smilies[11][1]	= ":+";
$smilies[12][1]	= ":)";
$smilies[13][1]	= ":9";
$smilies[14][1]	= ":P";
$smilies[15][1]	= "8)7";
$smilies[16][1]	= ";)";
$smilies[17][1]	= ":o";
$smilies[18][1]	= ":*";
$smilies[19][1]	= ":?";
$smilies[20][1]	= "8D";
$smilies[21][1]	= ":')";
$smilies[22][1]	= "}:O";
$smilies[23][1]	= "B)";
$smilies[24][1]	= "|o";
$smilies[25][1]	= ":!)";

//String
function processSmilies($text, $usehtml)							//verwerk hier de smilie codes
{
	$usehtml = 0 + $usehtml;
	global $smilies;
	for ($i = 0; $i < sizeof($smilies); $i++)
	{
		if ($smilies[$i][0] != "" && $smilies[$i][1] != "")
		{
			if ($usehtml) $s = $smilies[$i][1];
			else $s = htmlspecialchars($smilies[$i][1]);
			$text = str_replace($s, '<img src="' . $smilies[$i][0] . '" alt="' . $smilies[$i][1] . '">', $text);
		}
	}
	unset($s);
	unset($i);
	return $text;
}
*/

?>