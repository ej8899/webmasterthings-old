<?php if (!$GLOBALS['includeBit']) exit();

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

if (!isset($cfgAllowHTMLinProfile)) sendError("pe: Configuration not set!");
if (!$cfgAllowHTMLinProfile)
{
/*
			$regUserName = str_replace("<","&lt;",$regUserName);
			$password = str_replace("<","&lt;",$password);
			$regEmail = str_replace("<","&lt;",$regEmail);
			$regHomepage = str_replace("<","&lt;",$regHomepage);
			$regBio = str_replace("<","&lt;",$regBio);
			$regLocation = str_replace("<","&lt;",$regLocation);

			$regUserName = str_replace(">","&gt;",$regUserName);
			$password = str_replace(">","&gt;",$password);
			$regEmail = str_replace(">","&gt;",$regEmail);
			$regHomepage = str_replace(">","&gt;",$regHomepage);
			$regBio = str_replace(">","&gt;",$regBio);
			$regLocation = str_replace(">","&gt;",$regLocation);
*/
			$reg->userName = htmlspecialchars($reg->userName);
			$key = htmlspecialchars($key);
			$reg->userPass1 = htmlspecialchars($reg->userPass1);
			$reg->email = htmlspecialchars($reg->email);
			$reg->homepage = htmlspecialchars($reg->homepage);
			$reg->bio = htmlspecialchars($reg->bio);
			$reg->location = htmlspecialchars($reg->location);
}
			$regICQ = 0 + $regICQ;									//filter strings weg
			$regUserName = trim($reg->userName);						//filter spaties weg
			$key = ROT13(trim($key));
			$regUserPass1 = ROT13(trim($reg->userPass1));
			$regEmail = trim($reg->email);
			$regHomepage = trim($reg->homepage);
			$regBio = trim($reg->bio);
			$regLocation = trim($reg->location);
			$regSignature = trim($reg->signature);
			$regAvatarurl = trim($reg->avatarurl);
?>