<?php if (!$GLOBALS['includeBit']) exit();

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

if (!isset($forumResultRow)) sendError('pe: No check possible! \$forumResultRow not set!');

$clearance = FALSE;
if ($forumResultRow['password'] > 1)
{
//	if (!sess_is_registered("sessionUser") || !sess_is_registered("sessionPass") || !sess_is_registered("sessionUserID") || !sess_is_registered("sessionUserGroup"))
	if (!$templateLoggedIn)
	{
		//eerst inloggen
		echo '
			<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
			<html>
			<head>
			<meta name="MSSmartTagsPreventParsing" content="TRUE">
			<meta http-equiv="Refresh" content="0; URL=' . $cfgBaseURL . 'login.php">
			<meta http-equiv="Pragma" content="no-cache">
			<meta http-equiv="Cache-control" content="no-cache, must-revalidate">
			<title>Error</title>
			</head>
			<body>
			You are not logged in!<br><a href="' . $cfgBaseURL . 'login.php">Please log in first!</a>
			</body>
			</html>
		';
		exit();
	}
	else
	{
		if ($sessionUserGroup >= $forumResultRow['password'])
			$clearance = TRUE;
		else
			;//invalid user clearance!
	}
}
elseif ($forumResultRow['password'] == 1)
	$clearance = TRUE;
else
	sendError("pe: Wrong authorization password value thingie");

if (!$clearance) sendError("No admitance<br><a target='_top' href='" . $cfgBaseURL . "frontpage.php'>Back</a>");
unset($clearance);

?>