<?php
class MySQLquery
{
	// execute a MySQL query
	var $classname = "MySQLquery";	/* for serialize */
	var $query;
	var $rows;
	var $a;

	function MySQLquery(){} //required for PHP3

	function query($query, $debug = 0)
	{
		if ($query == "") return;
		global $cfgDatabase, $cfgShowMySQLFalseErrors;
		$cfgDatabaseDatabase = $cfgDatabase['database'];

		if ($cfgShowMySQLFalseErrors)
		{
			$this->query = @mysql_db_query($cfgDatabaseDatabase, $query)
				or die ("<P>\n\nInvalid SQL-query:\n\n<P><PRE>$query</PRE>\n\n<P>MySQL said: " . mysql_error() . "<P>");
		}
		else
		{
			$error = "";
			$this->query = @mysql_db_query($cfgDatabaseDatabase, $query)
				or $error = mysql_error();
			if ($error != "" && $debug != 2)
				die ("<P>\n\nInvalid SQL-query:\n\n<P><PRE>$query</PRE>\n\n<P>MySQL said: $error<P>");
			unset($error);
		}

		$tok = substr(strtoupper(trim($query)), 0, 6);
		if ($tok == "SELECT")
			$this->rows = mysql_num_rows($this->query);
		else	////voor een ander soort queries?
			$this->rows = 0;

		if ($debug == 1)
			echo "<P>\n\n$query</P><br>\n\n";
		unset($tok);
		unset($error);
	}
}
?>