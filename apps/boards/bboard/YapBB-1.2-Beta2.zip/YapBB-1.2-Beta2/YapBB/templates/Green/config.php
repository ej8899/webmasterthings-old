<?php
	//	THIS CONTROLS THE STYLE SETTING

		$templateDescription		= 'An green-ish alternative to the default template.';
?>
