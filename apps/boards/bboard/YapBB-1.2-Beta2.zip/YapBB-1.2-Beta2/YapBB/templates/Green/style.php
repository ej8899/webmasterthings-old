/*

#
#
# YapBB, a fully functional bulletin board system
# Copyright (C) 2000/01  Arno van der Kolk
# http://yapbb.sourceforge.net/
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
#

*/

/**

<p>
  <a href="http://jigsaw.w3.org/css-validator">
    <img style="border:0;width:88px;height:31px" 
    src="http://jigsaw.w3.org/css-validator/images/vcss.gif" 
    alt="Correct CSS!">
  </a>
</p>

*/

/*=====================================================================================================================*/
/* general (default theme)                                                                                             */
/*=====================================================================================================================*/

Xinput.inp,									/* INPUT FIELDS */
Xselect.inp,
Xtextarea.inp {
	font: 8pt Tahoma;
/*	font-size: 8pt; */
	border-width: 1pt;
	border-color: #000000;
	border-style: solid;
}

input.button {								/* Submit/Reset/Normal buttons */
	font: 8pt Tahoma;
}

.thtcolor {
  COLOR: #FFFFFF;
}
#all A:active {								/* SELECTED LINK COLOR */
  COLOR: #339933;
}
#all A:visited {							/* VISITED LINK COLOR */
  COLOR: #339933;
}
#all A:hover {								/* LINK COLOR with the mouse cursor over it */
  COLOR: #0000ff;
}
#all A:link {								/* NORMAL LINK COLOR */
  COLOR: #339933;
}

#cat A:active {								/* SELECTED LINK COLOR */
  COLOR: #000000;
  text-decoration: none;
}
#cat A:visited {							/* VISITED LINK COLOR */
  COLOR: #000000;
  text-decoration: none;
}
#cat A:hover {								/* LINK COLOR with the mouse cursor over it */
  COLOR: #000000;
  text-decoration: underline;
}
#cat A:link {								/* NORMAL LINK COLOR */
  COLOR: #000000;
  text-decoration: none;
}

tr.alternate1 {								/* ALTERNATING COLOR 1 (light) */
	background-color: #ccFFcc;
}

tr.alternate2 {								/* ALTERNATING COLOR 2 (dark) */
	background-color: #aaFFaa;
}

.header {									/* TABLE HEADER COLOR */
/*	background-color: #327411; */
	background-color: #229922;
	color: #ffffff;
	font: bold 8pt/10pt Verdana, serif;
}

tr.headerLight {							/* TABLE HEADER COLOR (no bold font) */
	background-color: #c0f0c0;
	color: #000000;
	font: 8pt/10pt Verdana, serif;
}

tr.footer {									/* TABLE FOOTER COLOR */
	background-color: #eeFFee;
}

table.bright {								/* Normal tables */
}

table.brightBox {							/* Normal tables with a border */
	border-style: solid;
	border-color: #000000;
	border-width: 1px;/* 2pt 2pt 1pt;*/
	border: 1px solid #000000;
}

table.dark {								/* Tables with dark back */
	background-color: #000000;
	background: #000000;
}

table.darkBox {								/* Tables with dark back and a border */
	background-color: #000000;
	border-style: solid;
	border-color: #000000;
	border-width: 1px;/* 2pt 2pt 1pt;*/
	background-color: #000000;
	background: #000000;
	border: 1px solid #000000;
}

body {										/* General body specification */
	background-color: #ddFFdd;
	font: 10pt/12pt Arial, serif;
/*	font-size: 13pt; */
	color: #000000;
}

span.me {									/* Color for /me tag */
	color: #040fdf;
}

span.you {									/* Color for [you] tag */
	color: #00ff00;
}

.smallFont {								/* SMALL FONT */
	font: 8pt/9pt Verdana, serif;
	/* fontOpen1 */
}

.normalFont, select {						/* NORMAL FONT */
	font: 10pt/12pt Arial, serif;
	/* fontOpen3 */
}

.bigFont {									/* NORMAL FONT BOLD */
	font: bold 10pt/12pt Arial, serif;
	/* fontOpen2 */
}

select.forumhopper {						/* Forum navigation selector */
	background-color: #eeFFee;
	font-family: Verdana, Helvetica;
	font-size: 8pt;
	color: #000000;
	text-decoration: none;
}

select.forumnavigation, 					/* Topic and Post navigation selector */
select.topicnavigation,
select.postnavigation {
/*	background-color: #229922; */
	background-color: #c0f0c0;
	font-family: Verdana, Helvetica;
	font-size: 8pt;
	color: #000000;
	text-decoration: none;
}

select.alternate1 {							/* Topic and Post navigation selector */
	background-color: #ccFFcc;
	font-family: Verdana, Helvetica;
	font-size: 8pt;
	color: #000000;
	text-decoration: none;
}

select.alternate2 {							/* Topic and Post navigation selector */
	background-color: #aaFFaa;
	font-family: Verdana, Helvetica;
	font-size: 8pt;
	color: #000000;
	text-decoration: none;
}

option.category {
}

option.forum {
}

option.seperator {
	text-decoration: line-through;
}

option.empty {
}

img {										/* Standard image definition: remove border (when in hyperlink) */
/*	border-style: transparant; */
	border-width: 0pt;
}

form {
	display: inline;
}


/*=====================================================================================================================*/
/* posts-list only                                                                                                     */
/*=====================================================================================================================*/

tr.quote {									/* SPECIAL QUOTE MARK UP */
	background-color: #bbFFbb;
	font-size: 8pt;
}

tr.code {									/* SPECIAL CODE MARK UP */
	background-color: #b0ffa0;
	font: 8pt/9pt Courier;
}

tr.image {
	background-color: #c0ffc0;				/* SPECIAL PICTURE MARK UP */
	font-size: 8pt;
}

td.buttonbar {								/* BUTTON BAR */
	background-color: #99ff99;
	border-style: solid;
	border-color: #000000;
	border-width: 1pt;
}

span.userNormal {							/* Color of the name of normal users */
	color: black;
	font-weight: bold;
}

span.userMod {								/* Color of the name of moderators */
	color: blue;
	font-weight: bold;
}

span.userAdmin {							/* Color of the name of administrators */
	color: green;
	font-weight: bold;
}

span.userSuper {							/* Color of the name of superusers */
	color: yellow;
	font-weight: bold;
}

img.avatar {
	border-color: #00ff00;					/* THE BORDER AROUND AVATAR IMAGES */
	border-style: solid;
	border-width: 1pt;
	border: 1pt solid #00ff00;
	width: 60px;
	height: 60px;
}

form {
	display: inline;						/* MAKE ALL FORMS INLINE */
}


/*=====================================================================================================================*/
/* forum-list only                                                                                                     */
/*=====================================================================================================================*/

td.alternate1 {
	background-color: #ccFFcc;
}
td.alternate2 {
	background-color: #aaFFaa;
}
