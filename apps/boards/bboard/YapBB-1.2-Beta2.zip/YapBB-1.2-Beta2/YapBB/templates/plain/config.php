<?php
	//	THIS CONTROLS THE STYLE SETTING

		$templateDescription		= 'A template meant for a bare layout, which is useful for printing.';
?>
