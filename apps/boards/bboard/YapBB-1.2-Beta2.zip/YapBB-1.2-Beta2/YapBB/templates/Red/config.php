<?php
	//	THIS CONTROLS THE STYLE SETTING

		$templateDescription		= 'A red-ish alternative to the default template.';
?>
