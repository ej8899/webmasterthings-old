<?php

//=====================================================================================================================
// Configuration section for this template
//=====================================================================================================================
		$cfgEscapeTemplateValues		= false;		// when this is set to true, values are not stripslashed
														// this is useful for javascript-based templates
		$cfgThreadedView				= false;		// when this is set to true, the template files in question
														// should comply to the threaded model, else to the flat model


		$lang = array();
//=====================================================================================================================
// Language section for this template
//=====================================================================================================================
		$lang['day']					= "day";
		$lang['month']					= "month";
		$lang['year']					= "year";
		$lang['you']					= "Guest";
		$lang['errorNoConnection']		= "Can't connect to MySQL database<br>\n";
		$lang['next']					= "Next";
		$lang['previous']				= "Previous";
		$lang['navigation']				= "Navigation";
		$lang['threads']				= "threads";
		$lang['pages']					= "pages";
		$lang['page']					= "page";
		$lang['hasMore']				= "has more";
		$lang['thisTopic']				= "This topic has";
		$lang['thisForum']				= "This forum has";
		$lang['index']					= "Index";
		$lang['none']					= "none";
		$lang['unmoderated']			= "Unmoderated";
		$lang['by']						= "by";
		$lang['new']					= "new";
		$lang['posts']					= "posts";
		$lang['topicLocked']			= "This topic is locked";
		$lang['lastPost']				= "Last Post";
		$lang['on']						= "on";
		$lang['edited']					= "Edited";
		$lang['edit']					= "Edit";
		$lang['delete']					= "Delete";
		$lang['reply']					= "Reply";
		$lang['bottom']					= "Bottom";
		$lang['top']					= "Top";
		$lang['closed']					= "closed";
		$lang['open']					= "open";
		$lang['closedNew']				= "new - closed";
		$lang['openNew']				= "new - open";
		$lang['displayForums']			= "Display forums";
		$lang['restricted']				= "Admins and mods only";
		$lang['postTopic']				= "Post a new topic";
		$lang['editMessage']			= "Edit a message";
		$lang['postMessage']			= "Post new message";
		$lang['wrote']					= "wrote";
		$lang['ban']					= "You have been banned from this board. Contact the administrator ($cfgEmail) if you believe this to be in error.";
		$lang['errorLogin']				= "Invalid user/password combination!";
		$lang['loginActivate']			= "This account is not yet activated. You must specify the activation code.";
		$lang['errorEdit']				= "You are not allowed to edit/delete the message!";
		$lang['editLocked']				= "Topic is locked. No further editing is allowed.";
		$lang['msgDeleted']				= "This message has been deleted";
		$lang['msgDeleteRest']			= "along with the rest of the topic";
		$lang['errorNoText']			= "No text was specified.";
		$lang['errorLinkPost']			= "error: Post was inserted, but could not be linked to a topic";
		$lang['errorNoTitle']			= "No topic title was specified.";
		$lang['errorLinkTopic']			= "error: Topic was inserted, but could not be linked to a post.";
		$lang['thanksMessage']			= "Thank you for your message";
		$lang['returnForum']			= "we are now returning you to the forum";
		$lang['clickNoWait']			= "Click here if you don't want to wait anylonger";
		$lang['errorLoginName']			= "Invalid login name";
		$lang['errorLoginNameTooShort']	= "Login name too short - min $cfgMinLengthNickname characters";
		$lang['errorLoginNameTooLong']	= "Login name too long - max $cfgMaxLengthNickname characters";
		$lang['errorUserExists']		= "That user already exists";
		$lang['errorEmailAddress']		= "Invalid e-mail address";
		$lang['errorEmailExists']		= "That e-mail address has already been used";
		$lang['errorPassword']			= "Invalid password";
		$lang['errorPasswordMatch']		= "Passwords do not match";
		$lang['errorPasswordTooShort']	= "Password too short - min $cfgMinLengthPassword characters";
		$lang['errorPasswordTooLong']	= "Password too long - max $cfgMaxLengthPassword characters";
		$lang['errorRegMail']			= "Registration e-mail could not be sent.";
		$lang['errorNoNameChange']		= "You are not allowed to change nickname";
		$lang['errorEmailDomain']		= "We currently do not accept e-mail addresses from this domain";
		$lang['errorNoGuestEdit']		= "Anonymous users are not allowed to edit posts";
		$lang['errorNoGuestPost']		= "You can't post anonymously";
		$lang['locationFAQ']			= "Frequently Asked Questions";
		$lang['locationSettings']		= "Personal Settings";
		$lang['locationPubProfile']		= "Public Profile";
		$lang['locationPrivProfile']	= "Personal Profile";
		$lang['locationRegister']		= "Register";
		$lang['locationWhosOnline']		= "Visitors";
		$lang['locationWhosRegistered']	= "Members";
		$lang['locationControlPanel']	= "Control Panel";
		$lang['guest']					= "Visitor";
		$lang['default']				= "default";
		$lang['quote']					= "quote";
		$lang['code']					= "code";
		$lang['boardadmin']				= "Board admin";
		$lang['all']					= "all";
		$lang['nicknames']				= "All nicknames beginning with ";


//=====================================================================================================================
// Ranking Descriptions - It is NOT a good idea to add new entries to this array!
//=====================================================================================================================

		$cfgStrOperator[0]				= "Normal user";		// Normal user
		$cfgStrOperator[1]				= "Moderator";			// May move/lock topics in his forum
		$cfgStrOperator[2]				= "Global Moderator";	// May move/lock any topic, appoint new moderators, ban users
		$cfgStrOperator[3]				= "Administrator";		// Everything ;) (including altering database structure)


//=====================================================================================================================
// Antiquated (yes, obsolete)
//=====================================================================================================================
///		$templateColor1					= '#ccccFF';
///		$templateColor2					= '#aaaaFF';
///		$templateNormalFont				= '<FONT FACE="arial, helvetica" SIZE="2">';
///		$templateSmallFont				= '<FONT SIZE="1" FACE="verdana,arial,helvetica">';
///		$templateBackColor				= '#FFFFFF';
///		$templateTextColor				= '#000000';

///		$cfgColor3						= '#eeeeFF';
///		$cfgColor4						= '#113274';
///		$cfgLinkColor					= '#333399';
///		$cfgVisitedLinkColor			= '#333399';
///		$cfgHoverLinkColor				= '#ff0000';
///		$cfgActiveLinkColor				= '#333399';
///		$cfgUserColorSuper				= 'yellow';
///		$cfgUserColorAdmin				= 'green';
///		$cfgUserColorMod				= 'blue';
///		$cfgUserColorNormal				= 'black';
///		$cfgTableBackColor				= $cfgBackColor;		// The background of most tables (comment this line to make all tables transparant)
///		$cfgTableInverseBackColor		= "#000000";			// Alternative background (comment this line to automatically calculate the inverse of $cfgTableBackColor)
///		$cfgFontMeColor					= '#df040f';
///		$fontOpen1						= '<FONT SIZE="1" FACE="verdana,arial,helvetica" xCOLOR="#FFFFFF">';	//SMALLEST WHITE FONT
///		$fontOpen2						= '<FONT FACE="arial, helvetica" SIZE="2">';						//NORMAL FONT
///		$fontOpen3						= '<FONT SIZE="1" FACE="verdana,arial,helvetica">';					//SMALLEST FONT
///		$fontOpen4						= $fontOpen2;//'<FONT SIZE="-1" FACE="arial, helvetica">';						//SMALLER FONT

///		$template->register($templateHandler, array("templateColor1", "templateColor2"));


//=====================================================================================================================
// Information on this template
//=====================================================================================================================
		$templateDescription			= 'A basic template with all functionality, originally more or less inspired by vBulletin.';
?>
