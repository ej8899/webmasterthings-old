<?php require("./config.inc.php");

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//=====================================================================================================================
// Description: page redirector
//=====================================================================================================================


//=====================================================================================================================
// Choose action
//=====================================================================================================================
if ($action == "next" || $action == "prev")
{

//=====================================================================================================================
// Action-branch: Navigate
//=====================================================================================================================
	$topicQuery = new MySQL;
	$topRes = $topicQuery->select("SELECT t.id FROM " . $cfgDatabase['post'] . " AS p, " . $cfgDatabase['topic'] . " AS t WHERE t.forumid = $forumID AND t.lastpostid = p.id ORDER BY p.date DESC");
	for ($teller = 0; $teller < $topicQuery->rows; $teller++)
	{
		if ($topRes[$teller]['id'] == $topicID)
		{
			$teller++;
			break;
		}
	}
	$teller--;

//	if ($topRes[$teller]['id'] != $topicID) $teller--;
	$error = FALSE;
	if ($action == "next")
	{
		$teller--;
		$error = ($teller < 0);
//		@mysql_data_seek($topicQuery->query, $teller - 1)
//			or $error = TRUE;
	}
	else //if ($action == "prev")
	{
		$teller++;
		$error = ($teller >= $topicQuery->rows);
//		@mysql_data_seek($topicQuery->query, $teller + 1)
//			or $error = TRUE;
	}

	if ($error)
	{
		$url = "forumDisplay.php?forumID=$forumID";
	}
	else
	{
		$url = "topicDisplay.php?topicID=" . $topRes[$teller]['id'];
	}
}
elseif ($action == "Hop")

//=====================================================================================================================
// Action-branch: Hop to forum
//=====================================================================================================================
	$url = "forumDisplay.php?forumID=$forumID";
else

//=====================================================================================================================
// Do nothing
//=====================================================================================================================
	$url = "";

header("Location: " . $cfgBaseURL . $url);

/*
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
<meta name="MSSmartTagsPreventParsing" content="TRUE">
<LINK HREF="<?=$cfgBaseURL?>style.php" rel="styleSheet" TYPE="text/css">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta http-equiv="refresh" content="0; URL=<?=$cfgBaseURL?><?=$url?>">
</head>
<body bgcolor="<?=$cfgBackColor?>" text="<?=$cfgTextColor?>" id=all>
<a href="<?=$cfgBaseURL?><?=$url?>">Redirecting...</a>
</body>
</html>
*/

require($cfgIncludeDirectory . "cleanup.php");
?>
