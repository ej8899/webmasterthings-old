<?php require("./config.inc.php");

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//=====================================================================================================================
// Description: page to mail passwords to users
//=====================================================================================================================

echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
' . $pageOptions . '
<meta name="MSSmartTagsPreventParsing" content="TRUE">
<META HTTP-EQUIV="Content-Script-Type" CONTENT="text/javascript">
<title>' . $cfgForumTitle . ' - Mail password</title>
<LINK HREF="' . $cfgBaseURL . 'style.php" rel="styleSheet" TYPE="text/css">
<LINK REL="SHORTCUT ICON" HREF="' . $cfgBaseURL . 'favicon.ico">
</head>
<body id="all">
';

if (!isset($HTTP_POST_VARS['mail'])) {

//=====================================================================================================================
// Show form
//=====================================================================================================================

	echo '
	<form name="passMailer" method="post" action="' . $cfgBaseURL . 'mailPassword.php">
	Your e-mail address: <input type="text" name="email"><br>
	Your username: <input type="text" name="username"> (case sensitive)<br>
	<input type="submit" name="mail" value="Go">
	</form>
	';

}
else
{

//=====================================================================================================================
// Process form
//=====================================================================================================================
	$email = strtolower($email);
	$userQuery = new MySQL;
	$usrRes = $userQuery->select("SELECT activationkey, password, nickname FROM " . $cfgDatabase['user'] . " WHERE email = '" . addslashes($email) . "' AND nickname = '" . addslashes($username) . "'");
	if ($userQuery->rows != 1)
	{
		sendError("No user is known with the specified name and e-mail address");
	}
	else
	{
		$usrRes[0]['nickname'] = stripslashes($usrRes[0]['nickname']);
		$usrRes[0]['password'] = stripslashes($usrRes[0]['password']);
		$usrRes[0]['activationkey'] = stripslashes($usrRes[0]['activationkey']);
		if ($usrRes[0]['nickname'] != $username)
			sendError("No user is known with the specified name and e-mail.");

		if (sendRegMail($username, $email, ROT13($usrRes[0]['password']), $usrRes[0]['activationkey']))
			print("<h1>E-mail has been sent</h1>");
		else
			print("<h1>Error sending e-mail!</h1>");
		echo "<a href='" . $cfgBaseURL . "frontpage.php'>Back</a>";
	}
}

echo '
</body>
</html>
';

require($cfgIncludeDirectory . "cleanup.php");
?>
