<?php require("./config.inc.php");

/*

YapBB, a fully functional bulletin board system
Copyright (C) 2000/01  Arno van der Kolk
http://yapbb.sourceforge.net/

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

function _sendMail($to, $subj, $msg)
{
	global $sessionUser, $sessionUserID;
	return sendMail($to, $sub, $msg, $sessionUserID, $sessionUser);
}

$acceptEmail = true;
if ($templateLoggedIn)												// you have to be logged in
{
	$query = new MySQL();
	if (!empty($userID) && $userID > 0)								// show mail-user page
	{
		$res = $query->select("SELECT showemail, email, nickname FROM " . $cfgDatabase['user'] . " WHERE id = $userID");
		if (count($res) != 1)
			sendError("ue: Invalid user id");
		else
		{
			if ($res[0]['showemail'])
			{
				if ($submitted = (!empty($HTTP_POST_VARS['message']) && !empty($HTTP_POST_VARS['userID'])))
				{
					// send e-mail
					$success = _sendMail(stripslashes($res[0]['email']), "", stripslashes($HTTP_POST_VARS['message']));
				}
				else
				{
					$USERNAME = htmlspecialchars(stripslashes($res[0]['nickname']));
					$USERID = $userID;
					$template->register($templateHandler, "USERNAME, USERID");
					// show input form
				}
			}
			else
				$acceptEmail = false;
		}
	}
	else if (!empty($topicID) && $topicID > 0)						// show mail a friend page
	{
		$res = $query->select("SELECT description FROM " . $cfgDatabase['topic'] . " WHERE id = $topicID");
		if (count($res) != 1)
			sendError("ue: Invalid topic id");
		else
		{
			if ($submitted = (!empty($HTTP_POST_VARS['email']) && !empty($HTTP_POST_VARS['message'])))
			{
				// send e-mail
				if (empty($HTTP_POST_VARS['pmessage']))
					$HTTP_POST_VARS['pmessage'] = $lang['none'];
				$success = _sendMail(stripslashes($HTTP_POST_VARS['email']), "", stripslashes($HTTP_POST_VARS['message'] . "\n" . $HTTP_POST_VARS['pmessage']));
			}
			else
			{
				$FULLURL = getFullForumURL() . "topicDisplay.php?topicID=$topicID";
				$TOPICID = $topicID;
				$template->register($templateHandler, "TOPIC, FULLURL, TOPICID");
				$TOPIC = htmlspecialchars(stripslashes($res[0]['description']));
				// show input form
			}
		}
	}
	else															// show list of moderators/admins/etc page
	{
		if ($submitted = (!empty($HTTP_POST_VARS['email']) && !empty($HTTP_POST_VARS['message'])))
		{
			// send e-mail
			$success = _sendMail(stripslashes($HTTP_POST_VARS['email']), "", stripslashes($HTTP_POST_VARS['message']));
		}
		else
		{
			$res = $query->select("SELECT id, groupid, nickname FROM " . $cfgDatabase['user'] . " WHERE groupid > 1");
			$crew = array();
			$crew[] = array("ID" => "0", "NAME" => $lang['boardadmin'] . " ($cfgEmail)");
			for ($i = 0; $i < $query->rows; $i++)
				$crew[] = array(
					"ID" => $res[$i]['id'],
					"NAME" => htmlspecialchars(stripslashes($res[$i]['nickname'])) .  " (" . $cfgStrOperator[$res[$i]['groupid'] - 1] .  ")"
				);

			// show input form
		}
	}
}

if (!$template->load_file($templateHandler, "$cfgTemplateDirectory$cookieTemplateName/mail.ybt"))
	if (!$template->load_file($templateHandler, $cfgTemplateDirectory . "Default/mail.ybt"))
		sendError("pe: Could not load template (mail.ybt)!");

if (is_array($crew))
	$template->parse_loop($templateHandler, "crew");

echo $template->pget($templateHandler);

require($cfgIncludeDirectory . "cleanup.php");
?>
